# Estado da Observação - Guia de Implementação do Sumário de Alta (SA) da RNDS v1.0.0

## ValueSet: Estado da Observação 

 **References** 

* [Observação Descritiva](StructureDefinition-BRObservacaoDescritiva-1.0.md)

### Definição lógica (CLD)

 

### Expansão

-------

 [Descrição do(s) quadro(s) acima](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "BREstadoObservacao-1.0",
  "language" : "en",
  "url" : "http://www.saude.gov.br/fhir/r4/ValueSet/BREstadoObservacao-1.0",
  "version" : "1.0.0",
  "name" : "BREstadoObservacao",
  "title" : "Estado da Observação",
  "status" : "active",
  "experimental" : false,
  "date" : "2020-03-12T13:09:42.3921631+00:00",
  "publisher" : "Ministério da Saúde do Brasil",
  "contact" : [{
    "name" : "Ministério da Saúde do Brasil",
    "telecom" : [{
      "system" : "url",
      "value" : "http://www.saude.gov.br"
    },
    {
      "system" : "email",
      "value" : "cgiis.datasus@saude.gov.br"
    }]
  }],
  "description" : "Tipos de estados de uma observação.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "BR"
    }]
  }],
  "immutable" : false,
  "compose" : {
    "include" : [{
      "system" : "http://hl7.org/fhir/observation-status",
      "concept" : [{
        "code" : "final",
        "display" : "Final",
        "designation" : [{
          "language" : "pt-BR",
          "value" : "Concluída"
        }]
      },
      {
        "code" : "entered-in-error",
        "display" : "Entered in Error",
        "designation" : [{
          "language" : "pt-BR",
          "value" : "Cancelada por informação errada"
        }]
      }]
    }]
  }
}

```
