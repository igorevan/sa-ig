# Reações Adversas da MedDRA - Guia de Implementação do Sumário de Alta (SA) da RNDS v1.0.0

## ValueSet: Reações Adversas da MedDRA 

 **References** 

* [Alergia ou Reação Adversa](StructureDefinition-BRAlergiaReacaoAdversa-1.0.md)

### Definição lógica (CLD)

 

### Expansão

-------

 [Descrição do(s) quadro(s) acima](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "BRReacoesAdversasMedDRA-1.0",
  "meta" : {
    "versionId" : "1",
    "lastUpdated" : "2020-09-20T20:38:38.152+00:00"
  },
  "language" : "pt-BR",
  "url" : "http://www.saude.gov.br/fhir/r4/ValueSet/BRReacoesAdversasMedDRA-1.0",
  "version" : "1.0.0",
  "name" : "BRReacoesAdversasMedDRA",
  "title" : "Reações Adversas da MedDRA",
  "status" : "active",
  "experimental" : false,
  "date" : "2020-09-20T20:38:38.026206+00:00",
  "publisher" : "Ministério da Saúde do Brasil",
  "contact" : [{
    "name" : "Ministério da Saúde do Brasil",
    "telecom" : [{
      "system" : "url",
      "value" : "http://www.saude.gov.br"
    },
    {
      "system" : "email",
      "value" : "cgiis.datasus@saude.gov.br"
    }]
  }],
  "description" : "Classifica as reações adversas de acordo com o Medical Dictionary for Regulatory Activities.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "BR"
    }]
  }],
  "immutable" : false,
  "compose" : {
    "include" : [{
      "system" : "http://www.saude.gov.br/fhir/r4/CodeSystem/BRMedDRA"
    }]
  }
}

```
