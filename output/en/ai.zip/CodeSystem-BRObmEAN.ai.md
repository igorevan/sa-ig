# Terminologia de Produto Medicinal Virtual (VMP) na GS1.org - Guia de Implementação do Sumário de Alta (SA) da RNDS v1.0.0-release

## CodeSystem: Terminologia de Produto Medicinal Virtual (VMP) na GS1.org 

This Code system is referenced in the definition of the following value sets:

* [Terminologia dos medicamentos](ValueSet-BRTerminologiaMedicamento.md)

-------

 [Description of the above table(s)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "BRObmEAN",
  "meta" : {
    "lastUpdated" : "2022-04-06T12:48:11.6743763+03:00"
  },
  "language" : "pt-BR",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-wg",
    "valueCode" : "ehr"
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-fmm",
    "valueInteger" : 1,
    "_valueInteger" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "https://fhir.saude.gov.br/sa/ImplementationGuide/br.gov.saude.sa.fhir"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
    "valueCode" : "normative",
    "_valueCode" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "https://fhir.saude.gov.br/sa/ImplementationGuide/br.gov.saude.sa.fhir"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-normative-version",
    "valueCode" : "4.0.1"
  }],
  "url" : "http://www.saude.gov.br/fhir/r4/CodeSystem/BRObmEAN",
  "version" : "1.0.0-release",
  "name" : "BRObmEAN",
  "title" : "Terminologia de Produto Medicinal Virtual (VMP) na GS1.org",
  "status" : "active",
  "experimental" : false,
  "date" : "2022-04-06T12:48:11.6743763+03:00",
  "publisher" : "Ministério da Saúde do Brasil",
  "contact" : [{
    "name" : "Ministério da Saúde do Brasil",
    "telecom" : [{
      "system" : "url",
      "value" : "http://www.saude.gov.br"
    },
    {
      "system" : "email",
      "value" : "cgiis.datasus@saude.gov.br"
    }]
  }],
  "description" : "Apresenta o Produto Medicinal Virtual (VMP) e seu Número Europeu do Artigo (EAN) na GS1.org",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "BR"
    }]
  }],
  "caseSensitive" : true,
  "content" : "complete",
  "concept" : [{
    "code" : "7896241221853",
    "display" : "Ablok 25 mg comprimido (Biolab Sanus Farmacêutica Ltda) x 30 comprimidos"
  },
  {
    "code" : "7896112411451",
    "display" : "Ablok 25 mg comprimido (Biolab Sanus Farmacêutica Ltda) x 60 comprimidos"
  },
  {
    "code" : "7896112419785",
    "display" : "Ablok 25 mg comprimido (Biolab Sanus Farmacêutica Ltda) x 90 comprimidos"
  },
  {
    "code" : "7896112147640",
    "display" : "Aerodini 100 microgramas/dose suspensão aerossol (Laboratório Teuto Brasileiro S/A) x 200 doses"
  },
  {
    "code" : "7896112157380",
    "display" : "Aerodivent 0,25 mg/mL solução para inalação 20 mL; frasco (Laboratório Teuto Brasileiro S/A) x 1 frasco"
  },
  {
    "code" : "7898014561333",
    "display" : "Aerofrin 100 microgramas/dose suspensão aerossol; inalador (Pharmascience Indústria Farmacêutica S.A.) x 200 doses"
  },
  {
    "code" : "7897473201071",
    "display" : "Aerogold 100 microgramas/dose suspensão aerossol; inalador (Glenmark Farmacêutica Ltda) x 200 doses"
  },
  {
    "code" : "7896269900150",
    "display" : "Aerolin 100 microgramas/dose suspensão aerossol; inalador (Glaxosmithkline Brasil Ltda) x 200 doses"
  },
  {
    "code" : "7896269900068",
    "display" : "Aerolin 5 mg/mL solução para inalação 10 mL; frasco (Glaxosmithkline Brasil Ltda) x 1 frasco"
  },
  {
    "code" : "7898040320621",
    "display" : "Alendil 70 mg comprimido (Farmoquímica S/A) x 4 comprimidos"
  },
  {
    "code" : "7898075317894",
    "display" : "Alendronato de Sódio 70 mg comprimido (1Farma Indústria Química Farmacêutica LTDA) x 4 comprimidos"
  },
  {
    "code" : "7896181920038",
    "display" : "Alendronato de Sódio 70 mg comprimido (Aché Laboratórios Farmacêuticos S.A) x 4 comprimidos"
  },
  {
    "code" : "7896714231204",
    "display" : "Alendronato de Sódio 70 mg comprimido (Brainfarma Indústria Química e Farmacêutica S.A) x 4 comprimidos"
  },
  {
    "code" : "7893454101644",
    "display" : "Alendronato de Sódio 70 mg comprimido (Cellera Farmacêutica S.A) x 4 comprimidos"
  },
  {
    "code" : "7896004715353",
    "display" : "Alendronato de Sódio 70 mg comprimido (Germed Farmacêutica Ltda) x 4 comprimidos"
  },
  {
    "code" : "7896112162322",
    "display" : "Alendronato de Sódio 70 mg comprimido (Laboratório Teuto Brasileiro S/A) x 4 comprimidos"
  },
  {
    "code" : "7894916143424",
    "display" : "Alendronato de Sódio 70 mg comprimido (Legrand Pharma Indústria Farmacêutica Ltda) x 4 comprimidos"
  },
  {
    "code" : "7895296420020",
    "display" : "Alendronato de Sódio 70 mg comprimido (Nova Química Farmacêutica S.A.) x 4 comprimidos"
  },
  {
    "code" : "7897595637574",
    "display" : "Alendronato de Sódio 70 mg comprimido (Novartis Biociências S.A.) x 4 comprimidos"
  },
  {
    "code" : "7897595610089",
    "display" : "Alendronato de Sódio 70 mg comprimido (Sandoz Do Brasil Indústria Farmacêutica Ltda) x 4 comprimidos"
  },
  {
    "code" : "7896006216476",
    "display" : "Alendronato de Sódio 70 mg comprimido (União Química Farmacêutica Nacional S.A.) x 4 comprimidos"
  },
  {
    "code" : "7896523227252",
    "display" : "Alendronato Sódico 70 mg comprimido (Cimed Indústria de Medicamentos LTDA) x 4 comprimidos"
  },
  {
    "code" : "7896004715308",
    "display" : "Alendronato Sódico 70 mg comprimido (EMS S/A) x 2 comprimidos"
  },
  {
    "code" : "7896004715322",
    "display" : "Alendronato Sódico 70 mg comprimido (EMS S/A) x 4 comprimidos"
  },
  {
    "code" : "7891317001476",
    "display" : "Alendronato Sódico 70 mg comprimido (Eurofarma Laboratórios S.A.) x 4 comprimidos"
  },
  {
    "code" : "7898049790531",
    "display" : "Amprax 40 mg comprimido (Vitamedic Indústria Farmacêutica Ltda) x 30 comprimidos"
  },
  {
    "code" : "7898096578229",
    "display" : "Angiopril 10 mg comprimido (Diffucap - Chemobrás Química e Farmacêutica Ltda) x 30 comprimidos"
  },
  {
    "code" : "7896181901723",
    "display" : "Angipress 25 mg comprimido (Aché Laboratórios Farmacêuticos S.A.) x 28 comprimidos"
  },
  {
    "code" : "7896181916222",
    "display" : "Angipress 25 mg comprimido (Aché Laboratórios Farmacêuticos S.A.) x 30 comprimidos"
  },
  {
    "code" : "7896202520513",
    "display" : "Aortt 25 mg comprimido (LABORATÓRIO FARMACÊUTICO VITAMED LTDA) x 30 comprimidos"
  },
  {
    "code" : "7896112486787",
    "display" : "Aradois 50 mg comprimido (Biolab Sanus Farmacêutica Ltda) x 30 comprimidos"
  },
  {
    "code" : "7896112486886",
    "display" : "Aradois 50 mg comprimido (Biolab Sanus Farmacêutica Ltda) x 60 comprimidos"
  },
  {
    "code" : "7899095204829",
    "display" : "Arartan 50 mg comprimido (Geolab Indústria Farmacêutica S/A) x 30 comprimidos"
  },
  {
    "code" : "7896714233376",
    "display" : "Ateneum 25 mg comprimido (Brainfarma Indústria Química e Farmacêutica S.A) x 30 comprimidos"
  },
  {
    "code" : "7897851220168",
    "display" : "Atenobal 25 mg comprimido (Laboratórios Baldacci Ltda) x 30 comprimidos (3 blisters x 10)"
  },
  {
    "code" : "7896206407612",
    "display" : "Atenol 25 mg comprimido (Astrazeneca do Brasil Ltda) x 30 comprimidos"
  },
  {
    "code" : "7896472513130",
    "display" : "Atenolab 25 mg comprimido (Multilab Indústria e Comércio de Produtos Farmacêuticos Ltda) x 30 comprimidos"
  },
  {
    "code" : "7896472519828",
    "display" : "Atenolab 25 mg comprimido (Multilab Indústria e Comércio de Produtos Farmacêuticos Ltda) x 60 comprimidos"
  },
  {
    "code" : "7898075314954",
    "display" : "Atenolol 25 mg comprimido (1Farma Indústria Farmacêutica Ltda) x 30 comprimidos"
  },
  {
    "code" : "7896112401452",
    "display" : "Atenolol 25 mg comprimido (Biolab Sanus Farmacêutica Ltda) x 30 comprimidos"
  },
  {
    "code" : "7896181900122",
    "display" : "Atenolol 25 mg comprimido (Biosintética Farmacêutica Ltda) x 30 comprimidos"
  },
  {
    "code" : "7896714262031",
    "display" : "Atenolol 25 mg comprimido (Brainfarma Indústria Química e Farmacêutica S.A) x 30 comprimidos"
  },
  {
    "code" : "7896523212920",
    "display" : "Atenolol 25 mg comprimido (Cimed Indústria de Medicamentos Ltda) x 30 comprimidos"
  },
  {
    "code" : "7896004767611",
    "display" : "Atenolol 25 mg comprimido (EMS S/A) x 30 comprimidos"
  },
  {
    "code" : "7896004705781",
    "display" : "Atenolol 25 mg comprimido (EMS S/A) x 30 comprimidos"
  },
  {
    "code" : "7896004705880",
    "display" : "Atenolol 25 mg comprimido (EMS S/A) x 60 comprimidos"
  },
  {
    "code" : "7896004767628",
    "display" : "Atenolol 25 mg comprimido (EMS S/A) x 60 comprimidos"
  },
  {
    "code" : "7899095246232",
    "display" : "Atenolol 25 mg comprimido (Geolab Indústria Farmacêutica S/A) x 14 comprimidos"
  },
  {
    "code" : "7899095245853",
    "display" : "Atenolol 25 mg comprimido (Geolab Indústria Farmacêutica S/A) x 14 comprimidos"
  },
  {
    "code" : "7899095246201",
    "display" : "Atenolol 25 mg comprimido (Geolab Indústria Farmacêutica S/A) x 28 comprimidos"
  },
  {
    "code" : "7899095285828",
    "display" : "Atenolol 25 mg comprimido (Geolab Indústria Farmacêutica S/A) x 28 comprimidos"
  },
  {
    "code" : "7899095246195",
    "display" : "Atenolol 25 mg comprimido (Geolab Indústria Farmacêutica S/A) x 30 comprimidos"
  },
  {
    "code" : "7899095245815",
    "display" : "Atenolol 25 mg comprimido (Geolab Indústria Farmacêutica S/A) x 30 comprimidos"
  },
  {
    "code" : "7896004709024",
    "display" : "Atenolol 25 mg comprimido (Germed Farmacêutica Ltda) x 30 comprimidos"
  },
  {
    "code" : "7894916144209",
    "display" : "Atenolol 25 mg comprimido (Legrand Pharma Indústria Farmacêutica Ltda) x 30 comprimidos"
  },
  {
    "code" : "7896472513338",
    "display" : "Atenolol 25 mg comprimido (Multilab Indústria e Comércio de Produtos Farmacêuticos Ltda) x 30 comprimidos"
  },
  {
    "code" : "7896472519774",
    "display" : "Atenolol 25 mg comprimido (Multilab Indústria e Comércio de Produtos Farmacêuticos Ltda) x 60 comprimidos"
  },
  {
    "code" : "7895296299022",
    "display" : "Atenolol 25 mg comprimido (Nova Química Farmacêutica S/A) x 30 comprimidos"
  },
  {
    "code" : "7895296444019",
    "display" : "Atenolol 25 mg comprimido (Nova Química Farmacêutica S/A) x 30 comprimidos"
  },
  {
    "code" : "7898148290772",
    "display" : "Atenolol 25 mg comprimido (Prati Donaduzzi & Cia Ltda) x 30 comprimidos"
  },
  {
    "code" : "7897595602572",
    "display" : "Atenolol 25 mg comprimido (Sandoz do Brasil Indústria Farmacêutica Ltda) x 30 comprimidos"
  },
  {
    "code" : "7897595605412",
    "display" : "Atenolol 25 mg comprimido (Sandoz do Brasil Indústria Farmacêutica Ltda) x 60 comprimidos"
  },
  {
    "code" : "7896422506342",
    "display" : "Atenolol 25 mg comprimido (Sanofi Medley Farmacêutica Ltda) x 30 comprimidos"
  },
  {
    "code" : "7898049792979",
    "display" : "Atenolol 25 mg comprimido (Vitamedic Indústria Farmacêutica Ltda) x 30 comprimidos"
  },
  {
    "code" : "7896026300216",
    "display" : "Atrovent 0,25 mg/mL solução para inalação 20 mL; frasco (BOEHRINGER INGELHEIM DO BRASIL QUÍMICA E FARMACÊUTICA LTDA) x 1 frasco"
  },
  {
    "code" : "7896026302432",
    "display" : "Atrovent N 20 microgramas/dose solução aerossol 10 mL; inalador; frasco (BOEHRINGER INGELHEIM DO BRASIL QUÍMICA E FARMACÊUTICA LTDA) x 1 frasco"
  },
  {
    "code" : "7896269900211",
    "display" : "Beclosol 50 microgramas/dose suspensão spray (GLAXOSMITHKLINE BRASIL LTDA); frasco com 200 doses"
  },
  {
    "code" : "7896004726847",
    "display" : "Bonagran 70 mg comprimido (Legrand Pharma Indústria Farmacêutica LTDA) x 4 comprimidos"
  },
  {
    "code" : "7896006216353",
    "display" : "Bonalen 70 mg comprimido (União Química Farmacêutica Nacional S/A) x 4 comprimidos"
  },
  {
    "code" : "7897595610973",
    "display" : "Boneprev 70 mg comprimido (Sandoz Do Brasil Indústria Farmacêutica Ltda) x 4 comprimidos"
  },
  {
    "code" : "7896181913252",
    "display" : "Brometo de Ipratrópio 0,25 mg/mL solução para inalação 20 mL; frasco (Aché Laboratórios Farmacêuticos S/A); 1 frasco"
  },
  {
    "code" : "7896714214337",
    "display" : "Brometo de Ipratrópio 0,25 mg/mL solução para inalação 20 mL; frasco (Brainfarma Indústria Química e Farmacêutica S/A); 1 frasco"
  },
  {
    "code" : "7896004725420",
    "display" : "Brometo de Ipratrópio 0,25 mg/mL solução para inalação 20 mL; frasco (EMS S/A); 1 frasco"
  },
  {
    "code" : "7896004725437",
    "display" : "Brometo de Ipratrópio 0,25 mg/mL solução para inalação 20 mL; frasco (Germed Farmacêutica LTDA); 1 frasco"
  },
  {
    "code" : "7898060132785",
    "display" : "Brometo de Ipratrópio 0,25 mg/mL solução para inalação 20 mL; frasco (Laboratório Globo LTDA); 1 frasco"
  },
  {
    "code" : "7896112114413",
    "display" : "Brometo de Ipratrópio 0,25 mg/mL solução para inalação 20 mL; frasco (Laboratório Teuto Brasileiro S/A); 1 frasco"
  },
  {
    "code" : "7894916145435",
    "display" : "Brometo de Ipratrópio 0,25 mg/mL solução para inalação 20 mL; frasco (Legrand Pharma Indústria Farmacêutica LTDA); 1 frasco"
  },
  {
    "code" : "7895296044011",
    "display" : "Brometo de Ipratrópio 0,25 mg/mL solução para inalação 20 mL; frasco (Nova Química Farmacêutica S/A); 1 frasco"
  },
  {
    "code" : "7898216366972",
    "display" : "Brometo de Ipratrópio 0,25 mg/mL solução para inalação 20 mL; frasco (Pharlab Indústria Farmacêutica S/A); 1 frasco"
  },
  {
    "code" : "7898148299010",
    "display" : "Brometo de Ipratrópio 0,25 mg/mL solução para inalação 20 mL; frasco (Prati Donaduzzi & CIA LTDA); 1 frasco"
  },
  {
    "code" : "7896006262510",
    "display" : "Brometo de Ipratrópio 0,25 mg/mL solução para inalação 20 mL; frasco (União Química Farmacêutica Nacional S/A); 1 frasco"
  },
  {
    "code" : "7896206402037",
    "display" : "Budecort Aqua 32 microgramas/dose suspensão spray (ASTRAZENECA DO BRASIL LTDA); 1 frasco"
  },
  {
    "code" : "7891010245146",
    "display" : "Budecort Aqua 32 microgramas/dose suspensão spray (JANSSEN-CILAG FARMACÊUTICA LTDA); 1 frasco"
  },
  {
    "code" : "7896004758268",
    "display" : "Budesonida 32 microgramas/dose suspensão spray x 120 doses (EMS S.A.); 1 frasco"
  },
  {
    "code" : "7896181915171",
    "display" : "Busonid 32 microgramas/dose suspensão spray; 120 doses (ACHÉ LABORATÓRIOS FARMACÊUTICOS S.A); 1 frasco"
  },
  {
    "code" : "7896181917199",
    "display" : "Busonid 32 microgramas/dose suspensão spray; 60 doses (ACHÉ LABORATÓRIOS FARMACÊUTICOS S.A); 1 frasco"
  },
  {
    "code" : "7896181907176",
    "display" : "Busonid 50 microgramas/dose suspensão spray; 120 doses (ACHÉ LABORATÓRIOS FARMACÊUTICOS S.A); 1 frasco"
  },
  {
    "code" : "7896181917205",
    "display" : "Busonid 50 microgramas/dose suspensão spray; 60 doses (ACHÉ LABORATÓRIOS FARMACÊUTICOS S.A); 1 frasco"
  },
  {
    "code" : "7896714201207",
    "display" : "Capotrineo 25 mg comprimido (Brainfarma Indústria Química e Farmacêutica S.A) x 16 comprimidos"
  },
  {
    "code" : "7896714207797",
    "display" : "Capotrineo 25 mg comprimido (Brainfarma Indústria Química e Farmacêutica S.A) x 30 comprimidos"
  },
  {
    "code" : "7899095262980",
    "display" : "Capox 25 mg comprimido (Geolab Indústria Farmacêutica S/A) x 15 comprimidos"
  },
  {
    "code" : "7899095262973",
    "display" : "Capox 25 mg comprimido (Geolab Indústria Farmacêutica S/A) x 30 comprimidos"
  },
  {
    "code" : "7899095200067",
    "display" : "Capox 25 mg comprimido (Geolab Indústria Farmacêutica S/A) x 30 comprimidos (2 blisters x 15)"
  },
  {
    "code" : "7898060138060",
    "display" : "Captocord 25 mg comprimido (Laboratório Globo Ltda) x 30 comprimidos"
  },
  {
    "code" : "7898060131948",
    "display" : "Captocord 25 mg comprimido (Laboratório Globo Ltda) x 60 comprimidos"
  },
  {
    "code" : "7896472519903",
    "display" : "Captolab 25 mg comprimido (Multilab Indústria e Comércio de Produtos Farmacêuticos Ltda) x 15 comprimidos"
  },
  {
    "code" : "7896472519910",
    "display" : "Captolab 25 mg comprimido (Multilab Indústria e Comércio de Produtos Farmacêuticos Ltda) x 16 comprimidos"
  },
  {
    "code" : "7896472519927",
    "display" : "Captolab 25 mg comprimido (Multilab Indústria e Comércio de Produtos Farmacêuticos Ltda) x 28 comprimidos"
  },
  {
    "code" : "7896004777320",
    "display" : "Captolab 25 mg comprimido (Multilab Indústria e Comércio de Produtos Farmacêuticos Ltda) x 30 comprimidos"
  },
  {
    "code" : "7896472501915",
    "display" : "Captolab 25 mg comprimido (Multilab Indústria e Comércio de Produtos Farmacêuticos Ltda) x 30 comprimidos"
  },
  {
    "code" : "7896004777337",
    "display" : "Captolab 25 mg comprimido (Multilab Indústria e Comércio de Produtos Farmacêuticos Ltda) x 60 comprimidos"
  },
  {
    "code" : "7896472504558",
    "display" : "Captolab 25 mg comprimido (Multilab Indústria e Comércio de Produtos Farmacêuticos Ltda) x 60 comprimidos"
  },
  {
    "code" : "7896523208350",
    "display" : "Captomed 25 mg comprimido (Cimed Indústria de Medicamentos Ltda) x 30 comprimidos"
  },
  {
    "code" : "7897917001489",
    "display" : "Captomido 25 mg comprimido (Belfar Ltda) x 30 comprimidos"
  },
  {
    "code" : "7898075313711",
    "display" : "Captopril 25 mg comprimido (1Farma Indústria Farmacêutica Ltda) x 30 comprimidos"
  },
  {
    "code" : "7897917005029",
    "display" : "Captopril 25 mg comprimido (Belfar LTDA) x 20 comprimidos"
  },
  {
    "code" : "7897917005036",
    "display" : "Captopril 25 mg comprimido (Belfar LTDA) x 30 comprimidos"
  },
  {
    "code" : "7896714205687",
    "display" : "Captopril 25 mg comprimido (Brainfarma Indústria Química E Farmacêutica S.A) x 30 comprimidos"
  },
  {
    "code" : "7898100242917",
    "display" : "Captopril 25 mg comprimido (Brasterapica Indústria Farmacêutica Ltda) x 30 comprimidos"
  },
  {
    "code" : "7896523209845",
    "display" : "Captopril 25 mg comprimido (Cimed Indústria de Medicamentos Ltda) x 30 comprimidos"
  },
  {
    "code" : "7896523209852",
    "display" : "Captopril 25 mg comprimido (Cimed Indústria de Medicamentos Ltda) x 60 comprimidos"
  },
  {
    "code" : "7896004704326",
    "display" : "Captopril 25 mg comprimido (EMS S/A) x 30 comprimidos"
  },
  {
    "code" : "7896004762272",
    "display" : "Captopril 25 mg comprimido (EMS S/A) x 30 comprimidos"
  },
  {
    "code" : "7896004707020",
    "display" : "Captopril 25 mg comprimido (EMS S/A) x 60 comprimidos"
  },
  {
    "code" : "7899095246669",
    "display" : "Captopril 25 mg comprimido (Geolab Indústria Farmacêutica S.A.) x 15 comprimidos"
  },
  {
    "code" : "7899095246676",
    "display" : "Captopril 25 mg comprimido (Geolab Indústria Farmacêutica S.A.) x 30 comprimidos"
  },
  {
    "code" : "7899095246683",
    "display" : "Captopril 25 mg comprimido (Geolab Indústria Farmacêutica S.A.) x 60 comprimidos"
  },
  {
    "code" : "7896004704654",
    "display" : "Captopril 25 mg comprimido (Germed Farmacêutica LTDA) x 30 comprimidos"
  },
  {
    "code" : "7896004767970",
    "display" : "Captopril 25 mg comprimido (Germed Farmacêutica LTDA) x 30 comprimidos"
  },
  {
    "code" : "7899620910133",
    "display" : "Captopril 25 mg comprimido (Laboratório Globo Ltda) x 30 comprimidos"
  },
  {
    "code" : "7899620910140",
    "display" : "Captopril 25 mg comprimido (Laboratório Globo Ltda) x 60 comprimidos"
  },
  {
    "code" : "7896112116660",
    "display" : "Captopril 25 mg comprimido (Laboratório Teuto Brasileiro S/A) x 30 comprimidos"
  },
  {
    "code" : "7896112176473",
    "display" : "Captopril 25 mg comprimido (Laboratório Teuto Brasileiro S/A) x 60 comprimidos"
  },
  {
    "code" : "7894916141147",
    "display" : "Captopril 25 mg comprimido (Legrand Pharma Indústria Farmacêutica Ltda) x 30 comprimidos"
  },
  {
    "code" : "7898917592489",
    "display" : "Captopril 25 mg comprimido (Mariol Indústrial Ltda) x 30 comprimidos"
  },
  {
    "code" : "7896862923365",
    "display" : "Captopril 25 mg comprimido (Medquimica Indústria Farmacêutica Ltda.) x 30 comprimidos"
  },
  {
    "code" : "7896862923372",
    "display" : "Captopril 25 mg comprimido (Medquimica Indústria Farmacêutica Ltda.) x 60 comprimidos"
  },
  {
    "code" : "7896472520077",
    "display" : "Captopril 25 mg comprimido (Multilab Indústria e Comércio de Produtos Farmacêuticos Ltda) x 15 comprimidos"
  },
  {
    "code" : "7896472520084",
    "display" : "Captopril 25 mg comprimido (Multilab Indústria e Comércio de Produtos Farmacêuticos Ltda) x 16 comprimidos"
  },
  {
    "code" : "7896472520091",
    "display" : "Captopril 25 mg comprimido (Multilab Indústria e Comércio de Produtos Farmacêuticos Ltda) x 28 comprimidos"
  },
  {
    "code" : "7896472508143",
    "display" : "Captopril 25 mg comprimido (Multilab Indústria e Comércio de Produtos Farmacêuticos Ltda) x 30 comprimidos"
  },
  {
    "code" : "7896004777740",
    "display" : "Captopril 25 mg comprimido (Multilab Indústria e Comércio de Produtos Farmacêuticos Ltda) x 30 comprimidos"
  },
  {
    "code" : "7896472520114",
    "display" : "Captopril 25 mg comprimido (Multilab Indústria e Comércio de Produtos Farmacêuticos Ltda) x 60 comprimidos"
  },
  {
    "code" : "7898216367726",
    "display" : "Captopril 25 mg comprimido (Pharlab Indústria Farmacêutica S.A.) x 30 comprimidos"
  },
  {
    "code" : "7898148290512",
    "display" : "Captopril 25 mg comprimido (Prati Donaduzzi & Cia Ltda) x 30 comprimidos"
  },
  {
    "code" : "7897595603357",
    "display" : "Captopril 25 mg comprimido (Sandoz do Brasil Indústria Farmacêutica Ltda) x 30 comprimidos (3 blisters x 10)"
  },
  {
    "code" : "7897595603401",
    "display" : "Captopril 25 mg comprimido (Sandoz do Brasil Indústria Farmacêutica Ltda) x 60 comprimidos (6 blisters x 10)"
  },
  {
    "code" : "7896422503709",
    "display" : "Captopril 25 mg comprimido (Sanofi Medley Farmacêutica Ltda) x 30 comprimidos"
  },
  {
    "code" : "7896422503716",
    "display" : "Captopril 25 mg comprimido (Sanofi Medley Farmacêutica Ltda) x 60 comprimidos"
  },
  {
    "code" : "7896006214984",
    "display" : "Captopril 25 mg comprimido (União Química Farmacêutica Nacional S/A) x 30 comprimidos"
  },
  {
    "code" : "7898049795697",
    "display" : "Captopril 25 mg comprimido (Vitamedic Indústria Farmacêutica Ltda) x 30 comprimidos"
  },
  {
    "code" : "7898216360161",
    "display" : "Captosen 25 mg comprimido (Pharlab Indústria Farmacêutica S.A.) x 30 comprimidos"
  },
  {
    "code" : "7897595605627",
    "display" : "Captotec 25 mg comprimido (Sandoz do Brasil Indústria Farmacêutica Ltda) x 30 comprimidos"
  },
  {
    "code" : "7897595609489",
    "display" : "Captotec 25 mg comprimido (Sandoz do Brasil Indústria Farmacêutica Ltda) x 60 comprimidos"
  },
  {
    "code" : "7896112189923",
    "display" : "Carbidol 25 mg + 250 mg comprimido (Laboratório Teuto Brasileiro S/A) x 30 comprimidos"
  },
  {
    "code" : "7896112143994",
    "display" : "Carbidol 25 mg + 250 mg comprimido (Laboratório Teuto Brasileiro S/A) x 30 comprimidos"
  },
  {
    "code" : "7896006234067",
    "display" : "Ciclo 21 (0,15 mg + 0,03 mg) comprimido (União Química Farmacêutica Nacional S/A) x 21 comprimidos"
  },
  {
    "code" : "7896006234005",
    "display" : "Ciclo 21 (0,15 mg + 0,03 mg) comprimido (União Química Farmacêutica Nacional S/A) x 63 comprimidos"
  },
  {
    "code" : "7896006234050",
    "display" : "Ciclo 21 (0,15 mg + 0,03 mg) comprimido (União Química Farmacêutica Nacional S/A) x 63 comprimidos"
  },
  {
    "code" : "7896672202322",
    "display" : "Clenil 200 microgramas/pó para inalação; inalador (Chiesi Farmacêutica LTDA); frasco com 100 doses"
  },
  {
    "code" : "7896672201943",
    "display" : "Clenil 50 microgramas/dose suspensão spray (Chiesi Farmacêutica LTDA); frasco com 200 doses"
  },
  {
    "code" : "7896672202919",
    "display" : "Clenil HFA JET 250 microgramas/dose solução aerossol; inalador (CHIESI FARMACÊUTICA LTDA); frasco com 200 doses"
  },
  {
    "code" : "7896672202872",
    "display" : "Clenil HFA Spray 200 microgramas/dose solução aerossol; inalador (CHIESI FARMACÊUTICA LTDA); frasco com 200 doses"
  },
  {
    "code" : "7896672202902",
    "display" : "Clenil HFA Spray 250 microgramas/dose solução aerossol; inalador (CHIESI FARMACÊUTICA LTDA); frasco com 200 doses"
  },
  {
    "code" : "7896672202810",
    "display" : "Clenil HFA Spray 50 microgramas/dose solução aerossol; inalador (CHIESI FARMACÊUTICA LTDA); frasco com 200 doses"
  },
  {
    "code" : "7891721003059",
    "display" : "Clinfar 10 mg comprimido (Merck S/A) x 10 comprimidos"
  },
  {
    "code" : "7891721003042",
    "display" : "Clinfar 10 mg comprimido (Merck S/A) x 30 comprimidos"
  },
  {
    "code" : "7891721013119",
    "display" : "Clinfar 20 mg comprimido (Merck S/A) x 10 comprimidos"
  },
  {
    "code" : "7891721012884",
    "display" : "Clinfar 20 mg comprimido (Merck S/A) x 30 comprimidos"
  },
  {
    "code" : "7891721016189",
    "display" : "Clinfar 40 mg comprimido (Merck S/A) x 10 comprimidos"
  },
  {
    "code" : "7891721016165",
    "display" : "Clinfar 40 mg comprimido (Merck S/A) x 30 comprimidos"
  },
  {
    "code" : "7897595901521",
    "display" : "Clorana 25 mg comprimido (Sanofi-Medley Farmacêutica Ltda) x 30 comprimidos"
  },
  {
    "code" : "7898361882655",
    "display" : "Cloridrato de Metformina 500 mg comprimido (Aurobindo Pharma Indústria Farmacêutica Limitada) x 30 comprimidos"
  },
  {
    "code" : "7896181904922",
    "display" : "Cloridrato de Metformina 500 mg comprimido (Biosintética Farmacêutica Ltda) x 30 comprimidos"
  },
  {
    "code" : "7896004709192",
    "display" : "Cloridrato de Metformina 500 mg comprimido (EMS S/A) x 30 comprimidos"
  },
  {
    "code" : "7896004712888",
    "display" : "Cloridrato de Metformina 500 mg comprimido (EMS S/A) x 60 comprimidos"
  },
  {
    "code" : "7896004712840",
    "display" : "Cloridrato de Metformina 500 mg comprimido (Germed Farmaceutica Ltda) x 60 comprimidos"
  },
  {
    "code" : "7896112126478",
    "display" : "Cloridrato de Metformina 500 mg comprimido (Laboratório Teuto Brasileiro S/A) x 30 comprimidos"
  },
  {
    "code" : "7896112131113",
    "display" : "Cloridrato de Metformina 500 mg comprimido (Laboratório Teuto Brasileiro S/A) x 60 comprimidos"
  },
  {
    "code" : "7891721238123",
    "display" : "Cloridrato de Metformina 500 mg comprimido (Merck S/A) x 30 comprimidos"
  },
  {
    "code" : "7891721238239",
    "display" : "Cloridrato de Metformina 500 mg comprimido (Merck S/A) x 60 comprimidos"
  },
  {
    "code" : "7896004778136",
    "display" : "Cloridrato de Metformina 500 mg comprimido (Multilab Indústria e Comércio de Produtos Farmacêuticos Ltda) x 30 comprimidos"
  },
  {
    "code" : "7896472512386",
    "display" : "Cloridrato de Metformina 500 mg comprimido (Multilab Indústria e Comércio de Produtos Farmacêuticos Ltda) x 30 comprimidos"
  },
  {
    "code" : "7896004778259",
    "display" : "Cloridrato de Metformina 500 mg comprimido (Multilab Indústria e Comércio de Produtos Farmacêuticos Ltda) x 60 comprimidos"
  },
  {
    "code" : "7895296432016",
    "display" : "Cloridrato de Metformina 500 mg comprimido (Nova Química Farmacêutica S.A.) x 30 comprimidos"
  },
  {
    "code" : "7898148291267",
    "display" : "Cloridrato de Metformina 500 mg comprimido (Prati Donaduzzi & Cia Ltda) x 30 comprimidos"
  },
  {
    "code" : "7899547528633",
    "display" : "Cloridrato de Metformina 500 mg comprimido (Prati Donaduzzi & Cia Ltda) x 60 comprimidos"
  },
  {
    "code" : "7896422507943",
    "display" : "Cloridrato de Metformina 500 mg comprimido (Sanofi Medley Farmacêutica Ltda) x 30 comprimidos"
  },
  {
    "code" : "7896422508056",
    "display" : "Cloridrato de Metformina 500 mg comprimido (Sanofi Medley Farmacêutica Ltda) x 60 comprimidos"
  },
  {
    "code" : "7896004750682",
    "display" : "Cloridrato de Metformina 500 mg comprimido de liberação prolongada (EMS S/A) x 30 comprimidos"
  },
  {
    "code" : "7896004766188",
    "display" : "Cloridrato de Metformina 500 mg comprimido de liberação prolongada (Germed Farmacêutica LTDA) x 10 comprimidos"
  },
  {
    "code" : "7896004766195",
    "display" : "Cloridrato de Metformina 500 mg comprimido de liberação prolongada (Germed Farmacêutica LTDA) x 20 comprimidos"
  },
  {
    "code" : "7896004766201",
    "display" : "Cloridrato de Metformina 500 mg comprimido de liberação prolongada (Germed Farmacêutica LTDA) x 30 comprimidos"
  },
  {
    "code" : "7896004766218",
    "display" : "Cloridrato de Metformina 500 mg comprimido de liberação prolongada (Germed Farmacêutica LTDA) x 60 comprimidos"
  },
  {
    "code" : "7894916148870",
    "display" : "Cloridrato De Metformina 500 mg comprimido de liberação prolongada (Legrand Pharma Indústria Farmacêutica Ltda) x 30 comprimidos"
  },
  {
    "code" : "7891721022722",
    "display" : "Cloridrato de Metformina 500 mg comprimido de liberação prolongada (Merck S/A) x 30 comprimidos"
  },
  {
    "code" : "7891721201783",
    "display" : "Cloridrato de Metformina 500 mg comprimido de liberação prolongada (Merck S/A) x 30 comprimidos"
  },
  {
    "code" : "7899547511031",
    "display" : "Cloridrato de Metformina 500 mg comprimido de liberação prolongada (Prati Donaduzzi & Cia Ltda) x 30 comprimidos"
  },
  {
    "code" : "7899547528602",
    "display" : "Cloridrato de Metformina 500 mg comprimido de liberação prolongada (Prati Donaduzzi & Cia Ltda) x 60 comprimidos"
  },
  {
    "code" : "8902220108257",
    "display" : "Cloridrato de Metformina 500 mg comprimido de liberação prolongada (Torrent do Brasil LTDA) x 10 comprimidos"
  },
  {
    "code" : "8902220108264",
    "display" : "Cloridrato de Metformina 500 mg comprimido de liberação prolongada (Torrent do Brasil LTDA) x 20 comprimidos"
  },
  {
    "code" : "8902220107205",
    "display" : "Cloridrato de Metformina 500 mg comprimido de liberação prolongada (Torrent do Brasil LTDA) x 30 comprimidos"
  },
  {
    "code" : "8902220108271",
    "display" : "Cloridrato de Metformina 500 mg comprimido de liberação prolongada (Torrent do Brasil LTDA) x 60 comprimidos"
  },
  {
    "code" : "7898075313940",
    "display" : "Cloridrato de Metformina 850 mg comprimido (1Farma Industria Farmacêutica Ltda) x 30 comprimidos"
  },
  {
    "code" : "7898902274031",
    "display" : "Cloridrato de Metformina 850 mg comprimido (Accord Farmacêutica Ltda) x 30 comprimidos"
  },
  {
    "code" : "7898361882662",
    "display" : "Cloridrato de Metformina 850 mg comprimido (Aurobindo Pharma Indústria Farmacêutica Limitada) x 30 comprimidos"
  },
  {
    "code" : "7896181901402",
    "display" : "Cloridrato de Metformina 850 mg comprimido (Biosintética Farmacêutica Ltda) x 30 comprimidos"
  },
  {
    "code" : "7896523210001",
    "display" : "Cloridrato de Metformina 850 mg comprimido (Cimed Indústria de Medicamentos Ltda) x 30 comprimidos"
  },
  {
    "code" : "7896004709185",
    "display" : "Cloridrato de Metformina 850 mg comprimido (EMS S/A) x 30 comprimidos"
  },
  {
    "code" : "7896004712895",
    "display" : "Cloridrato de Metformina 850 mg comprimido (EMS S/A) x 60 comprimidos"
  },
  {
    "code" : "7895296190022",
    "display" : "Cloridrato de Metformina 850 mg comprimido (EMS Sigma Pharma Ltda) x 30 comprimidos"
  },
  {
    "code" : "7899095238763",
    "display" : "Cloridrato de Metformina 850 mg comprimido (Geolab Industria Farmacêutica S.A.) x 30 comprimidos"
  },
  {
    "code" : "7896004712864",
    "display" : "Cloridrato de Metformina 850 mg comprimido (Germed Farmacêutica LTDA) x 60 comprimidos"
  },
  {
    "code" : "7896112126485",
    "display" : "Cloridrato de Metformina 850 mg comprimido (Laboratório Teuto Brasileiro S/A) x 30 comprimidos"
  },
  {
    "code" : "7896112128670",
    "display" : "Cloridrato de Metformina 850 mg comprimido (Laboratório Teuto Brasileiro S/A) x 60 comprimidos"
  },
  {
    "code" : "7891721027406",
    "display" : "Cloridrato de Metformina 850 mg comprimido (Merck S/A) x 30 comprimidos"
  },
  {
    "code" : "7891721238246",
    "display" : "Cloridrato de Metformina 850 mg comprimido (Merck S/A) x 60 comprimidos"
  },
  {
    "code" : "7896004778143",
    "display" : "Cloridrato de Metformina 850 mg comprimido (Multilab Indústria e Comércio de Produtos Farmacêuticos Ltda) x 30 comprimidos"
  },
  {
    "code" : "7896472512409",
    "display" : "Cloridrato de Metformina 850 mg comprimido (Multilab Indústria e Comércio de Produtos Farmacêuticos Ltda) x 30 comprimidos"
  },
  {
    "code" : "7896004778266",
    "display" : "Cloridrato de Metformina 850 mg comprimido (Multilab Indústria e Comércio de Produtos Farmacêuticos Ltda) x 60 comprimidos"
  },
  {
    "code" : "7895296080019",
    "display" : "Cloridrato de Metformina 850 mg comprimido (Nova Química Farmacêutica S.A.) x 60 comprimidos"
  },
  {
    "code" : "7898148291298",
    "display" : "Cloridrato de Metformina 850 mg comprimido (Prati Donaduzzi & Cia Ltda) x 30 comprimidos"
  },
  {
    "code" : "7899547528640",
    "display" : "Cloridrato de Metformina 850 mg comprimido (Prati Donaduzzi & Cia Ltda) x 60 comprimidos"
  },
  {
    "code" : "7896422507950",
    "display" : "Cloridrato de Metformina 850 mg comprimido (Sanofi Medley Farmacêutica Ltda) x 30 comprimidos"
  },
  {
    "code" : "7896422508063",
    "display" : "Cloridrato de Metformina 850 mg comprimido (Sanofi Medley Farmacêutica Ltda) x 60 comprimidos"
  },
  {
    "code" : "7896714205182",
    "display" : "Cloridrato de Propranolol 40 mg comprimido (Brainfarma Indústria Química e Farmacêutica S.A) x 30 comprimidos"
  },
  {
    "code" : "7896523210438",
    "display" : "Cloridrato de Propranolol 40 mg comprimido (Cimed Indústria de Medicamentos Ltda) x 30 comprimidos"
  },
  {
    "code" : "7896004761701",
    "display" : "Cloridrato de Propranolol 40 mg comprimido (EMS S.A.) x 30 comprimidos"
  },
  {
    "code" : "7896004707341",
    "display" : "Cloridrato de Propranolol 40 mg comprimido (Germed Farmacêutica LTDA) x 60 comprimidos"
  },
  {
    "code" : "7899620914049",
    "display" : "Cloridrato de Propranolol 40 mg comprimido (Laboratório Globo LTDA) x 30 comprimidos"
  },
  {
    "code" : "7899620911987",
    "display" : "Cloridrato de Propranolol 40 mg comprimido (Laboratório Globo LTDA) x 40 comprimidos"
  },
  {
    "code" : "7896112110576",
    "display" : "Cloridrato de Propranolol 40 mg comprimido (Laboratório Teuto Brasileiro S/A) x 30 comprimidos (3 blisters x 10)"
  },
  {
    "code" : "7896862923402",
    "display" : "Cloridrato de Propranolol 40 mg comprimido (Medquimica Industria Farmacêutica Ltda.) x 40 comprimidos"
  },
  {
    "code" : "7898216362431",
    "display" : "Cloridrato de Propranolol 40 mg comprimido (Pharlab Indústria Farmacêutica S.A.) x 30 comprimidos"
  },
  {
    "code" : "7899547512731",
    "display" : "Cloridrato de Propranolol 40 mg comprimido (Prati Donaduzzi & Cia Ltda) x 30 comprimidos"
  },
  {
    "code" : "7896422515535",
    "display" : "Cloridrato de Propranolol 40 mg comprimido (Sanofi Medley Farmacêutica Ltda) x 30 comprimidos"
  },
  {
    "code" : "7896006245247",
    "display" : "Cloridrato de Propranolol 40 mg comprimido (União Química Farmacêutica Nacional S/A) x 30 comprimidos"
  },
  {
    "code" : "7894916507004",
    "display" : "Contracep 150 mg/mL suspensão injetável (Germed Farmacêutica LTDA) x 1 ampola 1mL"
  },
  {
    "code" : "7894916502900",
    "display" : "Contracep 150 mg/mL suspensão injetável (Germed Farmacêutica LTDA) x 1 ampola 1mL"
  },
  {
    "code" : "7894916512589",
    "display" : "Contracep 150 mg/mL suspensão injetável (Germed Farmacêutica LTDA) x 1 frasco-ampola 1mL"
  },
  {
    "code" : "7898096577284",
    "display" : "Cordiron 10 mg comprimido (Diffucap - Chemobrás Química E Farmacêutica Ltda) x 30 comprimidos"
  },
  {
    "code" : "7896181917748",
    "display" : "Corus 50 mg comprimido (ACHÉ LABORATÓRIOS FARMACÊUTICOS S.A) x 14 comprimidos"
  },
  {
    "code" : "7896181902737",
    "display" : "Corus 50 mg comprimido (ACHÉ LABORATÓRIOS FARMACÊUTICOS S.A) x 28 comprimidos"
  },
  {
    "code" : "7896181920410",
    "display" : "Corus 50 mg comprimido (ACHÉ LABORATÓRIOS FARMACÊUTICOS S.A) x 30 comprimidos"
  },
  {
    "code" : "7897337708463",
    "display" : "Cozaar 50 mg comprimido (ORGANON FARMACÊUTICA LTDA.) x 15 comprimidos"
  },
  {
    "code" : "7897337706384",
    "display" : "Cozaar 50 mg comprimido (ORGANON FARMACÊUTICA LTDA.) x 30 comprimidos"
  },
  {
    "code" : "7896472513482",
    "display" : "Cytrana 50 mg comprimido (Multilab Indústria e Comércio de Produtos Farmacêuticos Ltda) x 30 comprimidos"
  },
  {
    "code" : "7896472513499",
    "display" : "Cytrana 50 mg comprimido (Multilab Indústria e Comércio de Produtos Farmacêuticos Ltda) x 60 comprimidos"
  },
  {
    "code" : "7891058212070",
    "display" : "Daonil 5 mg comprimido (Sanofi Medley Farmacêutica Ltda) x 30 comprimidos"
  },
  {
    "code" : "7896006259657",
    "display" : "Demedrox 150 mg/mL suspensão injetável (União Química Farmacêutica Nacional S/A) x 1 ampola 1mL"
  },
  {
    "code" : "7896006205395",
    "display" : "Demedrox 150 mg/mL suspensão injetável (União Química Farmacêutica Nacional S/A) x 1 ampola 1mL"
  },
  {
    "code" : "7896006206781",
    "display" : "Demedrox 150 mg/mL suspensão injetável (União Química Farmacêutica Nacional S/A) x 1 seringa preenchida 1mL"
  },
  {
    "code" : "7891268101799",
    "display" : "Depo-provera 150 mg/mL suspensão injetável (Wyeth Indústria Farmacêutica LTDA) x 1 frasco-ampola 1mL"
  },
  {
    "code" : "7891268101782",
    "display" : "Depo-provera 150 mg/mL suspensão injetável (Wyeth Indústria Farmacêutica LTDA) x 1 seringa preenchida 1mL"
  },
  {
    "code" : "7896006230663",
    "display" : "Diaformin 850 mg comprimido (União Química Farmacêutica Nacional S/A) x 30 comprimidos"
  },
  {
    "code" : "7896672203688",
    "display" : "Dipropionato de Beclometasona 200 microgramas/dose solução aerossol; inalador (CHIESI FARMACÊUTICA LTDA) dispositivo oral + espaçador jet 200 doses"
  },
  {
    "code" : "7896672203664",
    "display" : "Dipropionato de Beclometasona 200 microgramas/dose solução aerossol; inalador (CHIESI FARMACÊUTICA LTDA) dispositivo oral 200 doses"
  },
  {
    "code" : "7896672203671",
    "display" : "Dipropionato de Beclometasona 200 microgramas/dose solução aerossol; inalador (CHIESI FARMACÊUTICA LTDA) espaçador jet 200 doses"
  },
  {
    "code" : "7896672203718",
    "display" : "Dipropionato de Beclometasona 250 microgramas/dose solução aerossol; inalador (CHIESI FARMACÊUTICA LTDA) dispositivo oral + espaçador jet 200 doses"
  },
  {
    "code" : "7896672203695",
    "display" : "Dipropionato de Beclometasona 250 microgramas/dose solução aerossol; inalador (CHIESI FARMACÊUTICA LTDA) dispositivo oral 200 doses"
  },
  {
    "code" : "7896672203701",
    "display" : "Dipropionato de Beclometasona 250 microgramas/dose solução aerossol; inalador (CHIESI FARMACÊUTICA LTDA) espaçador jet 200 doses"
  },
  {
    "code" : "7897473207103",
    "display" : "Dipropionato de Beclometasona 250 microgramas/dose solução aerossol; inalador (GLENMARK FARMACÊUTICA LTDA) 200 doses"
  },
  {
    "code" : "7896672203626",
    "display" : "Dipropionato de Beclometasona 50 microgramas/dose solução aerossol; inalador (CHIESI FARMACÊUTICA LTDA) dispositivo oral + espaçador jet 200 doses"
  },
  {
    "code" : "7896672203602",
    "display" : "Dipropionato de Beclometasona 50 microgramas/dose solução aerossol; inalador (CHIESI FARMACÊUTICA LTDA) dispositivo oral 200 doses"
  },
  {
    "code" : "7896672203619",
    "display" : "Dipropionato de Beclometasona 50 microgramas/dose solução aerossol; inalador (CHIESI FARMACÊUTICA LTDA) espaçador jet 200 doses"
  },
  {
    "code" : "7893736002300",
    "display" : "Diurezin 25 mg comprimido (Cazi Quimica Farmaceutica Industria E Comercio Ltda) x 20 comprimidos"
  },
  {
    "code" : "7893736011319",
    "display" : "Diurezin 25 mg comprimido (Cazi Quimica Farmaceutica Industria E Comercio Ltda) x 30 comprimidos"
  },
  {
    "code" : "7896112141280",
    "display" : "Diurix 25 mg comprimido (Laboratório Teuto Brasileiro S/A) x 20 comprimidos"
  },
  {
    "code" : "7896112122432",
    "display" : "Diurix 25 mg comprimido (Laboratório Teuto Brasileiro S/A) x 30 comprimidos"
  },
  {
    "code" : "7896658033636",
    "display" : "Ekson 100 mg + 25 mg comprimido (Aché Laboratórios Farmacêuticos S.A) x 10 comprimidos"
  },
  {
    "code" : "7896658033582",
    "display" : "Ekson 100 mg + 25 mg comprimido (Aché Laboratórios Farmacêuticos S.A) x 30 comprimidos"
  },
  {
    "code" : "7896658033599",
    "display" : "Ekson 100 mg + 25 mg comprimido (Aché Laboratórios Farmacêuticos S.A) x 60 comprimidos"
  },
  {
    "code" : "7897851259595",
    "display" : "Enalabal 10 mg comprimido (Laboratórios Baldacci Ltda) x 30 comprimidos"
  },
  {
    "code" : "7896523206073",
    "display" : "Enalamed 10 mg comprimido (Cimed Indústria de Medicamentos Ltda) x 30 comprimidos"
  },
  {
    "code" : "7908020502524",
    "display" : "Enantato de Noretisterona 50 mg/mL + Valerato de Estradiol 5 mg/mL solução para injeção; ampola (Cifarma Científica Farmacêutica LTDA); 1 ampola"
  },
  {
    "code" : "7898495609548",
    "display" : "Enantato de Noretisterona 50 mg/mL + Valerato de Estradiol 5 mg/mL solução para injeção; ampola (Cifarma Científica Farmacêutica LTDA); 1 ampola"
  },
  {
    "code" : "7891317437220",
    "display" : "Enantato de Noretisterona 50 mg/mL + Valerato de Estradiol 5m mg/mL solução para injeção; seringa preenchida (Eurofarma Laboratórios S.A.); 1 seringa"
  },
  {
    "code" : "7891317496388",
    "display" : "Enantato de Noretisterona 50 mg/mL + Valerato de Estradiol 5m mg/mL solução para injeção; seringa preenchida (Eurofarma Laboratórios S.A.); 1 seringa"
  },
  {
    "code" : "7898216360215",
    "display" : "Enaplex 10 mg comprimido (Pharlab Indústria Farmacêutica S.A) x 30 comprimidos"
  },
  {
    "code" : "7897595601476",
    "display" : "Enaprotec 10 mg comprimido (Sandoz do Brasil Indústria Farmacêutica Ltda) x 30 comprimidos"
  },
  {
    "code" : "7893454213118",
    "display" : "Endrostan 70 mg comprimido (Cellera Farmacêutica S.A.) x 4 comprimidos"
  },
  {
    "code" : "7893454100012",
    "display" : "Endrostan 70 mg comprimido (Cellera Farmacêutica S.A.) x 4 comprimidos"
  },
  {
    "code" : "7896181903376",
    "display" : "Eupressin 10 mg comprimido (ACHÉ LABORATÓRIOS FARMACÊUTICOS S.A) x 30 comprimidos"
  },
  {
    "code" : "7896181916390",
    "display" : "Eupressin 10 mg comprimido (ACHÉ LABORATÓRIOS FARMACÊUTICOS S.A) x 7 comprimidos"
  },
  {
    "code" : "7896006205937",
    "display" : "Flossotec 10 mg comprimido (União Química Farmacêutica Nacional S/A) x 30 comprimidos"
  },
  {
    "code" : "7896004777573",
    "display" : "Formyn 500 mg comprimido (Multilab Indústria e Comércio de Produtos Farmacêuticos Ltda) x 30 comprimidos"
  },
  {
    "code" : "7896472502394",
    "display" : "Formyn 500 mg comprimido (Multilab Indústria e Comércio de Produtos Farmacêuticos Ltda) x 30 comprimidos"
  },
  {
    "code" : "7896472520008",
    "display" : "Formyn 500 mg comprimido (Multilab Indústria e Comércio de Produtos Farmacêuticos Ltda) x 60 comprimidos"
  },
  {
    "code" : "7896004777580",
    "display" : "Formyn 850 mg comprimido (Multilab Indústria e Comércio de Produtos Farmacêuticos Ltda) x 30 comprimidos"
  },
  {
    "code" : "7896472519989",
    "display" : "Formyn 850 mg comprimido (Multilab Indústria e Comércio de Produtos Farmacêuticos Ltda) x 60 comprimidos"
  },
  {
    "code" : "7897337706421",
    "display" : "Fosamax 70 mg comprimido (Organon Farmacêutica Ltda) x 4 comprimidos"
  },
  {
    "code" : "7898654700680",
    "display" : "Fralda Adulta Affagio Bem Estar G (Godoy e Baptistella Indústria e Comércio de Produtos de Higiene LTDA) x 16 tiras"
  },
  {
    "code" : "7898954589770",
    "display" : "Fralda Adulta Affagio Bem Estar G (Godoy e Baptistella Indústria e Comércio de Produtos de Higiene LTDA) x 8 tiras"
  },
  {
    "code" : "7898954589008",
    "display" : "Fralda Adulta Affagio Bem Estar M (Godoy e Baptistella Indústria e Comércio de Produtos de Higiene LTDA) x 16 tiras"
  },
  {
    "code" : "7898954589756",
    "display" : "Fralda Adulta Affagio Bem Estar M (Godoy e Baptistella Indústria e Comércio de Produtos de Higiene LTDA) x 8 tiras"
  },
  {
    "code" : "7898654700697",
    "display" : "Fralda Adulta Affagio Bem Estar XG (Godoy e Baptistella Indústria e Comércio de Produtos de Higiene LTDA) x 14 tiras"
  },
  {
    "code" : "7898954589794",
    "display" : "Fralda Adulta Affagio Bem Estar XG (Godoy e Baptistella Indústria e Comércio de Produtos de Higiene LTDA) x 7 tiras"
  },
  {
    "code" : "7898654700710",
    "display" : "Fralda Adulta Affagio Essencial G (Godoy e Baptistella Indústria e Comércio de Produtos de Higiene LTDA) x 16 tiras"
  },
  {
    "code" : "7898954589947",
    "display" : "Fralda Adulta Affagio Essencial G (Godoy e Baptistella Indústria e Comércio de Produtos de Higiene LTDA) x 8 tiras"
  },
  {
    "code" : "7898654700703",
    "display" : "Fralda Adulta Affagio Essencial M (Godoy e Baptistella Indústria e Comércio de Produtos de Higiene LTDA) x 16 tiras"
  },
  {
    "code" : "7898954589923",
    "display" : "Fralda Adulta Affagio Essencial M (Godoy e Baptistella Indústria e Comércio de Produtos de Higiene LTDA) x 8 tiras"
  },
  {
    "code" : "7898654700727",
    "display" : "Fralda Adulta Affagio Essencial XG (Godoy e Baptistella Indústria e Comércio de Produtos de Higiene LTDA) x 14 tiras"
  },
  {
    "code" : "7898954589954",
    "display" : "Fralda Adulta Affagio Essencial XG (Godoy e Baptistella Indústria e Comércio de Produtos de Higiene LTDA) x 7 tiras"
  },
  {
    "code" : "7898924155325",
    "display" : "Fralda Adulta Big Roger Plus EG (Haryon Indústria e Comércio de Fraldas e Cosméticos LTDA) x 7 tiras"
  },
  {
    "code" : "7898924155318",
    "display" : "Fralda Adulta Big Roger Plus G (Haryon Indústria e Comércio de Fraldas e Cosméticos LTDA) x 8 tiras"
  },
  {
    "code" : "7898924155301",
    "display" : "Fralda Adulta Big Roger Plus M (Haryon Indústria e Comércio de Fraldas e Cosméticos LTDA) x 8 tiras"
  },
  {
    "code" : "7899816237367",
    "display" : "Fralda Adulta Cotonfral Classic EG (M.T. Indústria e Comércio de Produtos para Higiene LTDA) x 7 tiras"
  },
  {
    "code" : "7899816237350",
    "display" : "Fralda Adulta Cotonfral Classic G (M.T. Indústria e Comércio de Produtos para Higiene LTDA) x 8 tiras"
  },
  {
    "code" : "7899816237343",
    "display" : "Fralda Adulta Cotonfral Classic M (M.T. Indústria e Comércio de Produtos para Higiene LTDA) x 8 tiras"
  },
  {
    "code" : "7898916237398",
    "display" : "Fralda Adulta Cotonfral Econômica Classic EG (M.T. Indústria e Comércio de Produtos para Higiene LTDA) x 26 tiras"
  },
  {
    "code" : "7898916237381",
    "display" : "Fralda Adulta Cotonfral Econômica Classic G (M.T. Indústria e Comércio de Produtos para Higiene LTDA) x 30 tiras"
  },
  {
    "code" : "7898916237343",
    "display" : "Fralda Adulta Cotonfral Econômica Classic M (M.T. Indústria e Comércio de Produtos para Higiene LTDA) x 30 tiras"
  },
  {
    "code" : "7898961775166",
    "display" : "Fralda Adulta Nathyfral G (ERS Indústria e Comércio de Produtos de Higiene e Limpeza LTDA) x 8 tiras"
  },
  {
    "code" : "7898961775159",
    "display" : "Fralda Adulta Nathyfral M (ERS Indústria e Comércio de Produtos de Higiene e Limpeza LTDA) x 8 tiras"
  },
  {
    "code" : "7898961775173",
    "display" : "Fralda Adulta Nathyfral XG (ERS Indústria e Comércio de Produtos de Higiene e Limpeza LTDA) x 7 tiras"
  },
  {
    "code" : "7898654700284",
    "display" : "Fralda Adulta Needs Care G (Godoy e Baptistella Indústria e Comércio de Produtos de Higiene LTDA) x 16 tiras"
  },
  {
    "code" : "7898654700024",
    "display" : "Fralda Adulta Needs Care G (Godoy e Baptistella Indústria e Comércio de Produtos de Higiene LTDA) x 8 tiras"
  },
  {
    "code" : "7898654700482",
    "display" : "Fralda Adulta Needs Care M (Godoy e Baptistella Indústria e Comércio de Produtos de Higiene LTDA) x 16 tiras"
  },
  {
    "code" : "7898654700031",
    "display" : "Fralda Adulta Needs Care M (Godoy e Baptistella Indústria e Comércio de Produtos de Higiene LTDA) x 8 tiras"
  },
  {
    "code" : "7898654700291",
    "display" : "Fralda Adulta Needs Care XG (Godoy e Baptistella Indústria e Comércio de Produtos de Higiene LTDA) x 14 tiras"
  },
  {
    "code" : "7898654700017",
    "display" : "Fralda Adulta Needs Care XG (Godoy e Baptistella Indústria e Comércio de Produtos de Higiene LTDA) x 7 tiras"
  },
  {
    "code" : "7898924154847",
    "display" : "Fralda Adulta Prevent Care Diurna EG (Haryon Indústria e Comércio de Fraldas e Cosméticos LTDA) x 7 tiras"
  },
  {
    "code" : "7898138782775",
    "display" : "Fralda Adulta Prevent Care Diurna EG (Roger do Brasil Indústria de Cosméticos e Produtos de Higiene Pessoal) x 7 tiras"
  },
  {
    "code" : "7898924154830",
    "display" : "Fralda Adulta Prevent Care Diurna G (Haryon Indústria e Comércio de Fraldas e Cosméticos LTDA) x 8 tiras"
  },
  {
    "code" : "7898138782768",
    "display" : "Fralda Adulta Prevent Care Diurna G (Roger do Brasil Indústria de Cosméticos e Produtos de Higiene Pessoal) x 8 tiras"
  },
  {
    "code" : "7898924154823",
    "display" : "Fralda Adulta Prevent Care Diurna M (Haryon Indústria e Comércio de Fraldas e Cosméticos LTDA) x 8 tiras"
  },
  {
    "code" : "7898138782751",
    "display" : "Fralda Adulta Prevent Care Diurna M (Roger do Brasil Indústria de Cosméticos e Produtos de Higiene Pessoal) x 8 tiras"
  },
  {
    "code" : "7898662330039",
    "display" : "Fralda Adulta Sanar Senior G (WF Indústria e Comércio de Fraldas LTDA) x 8 tiras"
  },
  {
    "code" : "7898662330022",
    "display" : "Fralda Adulta Sanar Senior M (WF Indústria e Comércio de Fraldas LTDA) x 8 tiras"
  },
  {
    "code" : "7898662330046",
    "display" : "Fralda Adulta Sanar Senior XG (WF Indústria e Comércio de Fraldas LTDA) x 7 tiras"
  },
  {
    "code" : "7898136150484",
    "display" : "Fralda Adulta Sentir Bem G (ERS Indústria e Comércio de Produtos de Higiene e Limpeza LTDA) x 8 tiras"
  },
  {
    "code" : "7898136150477",
    "display" : "Fralda Adulta Sentir Bem M (ERS Indústria e Comércio de Produtos de Higiene e Limpeza LTDA) x 8 tiras"
  },
  {
    "code" : "7898136150491",
    "display" : "Fralda Adulta Sentir Bem XG (ERS Indústria e Comércio de Produtos de Higiene e Limpeza LTDA) x 7 tiras"
  },
  {
    "code" : "7898914605250",
    "display" : "Fralda Adulta Vita Magna EG (Fraldas CK Indústria e Comércio LTDA) x 20 tiras"
  },
  {
    "code" : "7898914605274",
    "display" : "Fralda Adulta Vita Magna G (Fraldas CK Indústria e Comércio LTDA) x 20 tiras"
  },
  {
    "code" : "7898914605076",
    "display" : "Fralda Adulta Vita Magna M (Fraldas CK Indústria e Comércio LTDA) x 20 tiras"
  },
  {
    "code" : "7898662330077",
    "display" : "Fralda Adulta WF Master Confort G (WF Indústria e Comércio de Fraldas LTDA) x 8 tiras"
  },
  {
    "code" : "7898662330060",
    "display" : "Fralda Adulta WF Master Confort M (WF Indústria e Comércio de Fraldas LTDA) x 8 tiras"
  },
  {
    "code" : "7898662330053",
    "display" : "Fralda Adulta WF Master Confort P (WF Indústria e Comércio de Fraldas LTDA) x 10 tiras"
  },
  {
    "code" : "7898662330084",
    "display" : "Fralda Adulta WF Master Confort XG (WF Indústria e Comércio de Fraldas LTDA) x 7 tiras"
  },
  {
    "code" : "7898662330329",
    "display" : "Fralda Adulta WF Master Confort XXG (WF Indústria e Comércio de Fraldas LTDA) x 7 tiras"
  },
  {
    "code" : "7896104605462",
    "display" : "Fralda Adultcare Econômica EG (Incofral de Bom Jardim Indústria, Comércio, Importação e Exportação de Produtos Descartáveis e de Higiene LTDA) x 21 tiras"
  },
  {
    "code" : "7896104605363",
    "display" : "Fralda Adultcare Econômica G (Topfral Indústria e Comércio de Produtos Higiênicos LTDA) x 24 tiras"
  },
  {
    "code" : "7896104605653",
    "display" : "Fralda Adultcare Econômica M (Incofral de Bom Jardim Indústria, Comércio, Importação e Exportação de Produtos Descartáveis e de Higiene LTDA) x 30 tiras"
  },
  {
    "code" : "7896104605356",
    "display" : "Fralda Adultcare Econômica M (Topfral Indústria e Comércio de Produtos Higiênicos LTDA) x 26 tiras"
  },
  {
    "code" : "7896104605264",
    "display" : "Fralda Adultcare EG (Topfral Indústria e Comércio de Produtos Higiênicos LTDA) x 7 tiras"
  },
  {
    "code" : "7896104605110",
    "display" : "Fralda Adultcare G (Topfral Indústria e Comércio de Produtos Higiênicos LTDA) x 8 tiras"
  },
  {
    "code" : "7896104605127",
    "display" : "Fralda Adultcare M (Topfral Indústria e Comércio de Produtos Higiênicos LTDA) x 10 tiras"
  },
  {
    "code" : "7896104605332",
    "display" : "Fralda Adultcare Premium EG (Topfral Indústria e Comércio de Produtos Higiênicos LTDA) x 7 tiras"
  },
  {
    "code" : "7896104605318",
    "display" : "Fralda Adultcare Premium G (Topfral Indústria e Comércio de Produtos Higiênicos LTDA) x 8 tiras"
  },
  {
    "code" : "7896104605325",
    "display" : "Fralda Adultcare Premium M (Topfral Indústria e Comércio de Produtos Higiênicos LTDA) x 10 tiras"
  },
  {
    "code" : "7896272308523",
    "display" : "Fralda Adultex EG (Divina Dama Indústria e Comércio LTDA) x 8 tiras"
  },
  {
    "code" : "7896272308516",
    "display" : "Fralda Adultex G (Divina Dama Indústria e Comércio LTDA) x 8 tiras"
  },
  {
    "code" : "7896272308509",
    "display" : "Fralda Adultex M (Divina Dama Indústria e Comércio LTDA) x 8 tiras"
  },
  {
    "code" : "7898146000953",
    "display" : "Fralda Adultfral Dia e Noite EG (Higi-Plus Indústria de Produtos Higiênicos Eireli) x 26 tiras"
  },
  {
    "code" : "7898146000922",
    "display" : "Fralda Adultfral Dia e Noite EG (Higi-Plus Indústria de Produtos Higiênicos Eireli) x 7 tiras"
  },
  {
    "code" : "7898146000946",
    "display" : "Fralda Adultfral Dia e Noite G (Higi-Plus Indústria de Produtos Higiênicos Eireli) x 28 tiras"
  },
  {
    "code" : "7898146000632",
    "display" : "Fralda Adultfral Dia e Noite G (Higi-Plus Indústria de Produtos Higiênicos Eireli) x 8 tiras"
  },
  {
    "code" : "7898146000939",
    "display" : "Fralda Adultfral Dia e Noite M (Higi-Plus Indústria de Produtos Higiênicos Eireli) x 30 tiras"
  },
  {
    "code" : "7898146000625",
    "display" : "Fralda Adultfral Dia e Noite M (Higi-Plus Indústria de Produtos Higiênicos Eireli) x 8 tiras"
  },
  {
    "code" : "7898146000915",
    "display" : "Fralda Adultfral Dia e Noite P (Higi-Plus Indústria de Produtos Higiênicos Eireli) x 10 tiras"
  },
  {
    "code" : "7898224890094",
    "display" : "Fralda Adultmax Maturidade G (Active Indústria de Cosméticos S.A.) x 8 tiras"
  },
  {
    "code" : "7898224890087",
    "display" : "Fralda Adultmax Maturidade M (Active Indústria de Cosméticos S.A.) x 8 tiras"
  },
  {
    "code" : "7898224890629",
    "display" : "Fralda Adultmax Maturidade Plus G (Active Indústria de Cosméticos S.A.) x 20 tiras"
  },
  {
    "code" : "7898224890612",
    "display" : "Fralda Adultmax Maturidade Plus M (Active Indústria de Cosméticos S.A.) x 20 tiras"
  },
  {
    "code" : "7896914002963",
    "display" : "Fralda Adulto Bem Estar Comfort Econômica EG (Carta Goiás Indústria e Comércio de Papéis S.A.) x 18 tiras"
  },
  {
    "code" : "7896914002956",
    "display" : "Fralda Adulto Bem Estar Comfort Econômica G (Carta Goiás Indústria e Comércio de Papéis S.A.) x 26 tiras"
  },
  {
    "code" : "7896914002949",
    "display" : "Fralda Adulto Bem Estar Comfort Econômica M (Carta Goiás Indústria e Comércio de Papéis S.A.) x 26 tiras"
  },
  {
    "code" : "7896914002932",
    "display" : "Fralda Adulto Bem Estar Comfort EG (Carta Goiás Indústria e Comércio de Papéis S.A.) x 7 tiras"
  },
  {
    "code" : "7896914002925",
    "display" : "Fralda Adulto Bem Estar Comfort G (Carta Goiás Indústria e Comércio de Papéis S.A.) x 8 tiras"
  },
  {
    "code" : "7896914003267",
    "display" : "Fralda Adulto Bem Estar Comfort Hiperpacote EG (Carta Goiás Indústria e Comércio de Papéis S.A.) x 36 tiras"
  },
  {
    "code" : "7896914003250",
    "display" : "Fralda Adulto Bem Estar Comfort Hiperpacote G (Carta Goiás Indústria e Comércio de Papéis S.A.) x 44 tiras"
  },
  {
    "code" : "7896914003243",
    "display" : "Fralda Adulto Bem Estar Comfort Hiperpacote M (Carta Goiás Indústria e Comércio de Papéis S.A.) x 44 tiras"
  },
  {
    "code" : "7896914002918",
    "display" : "Fralda Adulto Bem Estar Comfort M (Carta Goiás Indústria e Comércio de Papéis S.A.) x 8 tiras"
  },
  {
    "code" : "7898934650889",
    "display" : "Fralda Adulto Big Comfort G (Plena Indústria de Fraldas Eireli) x 8 tiras"
  },
  {
    "code" : "7898934650872",
    "display" : "Fralda Adulto Big Comfort M (Plena Indústria de Fraldas Eireli) x 8 tiras"
  },
  {
    "code" : "7898960026092",
    "display" : "Fralda Adulto Big Comfort P (Plena Indústria de Fraldas Eireli) x 9 tiras"
  },
  {
    "code" : "7898934650865",
    "display" : "Fralda Adulto Big Comfort XG (Plena Indústria de Fraldas Eireli) x 7 tiras"
  },
  {
    "code" : "7896914003120",
    "display" : "Fralda Adulto Confiance Comfort G (Carta Goiás Indústria e Comércio de Papéis S.A.) x 8 tiras"
  },
  {
    "code" : "7896914003113",
    "display" : "Fralda Adulto Confiance Comfort M (Carta Goiás Indústria e Comércio de Papéis S.A.) x 8 tiras"
  },
  {
    "code" : "7896914003137",
    "display" : "Fralda Adulto Confiance Comfort XG (Carta Goiás Indústria e Comércio de Papéis S.A.) x 7 tiras"
  },
  {
    "code" : "7898934650520",
    "display" : "Fralda Adulto Master Care G (Plena Indústria de Fraldas Eireli) x 8 tiras"
  },
  {
    "code" : "7898934650537",
    "display" : "Fralda Adulto Master Care M (Plena Indústria de Fraldas Eireli) x 8 tiras"
  },
  {
    "code" : "7898934650551",
    "display" : "Fralda Adulto Master Care P (Plena Indústria de Fraldas Eireli) x 9 tiras"
  },
  {
    "code" : "7898934650544",
    "display" : "Fralda Adulto Master Care XG (Plena Indústria de Fraldas Eireli) x 7 tiras"
  },
  {
    "code" : "7898506370344",
    "display" : "Fralda Adulto MaxFral Econômico G (Godoy e Baptistella Indústria e Comércio de Produtos de Higiene LTDA) x 24 tiras"
  },
  {
    "code" : "7898506370368",
    "display" : "Fralda Adulto MaxFral Econômico M (Godoy e Baptistella Indústria e Comércio de Produtos de Higiene LTDA) x 24 tiras"
  },
  {
    "code" : "7898960026030",
    "display" : "Fralda Adulto Plena Confort G (Plena Indústria de Fraldas Eireli) x 8 tiras"
  },
  {
    "code" : "7898960026016",
    "display" : "Fralda Adulto Plena Confort M (Plena Indústria de Fraldas Eireli) x 8 tiras"
  },
  {
    "code" : "7898960026023",
    "display" : "Fralda Adulto Plena Confort XG (Plena Indústria de Fraldas Eireli) x 7 tiras"
  },
  {
    "code" : "7898506370146",
    "display" : "Fralda Adulto Pró Senior Econômico G (Godoy e Baptistella Indústria e Comércio de Produtos de Higiene LTDA) x 30 tiras"
  },
  {
    "code" : "7898506370139",
    "display" : "Fralda Adulto Pró Senior Econômico M (Godoy e Baptistella Indústria e Comércio de Produtos de Higiene LTDA) x 30 tiras"
  },
  {
    "code" : "7898506370207",
    "display" : "Fralda Adulto Pró Senior Econômico XG (Godoy e Baptistella Indústria e Comércio de Produtos de Higiene LTDA) x 26 tiras"
  },
  {
    "code" : "7898957747047",
    "display" : "Fralda Affection Pacote Econômico EG (Johan e Stefani LTDA) x 26 tiras"
  },
  {
    "code" : "7898957747030",
    "display" : "Fralda Affection Pacote Econômico G (Johan e Stefani LTDA) x 28 tiras"
  },
  {
    "code" : "7898957747023",
    "display" : "Fralda Affection Pacote Econômico M (Johan e Stefani LTDA) x 30 tiras"
  },
  {
    "code" : "7898957747016",
    "display" : "Fralda Affection Pacote Econômico P (Johan e Stefani LTDA) x 32 tiras"
  },
  {
    "code" : "7898957747122",
    "display" : "Fralda Affection Soft Geriatric EG (Johan e Stefani LTDA) x 8 tiras"
  },
  {
    "code" : "7898957747092",
    "display" : "Fralda Affection Soft Geriatric G (Johan e Stefani LTDA) x 8 tiras"
  },
  {
    "code" : "7898957747085",
    "display" : "Fralda Affection Soft Geriatric M (Johan e Stefani LTDA) x 8 tiras"
  },
  {
    "code" : "7898957747115",
    "display" : "Fralda Affection Soft Geriatric P (Johan e Stefani LTDA) x 8 tiras"
  },
  {
    "code" : "7898064035808",
    "display" : "Fralda Affective Basic G (Mabesa do Brasil Participações LTDA) x 8 tiras"
  },
  {
    "code" : "7898064034801",
    "display" : "Fralda Affective Discreet Elastic (Mabesa do Brasil Participações LTDA) x 10 tiras"
  },
  {
    "code" : "7898914605021",
    "display" : "Fralda Aga Senior Adult EG (Fraldas CK Indústria e Comércio LTDA) x 21 tiras"
  },
  {
    "code" : "7898914605182",
    "display" : "Fralda Aga Senior Adult G (Fraldas CK Indústria e Comércio LTDA) x 24 tiras"
  },
  {
    "code" : "7898914605199",
    "display" : "Fralda Aga Senior Adult M (Fraldas CK Indústria e Comércio LTDA) x 24 tiras"
  },
  {
    "code" : "7898914605137",
    "display" : "Fralda Aga Senior Adult M (Fraldas CK Indústria e Comércio LTDA) x 8 tiras"
  },
  {
    "code" : "7898914605144",
    "display" : "Fralda Aga Senior EG (Fraldas CK Indústria e Comércio LTDA) x 7 tiras"
  },
  {
    "code" : "7898914605120",
    "display" : "Fralda Aga Senior G (Fraldas CK Indústria e Comércio LTDA) x 8 tiras"
  },
  {
    "code" : "7898204648936",
    "display" : "Fralda Ali Master Premium EG (Icofa Indústria e Comércio de Fraldas e Absorventes LTDA) x 26 tiras"
  },
  {
    "code" : "7898204649087",
    "display" : "Fralda Ali Master Premium EG (Icofa Indústria e Comércio de Fraldas e Absorventes LTDA) x 7 tiras"
  },
  {
    "code" : "7898204648943",
    "display" : "Fralda Ali Master Premium G (Icofa Indústria e Comércio de Fraldas e Absorventes LTDA) x 28 tiras"
  },
  {
    "code" : "7898204649094",
    "display" : "Fralda Ali Master Premium G (Icofa Indústria e Comércio de Fraldas e Absorventes LTDA) x 8 tiras"
  },
  {
    "code" : "7898204648950",
    "display" : "Fralda Ali Master Premium M (Icofa Indústria e Comércio de Fraldas e Absorventes LTDA) x 30 tiras"
  },
  {
    "code" : "7898204649100",
    "display" : "Fralda Ali Master Premium M (Icofa Indústria e Comércio de Fraldas e Absorventes LTDA) x 8 tiras"
  },
  {
    "code" : "7898204649117",
    "display" : "Fralda Ali Master Premium P (Icofa Indústria e Comércio de Fraldas e Absorventes LTDA) x 32 tiras"
  },
  {
    "code" : "7896104606063",
    "display" : "Fralda Amorável Classic Econômica EG (Incofral de Bom Jardim Indústria, Comércio, Importação e Exportação de Produtos Descartáveis e de Higiene LTDA) x 14 tiras"
  },
  {
    "code" : "7896104606056",
    "display" : "Fralda Amorável Classic Econômica G (Incofral de Bom Jardim Indústria, Comércio, Importação e Exportação de Produtos Descartáveis e de Higiene LTDA) x 16 tiras"
  },
  {
    "code" : "7896104606049",
    "display" : "Fralda Amorável Classic Econômica M (Incofral de Bom Jardim Indústria, Comércio, Importação e Exportação de Produtos Descartáveis e de Higiene LTDA) x 20 tiras"
  },
  {
    "code" : "7896104606032",
    "display" : "Fralda Amorável Classic EG (Incofral de Bom Jardim Indústria, Comércio, Importação e Exportação de Produtos Descartáveis e de Higiene LTDA) x 7 tiras"
  },
  {
    "code" : "7896104606025",
    "display" : "Fralda Amorável Classic G (Incofral de Bom Jardim Indústria, Comércio, Importação e Exportação de Produtos Descartáveis e de Higiene LTDA) x 8 tiras"
  },
  {
    "code" : "7896104606018",
    "display" : "Fralda Amorável Classic M (Incofral de Bom Jardim Indústria, Comércio, Importação e Exportação de Produtos Descartáveis e de Higiene LTDA) x 10 tiras"
  },
  {
    "code" : "7896297301592",
    "display" : "Fralda Amorável G (Descart Top Plus Indústria e Comércio de Produtos para Higiene LTDA) x 10 tiras"
  },
  {
    "code" : "7896297302162",
    "display" : "Fralda Amorável Noturna G (Descart Top Plus Indústria e Comércio de Produtos para Higiene LTDA) x 10 tiras"
  },
  {
    "code" : "7896297302155",
    "display" : "Fralda Amorável Noturna M (Descart Top Plus Indústria e Comércio de Produtos para Higiene LTDA) x 12 tiras"
  },
  {
    "code" : "7896272306178",
    "display" : "Fralda Ampla Gerin G (Divina Dama Indústria e Comércio LTDA) x 24 tiras"
  },
  {
    "code" : "7896272309193",
    "display" : "Fralda Ampla Gerin G (Divina Dama Indústria e Comércio LTDA) x 8 tiras"
  },
  {
    "code" : "7896272306185",
    "display" : "Fralda Ampla Gerin M (Divina Dama Indústria e Comércio LTDA) x 24 tiras"
  },
  {
    "code" : "7896272309186",
    "display" : "Fralda Ampla Gerin M (Divina Dama Indústria e Comércio LTDA) x 8 tiras"
  },
  {
    "code" : "7896272309179",
    "display" : "Fralda Ampla Gerin P (Divina Dama Indústria e Comércio LTDA) x 8 tiras"
  },
  {
    "code" : "7898286505066",
    "display" : "Fralda Bem Care EG (Mardam Indústria e Comércio de Produtos de Higiene LTDA) x 7 tiras"
  },
  {
    "code" : "7898286505059",
    "display" : "Fralda Bem Care G (Mardam Indústria e Comércio de Produtos de Higiene LTDA) x 8 tiras"
  },
  {
    "code" : "7898286505042",
    "display" : "Fralda Bem Care M (Mardam Indústria e Comércio de Produtos de Higiene LTDA) x 8 tiras"
  },
  {
    "code" : "7898070761661",
    "display" : "Fralda Bifarma G (Divina Dama Indústria e Comércio LTDA) x 8 tiras"
  },
  {
    "code" : "7898070761654",
    "display" : "Fralda Bifarma M (Divina Dama Indústria e Comércio LTDA) x 8 tiras"
  },
  {
    "code" : "7898934650117",
    "display" : "Fralda Big Life Plus EG (Life do Brasil Indústria e Comércio de Fraldas e Cosméticos LTDA) x 8 tiras"
  },
  {
    "code" : "7898934650025",
    "display" : "Fralda Big Life Plus G (Life do Brasil Indústria e Comércio de Fraldas e Cosméticos LTDA) x 8 tiras"
  },
  {
    "code" : "7898934650018",
    "display" : "Fralda Big Life Plus M (Life do Brasil Indústria e Comércio de Fraldas e Cosméticos LTDA) x 8 tiras"
  },
  {
    "code" : "7898138782195",
    "display" : "Fralda Big Roger EG (Roger do Brasil Indústria de Cosméticos e Produtos de Higiene Pessoal) x 7 tiras"
  },
  {
    "code" : "7898138781877",
    "display" : "Fralda Big Roger G (Roger do Brasil Indústria de Cosméticos e Produtos de Higiene Pessoal) x 8 tiras"
  },
  {
    "code" : "7898138781860",
    "display" : "Fralda Big Roger M (Roger do Brasil Indústria de Cosméticos e Produtos de Higiene Pessoal) x 9 tiras"
  },
  {
    "code" : "7898138782188",
    "display" : "Fralda Big Roger Plus EG (Roger do Brasil Indústria de Cosméticos e Produtos de Higiene Pessoal) x 7 tiras"
  },
  {
    "code" : "7898138781853",
    "display" : "Fralda Big Roger Plus G (Roger do Brasil Indústria de Cosméticos e Produtos de Higiene Pessoal) x 8 tiras"
  },
  {
    "code" : "7898138781846",
    "display" : "Fralda Big Roger Plus M (Roger do Brasil Indústria de Cosméticos e Produtos de Higiene Pessoal) x 8 tiras"
  },
  {
    "code" : "7896012880371",
    "display" : "Fralda Bigfral Clássica Econômica G (Active Indústria de Cosméticos S.A.) x 20 tiras"
  },
  {
    "code" : "7896012880364",
    "display" : "Fralda Bigfral Clássica Econômica M (Active Indústria de Cosméticos S.A.) x 22 tiras"
  },
  {
    "code" : "7896012880388",
    "display" : "Fralda Bigfral Clássica Econômica XG (Active Indústria de Cosméticos S.A.) x 18 tiras"
  },
  {
    "code" : "7896012880340",
    "display" : "Fralda Bigfral Clássica G (Active Indústria de Cosméticos S.A.) x 7 tiras"
  },
  {
    "code" : "7896012880333",
    "display" : "Fralda Bigfral Clássica M (Active Indústria de Cosméticos S.A.) x 8 tiras"
  },
  {
    "code" : "7896012880326",
    "display" : "Fralda Bigfral Clássica P (Active Indústria de Cosméticos S.A.) x 9 tiras"
  },
  {
    "code" : "7896012880357",
    "display" : "Fralda Bigfral Clássica XG (Active Indústria de Cosméticos S.A.) x 7 tiras"
  },
  {
    "code" : "7896012801826",
    "display" : "Fralda Bigfral Confort G (Active Indústria de Cosméticos S.A.) x 8 tiras"
  },
  {
    "code" : "7896012801819",
    "display" : "Fralda Bigfral Confort M (Active Indústria de Cosméticos S.A.) x 8 tiras"
  },
  {
    "code" : "7896012880210",
    "display" : "Fralda Bigfral Derma Plus Econômica G (Active Indústria de Cosméticos S.A.) x 16 tiras"
  },
  {
    "code" : "7896012880203",
    "display" : "Fralda Bigfral Derma Plus Econômica M (Active Indústria de Cosméticos S.A.) x 18 tiras"
  },
  {
    "code" : "7896012880227",
    "display" : "Fralda Bigfral Derma Plus Econômica XG (Active Indústria de Cosméticos S.A.) x 14 tiras"
  },
  {
    "code" : "7896012880180",
    "display" : "Fralda Bigfral Derma Plus G (Active Indústria de Cosméticos S.A.) x 7 tiras"
  },
  {
    "code" : "7896012880159",
    "display" : "Fralda Bigfral Derma Plus JUV (Active Indústria de Cosméticos S.A.) x 10 tiras"
  },
  {
    "code" : "7896012880173",
    "display" : "Fralda Bigfral Derma Plus M (Active Indústria de Cosméticos S.A.) x 8 tiras"
  },
  {
    "code" : "7896012880166",
    "display" : "Fralda Bigfral Derma Plus P (Active Indústria de Cosméticos S.A.) x 9 tiras"
  },
  {
    "code" : "7896012880197",
    "display" : "Fralda Bigfral Derma Plus XG (Active Indústria de Cosméticos S.A.) x 7 tiras"
  },
  {
    "code" : "7896012800843",
    "display" : "Fralda Bigfral EG (Hypermarcas) x 7 tiras"
  },
  {
    "code" : "7896012801895",
    "display" : "Fralda Bigfral Noturna G (Hypermarcas) x 7 tiras"
  },
  {
    "code" : "7896012801888",
    "display" : "Fralda Bigfral Noturna M (Active Indústria de Cosméticos S.A.) x 8 tiras"
  },
  {
    "code" : "7896012800836",
    "display" : "Fralda Bigfral Plus Normal G (Active Indústria de Cosméticos S.A.) x 8 tiras"
  },
  {
    "code" : "7896012800829",
    "display" : "Fralda Bigfral Plus Normal M (Active Indústria de Cosméticos S.A.) x 9 tiras"
  },
  {
    "code" : "7896012800812",
    "display" : "Fralda Bigfral Plus Normal P (Active Indústria de Cosméticos S.A.) x 10 tiras"
  },
  {
    "code" : "7896012802441",
    "display" : "Fralda Bigfral Plus Prática G (Active Indústria de Cosméticos S.A.) x 16 tiras"
  },
  {
    "code" : "7896012802434",
    "display" : "Fralda Bigfral Plus Prática M (Active Indústria de Cosméticos S.A.) x 18 tiras"
  },
  {
    "code" : "7896012880302",
    "display" : "Fralda Bigfral Plus Regular Econômica G (Active Indústria de Cosméticos S.A.) x 18 tiras"
  },
  {
    "code" : "7896012880296",
    "display" : "Fralda Bigfral Plus Regular Econômica M (Active Indústria de Cosméticos S.A.) x 20 tiras"
  },
  {
    "code" : "7896012880319",
    "display" : "Fralda Bigfral Plus Regular Econômica XG (Active Indústria de Cosméticos S.A.) x 16 tiras"
  },
  {
    "code" : "7896012880272",
    "display" : "Fralda Bigfral Plus Regular G (Active Indústria de Cosméticos S.A.) x 7 tiras"
  },
  {
    "code" : "7896012880265",
    "display" : "Fralda Bigfral Plus Regular M (Active Indústria de Cosméticos S.A.) x 8 tiras"
  },
  {
    "code" : "7896012880258",
    "display" : "Fralda Bigfral Plus Regular P (Active Indústria de Cosméticos S.A.) x 9 tiras"
  },
  {
    "code" : "7896012880289",
    "display" : "Fralda Bigfral Plus Regular XG (Active Indústria de Cosméticos S.A.) x 7 tiras"
  },
  {
    "code" : "7896770900403",
    "display" : "Fralda Biofral Classic Generic EG (Essity do Brasil Indústria e Comércio LTDA) x 7 tiras"
  },
  {
    "code" : "7896770900397",
    "display" : "Fralda Biofral Classic Generic G (Essity do Brasil Indústria e Comércio LTDA) x 8 tiras"
  },
  {
    "code" : "7896770900410",
    "display" : "Fralda Biofral Classic Generic M (Essity do Brasil Indústria e Comércio LTDA) x 10 tiras"
  },
  {
    "code" : "7896770979812",
    "display" : "Fralda Biofral Classic Generic M (Essity do Brasil Indústria e Comércio LTDA) x 9 tiras"
  },
  {
    "code" : "7896770979829",
    "display" : "Fralda Biofral Classic Generic Mega EG (Essity do Brasil Indústria e Comércio LTDA) x 24 tiras"
  },
  {
    "code" : "7896770900335",
    "display" : "Fralda Biofral Classic Generic Mega EG (Essity do Brasil Indústria e Comércio LTDA) x 26 tiras"
  },
  {
    "code" : "7896770979843",
    "display" : "Fralda Biofral Classic Generic Mega G (Essity do Brasil Indústria e Comércio LTDA) x 28 tiras"
  },
  {
    "code" : "7896770900311",
    "display" : "Fralda Biofral Classic Generic Mega G (Essity do Brasil Indústria e Comércio LTDA) x 30 tiras"
  },
  {
    "code" : "7896770900304",
    "display" : "Fralda Biofral Classic Generic Mega M (Essity do Brasil Indústria e Comércio LTDA) x 30 tiras"
  },
  {
    "code" : "7896770979836",
    "display" : "Fralda Biofral Classic Generic Mega M (Essity do Brasil Indústria e Comércio LTDA) x 32 tiras"
  },
  {
    "code" : "7896770900540",
    "display" : "Fralda Biofral Confort Plus EG (Essity do Brasil Indústria e Comércio LTDA) x 7 tiras"
  },
  {
    "code" : "7896770900021",
    "display" : "Fralda Biofral Confort Plus G (Essity do Brasil Indústria e Comércio LTDA) x 8 tiras"
  },
  {
    "code" : "7896770900083",
    "display" : "Fralda Biofral Confort Plus M (Essity do Brasil Indústria e Comércio LTDA) x 10 tiras"
  },
  {
    "code" : "7896770900090",
    "display" : "Fralda Biofral Confort Plus P (Essity do Brasil Indústria e Comércio LTDA) x 12 tiras"
  },
  {
    "code" : "7896770900045",
    "display" : "Fralda Biofral Noite e Dia Premium EG (Essity do Brasil Indústria e Comércio LTDA) x 7 tiras"
  },
  {
    "code" : "7896770900014",
    "display" : "Fralda Biofral Noite e Dia Premium G (Essity do Brasil Indústria e Comércio LTDA) x 7 tiras"
  },
  {
    "code" : "7896770900069",
    "display" : "Fralda Biofral Noite e Dia Premium M (Essity do Brasil Indústria e Comércio LTDA) x 8 tiras"
  },
  {
    "code" : "7896770900076",
    "display" : "Fralda Biofral Noite e Dia Premium P (Essity do Brasil Indústria e Comércio LTDA) x 10 tiras"
  },
  {
    "code" : "7898656390858",
    "display" : "Fralda Calça Lifree Extra Absorção G/XG (Unicharm do Brasil Indústria e Comércio de Produtos de Higiene LTDA) x 8 tiras"
  },
  {
    "code" : "7898656390841",
    "display" : "Fralda Calça Lifree Extra Absorção P/M (Unicharm do Brasil Indústria e Comércio de Produtos de Higiene LTDA) x 8 tiras"
  },
  {
    "code" : "7898656390872",
    "display" : "Fralda Calça Lifree Super Conforto G/XG (Unicharm do Brasil Indústria e Comércio de Produtos de Higiene LTDA) x 8 tiras"
  },
  {
    "code" : "7898656390865",
    "display" : "Fralda Calça Lifree Super Conforto P/M (Unicharm do Brasil Indústria e Comércio de Produtos de Higiene LTDA) x 8 tiras"
  },
  {
    "code" : "7897891300547",
    "display" : "Fralda Carinho Soft Care Noturna G (Carinho Indústria, Comércio, Importação e Exportação LTDA) x 8 tiras"
  },
  {
    "code" : "7897891300578",
    "display" : "Fralda Carinho Soft Care Noturna M (Carinho Indústria, Comércio, Importação e Exportação LTDA) x 8 tiras"
  },
  {
    "code" : "7898914605038",
    "display" : "Fralda CK Adult EG (Fraldas CK Indústria e Comércio LTDA) x 7 tiras"
  },
  {
    "code" : "7898914605138",
    "display" : "Fralda CK Adult EG (Fraldas CK Indústria e Comércio LTDA) x 7 tiras"
  },
  {
    "code" : "7898914605014",
    "display" : "Fralda CK Adult G (Fraldas CK Indústria e Comércio LTDA) x 8 tiras"
  },
  {
    "code" : "7898914605212",
    "display" : "Fralda CK Adult M (Fraldas CK Indústria e Comércio LTDA) x 8 tiras"
  },
  {
    "code" : "7898914605205",
    "display" : "Fralda CK Adult P (Fraldas CK Indústria e Comércio LTDA) x 8 tiras"
  },
  {
    "code" : "7898914605175",
    "display" : "Fralda CK Noturna EG (Fraldas CK Indústria e Comércio LTDA) x 20 tiras"
  },
  {
    "code" : "7898914605168",
    "display" : "Fralda CK Noturna G (Fraldas CK Indústria e Comércio LTDA) x 20 tiras"
  },
  {
    "code" : "7898914605151",
    "display" : "Fralda CK Noturna M (Fraldas CK Indústria e Comércio LTDA) x 20 tiras"
  },
  {
    "code" : "7898067950030",
    "display" : "Fralda Clin Off Confort EG (Confecções Capricho LTDA) x 7 tiras"
  },
  {
    "code" : "7898067950016",
    "display" : "Fralda Clin Off Confort G (Confecções Capricho LTDA) x 8 tiras"
  },
  {
    "code" : "7898067950009",
    "display" : "Fralda Clin Off Confort M (Confecções Capricho LTDA) x 8 tiras"
  },
  {
    "code" : "7898067951228",
    "display" : "Fralda Clin Off EG (Clin Off do Brasil S.A.) x 5 tiras"
  },
  {
    "code" : "7898067950719",
    "display" : "Fralda Clin Off G (Clin Off do Brasil S.A.) x 6 tiras"
  },
  {
    "code" : "7898902458578",
    "display" : "Fralda Comfort Life Basic EG (Cahe Produtos Descartáveis LTDA) x 7 tiras"
  },
  {
    "code" : "7898902458561",
    "display" : "Fralda Comfort Life Basic G (Cahe Produtos Descartáveis LTDA) x 8 tiras"
  },
  {
    "code" : "7898902458554",
    "display" : "Fralda Comfort Life Basic M (Cahe Produtos Descartáveis LTDA) x 8 tiras"
  },
  {
    "code" : "7898902458677",
    "display" : "Fralda Comfort Life Plus Econômico EG (Cahe Produtos Descartáveis LTDA) x 26 tiras"
  },
  {
    "code" : "7898902458660",
    "display" : "Fralda Comfort Life Plus Econômico G (Cahe Produtos Descartáveis LTDA) x 30 tiras"
  },
  {
    "code" : "7898902458653",
    "display" : "Fralda Comfort Life Plus Econômico M (Cahe Produtos Descartáveis LTDA) x 30 tiras"
  },
  {
    "code" : "7898902458646",
    "display" : "Fralda Comfort Life Plus EG (Cahe Produtos Descartáveis LTDA) x 7 tiras"
  },
  {
    "code" : "7898902458639",
    "display" : "Fralda Comfort Life Plus G (Cahe Produtos Descartáveis LTDA) x 8 tiras"
  },
  {
    "code" : "7898902458622",
    "display" : "Fralda Comfort Life Plus M (Cahe Produtos Descartáveis LTDA) x 8 tiras"
  },
  {
    "code" : "7898303553735",
    "display" : "Fralda Comodidad EG (Viver Bem Indústria e Comércio LTDA) x 8 tiras"
  },
  {
    "code" : "7898303553728",
    "display" : "Fralda Comodidad G (Viver Bem Indústria e Comércio LTDA) x 8 tiras"
  },
  {
    "code" : "7898303553711",
    "display" : "Fralda Comodidad M (Viver Bem Indústria e Comércio LTDA) x 8 tiras"
  },
  {
    "code" : "7898303553704",
    "display" : "Fralda Comodidad P (Viver Bem Indústria e Comércio LTDA) x 10 tiras"
  },
  {
    "code" : "7898344817766",
    "display" : "Fralda Confiance Excellence Regular G (Aloés Indústria e Comércio LTDA) x 8 tiras"
  },
  {
    "code" : "7898344817759",
    "display" : "Fralda Confiance Excellence Regular M (Aloés Indústria e Comércio LTDA) x 8 tiras"
  },
  {
    "code" : "7898905111609",
    "display" : "Fralda Confort Care EG (Megafral Indústria e Comércio LTDA) x 7 tiras"
  },
  {
    "code" : "7898905111593",
    "display" : "Fralda Confort Care G (Megafral Indústria e Comércio LTDA) x 8 tiras"
  },
  {
    "code" : "7898905111586",
    "display" : "Fralda Confort Care M (Megafral Indústria e Comércio LTDA) x 8 tiras"
  },
  {
    "code" : "7898905111579",
    "display" : "Fralda Confort Care P (Megafral Indústria e Comércio LTDA) x 9 tiras"
  },
  {
    "code" : "7898197410343",
    "display" : "Fralda Confort Line EG (Hygimax do Brasil Indústria e Comércio de Produtos de Higiênicos LTDA) x 7 tiras"
  },
  {
    "code" : "7898197410336",
    "display" : "Fralda Confort Line G (Hygimax do Brasil Indústria e Comércio de Produtos de Higiênicos LTDA) x 8 tiras"
  },
  {
    "code" : "7898197410329",
    "display" : "Fralda Confort Line M (Hygimax do Brasil Indústria e Comércio de Produtos de Higiênicos LTDA) x 8 tiras"
  },
  {
    "code" : "7899700800095",
    "display" : "Fralda Confort Master Econômica EG (CCM Indústria e Comércio de Produtos Descartáveis S.A.) x 26 tiras"
  },
  {
    "code" : "7898931019269",
    "display" : "Fralda Confort Master Econômica G (CCM Indústria e Comércio de Produtos Descartáveis S.A.) x 30 tiras"
  },
  {
    "code" : "7898931019252",
    "display" : "Fralda Confort Master Econômica M (CCM Indústria e Comércio de Produtos Descartáveis S.A.) x 30 tiras"
  },
  {
    "code" : "7898931019313",
    "display" : "Fralda Confort Master EG (Mafra Indústria e Comércio LTDA) x 7 tiras"
  },
  {
    "code" : "7898931019245",
    "display" : "Fralda Confort Master G (Mafra Indústria e Comércio LTDA) x 8 tiras"
  },
  {
    "code" : "7898931019238",
    "display" : "Fralda Confort Master M (Mafra Indústria e Comércio LTDA) x 8 tiras"
  },
  {
    "code" : "7899700801115",
    "display" : "Fralda Confort Master P (CCM Indústria e Comércio de Produtos Descartáveis S.A.) x 10 tiras"
  },
  {
    "code" : "7899700802006",
    "display" : "Fralda Confort Master Premium EG (CCM Indústria e Comércio de Produtos Descartáveis S.A.) x 7 tiras"
  },
  {
    "code" : "7899700801993",
    "display" : "Fralda Confort Master Premium G (CCM Indústria e Comércio de Produtos Descartáveis S.A.) x 8 tiras"
  },
  {
    "code" : "7899700801986",
    "display" : "Fralda Confort Master Premium M (CCM Indústria e Comércio de Produtos Descartáveis S.A.) x 8 tiras"
  },
  {
    "code" : "7899700801979",
    "display" : "Fralda Confort Master Premium P (CCM Indústria e Comércio de Produtos Descartáveis S.A.) x 10 tiras"
  },
  {
    "code" : "7899700801924",
    "display" : "Fralda Confortfral Econômica EG (CCM Indústria e Comércio de Produtos Descartáveis S.A.) x 26 tiras"
  },
  {
    "code" : "7899700801917",
    "display" : "Fralda Confortfral Econômica G (CCM Indústria e Comércio de Produtos Descartáveis S.A.) x 30 tiras"
  },
  {
    "code" : "7899700801931",
    "display" : "Fralda Confortfral Econômica M (CCM Indústria e Comércio de Produtos Descartáveis S.A.) x 30 tiras"
  },
  {
    "code" : "7899700801962",
    "display" : "Fralda Confortfral Regular EG (CCM Indústria e Comércio de Produtos Descartáveis S.A.) x 7 tiras"
  },
  {
    "code" : "7899700801955",
    "display" : "Fralda Confortfral Regular G (CCM Indústria e Comércio de Produtos Descartáveis S.A.) x 8 tiras"
  },
  {
    "code" : "7899700801948",
    "display" : "Fralda Confortfral Regular M (CCM Indústria e Comércio de Produtos Descartáveis S.A.) x 8 tiras"
  },
  {
    "code" : "7898135920095",
    "display" : "Fralda Conforto Mania G (Baby Mania Fraldas Descartáveis LTDA) x 8 tiras"
  },
  {
    "code" : "7898135920101",
    "display" : "Fralda Conforto Mania M (Baby Mania Fraldas Descartáveis LTDA) x 10 tiras"
  },
  {
    "code" : "7806500773603",
    "display" : "Fralda Cotidian G (Melhoramentos CMCP LTDA) x 8 tiras"
  },
  {
    "code" : "7806500773405",
    "display" : "Fralda Cotidian M (Melhoramentos CMCP LTDA) x 8 tiras"
  },
  {
    "code" : "7896061993046",
    "display" : "Fralda Cotidian Plus Noturna G (Melhoramentos CMCP LTDA) x 8 tiras"
  },
  {
    "code" : "7896061993015",
    "display" : "Fralda Cotidian Plus Noturna M (Melhoramentos CMCP LTDA) x 9 tiras"
  },
  {
    "code" : "7896061990410",
    "display" : "Fralda Cotidian Plus Noturna XG (Melhoramentos CMCP LTDA) x 7 tiras"
  },
  {
    "code" : "7896061990403",
    "display" : "Fralda Cotidian XG (Melhoramentos CMCP LTDA) x 7 tiras"
  },
  {
    "code" : "7896104606261",
    "display" : "Fralda Dauf Econômica EG (Topfral Indústria e Comércio de Produtos Higiênicos LTDA) x 14 tiras"
  },
  {
    "code" : "7896104606254",
    "display" : "Fralda Dauf Econômica G (Topfral Indústria e Comércio de Produtos Higiênicos LTDA) x 16 tiras"
  },
  {
    "code" : "7896104606247",
    "display" : "Fralda Dauf Econômica M (Topfral Indústria e Comércio de Produtos Higiênicos LTDA) x 20 tiras"
  },
  {
    "code" : "7896104606230",
    "display" : "Fralda Dauf EG (Topfral Indústria e Comércio de Produtos Higiênicos LTDA) x 7 tiras"
  },
  {
    "code" : "7896104606223",
    "display" : "Fralda Dauf G (Topfral Indústria e Comércio de Produtos Higiênicos LTDA) x 8 tiras"
  },
  {
    "code" : "7896104606216",
    "display" : "Fralda Dauf M (Topfral Indústria e Comércio de Produtos Higiênicos LTDA) x 10 tiras"
  },
  {
    "code" : "7898911199127",
    "display" : "Fralda Delicata Soft EG (Forte Bella Indústria e Comércio de Cosméticos e Produtos de Higiene LTDA) x 7 tiras"
  },
  {
    "code" : "7898911199110",
    "display" : "Fralda Delicata Soft G (Forte Bella Indústria e Comércio de Cosméticos e Produtos de Higiene LTDA) x 8 tiras"
  },
  {
    "code" : "7898911199080",
    "display" : "Fralda Delicata Soft M (Forte Bella Indústria e Comércio de Cosméticos e Produtos de Higiene LTDA) x 8 tiras"
  },
  {
    "code" : "7898283812945",
    "display" : "Fralda Descarpack EG (Descarpack Descartáveis do Brasil LTDA) x 7 tiras"
  },
  {
    "code" : "7898283812938",
    "display" : "Fralda Descarpack G (Descarpack Descartáveis do Brasil LTDA) x 8 tiras"
  },
  {
    "code" : "7898283812921",
    "display" : "Fralda Descarpack M (Descarpack Descartáveis do Brasil LTDA) x 8 tiras"
  },
  {
    "code" : "7898283815670",
    "display" : "Fralda Descarpack P (Descarpack Descartáveis do Brasil LTDA) x 10 tiras"
  },
  {
    "code" : "7898283815298",
    "display" : "Fralda Descarpack Premium EG (Descarpack Descartáveis do Brasil LTDA) x 7 tiras"
  },
  {
    "code" : "7898283815281",
    "display" : "Fralda Descarpack Premium G (Descarpack Descartáveis do Brasil LTDA) x 8 tiras"
  },
  {
    "code" : "7898283815274",
    "display" : "Fralda Descarpack Premium M (Descarpack Descartáveis do Brasil LTDA) x 8 tiras"
  },
  {
    "code" : "7896877601432",
    "display" : "Fralda Diguifral Premium EG (Diguinho Indústria e Comércio de Fraldas LTDA) x 7 tiras"
  },
  {
    "code" : "7896877601425",
    "display" : "Fralda Diguifral Premium G (Diguinho Indústria e Comércio de Fraldas LTDA) x 8 tiras"
  },
  {
    "code" : "7896877601418",
    "display" : "Fralda Diguifral Premium M (Diguinho Indústria e Comércio de Fraldas LTDA) x 10 tiras"
  },
  {
    "code" : "7896272309131",
    "display" : "Fralda Droga Ética G (Divina Dama Indústria e Comércio LTDA) x 8 tiras"
  },
  {
    "code" : "7896272309148",
    "display" : "Fralda Droga Ética M (Divina Dama Indústria e Comércio LTDA) x 8 tiras"
  },
  {
    "code" : "7898070761630",
    "display" : "Fralda Droga Farma Ponte G (Divina Dama Indústria e Comércio LTDA) x 8 tiras"
  },
  {
    "code" : "7898070761623",
    "display" : "Fralda Droga Farma Ponte M (Divina Dama Indústria e Comércio LTDA) x 8 tiras"
  },
  {
    "code" : "7896272306710",
    "display" : "Fralda Droga Forte Farma M (Divina Dama Indústria e Comércio LTDA) x 8 tiras"
  },
  {
    "code" : "7898905915085",
    "display" : "Fralda Drogarias Atual M (Divina Dama Indústria e Comércio LTDA) x 8 tiras"
  },
  {
    "code" : "7896272310229",
    "display" : "Fralda Drogarias Guanabara G (Divina Dama Indústria e Comércio LTDA) x 24 tiras"
  },
  {
    "code" : "7896272310182",
    "display" : "Fralda Drogarias Guanabara G (Divina Dama Indústria e Comércio LTDA) x 8 tiras"
  },
  {
    "code" : "7896272310199",
    "display" : "Fralda Drogarias Guanabara M (Divina Dama Indústria e Comércio LTDA) x 8 tiras"
  },
  {
    "code" : "7896272308592",
    "display" : "Fralda Drogarias Legítima G (Divina Dama Indústria e Comércio LTDA) x 8 tiras"
  },
  {
    "code" : "7896272308585",
    "display" : "Fralda Drogarias Legítima M (Divina Dama Indústria e Comércio LTDA) x 8 tiras"
  },
  {
    "code" : "7896104605530",
    "display" : "Fralda Drogarias Mundial EG (Incofral de Bom Jardim Indústria, Comércio, Importação e Exportação de Produtos Descartáveis e de Higiene LTDA) x 7 tiras"
  },
  {
    "code" : "7896104605523",
    "display" : "Fralda Drogarias Mundial G (Incofral de Bom Jardim Indústria, Comércio, Importação e Exportação de Produtos Descartáveis e de Higiene LTDA) x 8 tiras"
  },
  {
    "code" : "7896104605516",
    "display" : "Fralda Drogarias Mundial M (Incofral de Bom Jardim Indústria, Comércio, Importação e Exportação de Produtos Descartáveis e de Higiene LTDA) x 10 tiras"
  },
  {
    "code" : "7898070760695",
    "display" : "Fralda Drogarias Ofertão G (Divina Dama Indústria e Comércio LTDA) x 8 tiras"
  },
  {
    "code" : "7896272310595",
    "display" : "Fralda Drogarias Ofertão M (Divina Dama Indústria e Comércio LTDA) x 8 tiras"
  },
  {
    "code" : "7896272310540",
    "display" : "Fralda Drogarias Tamoio M (Divina Dama Indústria e Comércio LTDA) x 8 tiras"
  },
  {
    "code" : "7908271300313",
    "display" : "Fralda Ever Care EG (Topfral Indústria e Comércio de Produtos Higiênicos LTDA) x 7 tiras"
  },
  {
    "code" : "7908271300320",
    "display" : "Fralda Ever Care G (Topfral Indústria e Comércio de Produtos Higiênicos LTDA) x 8 tiras"
  },
  {
    "code" : "7908271300337",
    "display" : "Fralda Ever Care M (Topfral Indústria e Comércio de Produtos Higiênicos LTDA) x 10 tiras"
  },
  {
    "code" : "7891522022341",
    "display" : "Fralda Fitcare Confort Econômico EG (Confecções Capricho LTDA) x 24 tiras"
  },
  {
    "code" : "7891522022334",
    "display" : "Fralda Fitcare Confort Econômico G (Confecções Capricho LTDA) x 30 tiras"
  },
  {
    "code" : "7891522022327",
    "display" : "Fralda Fitcare Confort Econômico M (Confecções Capricho LTDA) x 30 tiras"
  },
  {
    "code" : "7891522021344",
    "display" : "Fralda Fitcare Confort EG (Confecções Capricho LTDA) x 7 tiras"
  },
  {
    "code" : "7891522021337",
    "display" : "Fralda Fitcare Confort G (Confecções Capricho LTDA) x 8 tiras"
  },
  {
    "code" : "7891522021320",
    "display" : "Fralda Fitcare Confort M (Confecções Capricho LTDA) x 8 tiras"
  },
  {
    "code" : "7896297300946",
    "display" : "Fralda Gerialimp M (Descart Top Plus Indústria e Comércio de Produtos para Higiene LTDA) x 10 tiras"
  },
  {
    "code" : "7896064474030",
    "display" : "Fralda Geriamax Econômica EG (Ever Green Indústria e Comércio LTDA) x 22 tiras"
  },
  {
    "code" : "7896064474023",
    "display" : "Fralda Geriamax Econômica G (Ever Green Indústria e Comércio LTDA) x 24 tiras"
  },
  {
    "code" : "7896064474016",
    "display" : "Fralda Geriamax Econômica M (Ever Green Indústria e Comércio LTDA) x 26 tiras"
  },
  {
    "code" : "7896064475037",
    "display" : "Fralda Geriamax EG (Ever Green Indústria e Comércio LTDA) x 7 tiras"
  },
  {
    "code" : "7896064486170",
    "display" : "Fralda Geriamax G (Ever Green Indústria e Comércio LTDA) x 8 tiras"
  },
  {
    "code" : "7896064486163",
    "display" : "Fralda Geriamax M (Ever Green Indústria e Comércio LTDA) x 9 tiras"
  },
  {
    "code" : "7897760900427",
    "display" : "Fralda Geriatex Plus EG (Geriatex Indústria e Comércio LTDA) x 7 tiras"
  },
  {
    "code" : "7897760900748",
    "display" : "Fralda Geriatex Plus G (Geriatex Indústria e Comércio LTDA) x 7 tiras"
  },
  {
    "code" : "7897760900281",
    "display" : "Fralda Geriatex Plus G (Geriatex Indústria e Comércio LTDA) x 8 tiras"
  },
  {
    "code" : "7897760900274",
    "display" : "Fralda Geriatex Plus M (Geriatex Indústria e Comércio LTDA) x 10 tiras"
  },
  {
    "code" : "7897760900731",
    "display" : "Fralda Geriatex Plus M (Geriatex Indústria e Comércio LTDA) x 9 tiras"
  },
  {
    "code" : "7897760900762",
    "display" : "Fralda Geriatex Plus P (Geriatex Indústria e Comércio LTDA) x 10 tiras"
  },
  {
    "code" : "7897760900458",
    "display" : "Fralda Geriatex Premium EG (Geriatex Indústria e Comércio LTDA) x 7 tiras"
  },
  {
    "code" : "7897760900724",
    "display" : "Fralda Geriatex Premium G (Geriatex Indústria e Comércio LTDA) x 7 tiras"
  },
  {
    "code" : "7897760900434",
    "display" : "Fralda Geriatex Premium M (Geriatex Indústria e Comércio LTDA) x 9 tiras"
  },
  {
    "code" : "7897760900779",
    "display" : "Fralda Geriatex Premium P (Geriatex Indústria e Comércio LTDA) x 10 tiras"
  },
  {
    "code" : "7898620011147",
    "display" : "Fralda Geriátrica Blessfral EG (Biodont Indústria, Comércio, Importação e Exportação Eireli) x 7 tiras"
  },
  {
    "code" : "7898620011130",
    "display" : "Fralda Geriátrica Blessfral G (Biodont Indústria, Comércio, Importação e Exportação Eireli) x 8 tiras"
  },
  {
    "code" : "7898620011123",
    "display" : "Fralda Geriátrica Blessfral M (Biodont Indústria, Comércio, Importação e Exportação Eireli) x 8 tiras"
  },
  {
    "code" : "7898620011116",
    "display" : "Fralda Geriátrica Blessfral P (Biodont Indústria, Comércio, Importação e Exportação Eireli) x 10 tiras"
  },
  {
    "code" : "7898067951457",
    "display" : "Fralda Geriátrica Clinoff EG (Clin Off do Brasil S.A.) x 7 tiras"
  },
  {
    "code" : "7898067951440",
    "display" : "Fralda Geriátrica Clinoff G (Clin Off do Brasil S.A.) x 8 tiras"
  },
  {
    "code" : "7898067950702",
    "display" : "Fralda Geriátrica Clinoff M (Clin Off do Brasil S.A.) x 8 tiras"
  },
  {
    "code" : "7898931019832",
    "display" : "Fralda Geriátrica Confort Master Pacote Econômico EG (CCM Indústria e Comércio de Produtos Descartáveis S.A.) x 18 tiras"
  },
  {
    "code" : "7898931019825",
    "display" : "Fralda Geriátrica Confort Master Pacote Econômico G (CCM Indústria e Comércio de Produtos Descartáveis S.A.) x 20 tiras"
  },
  {
    "code" : "7898931019818",
    "display" : "Fralda Geriátrica Confort Master Pacote Econômico M (CCM Indústria e Comércio de Produtos Descartáveis S.A.) x 26 tiras"
  },
  {
    "code" : "7898931019801",
    "display" : "Fralda Geriátrica Confort Master Pacote Econômico P (CCM Indústria e Comércio de Produtos Descartáveis S.A.) x 30 tiras"
  },
  {
    "code" : "7898931019788",
    "display" : "Fralda Geriátrica Confort Master Pacote Regular EG (CCM Indústria e Comércio de Produtos Descartáveis S.A.) x 7 tiras"
  },
  {
    "code" : "7898931019771",
    "display" : "Fralda Geriátrica Confort Master Pacote Regular G (CCM Indústria e Comércio de Produtos Descartáveis S.A.) x 8 tiras"
  },
  {
    "code" : "7898931019764",
    "display" : "Fralda Geriátrica Confort Master Pacote Regular M (CCM Indústria e Comércio de Produtos Descartáveis S.A.) x 9 tiras"
  },
  {
    "code" : "7898931019757",
    "display" : "Fralda Geriátrica Confort Master Pacote Regular P (CCM Indústria e Comércio de Produtos Descartáveis S.A.) x 10 tiras"
  },
  {
    "code" : "7896480662967",
    "display" : "Fralda Geriátrica Enlace G (Ever Green Indústria e Comércio LTDA) x 8 tiras"
  },
  {
    "code" : "7896480662950",
    "display" : "Fralda Geriátrica Enlace M (Ever Green Indústria e Comércio LTDA) x 8 tiras"
  },
  {
    "code" : "7896480662974",
    "display" : "Fralda Geriátrica Enlace XG (Ever Green Indústria e Comércio LTDA) x 7 tiras"
  },
  {
    "code" : "7898960970289",
    "display" : "Fralda Geriátrica Fraltex G (Godoy e Baptistella Indústria e Comércio de Produtos de Higiene LTDA) x 30 tiras"
  },
  {
    "code" : "7898960970111",
    "display" : "Fralda Geriátrica Fraltex G (Godoy e Baptistella Indústria e Comércio de Produtos de Higiene LTDA) x 8 tiras"
  },
  {
    "code" : "7898960970272",
    "display" : "Fralda Geriátrica Fraltex M (Godoy e Baptistella Indústria e Comércio de Produtos de Higiene LTDA) x 30 tiras"
  },
  {
    "code" : "7898960970104",
    "display" : "Fralda Geriátrica Fraltex M (Godoy e Baptistella Indústria e Comércio de Produtos de Higiene LTDA) x 8 tiras"
  },
  {
    "code" : "7898960970296",
    "display" : "Fralda Geriátrica Fraltex XG (Godoy e Baptistella Indústria e Comércio de Produtos de Higiene LTDA) x 26 tiras"
  },
  {
    "code" : "7898960970128",
    "display" : "Fralda Geriátrica Fraltex XG (Godoy e Baptistella Indústria e Comércio de Produtos de Higiene LTDA) x 7 tiras"
  },
  {
    "code" : "7898400720610",
    "display" : "Fralda Geriátrica Guto Maxx EX (Indústria de Fraldas GBI LTDA) x 26 tiras"
  },
  {
    "code" : "7898400720580",
    "display" : "Fralda Geriátrica Guto Maxx EX (Indústria de Fraldas GBI LTDA) x 7 tiras"
  },
  {
    "code" : "7898400720603",
    "display" : "Fralda Geriátrica Guto Maxx G (Indústria de Fraldas GBI LTDA) x 30 tiras"
  },
  {
    "code" : "7898400720573",
    "display" : "Fralda Geriátrica Guto Maxx G (Indústria de Fraldas GBI LTDA) x 8 tiras"
  },
  {
    "code" : "7898400720597",
    "display" : "Fralda Geriátrica Guto Maxx M (Indústria de Fraldas GBI LTDA) x 30 tiras"
  },
  {
    "code" : "7898400720566",
    "display" : "Fralda Geriátrica Guto Maxx M (Indústria de Fraldas GBI LTDA) x 8 tiras"
  },
  {
    "code" : "7898914605113",
    "display" : "Fralda Geriátrica Intense Noite EG (Fraldas CK Indústria e Comércio LTDA) x 24 tiras"
  },
  {
    "code" : "7898914605052",
    "display" : "Fralda Geriátrica Intense Noite G (Fraldas CK Indústria e Comércio LTDA) x 24 tiras"
  },
  {
    "code" : "7898620011406",
    "display" : "Fralda Geriátrica Maxclean EG (Biodont Indústria, Comércio, Importação e Exportação Eireli) x 7 tiras"
  },
  {
    "code" : "7898620011390",
    "display" : "Fralda Geriátrica Maxclean G (Biodont Indústria, Comércio, Importação e Exportação Eireli) x 8 tiras"
  },
  {
    "code" : "7898620011383",
    "display" : "Fralda Geriátrica Maxclean M (Biodont Indústria, Comércio, Importação e Exportação Eireli) x 8 tiras"
  },
  {
    "code" : "7898620011376",
    "display" : "Fralda Geriátrica Maxclean P (Biodont Indústria, Comércio, Importação e Exportação Eireli) x 10 tiras"
  },
  {
    "code" : "7898286541088",
    "display" : "Fralda Geriátrica Slim EG (Mardam Indústria e Comércio de Produtos de Higiene LTDA) x 7 tiras"
  },
  {
    "code" : "7898286540197",
    "display" : "Fralda Geriátrica Slim G (Mardam Indústria e Comércio de Produtos de Higiene LTDA) x 8 tiras"
  },
  {
    "code" : "7898286541033",
    "display" : "Fralda Geriátrica Slim M (Mardam Indústria e Comércio de Produtos de Higiene LTDA) x 8 tiras"
  },
  {
    "code" : "7898039564869",
    "display" : "Fralda Geriátrica Super Geriátrico Confort EG (Eurofral Indústria de Produtos Higiênicos e Termoplásticos LTDA) x 7 tiras"
  },
  {
    "code" : "7898039564852",
    "display" : "Fralda Geriátrica Super Geriátrico Confort G (Eurofral Indústria de Produtos Higiênicos e Termoplásticos LTDA) x 8 tiras"
  },
  {
    "code" : "7898039564845",
    "display" : "Fralda Geriátrica Super Geriátrico Confort M (Eurofral Indústria de Produtos Higiênicos e Termoplásticos LTDA) x 8 tiras"
  },
  {
    "code" : "7898039564838",
    "display" : "Fralda Geriátrica Super Geriátrico Confort P (Eurofral Indústria de Produtos Higiênicos e Termoplásticos LTDA) x 10 tiras"
  },
  {
    "code" : "7898400720641",
    "display" : "Fralda Geriátrica Use Fral Master EX (Indústria de Fraldas GBI LTDA) x 26 tiras"
  },
  {
    "code" : "7898400720559",
    "display" : "Fralda Geriátrica Use Fral Master EX (Indústria de Fraldas GBI LTDA) x 7 tiras"
  },
  {
    "code" : "7898400720634",
    "display" : "Fralda Geriátrica Use Fral Master G (Indústria de Fraldas GBI LTDA) x 30 tiras"
  },
  {
    "code" : "7898400720542",
    "display" : "Fralda Geriátrica Use Fral Master G (Indústria de Fraldas GBI LTDA) x 8 tiras"
  },
  {
    "code" : "7898400720627",
    "display" : "Fralda Geriátrica Use Fral Master M (Indústria de Fraldas GBI LTDA) x 30 tiras"
  },
  {
    "code" : "7898400720535",
    "display" : "Fralda Geriátrica Use Fral Master M (Indústria de Fraldas GBI LTDA) x 8 tiras"
  },
  {
    "code" : "7898914605403",
    "display" : "Fralda Geriátrica Vita Magna EG (Fraldas CK Indústria e Comércio LTDA) x 7 tiras"
  },
  {
    "code" : "7898914605304",
    "display" : "Fralda Geriátrica Vita Magna G (Fraldas CK Indústria e Comércio LTDA) x 8 tiras"
  },
  {
    "code" : "7898914605229",
    "display" : "Fralda Geriátrica Vita Magna M (Fraldas CK Indústria e Comércio LTDA) x 8 tiras"
  },
  {
    "code" : "7896272310274",
    "display" : "Fralda Gerin Plus G (Divina Dama Indústria e Comércio LTDA) x 8 tiras"
  },
  {
    "code" : "7896272310281",
    "display" : "Fralda Gerin Plus M (Divina Dama Indústria e Comércio LTDA) x 8 tiras"
  },
  {
    "code" : "7897891300738",
    "display" : "Fralda Goldenfral EG (Carinho Indústria, Comércio, Importação e Exportação LTDA) x 7 tiras"
  },
  {
    "code" : "7897891300714",
    "display" : "Fralda Goldenfral G (Carinho Indústria, Comércio, Importação e Exportação LTDA) x 8 tiras"
  },
  {
    "code" : "7897891300721",
    "display" : "Fralda Goldenfral M (Carinho Indústria, Comércio, Importação e Exportação LTDA) x 8 tiras"
  },
  {
    "code" : "7898039563275",
    "display" : "Fralda Higifral Confort EG (Eurofral Indústria de Produtos Higiênicos e Termoplásticos LTDA) x 7 tiras"
  },
  {
    "code" : "7898039562544",
    "display" : "Fralda Higifral Confort G (Eurofral Indústria de Produtos Higiênicos e Termoplásticos LTDA) x 8 tiras"
  },
  {
    "code" : "7898039562537",
    "display" : "Fralda Higifral Confort M (Eurofral Indústria de Produtos Higiênicos e Termoplásticos LTDA) x 8 tiras"
  },
  {
    "code" : "7898039564814",
    "display" : "Fralda Higifral Confort Mega EG (Eurofral Indústria de Produtos Higiênicos e Termoplásticos LTDA) x 18 tiras"
  },
  {
    "code" : "7898039564807",
    "display" : "Fralda Higifral Confort Mega G (Eurofral Indústria de Produtos Higiênicos e Termoplásticos LTDA) x 20 tiras"
  },
  {
    "code" : "7898039564791",
    "display" : "Fralda Higifral Confort Mega M (Eurofral Indústria de Produtos Higiênicos e Termoplásticos LTDA) x 24 tiras"
  },
  {
    "code" : "7898039564784",
    "display" : "Fralda Higifral Confort Mega P (Eurofral Indústria de Produtos Higiênicos e Termoplásticos LTDA) x 30 tiras"
  },
  {
    "code" : "7898039562520",
    "display" : "Fralda Higifral Confort P (Eurofral Indústria de Produtos Higiênicos e Termoplásticos LTDA) x 10 tiras"
  },
  {
    "code" : "7898039563442",
    "display" : "Fralda Higifral Noite e Dia EG (Eurofral Indústria de Produtos Higiênicos e Termoplásticos LTDA) x 7 tiras"
  },
  {
    "code" : "7898039563435",
    "display" : "Fralda Higifral Noite e Dia G (Eurofral Indústria de Produtos Higiênicos e Termoplásticos LTDA) x 8 tiras"
  },
  {
    "code" : "7898039563428",
    "display" : "Fralda Higifral Noite e Dia M (Eurofral Indústria de Produtos Higiênicos e Termoplásticos LTDA) x 9 tiras"
  },
  {
    "code" : "7898039563411",
    "display" : "Fralda Higifral Noite e Dia P (Eurofral Indústria de Produtos Higiênicos e Termoplásticos LTDA) x 10 tiras"
  },
  {
    "code" : "7898039566115",
    "display" : "Fralda Higifral Premium Hiper Pack EG (Eurofral Indústria de Produtos Higiênicos e Termoplásticos LTDA) x 16 tiras"
  },
  {
    "code" : "7898039563466",
    "display" : "Fralda Higifral Premium Hiper Pack G (Eurofral Indústria de Produtos Higiênicos e Termoplásticos LTDA) x 18 tiras"
  },
  {
    "code" : "7898039563459",
    "display" : "Fralda Higifral Premium Hiper Pack M (Eurofral Indústria de Produtos Higiênicos e Termoplásticos LTDA) x 20 tiras"
  },
  {
    "code" : "7898902599028",
    "display" : "Fralda Hiper Seca G (Supragel de Maricá Indústria e Comércio de Descartáveis LTDA) x 8 tiras"
  },
  {
    "code" : "7898902599059",
    "display" : "Fralda Hiper Seca GG (Supragel de Maricá Indústria e Comércio de Descartáveis LTDA) x 8 tiras"
  },
  {
    "code" : "7898902599011",
    "display" : "Fralda Hiper Seca M (Supragel de Maricá Indústria e Comércio de Descartáveis LTDA) x 9 tiras"
  },
  {
    "code" : "7898902599073",
    "display" : "Fralda Hiper Seca Noturna G (Supragel de Maricá Indústria e Comércio de Descartáveis LTDA) x 7 tiras"
  },
  {
    "code" : "7898902599066",
    "display" : "Fralda Hiper Seca Noturna M (Supragel de Maricá Indústria e Comércio de Descartáveis LTDA) x 8 tiras"
  },
  {
    "code" : "7898558281469",
    "display" : "Fralda Home Care Adulto EG (Biobase Indústria e Comércio LTDA) x 7 tiras"
  },
  {
    "code" : "7898558281452",
    "display" : "Fralda Home Care Adulto G (Biobase Indústria e Comércio LTDA) x 8 tiras"
  },
  {
    "code" : "7898558281445",
    "display" : "Fralda Home Care Adulto M (Biobase Indústria e Comércio LTDA) x 8 tiras"
  },
  {
    "code" : "7898054954300",
    "display" : "Fralda Incontinence G (Medi House Indústria e Comércio de Produtos Cirúrgicos e Hospitalares Eireli) x 8 tiras"
  },
  {
    "code" : "7898054954270",
    "display" : "Fralda Incontinence M (Medi House Indústria e Comércio de Produtos Cirúrgicos e Hospitalares Eireli) x 8 tiras"
  },
  {
    "code" : "7891522117146",
    "display" : "Fralda Isacare EG (Confecções Capricho LTDA) x 7 tiras"
  },
  {
    "code" : "7891522117139",
    "display" : "Fralda Isacare G (Confecções Capricho LTDA) x 8 tiras"
  },
  {
    "code" : "7891522117122",
    "display" : "Fralda Isacare M (Confecções Capricho LTDA) x 8 tiras"
  },
  {
    "code" : "7898100320912",
    "display" : "Fralda Kisses EG (Midiz Indústria e Comércio de Fraldas LTDA) x 7 tiras"
  },
  {
    "code" : "7898100320110",
    "display" : "Fralda Kisses G (Midiz Indústria e Comércio de Fraldas LTDA) x 8 tiras"
  },
  {
    "code" : "7898100320103",
    "display" : "Fralda Kisses M (Midiz Indústria e Comércio de Fraldas LTDA) x 8 tiras"
  },
  {
    "code" : "7898100320578",
    "display" : "Fralda Kisses P (Midiz Indústria e Comércio de Fraldas LTDA) x 8 tiras"
  },
  {
    "code" : "7898124670307",
    "display" : "Fralda Longevita EG (Longevita Produtos Higiênicos LTDA) x 40 tiras"
  },
  {
    "code" : "7898124670444",
    "display" : "Fralda Longevita EG (Longevita Produtos Higiênicos LTDA) x 7 tiras"
  },
  {
    "code" : "7898124670246",
    "display" : "Fralda Longevita G (Longevita Produtos Higiênicos LTDA) x 40 tiras"
  },
  {
    "code" : "7898124670024",
    "display" : "Fralda Longevita G (Longevita Produtos Higiênicos LTDA) x 8 tiras"
  },
  {
    "code" : "7898124670239",
    "display" : "Fralda Longevita M (Longevita Produtos Higiênicos LTDA) x 40 tiras"
  },
  {
    "code" : "7898124670031",
    "display" : "Fralda Longevita M (Longevita Produtos Higiênicos LTDA) x 9 tiras"
  },
  {
    "code" : "7898124670017",
    "display" : "Fralda Longevita P (Longevita Produtos Higiênicos LTDA) x 10 tiras"
  },
  {
    "code" : "7898124670222",
    "display" : "Fralda Longevita P (Longevita Produtos Higiênicos LTDA) x 40 tiras"
  },
  {
    "code" : "7898936602091",
    "display" : "Fralda Mais Conforto Anatômica Noturna EG (Mais Conforto Produtos Descartáveis LTDA) x 8 tiras"
  },
  {
    "code" : "7898936602084",
    "display" : "Fralda Mais Conforto Anatômica Noturna G (Mais Conforto Produtos Descartáveis LTDA) x 8 tiras"
  },
  {
    "code" : "7898936602077",
    "display" : "Fralda Mais Conforto Anatômica Noturna M (Mais Conforto Produtos Descartáveis LTDA) x 10 tiras"
  },
  {
    "code" : "7898936602060",
    "display" : "Fralda Mais Conforto Premium EG (Mais Conforto Produtos Descartáveis LTDA) x 8 tiras"
  },
  {
    "code" : "7898936602053",
    "display" : "Fralda Mais Conforto Premium G (Mais Conforto Produtos Descartáveis LTDA) x 8 tiras"
  },
  {
    "code" : "7898936602046",
    "display" : "Fralda Mais Conforto Premium M (Mais Conforto Produtos Descartáveis LTDA) x 8 tiras"
  },
  {
    "code" : "7896064487863",
    "display" : "Fralda Masterfral Confort Econômica EG (Ever Green Indústria e Comércio LTDA) x 26 tiras"
  },
  {
    "code" : "7896064487856",
    "display" : "Fralda Masterfral Confort Econômica G (Ever Green Indústria e Comércio LTDA) x 30 tiras"
  },
  {
    "code" : "7896064487849",
    "display" : "Fralda Masterfral Confort Econômica M (Ever Green Indústria e Comércio LTDA) x 30 tiras"
  },
  {
    "code" : "7896064487832",
    "display" : "Fralda Masterfral Confort EG (Ever Green Indústria e Comércio LTDA) x 7 tiras"
  },
  {
    "code" : "7896064487825",
    "display" : "Fralda Masterfral Confort G (Ever Green Indústria e Comércio LTDA) x 8 tiras"
  },
  {
    "code" : "7896064487818",
    "display" : "Fralda Masterfral Confort M (Ever Green Indústria e Comércio LTDA) x 8 tiras"
  },
  {
    "code" : "7898286540869",
    "display" : "Fralda Mastersoft EG (Mardam Indústria e Comércio de Produtos de Higiene LTDA) x 26 tiras"
  },
  {
    "code" : "7898286540715",
    "display" : "Fralda Mastersoft EG (Mardam Indústria e Comércio de Produtos de Higiene LTDA) x 7 tiras"
  },
  {
    "code" : "7898286540562",
    "display" : "Fralda Mastersoft G (Mardam Indústria e Comércio de Produtos de Higiene LTDA) x 30 tiras"
  },
  {
    "code" : "7898286540265",
    "display" : "Fralda Mastersoft G (Mardam Indústria e Comércio de Produtos de Higiene LTDA) x 8 tiras"
  },
  {
    "code" : "7898286540555",
    "display" : "Fralda Mastersoft M (Mardam Indústria e Comércio de Produtos de Higiene LTDA) x 30 tiras"
  },
  {
    "code" : "7898286540258",
    "display" : "Fralda Mastersoft M (Mardam Indústria e Comércio de Produtos de Higiene LTDA) x 8 tiras"
  },
  {
    "code" : "7898286540357",
    "display" : "Fralda Mastersoft P (Mardam Indústria e Comércio de Produtos de Higiene LTDA) x 10 tiras"
  },
  {
    "code" : "7891522022235",
    "display" : "Fralda Maturi Care Econômico G (Confecções Capricho LTDA) x 30 tiras"
  },
  {
    "code" : "7891522022228",
    "display" : "Fralda Maturi Care Econômico M (Confecções Capricho LTDA) x 30 tiras"
  },
  {
    "code" : "7891522022242",
    "display" : "Fralda Maturi Care EG (Confecções Capricho LTDA) x 24 tiras"
  },
  {
    "code" : "7891522021245",
    "display" : "Fralda Maturi Care EG (Confecções Capricho LTDA) x 7 tiras"
  },
  {
    "code" : "7891522021238",
    "display" : "Fralda Maturi Care G (Confecções Capricho LTDA) x 8 tiras"
  },
  {
    "code" : "7891522021221",
    "display" : "Fralda Maturi Care M (Confecções Capricho LTDA) x 8 tiras"
  },
  {
    "code" : "7896282100384",
    "display" : "Fralda Maturitá G (Arrayanes Produtos Higiênicos Indústria e Comércio LTDA) x 8 tiras"
  },
  {
    "code" : "7896282100377",
    "display" : "Fralda Maturitá M (Arrayanes Produtos Higiênicos Indústria e Comércio LTDA) x 8 tiras"
  },
  {
    "code" : "7896282100391",
    "display" : "Fralda Maturitá P (Arrayanes Produtos Higiênicos Indústria e Comércio LTDA) x 10 tiras"
  },
  {
    "code" : "7896282101374",
    "display" : "Fralda Maturitá Plus Adulto G (Arrayanes Produtos Higiênicos Indústria e Comércio LTDA) x 8 tiras"
  },
  {
    "code" : "7896282101367",
    "display" : "Fralda Maturitá Plus Adulto M (Arrayanes Produtos Higiênicos Indústria e Comércio LTDA) x 8 tiras"
  },
  {
    "code" : "7898281622249",
    "display" : "Fralda Max Confort EG (Iris Indústria e Comércio de Produtos Descartáveis LTDA) x 7 tiras"
  },
  {
    "code" : "7898281621174",
    "display" : "Fralda Max Confort EG (Iris Indústria e Comércio de Produtos Descartáveis LTDA) x 7 tiras"
  },
  {
    "code" : "7898281622232",
    "display" : "Fralda Max Confort G (Iris Indústria e Comércio de Produtos Descartáveis LTDA) x 8 tiras"
  },
  {
    "code" : "7898281620566",
    "display" : "Fralda Max Confort G (Iris Indústria e Comércio de Produtos Descartáveis LTDA) x 8 tiras"
  },
  {
    "code" : "7898281622225",
    "display" : "Fralda Max Confort M (Iris Indústria e Comércio de Produtos Descartáveis LTDA) x 8 tiras"
  },
  {
    "code" : "7898281620559",
    "display" : "Fralda Max Confort M (Iris Indústria e Comércio de Produtos Descartáveis LTDA) x 8 tiras"
  },
  {
    "code" : "7898506370405",
    "display" : "Fralda MaxFral Top EG (Godoy e Baptistella Indústria e Comércio de Produtos de Higiene LTDA) x 7 tiras"
  },
  {
    "code" : "7898506370320",
    "display" : "Fralda MaxFral Top G (Godoy e Baptistella Indústria e Comércio de Produtos de Higiene LTDA) x 8 tiras"
  },
  {
    "code" : "7898506370351",
    "display" : "Fralda MaxFral Top M (Godoy e Baptistella Indústria e Comércio de Produtos de Higiene LTDA) x 8 tiras"
  },
  {
    "code" : "7898506370399",
    "display" : "Fralda MaxFral Top P (Godoy e Baptistella Indústria e Comércio de Produtos de Higiene LTDA) x 10 tiras"
  },
  {
    "code" : "7898054954232",
    "display" : "Fralda Medifral EG (Medi House Indústria e Comércio de Produtos Cirúrgicos e Hospitalares Eireli) x 6 tiras"
  },
  {
    "code" : "7898054954201",
    "display" : "Fralda Medifral P (Medi House Indústria e Comércio de Produtos Cirúrgicos e Hospitalares Eireli) x 8 tiras"
  },
  {
    "code" : "7898905111333",
    "display" : "Fralda Megafral Confort G (Megafral Indústria e Comércio LTDA) x 8 tiras"
  },
  {
    "code" : "7898905111340",
    "display" : "Fralda Megafral Confort GG (Megafral Indústria e Comércio LTDA) x 7 tiras"
  },
  {
    "code" : "7898905111326",
    "display" : "Fralda Megafral Confort M (Megafral Indústria e Comércio LTDA) x 8 tiras"
  },
  {
    "code" : "7898905111319",
    "display" : "Fralda Megafral Confort P (Megafral Indústria e Comércio LTDA) x 9 tiras"
  },
  {
    "code" : "7896104995754",
    "display" : "Fralda Mili Vita EG (Mili S.A.) x 7 tiras"
  },
  {
    "code" : "7896104995761",
    "display" : "Fralda Mili Vita G (Mili S.A.) x 8 tiras"
  },
  {
    "code" : "7896104995778",
    "display" : "Fralda Mili Vita M (Mili S.A.) x 9 tiras"
  },
  {
    "code" : "7896104995228",
    "display" : "Fralda Mili Vita Mega EG (Mili S.A.) x 21 tiras"
  },
  {
    "code" : "7896104995235",
    "display" : "Fralda Mili Vita Mega G (Mili S.A.) x 24 tiras"
  },
  {
    "code" : "7896104995242",
    "display" : "Fralda Mili Vita Mega M (Mili S.A.) x 27 tiras"
  },
  {
    "code" : "7896104995044",
    "display" : "Fralda Mili Vita P (Mili S.A.) x 10 tiras"
  },
  {
    "code" : "7896104995105",
    "display" : "Fralda Mili Vita P (Mili S.A.) x 10 tiras"
  },
  {
    "code" : "7898286541095",
    "display" : "Fralda Moderate Diurna EG (Mardam Indústria e Comércio de Produtos de Higiene LTDA) x 7 tiras"
  },
  {
    "code" : "7898286540210",
    "display" : "Fralda Moderate Diurna G (Mardam Indústria e Comércio de Produtos de Higiene LTDA) x 8 tiras"
  },
  {
    "code" : "7898286540203",
    "display" : "Fralda Moderate Diurna M (Mardam Indústria e Comércio de Produtos de Higiene LTDA) x 8 tiras"
  },
  {
    "code" : "7898286541637",
    "display" : "Fralda Moderate Econômico EG (Mardam Indústria e Comércio de Produtos de Higiene LTDA) x 26 tiras"
  },
  {
    "code" : "7898286541620",
    "display" : "Fralda Moderate Econômico G (Mardam Indústria e Comércio de Produtos de Higiene LTDA) x 30 tiras"
  },
  {
    "code" : "7898286541613",
    "display" : "Fralda Moderate Econômico M (Mardam Indústria e Comércio de Produtos de Higiene LTDA) x 30 tiras"
  },
  {
    "code" : "7891522015749",
    "display" : "Fralda Multifral EG (Confecções Capricho LTDA) x 7 tiras"
  },
  {
    "code" : "7891522015732",
    "display" : "Fralda Multifral G (Confecções Capricho LTDA) x 8 tiras"
  },
  {
    "code" : "7896064486095",
    "display" : "Fralda Natural Master Econômica G (Ever Green Indústria e Comércio LTDA) x 16 tiras"
  },
  {
    "code" : "7896064486101",
    "display" : "Fralda Natural Master Econômica M (Ever Green Indústria e Comércio LTDA) x 18 tiras"
  },
  {
    "code" : "7896064486309",
    "display" : "Fralda Natural Master EG (Ever Green Indústria e Comércio LTDA) x 7 tiras"
  },
  {
    "code" : "7896064486149",
    "display" : "Fralda Natural Master Normal G (Ever Green Indústria e Comércio LTDA) x 8 tiras"
  },
  {
    "code" : "7896064486125",
    "display" : "Fralda Natural Master Normal M (Ever Green Indústria e Comércio LTDA) x 9 tiras"
  },
  {
    "code" : "7896064486118",
    "display" : "Fralda Natural Master P (Ever Green Indústria e Comércio LTDA) x 12 tiras"
  },
  {
    "code" : "7896064486224",
    "display" : "Fralda Natural Master Premium Dia e Noite EG (Ever Green Indústria e Comércio LTDA) x 7 tiras"
  },
  {
    "code" : "7896064486217",
    "display" : "Fralda Natural Master Premium Dia e Noite G (Ever Green Indústria e Comércio LTDA) x 8 tiras"
  },
  {
    "code" : "7896064486200",
    "display" : "Fralda Natural Master Premium Dia e Noite M (Ever Green Indústria e Comércio LTDA) x 9 tiras"
  },
  {
    "code" : "7896064488822",
    "display" : "Fralda Natural Master Prime G/EG (Ever Green Indústria e Comércio LTDA) x 16 tiras"
  },
  {
    "code" : "7896064488815",
    "display" : "Fralda Natural Master Prime P/M (Ever Green Indústria e Comércio LTDA) x 16 tiras"
  },
  {
    "code" : "7898937840034",
    "display" : "Fralda Original Master G (Original Master Fábrica de Fraldas e Materiais Descartáveis LTDA) x 8 tiras"
  },
  {
    "code" : "7898937840027",
    "display" : "Fralda Original Master M (Original Master Fábrica de Fraldas e Materiais Descartáveis LTDA) x 8 tiras"
  },
  {
    "code" : "7893189457139",
    "display" : "Fralda Panvel Vida Plena EG (Mili S.A.) x 7 tiras"
  },
  {
    "code" : "7893189180310",
    "display" : "Fralda Panvel Vida Plena G (Mili S.A.) x 8 tiras"
  },
  {
    "code" : "7893189180303",
    "display" : "Fralda Panvel Vida Plena M (Mili S.A.) x 9 tiras"
  },
  {
    "code" : "7896007546879",
    "display" : "Fralda Plenitud Dia e Noite G (Kimberly-Clark Brasil Indústria e Comércio de Produtos de Higiene LTDA) x 7 tiras"
  },
  {
    "code" : "7896007520169",
    "display" : "Fralda Plenitud M (Kimberly-Clark Brasil Indústria e Comércio de Produtos de Higiene LTDA) x 8 tiras"
  },
  {
    "code" : "7896007520121",
    "display" : "Fralda Plenitud Noturna G (Kimberly-Clark Brasil Indústria e Comércio de Produtos de Higiene LTDA) x 8 tiras"
  },
  {
    "code" : "7896007520114",
    "display" : "Fralda Plenitud Noturna M (Kimberly-Clark Brasil Indústria e Comércio de Produtos de Higiene LTDA) x 8 tiras"
  },
  {
    "code" : "7896007546893",
    "display" : "Fralda Plenitud Supersec G (Kimberly-Clark Brasil Indústria e Comércio de Produtos de Higiene LTDA) x 20 tiras"
  },
  {
    "code" : "7896007546909",
    "display" : "Fralda Plenitud Supersec G (Kimberly-Clark Brasil Indústria e Comércio de Produtos de Higiene LTDA) x 7 tiras"
  },
  {
    "code" : "7896007546886",
    "display" : "Fralda Plenitud Supersec M (Kimberly-Clark Brasil Indústria e Comércio de Produtos de Higiene LTDA) x 22 tiras"
  },
  {
    "code" : "7896007520176",
    "display" : "Fralda Plenitud Supersec Regular G (Kimberly-Clark Brasil Indústria e Comércio de Produtos de Higiene LTDA) x 8 tiras"
  },
  {
    "code" : "7898124670437",
    "display" : "Fralda Popfral EG (Longevita Produtos Higiênicos LTDA) x 30 tiras"
  },
  {
    "code" : "7898124670390",
    "display" : "Fralda Popfral EG (Longevita Produtos Higiênicos LTDA) x 7 tiras"
  },
  {
    "code" : "7898124670420",
    "display" : "Fralda Popfral G (Longevita Produtos Higiênicos LTDA) x 30 tiras"
  },
  {
    "code" : "7898124670123",
    "display" : "Fralda Popfral G (Longevita Produtos Higiênicos LTDA) x 8 tiras"
  },
  {
    "code" : "7898124670413",
    "display" : "Fralda Popfral M (Longevita Produtos Higiênicos LTDA) x 30 tiras"
  },
  {
    "code" : "7898124670383",
    "display" : "Fralda Popfral M (Longevita Produtos Higiênicos LTDA) x 9 tiras"
  },
  {
    "code" : "7898124670376",
    "display" : "Fralda Popfral P (Longevita Produtos Higiênicos LTDA) x 10 tiras"
  },
  {
    "code" : "7898124670406",
    "display" : "Fralda Popfral P (Longevita Produtos Higiênicos LTDA) x 30 tiras"
  },
  {
    "code" : "7898954220055",
    "display" : "Fralda Privini Max EEG (Recanto Indústria e Comércio de Fraldas e Absorventes LTDA) x 15 tiras"
  },
  {
    "code" : "7898954220048",
    "display" : "Fralda Privini Max EG (Recanto Indústria e Comércio de Fraldas e Absorventes LTDA) x 15 tiras"
  },
  {
    "code" : "7898954220031",
    "display" : "Fralda Privini Max G (Recanto Indústria e Comércio de Fraldas e Absorventes LTDA) x 15 tiras"
  },
  {
    "code" : "7898954220024",
    "display" : "Fralda Privini Max M (Recanto Indústria e Comércio de Fraldas e Absorventes LTDA) x 15 tiras"
  },
  {
    "code" : "7898954220017",
    "display" : "Fralda Privini Max P (Recanto Indústria e Comércio de Fraldas e Absorventes LTDA) x 15 tiras"
  },
  {
    "code" : "7898506370191",
    "display" : "Fralda Pró Senior Pacotinho NE EG (Godoy e Baptistella Indústria e Comércio de Produtos de Higiene LTDA) x 7 tiras"
  },
  {
    "code" : "7898506370160",
    "display" : "Fralda Pró Senior Pacotinho NE G (Godoy e Baptistella Indústria e Comércio de Produtos de Higiene LTDA) x 8 tiras"
  },
  {
    "code" : "7898506370153",
    "display" : "Fralda Pró Senior Pacotinho NE M (Godoy e Baptistella Indústria e Comércio de Produtos de Higiene LTDA) x 8 tiras"
  },
  {
    "code" : "7898506370108",
    "display" : "Fralda Pró Senior Pacotinho NE P (Godoy e Baptistella Indústria e Comércio de Produtos de Higiene LTDA) x 10 tiras"
  },
  {
    "code" : "7898467286449",
    "display" : "Fralda Protfral Classic EG (Protdesc do Brasil Importação e Exportação LTDA) x 7 tiras"
  },
  {
    "code" : "7898467286432",
    "display" : "Fralda Protfral Classic G (Protdesc do Brasil Importação e Exportação LTDA) x 8 tiras"
  },
  {
    "code" : "7898467282021",
    "display" : "Fralda Protfral Classic M (Protdesc do Brasil Importação e Exportação LTDA) x 10 tiras"
  },
  {
    "code" : "7898467286951",
    "display" : "Fralda Protfral Econômico EG (Protdesc do Brasil Importação e Exportação LTDA) x 26 tiras"
  },
  {
    "code" : "7898467286944",
    "display" : "Fralda Protfral Econômico G (Protdesc do Brasil Importação e Exportação LTDA) x 30 tiras"
  },
  {
    "code" : "7898467286937",
    "display" : "Fralda Protfral Econômico M (Protdesc do Brasil Importação e Exportação LTDA) x 30 tiras"
  },
  {
    "code" : "7898467286463",
    "display" : "Fralda Protfral Plus EG (Protdesc do Brasil Importação e Exportação LTDA) x 7 tiras"
  },
  {
    "code" : "7898467286456",
    "display" : "Fralda Protfral Plus G (Protdesc do Brasil Importação e Exportação LTDA) x 8 tiras"
  },
  {
    "code" : "7898467282014",
    "display" : "Fralda Protfral Plus M (Protdesc do Brasil Importação e Exportação LTDA) x 10 tiras"
  },
  {
    "code" : "7899560805452",
    "display" : "Fralda Protfral Premium Econômico EG (Protdesc do Brasil Importação e Exportação LTDA) x 20 tiras"
  },
  {
    "code" : "7899560805445",
    "display" : "Fralda Protfral Premium Econômico G (Protdesc do Brasil Importação e Exportação LTDA) x 20 tiras"
  },
  {
    "code" : "7899560805421",
    "display" : "Fralda Protfral Premium Econômico M (Protdesc do Brasil Importação e Exportação LTDA) x 20 tiras"
  },
  {
    "code" : "7898467286364",
    "display" : "Fralda Protfral Premium Noturno EG (Protdesc do Brasil Importação e Exportação LTDA) x 7 tiras"
  },
  {
    "code" : "7898467286357",
    "display" : "Fralda Protfral Premium Noturno G (Protdesc do Brasil Importação e Exportação LTDA) x 8 tiras"
  },
  {
    "code" : "7898467282007",
    "display" : "Fralda Protfral Premium Noturno M (Protdesc do Brasil Importação e Exportação LTDA) x 10 tiras"
  },
  {
    "code" : "7899700800767",
    "display" : "Fralda Qualifral Econômica EG (CCM Indústria e Comércio de Produtos Descartáveis S.A.) x 26 tiras"
  },
  {
    "code" : "7899700800750",
    "display" : "Fralda Qualifral Econômica G (CCM Indústria e Comércio de Produtos Descartáveis S.A.) x 30 tiras"
  },
  {
    "code" : "7899700800743",
    "display" : "Fralda Qualifral Econômica M (CCM Indústria e Comércio de Produtos Descartáveis S.A.) x 30 tiras"
  },
  {
    "code" : "7899700801108",
    "display" : "Fralda Qualifral P (CCM Indústria e Comércio de Produtos Descartáveis S.A.) x 10 tiras"
  },
  {
    "code" : "7908079506061",
    "display" : "Fralda Qualifral Premium EG (CCM Indústria e Comércio de Produtos Descartáveis S.A.) x 7 tiras"
  },
  {
    "code" : "7908079506092",
    "display" : "Fralda Qualifral Premium G (CCM Indústria e Comércio de Produtos Descartáveis S.A.) x 8 tiras"
  },
  {
    "code" : "7908079506078",
    "display" : "Fralda Qualifral Premium M (CCM Indústria e Comércio de Produtos Descartáveis S.A.) x 8 tiras"
  },
  {
    "code" : "7908079506085",
    "display" : "Fralda Qualifral Premium P (CCM Indústria e Comércio de Produtos Descartáveis S.A.) x 10 tiras"
  },
  {
    "code" : "7899700800729",
    "display" : "Fralda Qualifral Regular EG (CCM Indústria e Comércio de Produtos Descartáveis S.A.) x 7 tiras"
  },
  {
    "code" : "7899700800736",
    "display" : "Fralda Qualifral Regular G (CCM Indústria e Comércio de Produtos Descartáveis S.A.) x 8 tiras"
  },
  {
    "code" : "7899700800712",
    "display" : "Fralda Qualifral Regular M (CCM Indústria e Comércio de Produtos Descartáveis S.A.) x 8 tiras"
  },
  {
    "code" : "7894994000633",
    "display" : "Fralda Qualy Life G (Tecnicare Indústria e Comércio LTDA) x 8 tiras"
  },
  {
    "code" : "7894994000626",
    "display" : "Fralda Qualy Life M (Tecnicare Indústria e Comércio LTDA) x 8 tiras"
  },
  {
    "code" : "7730207026994",
    "display" : "Fralda Readymod EG (Higiefarm Comércio, Importação e Exportação LTDA) x 14 tiras"
  },
  {
    "code" : "7730207012362",
    "display" : "Fralda Readymod G (Higiefarm Comércio, Importação e Exportação LTDA) x 8 tiras"
  },
  {
    "code" : "7730207012386",
    "display" : "Fralda Readymod M (Higiefarm Comércio, Importação e Exportação LTDA) x 8 tiras"
  },
  {
    "code" : "7730207028899",
    "display" : "Fralda Readysec G (Higiefarm Comércio, Importação e Exportação LTDA) x 8 tiras"
  },
  {
    "code" : "7730207028875",
    "display" : "Fralda Readysec M (Higiefarm Comércio, Importação e Exportação LTDA) x 8 tiras"
  },
  {
    "code" : "7730207028851",
    "display" : "Fralda Readysec P (Higiefarm Comércio, Importação e Exportação LTDA) x 8 tiras"
  },
  {
    "code" : "7899700800859",
    "display" : "Fralda Safety Confort Econômica EG (CCM Indústria e Comércio de Produtos Descartáveis S.A.) x 26 tiras"
  },
  {
    "code" : "7899700800842",
    "display" : "Fralda Safety Confort Econômica G (CCM Indústria e Comércio de Produtos Descartáveis S.A.) x 30 tiras"
  },
  {
    "code" : "7899700800835",
    "display" : "Fralda Safety Confort Econômica M (CCM Indústria e Comércio de Produtos Descartáveis S.A.) x 30 tiras"
  },
  {
    "code" : "7899700801061",
    "display" : "Fralda Safety Confort P (CCM Indústria e Comércio de Produtos Descartáveis S.A.) x 10 tiras"
  },
  {
    "code" : "7899700800828",
    "display" : "Fralda Safety Confort Regular EG (CCM Indústria e Comércio de Produtos Descartáveis S.A.) x 7 tiras"
  },
  {
    "code" : "7899700800811",
    "display" : "Fralda Safety Confort Regular G (CCM Indústria e Comércio de Produtos Descartáveis S.A.) x 8 tiras"
  },
  {
    "code" : "7899700800804",
    "display" : "Fralda Safety Confort Regular M (CCM Indústria e Comércio de Produtos Descartáveis S.A.) x 8 tiras"
  },
  {
    "code" : "7891522022143",
    "display" : "Fralda Sensaty Premium Noturna Econômica EG (Confecções Capricho LTDA) x 16 tiras"
  },
  {
    "code" : "7891522022136",
    "display" : "Fralda Sensaty Premium Noturna Econômica G (Confecções Capricho LTDA) x 20 tiras"
  },
  {
    "code" : "7891522022129",
    "display" : "Fralda Sensaty Premium Noturna Econômica M (Confecções Capricho LTDA) x 20 tiras"
  },
  {
    "code" : "7891522021146",
    "display" : "Fralda Sensaty Premium Noturna EG (Confecções Capricho LTDA) x 7 tiras"
  },
  {
    "code" : "7891522021139",
    "display" : "Fralda Sensaty Premium Noturna G (Confecções Capricho LTDA) x 8 tiras"
  },
  {
    "code" : "7891522211226",
    "display" : "Fralda Sensaty Premium Noturna M (Confecções Capricho LTDA) x 8 tiras"
  },
  {
    "code" : "7898172340573",
    "display" : "Fralda Seven Master EG (Parentex Indústria e Comércio LTDA) x 7 tiras"
  },
  {
    "code" : "7898172340054",
    "display" : "Fralda Seven Master G (Parentex Indústria e Comércio LTDA) x 8 tiras"
  },
  {
    "code" : "7898172340047",
    "display" : "Fralda Seven Master M (Parentex Indústria e Comércio LTDA) x 8 tiras"
  },
  {
    "code" : "7898172340030",
    "display" : "Fralda Seven Master P (Parentex Indústria e Comércio LTDA) x 10 tiras"
  },
  {
    "code" : "7898039564173",
    "display" : "Fralda Solucion Confort Line EG (Eurofral Indústria de Produtos Higiênicos e Termoplásticos LTDA) x 26 tiras"
  },
  {
    "code" : "7898039564166",
    "display" : "Fralda Solucion Confort Line G (Eurofral Indústria de Produtos Higiênicos e Termoplásticos LTDA) x 30 tiras"
  },
  {
    "code" : "7898039564159",
    "display" : "Fralda Solucion Confort Line M (Eurofral Indústria de Produtos Higiênicos e Termoplásticos LTDA) x 30 tiras"
  },
  {
    "code" : "7896877602248",
    "display" : "Fralda Suavidade EG (Diguinho Indústria e Comércio de Fraldas LTDA) x 7 tiras"
  },
  {
    "code" : "7896877602224",
    "display" : "Fralda Suavidade G (Diguinho Indústria e Comércio de Fraldas LTDA) x 8 tiras"
  },
  {
    "code" : "7896877602217",
    "display" : "Fralda Suavidade M (Diguinho Indústria e Comércio de Fraldas LTDA) x 9 tiras"
  },
  {
    "code" : "7896877602613",
    "display" : "Fralda Suavidade Premium EG (Diguinho Indústria e Comércio de Fraldas LTDA) x 7 tiras"
  },
  {
    "code" : "7896877602606",
    "display" : "Fralda Suavidade Premium G (Diguinho Indústria e Comércio de Fraldas LTDA) x 8 tiras"
  },
  {
    "code" : "7896877602590",
    "display" : "Fralda Suavidade Premium M (Diguinho Indústria e Comércio de Fraldas LTDA) x 9 tiras"
  },
  {
    "code" : "7898957747306",
    "display" : "Fralda Sublime Pacote Econômico EG (Johan e Stefani LTDA) x 20 tiras"
  },
  {
    "code" : "7898957747290",
    "display" : "Fralda Sublime Pacote Econômico G (Johan e Stefani LTDA) x 20 tiras"
  },
  {
    "code" : "7898957747283",
    "display" : "Fralda Sublime Pacote Econômico M (Johan e Stefani LTDA) x 20 tiras"
  },
  {
    "code" : "7898957747276",
    "display" : "Fralda Sublime Pacote Econômico P (Johan e Stefani LTDA) x 20 tiras"
  },
  {
    "code" : "7898957747238",
    "display" : "Fralda Sublime Soft Care EG (Johan e Stefani LTDA) x 7 tiras"
  },
  {
    "code" : "7898957747245",
    "display" : "Fralda Sublime Soft Care G (Johan e Stefani LTDA) x 8 tiras"
  },
  {
    "code" : "7898957747252",
    "display" : "Fralda Sublime Soft Care M (Johan e Stefani LTDA) x 8 tiras"
  },
  {
    "code" : "7898957747269",
    "display" : "Fralda Sublime Soft Care P (Johan e Stefani LTDA) x 8 tiras"
  },
  {
    "code" : "7896104605295",
    "display" : "Fralda Super Geriátrico Confort EG (Topfral Indústria e Comércio de Produtos Higiênicos LTDA) x 7 tiras"
  },
  {
    "code" : "7898905915030",
    "display" : "Fralda Super Geriátrico Confort G (Topfral Indústria e Comércio de Produtos Higiênicos LTDA) x 8 tiras"
  },
  {
    "code" : "7898905915023",
    "display" : "Fralda Super Geriátrico Confort M (Topfral Indústria e Comércio de Produtos Higiênicos LTDA) x 8 tiras"
  },
  {
    "code" : "7898937345416",
    "display" : "Fralda Superfral Confort Geriátrica G (Ferinha Fabricação de Fraldas Descartáveis e Produtos Higiênicos LTDA) x 20 tiras"
  },
  {
    "code" : "7898937354401",
    "display" : "Fralda Superfral Confort Geriátrica G (Ferinha Fabricação de Fraldas Descartáveis e Produtos Higiênicos LTDA) x 30 tiras"
  },
  {
    "code" : "7898937345386",
    "display" : "Fralda Superfral Confort Geriátrica G (Ferinha Fabricação de Fraldas Descartáveis e Produtos Higiênicos LTDA) x 8 tiras"
  },
  {
    "code" : "7898937345356",
    "display" : "Fralda Superfral Confort Geriátrica G (Ferinha Fabricação de Fraldas Descartáveis e Produtos Higiênicos LTDA) x 8 tiras"
  },
  {
    "code" : "7898937345423",
    "display" : "Fralda Superfral Confort Geriátrica GG (Ferinha Fabricação de Fraldas Descartáveis e Produtos Higiênicos LTDA) x 20 tiras"
  },
  {
    "code" : "7898937354418",
    "display" : "Fralda Superfral Confort Geriátrica GG (Ferinha Fabricação de Fraldas Descartáveis e Produtos Higiênicos LTDA) x 30 tiras"
  },
  {
    "code" : "7898937354425",
    "display" : "Fralda Superfral Confort Geriátrica GG (Ferinha Fabricação de Fraldas Descartáveis e Produtos Higiênicos LTDA) x 7 tiras"
  },
  {
    "code" : "7898937345430",
    "display" : "Fralda Superfral Confort Geriátrica M (Ferinha Fabricação de Fraldas Descartáveis e Produtos Higiênicos LTDA) x 20 tiras"
  },
  {
    "code" : "7898937354395",
    "display" : "Fralda Superfral Confort Geriátrica M (Ferinha Fabricação de Fraldas Descartáveis e Produtos Higiênicos LTDA) x 30 tiras"
  },
  {
    "code" : "7898937345393",
    "display" : "Fralda Superfral Confort Geriátrica M (Ferinha Fabricação de Fraldas Descartáveis e Produtos Higiênicos LTDA) x 8 tiras"
  },
  {
    "code" : "7896770979669",
    "display" : "Fralda Tena Confort M (Essity do Brasil Indústria e Comércio LTDA) x 9 tiras"
  },
  {
    "code" : "7896770902612",
    "display" : "Fralda Tena Confort Mega EG (Essity do Brasil Indústria e Comércio LTDA) x 18 tiras"
  },
  {
    "code" : "7896770902605",
    "display" : "Fralda Tena Confort Mega G (Essity do Brasil Indústria e Comércio LTDA) x 20 tiras"
  },
  {
    "code" : "7896770979751",
    "display" : "Fralda Tena Confort Mega G (Essity do Brasil Indústria e Comércio LTDA) x 30 tiras"
  },
  {
    "code" : "7896770979171",
    "display" : "Fralda Tena Confort Mega G Leve 22 Pague 20 (Essity do Brasil Indústria e Comércio LTDA) x 22 tiras"
  },
  {
    "code" : "7896770979799",
    "display" : "Fralda Tena Confort Mega G Leve 9 Pague 8 (Essity do Brasil Indústria e Comércio LTDA) x 9 tiras"
  },
  {
    "code" : "7896770900267",
    "display" : "Fralda Tena Confort Mega M (Essity do Brasil Indústria e Comércio LTDA) x 26 tiras"
  },
  {
    "code" : "7896770979744",
    "display" : "Fralda Tena Confort Mega M (Essity do Brasil Indústria e Comércio LTDA) x 36 tiras"
  },
  {
    "code" : "7896770979782",
    "display" : "Fralda Tena Confort Mega M Leve 10 Pague 9 (Essity do Brasil Indústria e Comércio LTDA) x 10 tiras"
  },
  {
    "code" : "7896770979164",
    "display" : "Fralda Tena Confort Mega M Leve 28 Pague 26 (Essity do Brasil Indústria e Comércio LTDA) x 28 tiras"
  },
  {
    "code" : "7896770900250",
    "display" : "Fralda Tena Confort Mega P (Essity do Brasil Indústria e Comércio LTDA) x 30 tiras"
  },
  {
    "code" : "7896770979652",
    "display" : "Fralda Tena Confort P (Essity do Brasil Indústria e Comércio LTDA) x 10 tiras"
  },
  {
    "code" : "7896770902599",
    "display" : "Fralda Tena Confort P (Essity do Brasil Indústria e Comércio LTDA) x 11 tiras"
  },
  {
    "code" : "7896770900656",
    "display" : "Fralda Tena Slip G (Essity do Brasil Indústria e Comércio LTDA) x 7 tiras"
  },
  {
    "code" : "7896770900564",
    "display" : "Fralda Tena Slip M (Essity do Brasil Indústria e Comércio LTDA) x 7 tiras"
  },
  {
    "code" : "7322540054910",
    "display" : "Fralda Tena Slip Mega G (Essity do Brasil Indústria e Comércio LTDA) x 28 tiras"
  },
  {
    "code" : "7322540054897",
    "display" : "Fralda Tena Slip Mega M (Essity do Brasil Indústria e Comércio LTDA) x 28 tiras"
  },
  {
    "code" : "7322540439199",
    "display" : "Fralda Tena Slip Mega P (Essity do Brasil Indústria e Comércio LTDA) x 30 tiras"
  },
  {
    "code" : "7896770900557",
    "display" : "Fralda Tena Slip P (Essity do Brasil Indústria e Comércio LTDA) x 7 tiras"
  },
  {
    "code" : "7896770979362",
    "display" : "Fralda Tena Slip Ultra G (Essity do Brasil Indústria e Comércio LTDA) x 8 tiras"
  },
  {
    "code" : "7896770979645",
    "display" : "Fralda Tena Slip Ultra Leve 20 Pague 14 G (Essity do Brasil Indústria e Comércio LTDA) x 20 tiras"
  },
  {
    "code" : "7896770979638",
    "display" : "Fralda Tena Slip Ultra Leve 20 Pague 14 M (Essity do Brasil Indústria e Comércio LTDA) x 20 tiras"
  },
  {
    "code" : "7896770979775",
    "display" : "Fralda Tena Slip Ultra Leve 20 Pague 17 G (Essity do Brasil Indústria e Comércio LTDA) x 20 tiras"
  },
  {
    "code" : "7896770979768",
    "display" : "Fralda Tena Slip Ultra Leve 20 Pague 17 M (Essity do Brasil Indústria e Comércio LTDA) x 20 tiras"
  },
  {
    "code" : "7896770979287",
    "display" : "Fralda Tena Slip Ultra Leve 22 Pague 20 M (Essity do Brasil Indústria e Comércio LTDA) x 22 tiras"
  },
  {
    "code" : "7896770979621",
    "display" : "Fralda Tena Slip Ultra Leve 7 Pague 5 G (Essity do Brasil Indústria e Comércio LTDA) x 7 tiras"
  },
  {
    "code" : "7896770979614",
    "display" : "Fralda Tena Slip Ultra Leve 7 Pague 5 M (Essity do Brasil Indústria e Comércio LTDA) x 7 tiras"
  },
  {
    "code" : "7896770979355",
    "display" : "Fralda Tena Slip Ultra M (Essity do Brasil Indústria e Comércio LTDA) x 8 tiras"
  },
  {
    "code" : "7896770902483",
    "display" : "Fralda Tena Slip Ultra Mega G (Essity do Brasil Indústria e Comércio LTDA) x 20 tiras"
  },
  {
    "code" : "7896770979270",
    "display" : "Fralda Tena Slip Ultra Mega Leve 22 Pague 20 G (Essity do Brasil Indústria e Comércio LTDA) x 22 tiras"
  },
  {
    "code" : "7896770902476",
    "display" : "Fralda Tena Slip Ultra Mega M (Essity do Brasil Indústria e Comércio LTDA) x 20 tiras"
  },
  {
    "code" : "7896770902544",
    "display" : "Fralda Tena Ultra G (Essity do Brasil Indústria e Comércio LTDA) x 8 tiras"
  },
  {
    "code" : "7896770902537",
    "display" : "Fralda Tena Ultra M (Essity do Brasil Indústria e Comércio LTDA) x 9 tiras"
  },
  {
    "code" : "7896770900434",
    "display" : "Fralda Tena Ultra Mega G (Essity do Brasil Indústria e Comércio LTDA) x 16 tiras"
  },
  {
    "code" : "7896770900427",
    "display" : "Fralda Tena Ultra Mega M (Essity do Brasil Indústria e Comércio LTDA) x 18 tiras"
  },
  {
    "code" : "7898957873180",
    "display" : "Fralda Ternura Adulto G (Quimpharma Indústria Química e Farmacêutica LTDA) x 8 tiras"
  },
  {
    "code" : "7898957873173",
    "display" : "Fralda Ternura Adulto M (Quimpharma Indústria Química e Farmacêutica LTDA) x 8 tiras"
  },
  {
    "code" : "7898957873166",
    "display" : "Fralda Ternura Adulto P (Quimpharma Indústria Química e Farmacêutica LTDA) x 10 tiras"
  },
  {
    "code" : "7898957873197",
    "display" : "Fralda Ternura Adulto XG (Quimpharma Indústria Química e Farmacêutica LTDA) x 7 tiras"
  },
  {
    "code" : "7898039563336",
    "display" : "Fralda Vida Nova EG (Eurofral Indústria de Produtos Higiênicos e Termoplásticos LTDA) x 24 tiras"
  },
  {
    "code" : "7898039563329",
    "display" : "Fralda Vida Nova G (Eurofral Indústria de Produtos Higiênicos e Termoplásticos LTDA) x 28 tiras"
  },
  {
    "code" : "7898039566047",
    "display" : "Fralda Vida Nova Genérica EG (Eurofral Indústria de Produtos Higiênicos e Termoplásticos LTDA) x 7 tiras"
  },
  {
    "code" : "7898039562582",
    "display" : "Fralda Vida Nova Genérica G (Eurofral Indústria de Produtos Higiênicos e Termoplásticos LTDA) x 8 tiras"
  },
  {
    "code" : "7898039563664",
    "display" : "Fralda Vida Nova Genérica M (Eurofral Indústria de Produtos Higiênicos e Termoplásticos LTDA) x 8 tiras"
  },
  {
    "code" : "7898039566030",
    "display" : "Fralda Vida Nova Genérica P (Eurofral Indústria de Produtos Higiênicos e Termoplásticos LTDA) x 10 tiras"
  },
  {
    "code" : "7898039563312",
    "display" : "Fralda Vida Nova M (Eurofral Indústria de Produtos Higiênicos e Termoplásticos LTDA) x 32 tiras"
  },
  {
    "code" : "7898039566344",
    "display" : "Fralda Vida Nova Mega EG (Eurofral Indústria de Produtos Higiênicos e Termoplásticos LTDA) x 26 tiras"
  },
  {
    "code" : "7898039566337",
    "display" : "Fralda Vida Nova Mega G (Eurofral Indústria de Produtos Higiênicos e Termoplásticos LTDA) x 30 tiras"
  },
  {
    "code" : "7898039566320",
    "display" : "Fralda Vida Nova Mega M (Eurofral Indústria de Produtos Higiênicos e Termoplásticos LTDA) x 30 tiras"
  },
  {
    "code" : "7898039566351",
    "display" : "Fralda Vida Nova Mega P (Eurofral Indústria de Produtos Higiênicos e Termoplásticos LTDA) x 34 tiras"
  },
  {
    "code" : "7898039563305",
    "display" : "Fralda Vida Nova P (Eurofral Indústria de Produtos Higiênicos e Termoplásticos LTDA) x 36 tiras"
  },
  {
    "code" : "7896272310380",
    "display" : "Fralda Viva Mais G (Divina Dama Indústria e Comércio LTDA) x 8 tiras"
  },
  {
    "code" : "7898070760992",
    "display" : "Fralda Viva Mais M (Divina Dama Indústria e Comércio LTDA) x 8 tiras"
  },
  {
    "code" : "7898943181060",
    "display" : "Fralda Vivamix EG (Embrafal Indústria e Comércio de Fraldas LTDA) x 32 tiras"
  },
  {
    "code" : "7898943181039",
    "display" : "Fralda Vivamix EG (Embrafal Indústria e Comércio de Fraldas LTDA) x 7 tiras"
  },
  {
    "code" : "7898943181053",
    "display" : "Fralda Vivamix G (Embrafal Indústria e Comércio de Fraldas LTDA) x 40 tiras"
  },
  {
    "code" : "7898943181022",
    "display" : "Fralda Vivamix G (Embrafal Indústria e Comércio de Fraldas LTDA) x 8 tiras"
  },
  {
    "code" : "7898943181046",
    "display" : "Fralda Vivamix M (Embrafal Indústria e Comércio de Fraldas LTDA) x 40 tiras"
  },
  {
    "code" : "7898943181015",
    "display" : "Fralda Vivamix M (Embrafal Indústria e Comércio de Fraldas LTDA) x 8 tiras"
  },
  {
    "code" : "7899700801214",
    "display" : "Fralda Wellness Premium Unit EG (CCM Indústria e Comércio de Produtos Descartáveis S.A.) x 7 tiras"
  },
  {
    "code" : "7899700801207",
    "display" : "Fralda Wellness Premium Unit G (CCM Indústria e Comércio de Produtos Descartáveis S.A.) x 8 tiras"
  },
  {
    "code" : "7899700801191",
    "display" : "Fralda Wellness Premium Unit M (CCM Indústria e Comércio de Produtos Descartáveis S.A.) x 8 tiras"
  },
  {
    "code" : "7899700801184",
    "display" : "Fralda Wellness Premium Unit P (CCM Indústria e Comércio de Produtos Descartáveis S.A.) x 10 tiras"
  },
  {
    "code" : "7896112403029",
    "display" : "Gestrelan 0,15 mg + 0,03 mg comprimido (Biolab Sanus Farmacêutica Ltda) x 21 comprimidos"
  },
  {
    "code" : "7896112403036",
    "display" : "Gestrelan 0,15 mg + 0,03 mg comprimido (Biolab Sanus Farmacêutica Ltda) x 63 comprimidos"
  },
  {
    "code" : "7896006290162",
    "display" : "Glaucotrat 5 mg/mL solução oftálmica (UNIÃO QUÍMICA FARMACÊUTICA NACIONAL S/A); 5 mL"
  },
  {
    "code" : "7896548114124",
    "display" : "Glautimol 5 mg/mL solução oftálmica (NOVARTIS BIOCIENCIAS S.A); 5 mL"
  },
  {
    "code" : "7898075317061",
    "display" : "Glibenclamida 5 mg comprimido (1Farma Indústria Farmacêutica LTDA) x 30 comprimidos"
  },
  {
    "code" : "7896181905509",
    "display" : "Glibenclamida 5 mg comprimido (Aché Laboratórios Farmacêuticos S.A) x 30 comprimidos"
  },
  {
    "code" : "7896714217093",
    "display" : "Glibenclamida 5 mg comprimido (Brainfarma Indústria Química E Farmacêutica S.A) x 30 comprimidos"
  },
  {
    "code" : "7896523213989",
    "display" : "Glibenclamida 5 mg comprimido (Cimed Indústria De Medicamentos Ltda) x 30 comprimidos"
  },
  {
    "code" : "7896004706474",
    "display" : "Glibenclamida 5 mg comprimido (EMS S/A) x 30 comprimidos"
  },
  {
    "code" : "7899095249707",
    "display" : "Glibenclamida 5 mg comprimido (Geolab Indústria Farmacêutica S/A) x 30 comprimidos"
  },
  {
    "code" : "7896004707945",
    "display" : "Glibenclamida 5 mg comprimido (Germed Farmacêutica LTDA) x 30 comprimidos"
  },
  {
    "code" : "7894916141024",
    "display" : "Glibenclamida 5 mg comprimido (Legrand Pharma Indústria Farmacêutica LTDA) x 30 comprimidos"
  },
  {
    "code" : "7895296272018",
    "display" : "Glibenclamida 5 mg comprimido (Nova Química Farmacêutica S/A) x 30 comprimidos"
  },
  {
    "code" : "7898148297269",
    "display" : "Glibenclamida 5 mg comprimido (Prati Donaduzzi & Cia Ltda) x 30 comprimidos"
  },
  {
    "code" : "7897076909626",
    "display" : "Glibenclamida 5 mg comprimido (Ranbaxy Farmacêutica Ltda) x 30 comprimidos"
  },
  {
    "code" : "7896422522571",
    "display" : "Glibenclamida 5 mg comprimido (Sanofi Medley Farmacêutica Ltda) x 30 comprimidos"
  },
  {
    "code" : "7896422522588",
    "display" : "Glibenclamida 5 mg comprimido (Sanofi Medley Farmacêutica Ltda) x 60 comprimidos"
  },
  {
    "code" : "7898075310376",
    "display" : "Glibeneck 5 mg comprimido (1Farma Industria Farmacêutica Ltda) x 30 comprimidos"
  },
  {
    "code" : "7899095201781",
    "display" : "Glicamin 5 mg comprimido (Geolab Indústria Farmacêutica S/A) x 30 comprimidos"
  },
  {
    "code" : "7899095201484",
    "display" : "Glicefor 850 mg comprimido (Geolab Indústria Farmacêutica S/A) x 30 comprimidos"
  },
  {
    "code" : "7898049794324",
    "display" : "Glicomet 500 mg comprimido (Vitamedic Industria Farmacêutica Ltda) x 30 comprimidos"
  },
  {
    "code" : "7898049798223",
    "display" : "Glicomet 850 mg comprimido (Vitamedic Industria Farmacêutica Ltda) x 30 comprimidos"
  },
  {
    "code" : "7896862910556",
    "display" : "Gliconil 5 mg comprimido (Medquimica Industria Farmacêutica Ltda.) x 30 comprimidos"
  },
  {
    "code" : "7891721000614",
    "display" : "Glifage 500 mg comprimido (Merck S/A) x 30 comprimidos"
  },
  {
    "code" : "7891721027437",
    "display" : "Glifage 850 mg comprimido (Merck S/A) x 30 comprimidos"
  },
  {
    "code" : "7891721201806",
    "display" : "Glifage XR 500 mg comprimido de liberação prolongada (Merck S/A) x 30 comprimidos"
  },
  {
    "code" : "7891721027468",
    "display" : "Glifage XR 500 mg comprimido de liberação prolongada (Merck S/A) x 30 comprimidos"
  },
  {
    "code" : "7891721201547",
    "display" : "Glifage XR 850 mg comprimido de liberação prolongada (Merck S/A) x 10 comprimidos"
  },
  {
    "code" : "7891721201530",
    "display" : "Glifage XR 850 mg comprimido de liberação prolongada (Merck S/A) x 30 comprimidos"
  },
  {
    "code" : "7896714266695",
    "display" : "Glionil 5 mg comprimido (Brainfarma Indústria Química E Farmacêutica S.A) x 30 comprimidos"
  },
  {
    "code" : "7898075314657",
    "display" : "Hidroclorotiazida 25 mg comprimido (1Farma Industria Farmacêutica Ltda) x 30 comprimidos"
  },
  {
    "code" : "7896714211978",
    "display" : "Hidroclorotiazida 25 mg comprimido (Brainfarma Indústria Química E Farmacêutica S.A) x 30 comprimidos"
  },
  {
    "code" : "7896523210070",
    "display" : "Hidroclorotiazida 25 mg comprimido (Cimed Indústria de Medicamentos Ltda) x 30 comprimidos"
  },
  {
    "code" : "7896004716176",
    "display" : "Hidroclorotiazida 25 mg comprimido (EMS S/A) x 30 comprimidos"
  },
  {
    "code" : "7896004716190",
    "display" : "Hidroclorotiazida 25 mg comprimido (Germed Farmacêutica Ltda) x 30 comprimidos"
  },
  {
    "code" : "7896112165651",
    "display" : "Hidroclorotiazida 25 mg comprimido (Laboratório Teuto Brasileiro S/A) x 30 comprimidos"
  },
  {
    "code" : "7894916143516",
    "display" : "Hidroclorotiazida 25 mg comprimido (Legrand Pharma Indústria Farmacêutica Ltda) x 30 comprimidos"
  },
  {
    "code" : "7896862918583",
    "display" : "Hidroclorotiazida 25 mg comprimido (Medquimica Industria Farmacêutica Ltda.) x 30 comprimidos"
  },
  {
    "code" : "7896862918590",
    "display" : "Hidroclorotiazida 25 mg comprimido (Medquimica Industria Farmacêutica Ltda.) x 60 comprimidos"
  },
  {
    "code" : "7898216368969",
    "display" : "Hidroclorotiazida 25 mg comprimido (Pharlab Indústria Farmacêutica S.A.) x 30 comprimidos"
  },
  {
    "code" : "7898148296729",
    "display" : "Hidroclorotiazida 25 mg comprimido (Prati Donaduzzi & Cia Ltda) x 30 comprimidos"
  },
  {
    "code" : "7891058002657",
    "display" : "Hidroclorotiazida 25 mg comprimido (Sanofi Medley Farmacêutica Ltda) x 30 comprimidos"
  },
  {
    "code" : "7896862910648",
    "display" : "Hidroflux 25 mg comprimido (Medquimica Industria Farmacêutica Ltda.) x 30 comprimidos"
  },
  {
    "code" : "7896862910754",
    "display" : "Hidroflux 25 mg comprimido (Medquimica Industria Farmacêutica Ltda.) x 60 comprimidos"
  },
  {
    "code" : "7898216362639",
    "display" : "Hidroless 25 mg comprimido (Pharlab Indústria Farmacêutica S.A.) x 30 comprimidos"
  },
  {
    "code" : "7896523207537",
    "display" : "Hidromed 25 mg comprimido (Cimed Indústria de Medicamentos Ltda) x 30 comprimidos"
  },
  {
    "code" : "7896382700583",
    "display" : "Humulin N 100 unidades internacionais/mL solução para injeção 10 mL; frasco-ampola (ELI LILLY DO BRASIL LTDA); 1 frasco-ampola"
  },
  {
    "code" : "7896382703317",
    "display" : "Humulin N 100 unidades internacionais/mL solução para injeção 3 mL; carpule (ELI LILLY DO BRASIL LTDA); 2 carpules"
  },
  {
    "code" : "7896382700576",
    "display" : "Humulin R 100 unidades internacionais/mL solução para injeção 10 mL; frasco-ampola (ELI LILLY DO BRASIL LTDA); 1 frasco-ampola"
  },
  {
    "code" : "7896382703300",
    "display" : "Humulin R 100 unidades internacionais/mL solução para injeção 3 mL; carpule (ELI LILLY DO BRASIL LTDA); 2 carpules"
  },
  {
    "code" : "7896004756721",
    "display" : "Inalajet 32 microgramas/dose suspensão spray; 120 doses (LEGRAND PHARMA INDÚSTRIA FARMACÊUTICA LTDA); 1 frasco"
  },
  {
    "code" : "7896004765716",
    "display" : "Inalide 32 microgramas/dose suspensão spray; 120 doses (EMS S/A); 1 frasco"
  },
  {
    "code" : "7896004750323",
    "display" : "Insuliv R 100 unidades internacionais/mL solução para injeção 10 mL; frasco-ampola (EMS S/A); 1 frasco-ampola"
  },
  {
    "code" : "7895858005436",
    "display" : "Insunorm N 100 unidades internacionais/mL solução para injeção 10 mL; frasco-ampola (ASPEN PHARMA INDÚSTRIA FARMACÊUTICA LTDA); 1 frasco-ampola"
  },
  {
    "code" : "7895858005412",
    "display" : "Insunorm R 100 unidades internacionais/mL solução para injeção 10 mL; frasco-ampola (ASPEN PHARMA INDÚSTRIA FARMACÊUTICA LTDA); 1 frasco-ampola"
  },
  {
    "code" : "7896714270234",
    "display" : "Ipraneo 0,25 mg/mL solução para inalação 20mL; frasco (BRAINFARMA INDÚSTRIA QUÍMICA E FARMACÊUTICA S.A); 1 frasco"
  },
  {
    "code" : "7895296284011",
    "display" : "Ipravent 0,25 mg/mL solução para inalação 20 mL; frasco (EMS SIGMA PHARMA LTDA); 1 frasco"
  },
  {
    "code" : "7896714203614",
    "display" : "Lanzacor 50 mg comprimido (BRAINFARMA INDÚSTRIA QUÍMICA E FARMACÊUTICA S.A) x 14 comprimidos"
  },
  {
    "code" : "7896714203607",
    "display" : "Lanzacor 50 mg comprimido (BRAINFARMA INDÚSTRIA QUÍMICA E FARMACÊUTICA S.A) x 28 comprimidos"
  },
  {
    "code" : "7896714249346",
    "display" : "Lanzacor 50 mg comprimido (BRAINFARMA INDÚSTRIA QUÍMICA E FARMACÊUTICA S.A) x 30 comprimidos"
  },
  {
    "code" : "7896658022760",
    "display" : "Ledar 70 mg comprimido (Aché Laboratórios Farmacêuticos S.A) x 4 comprimidos"
  },
  {
    "code" : "7896181929154",
    "display" : "Levodopa 100 mg + Cloridrato de Benserazida 25 mg comprimido (Aché Laboratórios Farmacêuticos S.A) x 30 comprimidos"
  },
  {
    "code" : "7896112403166",
    "display" : "Levonorgestrel 0,15 mg + Etinilestradiol 0,03 mg comprimido (Biolab Sanus Farmacêutica LTDA) x 21 comprimidos"
  },
  {
    "code" : "7896112403173",
    "display" : "Levonorgestrel 0,15 mg + Etinilestradiol 0,03 mg comprimido (Biolab Sanus Farmacêutica LTDA) x 63 comprimidos"
  },
  {
    "code" : "7908020500889",
    "display" : "Levonorgestrel 0,15 mg + Etinilestradiol 0,03 mg comprimido (Cifarma Científica Farmacêutica Ltda.) x 21 comprimidos"
  },
  {
    "code" : "7898505093138",
    "display" : "Levonorgestrel 0,15 mg + Etinilestradiol 0,03 mg comprimido (Mabra Farmacêutica Ltda.) x 21 comprimidos"
  },
  {
    "code" : "7908020502586",
    "display" : "Linofeme 0,15 mg + 0,03 mg comprimido (CIFARMA CIENTÍFICA FARMACÊUTICA LTDA) x 21 comprimidos"
  },
  {
    "code" : "7908020502593",
    "display" : "Linofeme 0,15 mg + 0,03 mg comprimido (CIFARMA CIENTÍFICA FARMACÊUTICA LTDA) x 63 comprimidos"
  },
  {
    "code" : "7896004736853",
    "display" : "Lipistatina 10 mg comprimido (NOVA QUIMICA FARMACÊUTICA S/A) x 30 comprimidos"
  },
  {
    "code" : "7896004739489",
    "display" : "Lipistatina 20 mg comprimido (NOVA QUIMICA FARMACÊUTICA S/A) x 30 comprimidos"
  },
  {
    "code" : "7896004736884",
    "display" : "Lipistatina 40 mg comprimido (NOVA QUIMICA FARMACÊUTICA S/A) x 30 comprimidos"
  },
  {
    "code" : "7897595628237",
    "display" : "Lorsacor 50 mg comprimido (Sandoz do Brasil Indústria Farmacêutica Ltda) x 30 comprimidos"
  },
  {
    "code" : "7897595628244",
    "display" : "Lorsacor 50 mg comprimido (Sandoz do Brasil Indústria Farmacêutica Ltda) x 60 comprimidos"
  },
  {
    "code" : "7898049796243",
    "display" : "Losacoron 50 mg comprimido (Vitamedic Industria Farmacêutica Ltda) x 30 comprimidos"
  },
  {
    "code" : "7896181905622",
    "display" : "Losartana Potassica 50 mg comprimido (ACHÉ LABORATÓRIOS FARMACÊUTICOS S.A) x 14 comprimidos"
  },
  {
    "code" : "7896181904861",
    "display" : "Losartana Potassica 50 mg comprimido (ACHÉ LABORATÓRIOS FARMACÊUTICOS S.A) x 28 comprimidos"
  },
  {
    "code" : "7896181915638",
    "display" : "Losartana Potassica 50 mg comprimido (ACHÉ LABORATÓRIOS FARMACÊUTICOS S.A) x 30 comprimidos"
  },
  {
    "code" : "7898361882457",
    "display" : "Losartana Potassica 50 mg comprimido (Aurobindo Pharma Indústria Farmacêutica Limitada) x 30 comprimidos"
  },
  {
    "code" : "7896714208565",
    "display" : "Losartana Potassica 50 mg comprimido (Brainfarma Indústria Química E Farmacêutica S.A) x 30 comprimidos"
  },
  {
    "code" : "7896523227399",
    "display" : "Losartana Potássica 50 mg comprimido (CIMED INDÚSTRIA DE MEDICAMENTOS LTDA) x 30 comprimidos"
  },
  {
    "code" : "7896004706795",
    "display" : "Losartana Potássica 50 mg comprimido (EMS S/A) x 30 comprimidos"
  },
  {
    "code" : "7891317427542",
    "display" : "Losartana Potássica 50 mg comprimido (Eurofarma Laboratórios S.A.) x 30 comprimidos"
  },
  {
    "code" : "7891317463229",
    "display" : "Losartana Potássica 50 mg comprimido (Eurofarma Laboratórios S.A.) x 60 comprimidos"
  },
  {
    "code" : "7899095236639",
    "display" : "Losartana Potássica 50 mg comprimido (Geolab Indústria Farmacêutica S/A) x 30 comprimidos"
  },
  {
    "code" : "7896004708539",
    "display" : "Losartana Potássica 50 mg comprimido (Germed Indústria LTDA) x 30 comprimidos"
  },
  {
    "code" : "7899620911222",
    "display" : "Losartana Potássica 50 mg comprimido (Laboratório Globo LTDA) x 30 comprimidos"
  },
  {
    "code" : "7896714273884",
    "display" : "Losartana Potássica 50 mg comprimido (Laboratório Neo Química Comércio e Indústria LTDA) x 30 comprimidos"
  },
  {
    "code" : "7896112114185",
    "display" : "Losartana Potássica 50 mg comprimido (Laboratório Teuto Brasileiro S/A) x 30 comprimidos"
  },
  {
    "code" : "7896112134220",
    "display" : "Losartana Potássica 50 mg comprimido (Laboratório Teuto Brasileiro S/A) x 60 comprimidos"
  },
  {
    "code" : "7894916145145",
    "display" : "Losartana Potássica 50 mg comprimido (LEGRAND PHARMA INDÚSTRIA FARMACÊUTICA LTDA) x 30 comprimidos"
  },
  {
    "code" : "7894916147019",
    "display" : "Losartana Potássica 50 mg comprimido (LEGRAND PHARMA INDÚSTRIA FARMACÊUTICA LTDA) x 60 comprimidos"
  },
  {
    "code" : "7896004778785",
    "display" : "Losartana Potássica 50 mg comprimido (Multilab Indústria e Comércio de Produtos Farmacêuticos Ltda) x 10 comprimidos"
  },
  {
    "code" : "7896004778792",
    "display" : "Losartana Potássica 50 mg comprimido (Multilab Indústria e Comércio de Produtos Farmacêuticos Ltda) x 14 comprimidos"
  },
  {
    "code" : "7896004778808",
    "display" : "Losartana Potássica 50 mg comprimido (Multilab Indústria e Comércio de Produtos Farmacêuticos Ltda) x 15 comprimidos"
  },
  {
    "code" : "7896004778815",
    "display" : "Losartana Potássica 50 mg comprimido (Multilab Indústria e Comércio de Produtos Farmacêuticos Ltda) x 20 comprimidos"
  },
  {
    "code" : "7896004778822",
    "display" : "Losartana Potássica 50 mg comprimido (Multilab Indústria e Comércio de Produtos Farmacêuticos Ltda) x 21 comprimidos"
  },
  {
    "code" : "7896004778907",
    "display" : "Losartana Potássica 50 mg comprimido (Multilab Indústria e Comércio de Produtos Farmacêuticos Ltda) x 28 comprimidos"
  },
  {
    "code" : "7896472513406",
    "display" : "Losartana Potássica 50 mg comprimido (Multilab Indústria e Comércio de Produtos Farmacêuticos Ltda) x 30 comprimidos"
  },
  {
    "code" : "7896004778204",
    "display" : "Losartana Potássica 50 mg comprimido (Multilab Indústria e Comércio de Produtos Farmacêuticos Ltda) x 30 comprimidos"
  },
  {
    "code" : "7896472513413",
    "display" : "Losartana Potássica 50 mg comprimido (Multilab Indústria e Comércio de Produtos Farmacêuticos Ltda) x 60 comprimidos"
  },
  {
    "code" : "7896004778358",
    "display" : "Losartana Potássica 50 mg comprimido (Multilab Indústria e Comércio de Produtos Farmacêuticos Ltda) x 60 comprimidos"
  },
  {
    "code" : "7896004778778",
    "display" : "Losartana Potássica 50 mg comprimido (Multilab Indústria e Comércio de Produtos Farmacêuticos Ltda) x 7 comprimidos"
  },
  {
    "code" : "7898216368167",
    "display" : "Losartana Potássica 50 mg comprimido (Pharlab Indústria Farmacêutica S.A.) x 30 comprimidos"
  },
  {
    "code" : "7898216368181",
    "display" : "Losartana Potássica 50 mg comprimido (Pharlab Indústria Farmacêutica S.A.) x 60 comprimidos"
  },
  {
    "code" : "7898148301720",
    "display" : "Losartana Potássica 50 mg comprimido (Prati Donaduzzi & Cia Ltda) x 30 comprimidos"
  },
  {
    "code" : "7899547505252",
    "display" : "Losartana Potássica 50 mg comprimido (Prati Donaduzzi & Cia Ltda) x 30 comprimidos"
  },
  {
    "code" : "7899547528626",
    "display" : "Losartana Potássica 50 mg comprimido (Prati Donaduzzi & Cia Ltda) x 60 comprimidos"
  },
  {
    "code" : "7897076907691",
    "display" : "Losartana Potássica 50 mg comprimido (Ranbaxy Farmacêutica Ltda) x 30 comprimidos"
  },
  {
    "code" : "7897595627360",
    "display" : "Losartana Potássica 50 mg comprimido (Sandoz do Brasil Indústria Farmacêutica Ltda) x 30 comprimidos"
  },
  {
    "code" : "7896422507721",
    "display" : "Losartana Potássica 50 mg comprimido (Sanofi Medley Farmacêutica Ltda) x 15 comprimidos"
  },
  {
    "code" : "7896422507738",
    "display" : "Losartana Potássica 50 mg comprimido (Sanofi Medley Farmacêutica Ltda) x 30 comprimidos"
  },
  {
    "code" : "7896422507752",
    "display" : "Losartana Potássica 50 mg comprimido (Sanofi Medley Farmacêutica Ltda) x 60 comprimidos"
  },
  {
    "code" : "8903855075334",
    "display" : "Losartana Potássica 50 mg comprimido (Torrent do Brasil Ltda) x 30 comprimidos"
  },
  {
    "code" : "7898049797967",
    "display" : "Losartana Potássica 50 mg comprimido (Vitamedic Industria Farmacêutica Ltda) x 30 comprimidos"
  },
  {
    "code" : "7898910350239",
    "display" : "Losartana Potássica 50 mg comprimido (Zydus Nikkho Farmacêutica Ltda) x 30 comprimidos"
  },
  {
    "code" : "7891721013362",
    "display" : "Losartion 50 mg comprimido (Merck S/A) x 30 comprimidos"
  },
  {
    "code" : "7896112121008",
    "display" : "Lotanol 50 mg comprimido (Laboratório Teuto Brasileiro S/A) x 30 comprimidos"
  },
  {
    "code" : "7896112120988",
    "display" : "Lotanol 50 mg comprimido (Laboratório Teuto Brasileiro S/A) x 60 comprimidos"
  },
  {
    "code" : "7898075314435",
    "display" : "Maleato de Enalapril 10 mg comprimido (1Farma Industria Farmaceutica Ltda) x 30 comprimidos"
  },
  {
    "code" : "7896181900894",
    "display" : "Maleato de Enalapril 10 mg comprimido (Aché Laboratórios Farmacêuticos S.A.); 30 comprimidos"
  },
  {
    "code" : "7897917005203",
    "display" : "Maleato de Enalapril 10 mg comprimido (Belfar LTDA); 30 comprimidos"
  },
  {
    "code" : "7896112401391",
    "display" : "Maleato De Enalapril 10 mg comprimido (Biolab Sanus Farmacêutica LTDA) x 30 comprimidos"
  },
  {
    "code" : "7896714205823",
    "display" : "Maleato De Enalapril 10 mg comprimido (Brainfarma Indústria Química E Farmacêutica S.A) x 30 comprimidos"
  },
  {
    "code" : "7896523210759",
    "display" : "Maleato de Enalapril 10 mg comprimido (Cimed Indústria de Medicamentos Ltda) x 30 comprimidos"
  },
  {
    "code" : "7899620910287",
    "display" : "Maleato de Enalapril 10 mg comprimido (Laboratório Globo LTDA); 30 comprimidos"
  },
  {
    "code" : "7896112126225",
    "display" : "Maleato de Enalapril 10 mg comprimido (Laboratório Teuto Brasileiro S/A) x 30 comprimidos"
  },
  {
    "code" : "7894916143028",
    "display" : "Maleato de Enalapril 10 mg comprimido (Legrand Pharma Indústria Farmacêutica Ltda) x 30 comprimidos"
  },
  {
    "code" : "7895296216036",
    "display" : "Maleato de Enalapril 10 mg comprimido (Nova Química Farmacêutica S/A) x 30 comprimidos"
  },
  {
    "code" : "7898216367450",
    "display" : "Maleato de Enalapril 10 mg comprimido (Pharlab Indústria Farmacêutica S.A) x 30 comprimidos"
  },
  {
    "code" : "7897595602268",
    "display" : "Maleato de Enalapril 10 mg comprimido (Sandoz do Brasil Indústria Farmacêutica Ltda) x 30 comprimidos"
  },
  {
    "code" : "7896422514248",
    "display" : "Maleato de Enalapril 10 mg comprimido (Sanofi Medley Farmacêutica Ltda) x 30 comprimidos"
  },
  {
    "code" : "7898049796564",
    "display" : "Maleato de Enalapril 10 mg comprimido (Vitamedic Industria Farmaceutica Ltda) x 30 comprimidos"
  },
  {
    "code" : "7896181909439",
    "display" : "Maleato de Timolol 0,25% solução oftálmica (Aché Laboratórios Farmacêuticos S.A.); 5 mL"
  },
  {
    "code" : "7897316804254",
    "display" : "Maleato de Timolol 0,25% solução oftálmica (Allergan Produtos Farmacêuticos LTDA); 5 mL"
  },
  {
    "code" : "7896181907077",
    "display" : "Maleato de Timolol 5 mg/mL solução oftálmica (Aché Laboratórios Farmacêuticos S.A.); 5 mL"
  },
  {
    "code" : "7896714225753",
    "display" : "Maleato de Timolol 5 mg/mL solução oftálmica (Brainfarma Indústria Química e Farmacêutica S.A.); 5 mL"
  },
  {
    "code" : "7896676406436",
    "display" : "Maleato de Timolol 5 mg/mL solução oftálmica (Cristália Produtos Químicos Farmacêuticos LTDA.); 5 mL"
  },
  {
    "code" : "7896004715711",
    "display" : "Maleato de Timolol 5 mg/mL solução oftálmica (EMS S/A); 5 mL"
  },
  {
    "code" : "7896004715896",
    "display" : "Maleato de Timolol 5 mg/mL solução oftálmica (Germed Farmacêutica LTDA); 5 mL"
  },
  {
    "code" : "7896112126669",
    "display" : "Maleato de Timolol 5 mg/mL solução oftálmica (Laboratório Teuto Brasileiro S/A); 5 mL"
  },
  {
    "code" : "7894916142786",
    "display" : "Maleato de Timolol 5 mg/mL solução oftálmica (Legrand Pharma Indústria Farmacêutica LTDA); 5 mL"
  },
  {
    "code" : "7896548165577",
    "display" : "Maleato de Timolol 5 mg/mL solução oftálmica (Novartis Biociências S.A.); 5 mL"
  },
  {
    "code" : "7896004700533",
    "display" : "Maleato Enalapril 10 mg comprimido (EMS S/A) x 30 comprimidos"
  },
  {
    "code" : "7899095244634",
    "display" : "Maleato Enalapril 10 mg comprimido (Geolab Indústria Farmacêutica S.A.) x 30 comprimidos"
  },
  {
    "code" : "7899095244535",
    "display" : "Maleato Enalapril 10 mg comprimido (Geolab Indústria Farmacêutica S.A.) x 30 comprimidos"
  },
  {
    "code" : "7899095244641",
    "display" : "Maleato Enalapril 10 mg comprimido (Geolab Indústria Farmacêutica S.A.) x 60 comprimidos"
  },
  {
    "code" : "7899095244542",
    "display" : "Maleato Enalapril 10 mg comprimido (Geolab Indústria Farmacêutica S.A.) x 60 comprimidos"
  },
  {
    "code" : "7896004772752",
    "display" : "Maleato Enalapril 10 mg comprimido (Germed Farmacêutica LTDA) x 30 comprimidos"
  },
  {
    "code" : "7896472502813",
    "display" : "Menocol 10 mg comprimido (Multilab Indústria e Comércio de Produtos Farmacêuticos Ltda) x 30 comprimidos"
  },
  {
    "code" : "7896472502820",
    "display" : "Menocol 20 mg comprimido (Multilab Indústria e Comércio de Produtos Farmacêuticos Ltda) x 30 comprimidos"
  },
  {
    "code" : "7896472502936",
    "display" : "Menocol 40 mg comprimido (Multilab Indústria e Comércio de Produtos Farmacêuticos Ltda) x 30 comprimidos"
  },
  {
    "code" : "7896472508594",
    "display" : "Menocol 40 mg comprimido (Multilab Indústria e Comércio de Produtos Farmacêuticos Ltda) x 60 comprimidos"
  },
  {
    "code" : "7891106911337",
    "display" : "Mesigyna 50 mg/1 mL + 5 mg/1 mL solução para injeção; ampola (BAYER S.A.); 1 mL"
  },
  {
    "code" : "7891106904537",
    "display" : "Mesigyna 50 mg/1 mL + 5 mg/1 mL solução para injeção; seringa preenchida (BAYER S.A.); 1 mL"
  },
  {
    "code" : "7896523206493",
    "display" : "Metformed 850 mg comprimido (Cimed Indústria de Medicamentos Ltda) x 30 comprimidos"
  },
  {
    "code" : "8902220107304",
    "display" : "Metta SR 500 mg comprimido de liberação prolongada (Torrent do Brasil Ltda) x 30 comprimidos"
  },
  {
    "code" : "7896212478859",
    "display" : "Micronor 350 microgramas comprimido (Janssen-Cilag Farmacêutica Ltda) x 35 comprimidos"
  },
  {
    "code" : "7891106905961",
    "display" : "Microvlar 0,15 mg + 0,03 mg comprimido (Bayer S.A) x 21 comprimidos"
  },
  {
    "code" : "7891106913997",
    "display" : "Microvlar 0,15 mg + 0,03 mg comprimido (Bayer S.A) x 21 comprimidos"
  },
  {
    "code" : "7891106914642",
    "display" : "Microvlar 0,15 mg + 0,03 mg comprimido (Bayer S.A) x 63 comprimidos"
  },
  {
    "code" : "7891106914369",
    "display" : "Microvlar 0,15 mg + 0,03 mg comprimido (Bayer S.A) x 63 comprimidos"
  },
  {
    "code" : "7896261004009",
    "display" : "Miflasona 200 microgramas cápsula para inalação; inalador (NOVARTIS BIOCIENCIAS S.A); 60 doses"
  },
  {
    "code" : "7897655402005",
    "display" : "Minusorb 70 mg comprimido (UCI - Farma Indústria Farmacêutica Ltda) x 4 comprimidos"
  },
  {
    "code" : "7898577811012",
    "display" : "Mytfor 850 mg comprimido (Accord Farmacêutica Ltda) x 30 comprimidos"
  },
  {
    "code" : "7896714211756",
    "display" : "Neo Hidroclor 25 mg comprimido (Brainfarma Indústria Química e Farmacêutica S.A) x 30 comprimidos"
  },
  {
    "code" : "7896714200224",
    "display" : "Neo Metformin 850 mg comprimido (Brainfarma Indústria Química e Farmacêutica S.A) x 30 comprimidos"
  },
  {
    "code" : "7896004774824",
    "display" : "Nociclin 0,15 mg + 0,03 mg comprimido (EMS S/A) x 21 comprimidos"
  },
  {
    "code" : "7896004714196",
    "display" : "Nociclin 0,15 mg + 0,03 mg comprimido (EMS S/A) x 21 comprimidos"
  },
  {
    "code" : "7891317460532",
    "display" : "Noex 32 microgramas/dose suspensão spray; 120 doses (EUROFARMA LABORATÓRIOS S.A.); 1 frasco"
  },
  {
    "code" : "7891317460518",
    "display" : "Noex 50 microgramas/dose suspensão spray; 200 doses (EUROFARMA LABORATÓRIOS S.A.); 1 frasco"
  },
  {
    "code" : "7891045008433",
    "display" : "Nordette 0,15 mg + 0,03 mg comprimido (Wyeth Indústria Farmacêutica Ltda) x 21 comprimidos"
  },
  {
    "code" : "7891045008440",
    "display" : "Nordette 0,15 mg + 0,03 mg comprimido (Wyeth Indústria Farmacêutica Ltda) x 63 comprimidos"
  },
  {
    "code" : "7908020502555",
    "display" : "Noregyna 50 mg/1 mL + 5 mg/1 mL solução para injeção; ampola (CIFARMA CIENTÍFICA FARMACÊUTICA LTDA); 1 ampola"
  },
  {
    "code" : "7896241274903",
    "display" : "Norestin 0,35 mg comprimido (Biolab Sanus Farmacêutica Ltda) x 35 comprimidos"
  },
  {
    "code" : "7896112474982",
    "display" : "Norestin 0,35 mg comprimido (Biolab Sanus Farmacêutica Ltda) x 35 comprimidos"
  },
  {
    "code" : "7896112401407",
    "display" : "Noretisterona 0,35 mg comprimido (Biolab Sanus Farmacêutica LTDA); 35 comprimidos"
  },
  {
    "code" : "7897705200087",
    "display" : "Novolin N 100 unidades internacionais/mL solução para injeção 10 mL; frasco-ampola (NOVO NORDISK FARMACÊUTICA DO BRASIL LTDA); 1 frasco-ampola"
  },
  {
    "code" : "7897705202449",
    "display" : "Novolin N Flexpen 100 unidades internacionais/mL solução para injeção 3 mL; carpule (NOVO NORDISK FARMACÊUTICA DO BRASIL LTDA); 1 carpule"
  },
  {
    "code" : "7897705202456",
    "display" : "Novolin N Flexpen 100 unidades internacionais/mL solução para injeção 3 mL; carpule (NOVO NORDISK FARMACÊUTICA DO BRASIL LTDA); 5 carpules"
  },
  {
    "code" : "7897705202623",
    "display" : "Novolin N Flexpen 100 unidades internacionais/mL solução para injeção 3 mL; carpule (NOVO NORDISK FARMACÊUTICA DO BRASIL LTDA); 5 carpules"
  },
  {
    "code" : "7897705200322",
    "display" : "Novolin N PenFill 100 unidades internacionais/mL solução para injeção 3 mL; carpule (NOVO NORDISK FARMACÊUTICA DO BRASIL LTDA); 5 carpules"
  },
  {
    "code" : "7897705201725",
    "display" : "Novolin R 100 unidades internacionais/mL solução para injeção 10 mL; frasco-ampola (NOVO NORDISK FARMACÊUTICA DO BRASIL LTDA); 1 frasco-ampola"
  },
  {
    "code" : "7897705200070",
    "display" : "Novolin R 100 unidades internacionais/mL solução para injeção 10 mL; frasco-ampola (NOVO NORDISK FARMACÊUTICA DO BRASIL LTDA); 1 frasco-ampola"
  },
  {
    "code" : "7897705202470",
    "display" : "Novolin R Flexpen 100 unidades internacionais/mL solução para injeção 3 mL; carpule (NOVO NORDISK FARMACÊUTICA DO BRASIL LTDA); 1 carpule"
  },
  {
    "code" : "7897705202616",
    "display" : "Novolin R Flexpen 100 unidades internacionais/mL solução para injeção 3 mL; carpule (NOVO NORDISK FARMACÊUTICA DO BRASIL LTDA); 5 carpules"
  },
  {
    "code" : "7897705202487",
    "display" : "Novolin R Flexpen 100 unidades internacionais/mL solução para injeção 3 mL; carpule (NOVO NORDISK FARMACÊUTICA DO BRASIL LTDA); 5 carpules"
  },
  {
    "code" : "7897705200315",
    "display" : "Novolin R PenFill 100 unidades internacionais/mL solução para injeção 3 mL; carpule (NOVO NORDISK FARMACÊUTICA DO BRASIL LTDA); 5 carpules"
  },
  {
    "code" : "7898574610267",
    "display" : "Ostelox 70 mg comprimido (Indústria Farmacêutica Melcon do Brasil S.A.) x 4 comprimidos"
  },
  {
    "code" : "7896226102641",
    "display" : "Ostenan 70 mg comprimido (Marjan Indústria E Comércio Ltda) x 4 comprimidos"
  },
  {
    "code" : "7898109241522",
    "display" : "Osteofar 70 mg comprimido (Laboratório Farmacêutico Elofar Ltda) x 4 comprimidos"
  },
  {
    "code" : "7894916510127",
    "display" : "Osteoform 70 mg comprimido (EMS Sigma Pharma Ltda) x 4 comprimidos"
  },
  {
    "code" : "7894916501729",
    "display" : "Osteoform 70 mg comprimido (EMS Sigma Pharma Ltda) x 4 comprimidos"
  },
  {
    "code" : "7896112163015",
    "display" : "Ostrazil 70 mg comprimido (Laboratório Teuto Brasileiro S/A) x 4 comprimidos"
  },
  {
    "code" : "7896676410877",
    "display" : "Parkidopa 250 mg + 25 mg comprimido (Cristália Produtos Químicos Farmacêuticos Ltda) x 30 comprimidos"
  },
  {
    "code" : "7899095200661",
    "display" : "Polol 40 mg comprimido (Geolab Indústria Farmacêutica S/A) x 30 comprimidos (2 blisters x 15)"
  },
  {
    "code" : "7893736001631",
    "display" : "Pranolal 40 mg comprimido (Cazi Quimica Farmaceutica Industria E Comercio Ltda) x 50 comprimidos"
  },
  {
    "code" : "7896004714455",
    "display" : "Pressel 10 mg comprimido; 30 comprimidos"
  },
  {
    "code" : "7896862910259",
    "display" : "Pressoflux 40 mg comprimido (Medquimica Industria Farmacêutica Ltda.) x 40 comprimidos"
  },
  {
    "code" : "7896862910969",
    "display" : "Pressomede 10 mg comprimido (Medquimica Industria Farmacêutica Ltda.) x 30 comprimidos"
  },
  {
    "code" : "7896112117858",
    "display" : "Pressotec 10 mg comprimido (Laboratório Teuto Brasileiro S/A) x 30 comprimidos"
  },
  {
    "code" : "7896862910884",
    "display" : "Presstopril 25 mg comprimido (Medquimica Industria Farmacêutica Ltda.) x 30 comprimidos"
  },
  {
    "code" : "7896226503721",
    "display" : "Prolopa 100 mg + 25 mg comprimido para suspensão (Produtos Roche Químicos E Farmacêuticos S.A) x 30 comprimidos"
  },
  {
    "code" : "7896226506371",
    "display" : "Prolopa BD 100 mg + 25 mg comprimido (Produtos Roche Químicos e Farmacêuticos S.A) x 30 comprimidos"
  },
  {
    "code" : "7896226506388",
    "display" : "Prolopa BD 100 mg + 25 mg comprimido (Produtos Roche Químicos e Farmacêuticos S.A) x 60 comprimidos"
  },
  {
    "code" : "7896226500362",
    "display" : "Prolopa HBS 100 mg + 25 mg cápsula de liberação prolongada (Produtos Roche Químicos E Farmacêuticos S.A) x 30 cápsulas"
  },
  {
    "code" : "7899620914056",
    "display" : "Propalol 40 mg comprimido (Laboratório Globo Ltda) x 30 comprimidos"
  },
  {
    "code" : "7898060131290",
    "display" : "Propalol 40 mg comprimido (Laboratório Globo Ltda) x 40 comprimidos"
  },
  {
    "code" : "7896523206646",
    "display" : "Propramed 40 mg comprimido (CIMED INDÚSTRIA DE MEDICAMENTOS LTDA) x 40 comprimidos"
  },
  {
    "code" : "7894916550055",
    "display" : "Propranolol 40 mg comprimido (EMS Sigma Pharma LTDA) x 30 comprimidos"
  },
  {
    "code" : "7899095201132",
    "display" : "Pryltec 10 mg comprimido (Geolab Indústria Farmacêutica S/A) x 30 comprimidos"
  },
  {
    "code" : "7896015591908",
    "display" : "Regrair 100 microgramas/dose suspensão aerossol; inalador (GLAXOSMITHKLINE BRASIL LTDA); 200 doses"
  },
  {
    "code" : "7896714200743",
    "display" : "Renalapril 10 mg comprimido (Brainfarma Indústria Química E Farmacêutica S.A) x 30 comprimidos"
  },
  {
    "code" : "7898049795833",
    "display" : "Renapril 10 mg comprimido (Vitamedic Industria Farmaceutica Ltda) x 30 comprimidos"
  },
  {
    "code" : "7897337705882",
    "display" : "Renitec 10 mg comprimido (ORGANON FARMACÊUTICA LTDA.) x 30 comprimidos"
  },
  {
    "code" : "7897917001182",
    "display" : "Renopril 10 mg comprimido (Belfar Ltda) x 30 comprimidos"
  },
  {
    "code" : "7898216369829",
    "display" : "Sinstiphar 20 mg comprimido (PHARLAB INDÚSTRIA FARMACÊUTICA S.A.); 30 comprimidos"
  },
  {
    "code" : "7898216369843",
    "display" : "Sinstiphar 40 mg comprimido (PHARLAB INDÚSTRIA FARMACÊUTICA S.A.); 30 comprimidos"
  },
  {
    "code" : "7894916206853",
    "display" : "Sinvalip 10 mg comprimido (EMS S/A) x 30 comprimidos"
  },
  {
    "code" : "7894916206860",
    "display" : "Sinvalip 20 mg comprimido (EMS S/A) x 30 comprimidos"
  },
  {
    "code" : "7894916206877",
    "display" : "Sinvalip 40 mg comprimido (EMS S/A) x 30 comprimidos"
  },
  {
    "code" : "7897851250394",
    "display" : "Sinvascor 10 mg comprimido (Laboratórios Baldacci Ltda) x 30 comprimidos"
  },
  {
    "code" : "7897851250530",
    "display" : "Sinvascor 20 mg comprimido (Laboratórios Baldacci Ltda) x 30 comprimidos"
  },
  {
    "code" : "7897851259915",
    "display" : "Sinvascor 40 mg comprimido (Laboratórios Baldacci Ltda) x 10 comprimidos"
  },
  {
    "code" : "7897851250622",
    "display" : "Sinvascor 40 mg comprimido (Laboratórios Baldacci Ltda) x 30 comprimidos"
  },
  {
    "code" : "7898060131566",
    "display" : "Sinvasmax 10 mg comprimido (Laboratório Globo Ltda) x 30 comprimidos"
  },
  {
    "code" : "7898060138114",
    "display" : "Sinvasmax 20 mg comprimido (Laboratório Globo Ltda) x 30 comprimidos"
  },
  {
    "code" : "7898060138091",
    "display" : "Sinvasmax 40 mg comprimido (Laboratório Globo Ltda) x 30 comprimidos"
  },
  {
    "code" : "7897595601766",
    "display" : "Sinvastacor 10 mg comprimido (Sandoz do Brasil Indústria Farmacêutica Ltda) x 30 comprimidos"
  },
  {
    "code" : "7897595601773",
    "display" : "Sinvastacor 20 mg comprimido (Sandoz do Brasil Indústria Farmacêutica Ltda) x 30 comprimidos"
  },
  {
    "code" : "7897595603180",
    "display" : "Sinvastacor 40 mg comprimido (Sandoz do Brasil Indústria Farmacêutica Ltda) x 10 comprimidos"
  },
  {
    "code" : "7897595604163",
    "display" : "Sinvastacor 40 mg comprimido (Sandoz do Brasil Indústria Farmacêutica Ltda) x 30 comprimidos"
  },
  {
    "code" : "7896523206660",
    "display" : "Sinvastamed 20 mg comprimido (Cimed Indústria de Medicamentos Ltda) x 30 comprimidos"
  },
  {
    "code" : "7896523215358",
    "display" : "Sinvastamed 40 mg comprimido (Cimed Indústria de Medicamentos Ltda) x 30 comprimidos"
  },
  {
    "code" : "7896112401346",
    "display" : "Sinvastatina 10 mg comprimido (Biolab Sanus Farmacêutica LTDA)"
  },
  {
    "code" : "7896004701943",
    "display" : "Sinvastatina 10 mg comprimido (EMS S.A.); 30 comprimidos"
  },
  {
    "code" : "7895296294010",
    "display" : "Sinvastatina 10 mg comprimido (EMS Sigma Pharma Ltda) x 30 comprimidos"
  },
  {
    "code" : "7899095249011",
    "display" : "Sinvastatina 10 mg comprimido (Geolab Indústria Farmacêutica S.A.); 10 comprimidos"
  },
  {
    "code" : "7899095249028",
    "display" : "Sinvastatina 10 mg comprimido (Geolab Indústria Farmacêutica S.A.); 30 comprimidos"
  },
  {
    "code" : "7896004711133",
    "display" : "Sinvastatina 10 mg comprimido (Germed Farmacêutica Ltda) x 30 comprimidos"
  },
  {
    "code" : "7891721028441",
    "display" : "Sinvastatina 10 mg comprimido (Merck S/A) x 30 comprimidos"
  },
  {
    "code" : "7896472511754",
    "display" : "Sinvastatina 10 mg comprimido (Multilab Indústria e Comércio de Produtos Farmacêuticos Ltda) x 30 comprimidos"
  },
  {
    "code" : "7898216366286",
    "display" : "Sinvastatina 10 mg comprimido (Pharlab Indústria Farmacêutica S.A.) x 30 comprimidos"
  },
  {
    "code" : "7897595609816",
    "display" : "Sinvastatina 10 mg comprimido (Sandoz do Brasil Indústria Farmacêutica Ltda) x 30 comprimidos"
  },
  {
    "code" : "7896422507837",
    "display" : "Sinvastatina 10 mg comprimido (Sanofi Medley Farmacêutica Ltda) x 30 comprimidos"
  },
  {
    "code" : "7898075314022",
    "display" : "Sinvastatina 20 mg comprimido (1Farma Industria Farmacêutica Ltda) x 30 comprimidos"
  },
  {
    "code" : "7896181913061",
    "display" : "Sinvastatina 20 mg comprimido (Aché Laboratórios Farmacêuticos S.A.) x 30 comprimidos"
  },
  {
    "code" : "7896112401384",
    "display" : "Sinvastatina 20 mg comprimido (Biolab Sanus Farmacêutica Ltda) x 30 comprimidos"
  },
  {
    "code" : "7896523215235",
    "display" : "Sinvastatina 20 mg comprimido (Cimed Indústria de Medicamentos Ltda) x 30 comprimidos"
  },
  {
    "code" : "7896004710761",
    "display" : "Sinvastatina 20 mg comprimido (EMS S/A) x 30 comprimidos"
  },
  {
    "code" : "7895296244060",
    "display" : "Sinvastatina 20 mg comprimido (EMS Sigma Pharma Ltda) x 30 comprimidos"
  },
  {
    "code" : "7899095249042",
    "display" : "Sinvastatina 20 mg comprimido (Geolab Indústria Farmacêutica S.A.); 10 comprimidos"
  },
  {
    "code" : "7899095249059",
    "display" : "Sinvastatina 20 mg comprimido (Geolab Indústria Farmacêutica S.A.); 30 comprimidos"
  },
  {
    "code" : "7896004710792",
    "display" : "Sinvastatina 20 mg comprimido (Germed Farmacêutica Ltda) x 30 comprimidos"
  },
  {
    "code" : "7899620911031",
    "display" : "Sinvastatina 20 mg comprimido (Laboratório Globo Ltda) x 30 comprimidos"
  },
  {
    "code" : "7894916140812",
    "display" : "Sinvastatina 20 mg comprimido (Legrand Pharma Indústria Farmacêutica Ltda) x 30 comprimidos"
  },
  {
    "code" : "7891721028458",
    "display" : "Sinvastatina 20 mg comprimido (Merck S/A) x 30 comprimidos"
  },
  {
    "code" : "7896472511808",
    "display" : "Sinvastatina 20 mg comprimido (Multilab Indústria e Comércio de Produtos Farmacêuticos Ltda) x 30 comprimidos"
  },
  {
    "code" : "7895296449274",
    "display" : "Sinvastatina 20 mg comprimido (Multilab Indústria e Comércio de Produtos Farmacêuticos Ltda) x 30 comprimidos"
  },
  {
    "code" : "7897595632548",
    "display" : "Sinvastatina 20 mg comprimido (Novartis Biociencias S.A) x 30 comprimidos"
  },
  {
    "code" : "7898216366309",
    "display" : "Sinvastatina 20 mg comprimido (Pharlab Indústria Farmacêutica S.A.) x 30 comprimidos"
  },
  {
    "code" : "7897076906960",
    "display" : "Sinvastatina 20 mg comprimido (Ranbaxy Farmacêutica Ltda) x 30 comprimidos"
  },
  {
    "code" : "7897595609830",
    "display" : "Sinvastatina 20 mg comprimido (Sandoz do Brasil Indústria Farmacêutica Ltda) x 10 comprimidos"
  },
  {
    "code" : "7897595609854",
    "display" : "Sinvastatina 20 mg comprimido (Sandoz do Brasil Indústria Farmacêutica Ltda) x 30 comprimidos"
  },
  {
    "code" : "7896422507844",
    "display" : "Sinvastatina 20 mg comprimido (Sanofi Medley Farmacêutica Ltda) x 30 comprimidos"
  },
  {
    "code" : "7898075314077",
    "display" : "Sinvastatina 40 mg comprimido (1Farma Industria Farmacêutica Ltda) x 30 comprimidos"
  },
  {
    "code" : "7896181913115",
    "display" : "Sinvastatina 40 mg comprimido (Aché Laboratórios Farmacêuticos S.A.) x 10 comprimidos"
  },
  {
    "code" : "7896181913627",
    "display" : "Sinvastatina 40 mg comprimido (Aché Laboratórios Farmacêuticos S.A.) x 30 comprimidos"
  },
  {
    "code" : "7896112401377",
    "display" : "Sinvastatina 40 mg comprimido (Biolab Sanus Farmacêutica Ltda) x 30 comprimidos"
  },
  {
    "code" : "7896523215273",
    "display" : "Sinvastatina 40 mg comprimido (Cimed Indústria de Medicamentos Ltda) x 30 comprimidos"
  },
  {
    "code" : "7896523200644",
    "display" : "Sinvastatina 40 mg comprimido (Cimed Indústria de Medicamentos Ltda) x 30 comprimidos"
  },
  {
    "code" : "7896004711188",
    "display" : "Sinvastatina 40 mg comprimido (EMS S/A) x 30 comprimidos"
  },
  {
    "code" : "7895296294027",
    "display" : "Sinvastatina 40 mg comprimido (EMS Sigma Pharma Ltda) x 30 comprimidos"
  },
  {
    "code" : "7899095249073",
    "display" : "Sinvastatina 40 mg comprimido (Geolab Indústria Farmacêutica S.A.); 10 comprimidos"
  },
  {
    "code" : "7899095249080",
    "display" : "Sinvastatina 40 mg comprimido (Geolab Indústria Farmacêutica S.A.); 30 comprimidos"
  },
  {
    "code" : "7896004711126",
    "display" : "Sinvastatina 40 mg comprimido (Germed Farmacêutica Ltda) x 30 comprimidos"
  },
  {
    "code" : "7896004737171",
    "display" : "Sinvastatina 40 mg comprimido (Germed Farmacêutica Ltda) x 60 comprimidos"
  },
  {
    "code" : "7899620911079",
    "display" : "Sinvastatina 40 mg comprimido (Laboratório Globo Ltda) x 30 comprimidos"
  },
  {
    "code" : "7894916141215",
    "display" : "Sinvastatina 40 mg comprimido (Legrand Pharma Indústria Farmacêutica Ltda) x 30 comprimidos"
  },
  {
    "code" : "7891721028472",
    "display" : "Sinvastatina 40 mg comprimido (Merck S/A) x 30 comprimidos"
  },
  {
    "code" : "7896472511853",
    "display" : "Sinvastatina 40 mg comprimido (Multilab Indústria e Comércio de Produtos Farmacêuticos Ltda) x 30 comprimidos"
  },
  {
    "code" : "7895296449281",
    "display" : "Sinvastatina 40 mg comprimido (Multilab Indústria e Comércio de Produtos Farmacêuticos Ltda) x 30 comprimidos"
  },
  {
    "code" : "7897595632623",
    "display" : "Sinvastatina 40 mg comprimido (Novartis Biociencias S.A) x 30 comprimidos"
  },
  {
    "code" : "7898216366323",
    "display" : "Sinvastatina 40 mg comprimido (Pharlab Indústria Farmacêutica S.A.) x 30 comprimidos"
  },
  {
    "code" : "7897076906977",
    "display" : "Sinvastatina 40 mg comprimido (Ranbaxy Farmacêutica Ltda) x 30 comprimidos"
  },
  {
    "code" : "7897595609892",
    "display" : "Sinvastatina 40 mg comprimido (Sandoz do Brasil Indústria Farmacêutica Ltda) x 30 comprimidos"
  },
  {
    "code" : "7896422508643",
    "display" : "Sinvastatina 40 mg comprimido (Sanofi Medley Farmacêutica Ltda) x 30 comprimidos"
  },
  {
    "code" : "7896137112722",
    "display" : "Sinvaston 20 mg comprimido (Sanval Comércio e Indústria Ltda) x 30 comprimidos"
  },
  {
    "code" : "7896004704470",
    "display" : "Sinvatrox 20 mg comprimido (Legrand Pharma Indústria Farmacêutica LTDA); 30 comprimidos"
  },
  {
    "code" : "7899095254947",
    "display" : "Sinvax 20 mg comprimido (Geolab Indústria Farmacêutica S/A) x 30 comprimidos"
  },
  {
    "code" : "7899095254961",
    "display" : "Sinvax 40 mg comprimido (Geolab Indústria Farmacêutica S/A) x 30 comprimidos"
  },
  {
    "code" : "7897473202771",
    "display" : "Sulfato de Salbutamol 100 microgramas/dose suspensão aerossol; inalador (Glenmark Farmacêutica LTDA); 1 frasco"
  },
  {
    "code" : "7899095201866",
    "display" : "Telol 25 mg comprimido (Geolab Indústria Farmacêutica S/A) x 30 comprimidos"
  },
  {
    "code" : "7896112197393",
    "display" : "Tenoftal 5 mg/mL solução oftálmica (LABORATÓRIO TEUTO BRASILEIRO S/A); 5 mL"
  },
  {
    "code" : "7898049795628",
    "display" : "Tenolon 25 mg comprimido (Vitamedic Industria Farmacêutica Ltda) x 30 comprimidos"
  },
  {
    "code" : "7896112198659",
    "display" : "Teusil 25 mg comprimido (Laboratório Teuto Brasileiro S/A) x 30 comprimidos"
  },
  {
    "code" : "7896112194279",
    "display" : "Teutoformin 500 mg comprimido (Laboratório Teuto Brasileiro S/A) x 30 comprimidos"
  },
  {
    "code" : "7896112194262",
    "display" : "Teutoformin 850 mg comprimido (Laboratório Teuto Brasileiro S/A) x 30 comprimidos"
  },
  {
    "code" : "7896714225005",
    "display" : "Timoneo 5 mg/mL solução oftálmica (BRAINFARMA INDÚSTRIA QUÍMICA E FARMACÊUTICA S.A); 5 mL"
  },
  {
    "code" : "7898586631397",
    "display" : "Timoptol 5 mg/mL gel oftálmico (MUNDIPHARMA BRASIL PRODUTOS MÉDICOS E FARMACÊUTICOS LTDA); 1 frasco 5 mL"
  },
  {
    "code" : "7898586631380",
    "display" : "Timoptol 5 mg/mL solução oftálmica (MUNDIPHARMA BRASIL PRODUTOS MÉDICOS E FARMACÊUTICOS LTDA); 1 frasco 5 mL"
  },
  {
    "code" : "7896676427066",
    "display" : "Timosan 5 mg/mL solução oftálmica (CRISTÁLIA PRODUTOS QUÍMICOS FARMACÊUTICOS LTDA.); 5 mL"
  },
  {
    "code" : "8902220105034",
    "display" : "Torlós 50 mg comprimido (Torrent do Brasil Ltda) x 14 comprimidos"
  },
  {
    "code" : "8903855062013",
    "display" : "Torlós 50 mg comprimido (Torrent do Brasil Ltda) x 30 comprimidos"
  },
  {
    "code" : "7898096578311",
    "display" : "Unak 10 mg comprimido (DIFFUCAP - CHEMOBRÁS QUÍMICA E FARMACÊUTICA LTDA); 10 comprimidos"
  },
  {
    "code" : "7898096578236",
    "display" : "Unak 10 mg comprimido (DIFFUCAP - CHEMOBRÁS QUÍMICA E FARMACÊUTICA LTDA); 30 comprimidos"
  },
  {
    "code" : "7898096578342",
    "display" : "Unak 20 mg comprimido (DIFFUCAP - CHEMOBRÁS QUÍMICA E FARMACÊUTICA LTDA); 10 comprimidos"
  },
  {
    "code" : "7898096578243",
    "display" : "Unak 20 mg comprimido (DIFFUCAP - CHEMOBRÁS QUÍMICA E FARMACÊUTICA LTDA); 30 comprimidos"
  },
  {
    "code" : "7898096578373",
    "display" : "Unak 40 mg comprimido (DIFFUCAP - CHEMOBRÁS QUÍMICA E FARMACÊUTICA LTDA); 10 comprimidos"
  },
  {
    "code" : "7898096578250",
    "display" : "Unak 40 mg comprimido (DIFFUCAP - CHEMOBRÁS QUÍMICA E FARMACÊUTICA LTDA); 30 comprimidos"
  },
  {
    "code" : "7896422510288",
    "display" : "Valtrian 50 mg comprimido (Sanofi Medley Farmacêutica Ltda) x 30 comprimidos"
  },
  {
    "code" : "7896241293737",
    "display" : "Vaslip 10 mg comprimido (Biolab Sanus Farmacêutica Ltda) x 30 comprimidos"
  },
  {
    "code" : "7896241228142",
    "display" : "Vaslip 20 mg comprimido (Biolab Sanus Farmacêutica Ltda) x 30 comprimidos"
  },
  {
    "code" : "7896241285022",
    "display" : "Vaslip 40 mg comprimido (Biolab Sanus Farmacêutica Ltda) x 30 comprimidos"
  },
  {
    "code" : "7896241293669",
    "display" : "Vasopril 10 mg comprimido (Biolab Sanus Farmacêutica Ltda) x 30 comprimidos"
  },
  {
    "code" : "7896112429913",
    "display" : "Vasopril 10 mg comprimido (Biolab Sanus Farmacêutica Ltda) x 45 comprimidos"
  },
  {
    "code" : "7896112414971",
    "display" : "Vasopril 10 mg comprimido (Biolab Sanus Farmacêutica Ltda) x 60 comprimidos"
  },
  {
    "code" : "7896004760322",
    "display" : "Visulin N 100 unidades internacionais/mL suspensão para injeção 10 mL; frasco-ampola (EMS S.A.); 1 frasco-ampola"
  },
  {
    "code" : "7896004762418",
    "display" : "Visulin N 100 unidades internacionais/mL suspensão para injeção 10 mL; frasco-ampola (EMS S.A.); 1 frasco-ampola"
  },
  {
    "code" : "7895197160063",
    "display" : "Wosulin N 100 unidades internacionais/mL solução para injeção 10 mL; frasco-ampola (GERAIS, COMÉRCIO E IMPORTAÇÃO DE MATERIAIS E EQUIPAMENTOS MEDICOS LTDA); 1 frasco-ampola"
  },
  {
    "code" : "7895197160117",
    "display" : "Wosulin N 100 unidades internacionais/mL solução para injeção 3 mL; carpule (GERAIS, COMÉRCIO E IMPORTAÇÃO DE MATERIAIS E EQUIPAMENTOS MEDICOS LTDA); 1 carpule"
  },
  {
    "code" : "7895197160148",
    "display" : "Wosulin N 100 unidades internacionais/mL solução para injeção 3 mL; carpule (GERAIS, COMÉRCIO E IMPORTAÇÃO DE MATERIAIS E EQUIPAMENTOS MEDICOS LTDA); 5 carpules"
  },
  {
    "code" : "7895197160032",
    "display" : "Wosulin R 100 unidades internacionais/mL solução para injeção 10 mL; frasco-ampola (GERAIS, COMÉRCIO E IMPORTAÇÃO DE MATERIAIS E EQUIPAMENTOS MEDICOS LTDA); 1 frasco-ampola"
  },
  {
    "code" : "7895197160100",
    "display" : "Wosulin R 100 unidades internacionais/mL solução para injeção 3 mL; carpule (GERAIS, COMÉRCIO E IMPORTAÇÃO DE MATERIAIS E EQUIPAMENTOS MEDICOS LTDA); 1 carpule"
  },
  {
    "code" : "7895197160131",
    "display" : "Wosulin R 100 unidades internacionais/mL solução para injeção 3 mL; carpule (GERAIS, COMÉRCIO E IMPORTAÇÃO DE MATERIAIS E EQUIPAMENTOS MEDICOS LTDA); 5 carpules"
  },
  {
    "code" : "7891317425869",
    "display" : "Zart 50 mg comprimido (Eurofarma Laboratórios S.A.) x 30 comprimidos"
  },
  {
    "code" : "7897337705752",
    "display" : "Zocor 10 mg comprimido (ORGANON FARMACÊUTICA LTDA.) x 30 comprimidos"
  },
  {
    "code" : "7897337701419",
    "display" : "Zocor 20 mg comprimido (ORGANON FARMACÊUTICA LTDA.) x 30 comprimidos"
  },
  {
    "code" : "7897337705769",
    "display" : "Zocor 40 mg comprimido (ORGANON FARMACÊUTICA LTDA.) x 10 comprimidos"
  }]
}

```
