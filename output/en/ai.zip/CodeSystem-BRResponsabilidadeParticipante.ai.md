# Responsabilidade no Contato Assistencial - Guia de Implementação do Sumário de Alta (SA) da RNDS v1.0.0-release

## CodeSystem: Responsabilidade no Contato Assistencial 

This Code system is referenced in the definition of the following value sets:

* [Reponsabilidade no Contato Assistencial](ValueSet-BRResponsabilidadeParticipante-1.0.md)

-------

 [Description of the above table(s)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "BRResponsabilidadeParticipante",
  "meta" : {
    "lastUpdated" : "2020-03-11T18:20:28.411+00:00"
  },
  "language" : "pt-BR",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-wg",
    "valueCode" : "ehr"
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-fmm",
    "valueInteger" : 1,
    "_valueInteger" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "https://fhir.saude.gov.br/sa/ImplementationGuide/br.gov.saude.sa.fhir"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
    "valueCode" : "normative",
    "_valueCode" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "https://fhir.saude.gov.br/sa/ImplementationGuide/br.gov.saude.sa.fhir"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-normative-version",
    "valueCode" : "4.0.1"
  }],
  "url" : "http://www.saude.gov.br/fhir/r4/CodeSystem/BRResponsabilidadeParticipante",
  "version" : "1.0.0-release",
  "name" : "BRResponsabilidadeParticipante",
  "title" : "Responsabilidade no Contato Assistencial",
  "status" : "active",
  "experimental" : false,
  "date" : "2020-03-11T18:20:48.9276301+00:00",
  "publisher" : "Ministério da Saúde do Brasil",
  "contact" : [{
    "name" : "Ministério da Saúde do Brasil",
    "telecom" : [{
      "system" : "url",
      "value" : "http://www.saude.gov.br"
    },
    {
      "system" : "email",
      "value" : "cgiis.datasus@saude.gov.br"
    }]
  }],
  "description" : "Classifica o tipo de responsabilidade de indivíduos ou profissionais no Contato Assisntecial.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "BR"
    }]
  }],
  "caseSensitive" : true,
  "content" : "complete",
  "concept" : [{
    "code" : "solicitante",
    "display" : "Profissional que solicitou o Contato Assistencial"
  },
  {
    "code" : "autorizador",
    "display" : "Profissional que autorizou a realização do Contato Assistencial"
  },
  {
    "code" : "admissao",
    "display" : "Profissional que admitiu do indivíduo no Contato Assistencial"
  },
  {
    "code" : "alta",
    "display" : "Profissional que realizou a alta do indivíduo no Contato Assistencial"
  },
  {
    "code" : "atendimento",
    "display" : "Profissional responsável pelo atendimento clínico Contato Assistencial"
  }]
}

```
