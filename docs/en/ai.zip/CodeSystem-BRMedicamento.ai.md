# Medicamento (CodeSystem) - Guia de Implementação do Sumário de Alta (SA) da RNDS v1.0.0-release

## CodeSystem: Medicamento (CodeSystem) 

 
Drogas dirigidas para uso humano, apresentadas em sua formulação final. 

This Code system is referenced in the definition of the following value sets:

* [Alérgenos](ValueSet-BRAlergenos-1.0.md)

-------

 [Description of the above table(s)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "BRMedicamento",
  "meta" : {
    "versionId" : "1",
    "lastUpdated" : "2020-09-20T20:43:12.27+00:00"
  },
  "language" : "pt-BR",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-wg",
    "valueCode" : "ehr"
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-fmm",
    "valueInteger" : 1,
    "_valueInteger" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "https://fhir.saude.gov.br/sa/ImplementationGuide/br.gov.saude.sa.fhir"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
    "valueCode" : "normative",
    "_valueCode" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "https://fhir.saude.gov.br/sa/ImplementationGuide/br.gov.saude.sa.fhir"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-normative-version",
    "valueCode" : "4.0.1"
  }],
  "url" : "http://www.saude.gov.br/fhir/r4/CodeSystem/BRMedicamento",
  "version" : "1.0.0-release",
  "name" : "BRMedicamento",
  "title" : "Medicamento (CodeSystem)",
  "status" : "active",
  "experimental" : false,
  "date" : "2020-09-20T20:43:08.980849+00:00",
  "publisher" : "Ministério da Saúde do Brasil",
  "contact" : [{
    "name" : "Ministério da Saúde do Brasil",
    "telecom" : [{
      "system" : "url",
      "value" : "http://www.saude.gov.br"
    },
    {
      "system" : "email",
      "value" : "cgiis.datasus@saude.gov.br"
    }]
  }],
  "description" : "Drogas dirigidas para uso humano, apresentadas em sua formulação final.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "BR"
    }]
  }],
  "caseSensitive" : true,
  "content" : "complete",
  "concept" : [{
    "code" : "BR0363843U0041",
    "display" : "ATAZANAVIR 300 MG CÁPSULA"
  },
  {
    "code" : "BR0268214U0005",
    "display" : "ATROPINA, SULFATO 0,25 MG/ML SOLUÇÃO INJETÁVEL 1 ML"
  },
  {
    "code" : "BR0292331-2",
    "display" : "SALBUTAMOL, SULFATO 0,4 MG/ML XAROPE  120 ML"
  },
  {
    "code" : "BR0268825",
    "display" : "TENOFOVIR 300MG COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0280883",
    "display" : "GLICOSAMINA, SULFATO + CONDROITINA, SULFATO 1,5 + 1,2 G PÓ PARA SOLUÇÃO ORAL"
  },
  {
    "code" : "BR0342526",
    "display" : "TIOTRÓPIO, BROMETO 18 MCG CÁPSULA"
  },
  {
    "code" : "BR0271582",
    "display" : "TOBRAMICINA 3 MG/G POMADA OFTÁLMICA  3,5 G"
  },
  {
    "code" : "BR0345783",
    "display" : "URÉIA 100 MG/G CREME  60 G"
  },
  {
    "code" : "BR0309040",
    "display" : "ÁCIDO URSODESOXICÓLICO 300 MG COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0273319",
    "display" : "INDOMETACINA 25 MG CÁPSULA"
  },
  {
    "code" : "BR0274921",
    "display" : "PINDOLOL 5 MG COMPRIMIDO"
  },
  {
    "code" : "BR0267779",
    "display" : "PARACETAMOL  750 MG COMPRIMIDO"
  },
  {
    "code" : "BR0268851",
    "display" : "NORFLOXACINO 400 MG COMPRIMIDO"
  },
  {
    "code" : "BR0273710",
    "display" : "NIMESULIDA 100 MG COMPRIMIDO"
  },
  {
    "code" : "BR0358755U0042",
    "display" : "MISOPROSTOL 200 MCG COMPRIMIDO"
  },
  {
    "code" : "BR0271434",
    "display" : "ESTROGÊNIOS CONJUGADOS 0,625 mg COMPRIMIDO"
  },
  {
    "code" : "BR0300725U0009",
    "display" : "FENOBARBITAL  100 MG/ML SOLUÇÃO INJETÁVEL 2 ML"
  },
  {
    "code" : "BR0305935-2",
    "display" : "PROPOFOL 10 MG/ML EMULSÃO INJETÁVEL 20 ML"
  },
  {
    "code" : "BR0268285",
    "display" : "NITRAZEPAM 5 MG MG COMPRIMIDO"
  },
  {
    "code" : "BR0268296",
    "display" : "INATIVO- ÁCIDO NALIDÍXICO 50 MG/ML SUSPENSÃO ORAL  100 ML"
  },
  {
    "code" : "BR0348672U0004",
    "display" : "SORO ANTIBOTRÓPICO SOLUÇÃO INJETÁVEL 10 ML"
  },
  {
    "code" : "BR0268513",
    "display" : "OXACILINA SÓDICA 500 MG PÓ PARA SOLUÇÃO INJETÁVEL"
  },
  {
    "code" : "BR0268076U0004",
    "display" : "MAGNÉSIO, SULFATO 10 % SOLUÇÃO INJETÁVEL  10 ML"
  },
  {
    "code" : "BR0268487",
    "display" : "MEROPENÉM 500 MG PÓ PARA SOLUÇÃO INJETÁVEL"
  },
  {
    "code" : "BR0358811U0118",
    "display" : "VACINA VARICELA (ATENUADA) SOLUÇÃO INJETÁVEL 0,5 ML"
  },
  {
    "code" : "BR0268416",
    "display" : "CEFTRIAXONA SÓDICA 500 MG PÓ PARA SOLUÇÃO INJETÁVEL   IV"
  },
  {
    "code" : "BR0272477",
    "display" : "CETIRIZINA, DICLORIDRATO 10 MG COMPRIMIDO"
  },
  {
    "code" : "BR0267573U0042",
    "display" : "VERAPAMIL, CLORIDRATO 120 MG COMPRIMIDO"
  },
  {
    "code" : "BR0268523U0005",
    "display" : "SALBUTAMOL, SULFATO 0,5 MG/ML SOLUÇÃO INJETÁVEL 1 ML"
  },
  {
    "code" : "BR0309441",
    "display" : "TRAMADOL, CLORIDRATO 100 MG COMPRIMIDO"
  },
  {
    "code" : "BR0367897",
    "display" : "IMUNOGLOBULINA HUMANA 50 MG/ML SOLUÇÃO INJETÁVEL  10 ML"
  },
  {
    "code" : "BR0267895",
    "display" : "RIVASTIGMINA, HIDROGENOTARTARATO 6 MG CÁPSULA"
  },
  {
    "code" : "BR0286632",
    "display" : "SULPIRIDA 200 MG COMPRIMIDO"
  },
  {
    "code" : "BR0270557",
    "display" : "ACETILCISTEÍNA 200 MG GRANULADO 5 G"
  },
  {
    "code" : "BR0271746",
    "display" : "BACLOFENO 10 MG COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0335097U0042",
    "display" : "CLORANFENICOL 250 MG  COMPRIMIDO"
  },
  {
    "code" : "BR0335101-1",
    "display" : "CLORANFENICOL 5 MG/ML SOLUÇÃO OFTÁLMICA 8 ML"
  },
  {
    "code" : "BR0268153",
    "display" : "SULFASSALAZINA 500 MG COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0271647",
    "display" : "OXIMETAZOLINA, CLORIDRATO 0,25 mg/ml SOLUÇÃO NASAL 20 ML"
  },
  {
    "code" : "BR0268375U0233",
    "display" : "ACICLOVIR 5 % CREME  5 G"
  },
  {
    "code" : "BR0269592",
    "display" : "DIMETICONA 40mg COMPRIMIDO"
  },
  {
    "code" : "BR0283156",
    "display" : "DIPIRONA + CAFEÍNA + ORFENADRINA 300 + 50 + 35 MG COMPRIMIDO"
  },
  {
    "code" : "BR0322254",
    "display" : "ESTAZOLAM 2 MG COMPRIMIDO"
  },
  {
    "code" : "BR0272045",
    "display" : "CLOPIDOGREL, BISSULFATO 75 MG  COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0276270",
    "display" : "MONTELUCASTE DE SÓDIO 5 MG COMPRIMIDO MASTIGÁVEL ELENCO ESTADUAL"
  },
  {
    "code" : "BR0276271",
    "display" : "MONTELUCASTE DE SÓDIO 10 MG COMPRIMIDO"
  },
  {
    "code" : "BR0268265-2",
    "display" : "IODETO DE POTÁSSIO 2 % XAROPE  150 ML"
  },
  {
    "code" : "BR0271356",
    "display" : "ALPRAZOLAM 1 MG COMPRIMIDO"
  },
  {
    "code" : "BR0275478",
    "display" : "PERICIAZINA 10 MG COMPRIMIDO"
  },
  {
    "code" : "BR0272825",
    "display" : "PRAMIPEXOL, CLORIDRATO 0,25 MG COMPRIMIDO"
  },
  {
    "code" : "BR0304181",
    "display" : "TIMOMODULINA 80 MG CÁPSULA"
  },
  {
    "code" : "BR0268356U0087",
    "display" : "RITONAVIR 80 MG/ML SOLUÇÃO ORAL 240 ML"
  },
  {
    "code" : "BR0269835-1",
    "display" : "LIDOCAÍNA, CLORIDRATO + PRILOCAÍNA 2,5 % + 2,5 % CREME  5 G"
  },
  {
    "code" : "BR0271866-1",
    "display" : "BRINZOLAMIDA 10 MG/ML SOLUÇÃO OFTÁLMICA 5 ML"
  },
  {
    "code" : "BR0272091",
    "display" : "VITAMINAS DO COMPLEXO B (B1,B2,B3,B5,B6) SOLUÇÃO INJETÁVEL  2 ML"
  },
  {
    "code" : "BR0401225U0238",
    "display" : "VACINA ADSORVIDA DIFTERIA, TÉTANO E PERTUSSIS SOLUÇÃO INJETÁVEL 10 ML"
  },
  {
    "code" : "BR0318690U0063",
    "display" : "VACINA POLIOMIELITE 1, 2 E 3 (ATENUADA) SOLUÇÃO ORAL"
  },
  {
    "code" : "BR0274807",
    "display" : "BETAISTINA, DICLORIDRATO 8 MG COMPRIMIDO"
  },
  {
    "code" : "BR0292249-2",
    "display" : "METOTREXATO 25 MG/ML SOLUÇÃO INJETÁVEL 20 ML"
  },
  {
    "code" : "BR0274631-1",
    "display" : "MONTELUCASTE DE SÓDIO 4 MG COMPRIMIDO MASTIGÁVEL"
  },
  {
    "code" : "BR0269962",
    "display" : "DOMPERIDONA 10 MG COMPRIMIDO"
  },
  {
    "code" : "BR0268493U0042",
    "display" : "DOXAZOSINA, MESILATO 2 MG COMPRIMIDO"
  },
  {
    "code" : "BR0268495U0042",
    "display" : "DOXAZOSINA, MESILATO 4 MG COMPRIMIDO"
  },
  {
    "code" : "BR0271848-1",
    "display" : "BIMATOPROSTA 0,3 MG/ML SOLUÇÃO OFTÁLMICA 3 ML ELENCO ESTADUAL"
  },
  {
    "code" : "BR0274191-1",
    "display" : "BRIMONIDINA, TARTARATO 0,15 % SOLUÇÃO OFTÁLMICA 5 ML ELENCO ESTADUAL"
  },
  {
    "code" : "BR0273621",
    "display" : "SULFATO FERROSO (60MG DE FERRO ELEMENTAR) 300 MG COMPRIMIDO"
  },
  {
    "code" : "BR0269574U0007",
    "display" : "BUPIVACAÍNA, CLORIDRATO 0,5 % SOLUÇÃO INJETÁVEL 20 ML"
  },
  {
    "code" : "BR0271876",
    "display" : "RINGER SIMPLES SOLUÇÃO INJETÁVEL  500 ML"
  },
  {
    "code" : "BR0268149",
    "display" : "RISPERIDONA 2 MG COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0267151",
    "display" : "CETOCONAZOL 200 MG  COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0274806",
    "display" : "ACETILCISTEÍNA 600 MG GRANULADO 5 G"
  },
  {
    "code" : "BR0334016-2",
    "display" : "FLUTICASONA, PROPIONATO 50 MCG AEROSSOL 120 DOSES"
  },
  {
    "code" : "BR0268831U0041",
    "display" : "SAQUINAVIR, MESILATO 200 MG CÁPSULA"
  },
  {
    "code" : "BR0308877",
    "display" : "SEVOFLURANO SOLUÇÃO PARA INALAÇÃO 250 ML"
  },
  {
    "code" : "BR0362802",
    "display" : "VILDAGLIPTINA 50 MG COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0267768U0042",
    "display" : "PROMETAZINA, CLORIDRATO 25 MG COMPRIMIDO"
  },
  {
    "code" : "BR0358753U0042",
    "display" : "MISOPROSTOL 25 MCG COMPRIMIDO"
  },
  {
    "code" : "BR0272334-2",
    "display" : "DIMENIDRINATO + PIRIDOXINA 50 + 50 MG/ML SOLUÇÃO INJETÁVEL 10 ML"
  },
  {
    "code" : "BR0368499-1",
    "display" : "VITAMINAS DO COMPLEXO B (B1,B2,B3,B5,B6) DRÁGEA"
  },
  {
    "code" : "BR0305270U0042",
    "display" : "LEVOFLOXACINO 500 MG COMPRIMIDO"
  },
  {
    "code" : "BR0267571",
    "display" : "DILTIAZEM, CLORIDRATO 90 MG CÁPSULA DURA DE LIBERAÇÃO PROLONGADA"
  },
  {
    "code" : "BR0267570",
    "display" : "DILTIAZEM, CLORIDRATO 180 MG CÁPSULA DURA DE LIBERAÇÃO PROLONGADA"
  },
  {
    "code" : "BR0308226",
    "display" : "METILFENIDATO, CLORIDRATO 36 MG COMPRIMIDO"
  },
  {
    "code" : "BR0274438",
    "display" : "VALSARTANA 80 MG COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0271950-3",
    "display" : "FENTANILA, CITRATO 0,05 MG/ML SOLUÇÃO INJETÁVEL  10 ML"
  },
  {
    "code" : "BR0353332U0042",
    "display" : "RALTEGRAVIR 400 MG COMPRIMIDO"
  },
  {
    "code" : "BR0266827",
    "display" : "IMUNOGLOBULINA ANTI-RHO (D) 300 MCG SOLUÇÃO INJETÁVEL  2 ML"
  },
  {
    "code" : "BR0393341",
    "display" : "RIBOFLAVINA 200 MG CÁPSULA"
  },
  {
    "code" : "BR0268510U0013",
    "display" : "FLUMAZENIL 0,1 MG/ML SOLUÇÃO INJETÁVEL 5 ML"
  },
  {
    "code" : "BR0273639-1",
    "display" : "MULTIVITAMINAS + SAIS MINERAIS COMPRIMIDO"
  },
  {
    "code" : "BR0268411",
    "display" : "CEFOTAXIMA 1G PÓ PARA SOLUÇÃO INJETÁVEL"
  },
  {
    "code" : "BR0270114-2",
    "display" : "CETAMINA, CLORIDRATO DE  50 MG/ML SOLUÇÃO INJETÁVEL 10 ML"
  },
  {
    "code" : "BR0306361U0042",
    "display" : "CARBONATO DE CÁLCIO + COLECALCIFEROL  600 MG + 400 UI COMPRIMIDO"
  },
  {
    "code" : "BR0294097U0118",
    "display" : "CEFTRIAXONA SÓDICA 250 MG PÓ PARA SOLUÇÃO INJETÁVEL"
  },
  {
    "code" : "BR0270769",
    "display" : "ISOCONAZOL, NITRATO 600 MG ÓVULO"
  },
  {
    "code" : "BR0327792",
    "display" : "CEFALEXINA 25 MG/ML SUSPENSÃO ORAL  60 ML"
  },
  {
    "code" : "BR0267077",
    "display" : "BEZAFIBRATO 200 MG COMPRIMIDO"
  },
  {
    "code" : "BR0352301",
    "display" : "INDAPAMIDA 1,5 MG COMPRIMIDO"
  },
  {
    "code" : "BR0273941",
    "display" : "PAROXETINA, CLORIDRATO 30 MG COMPRIMIDO"
  },
  {
    "code" : "BR0267256",
    "display" : "FENOTEROL, BROMIDRATO 5 MG/ML SOLUÇÃO PARA NEBULIZAÇÃO 20 ML"
  },
  {
    "code" : "BR0305494",
    "display" : "DIDROGESTERONA 10 mg COMPRIMIDO"
  },
  {
    "code" : "BR0276839U0013",
    "display" : "ÁGUA DESTILADA SOLUÇÃO INJETÁVEL 5 ML"
  },
  {
    "code" : "BR0437160U0105",
    "display" : "CLORETO DE SÓDIO 0,9 % SOLUÇÃO NASAL 50 ML"
  },
  {
    "code" : "BR0268081",
    "display" : "ATORVASTATINA CÁLCICA 20 MG COMPRIMIDO"
  },
  {
    "code" : "BR0267515-1",
    "display" : "AMPICILINA 500 MG CÁPSULA"
  },
  {
    "code" : "INATIVO 27",
    "display" : "INATIVO-OXIBUTININA, CLORIDRATO 1 MG/ML SOLUÇÃO ORAL  100 ML"
  },
  {
    "code" : "BR0267728U0042",
    "display" : "NIFEDIPINO 10 MG COMPRIMIDO"
  },
  {
    "code" : "BR0267203U0042",
    "display" : "DIPIRONA SÓDICA  500 MG COMPRIMIDO"
  },
  {
    "code" : "BR0267293",
    "display" : "IMIPRAMINA, CLORIDRATO 10 MG COMPRIMIDO"
  },
  {
    "code" : "BR0268442",
    "display" : "SUXAMETÔNIO, CLORETO 100 MG PÓ PARA SOLUÇÃO INJETÁVEL"
  },
  {
    "code" : "BR0267416",
    "display" : "TEOFILINA 200 MG CÁPSULA"
  },
  {
    "code" : "BR0268359U0041",
    "display" : "ZIDOVUDINA 100 MG CÁPSULA"
  },
  {
    "code" : "BR0268360U0085",
    "display" : "ZIDOVUDINA 10 MG/ML XAROPE  200 ML"
  },
  {
    "code" : "BR0268077",
    "display" : "CIPROTERONA, ACETATO 50 MG  COMPRIMIDO"
  },
  {
    "code" : "BR0305356",
    "display" : "NICOTINA 4 MG GOMA DE MASCAR"
  },
  {
    "code" : "BR0385435",
    "display" : "BETAMETASONA 0,5 MG COMPRIMIDO"
  },
  {
    "code" : "BR0273598",
    "display" : "TIORIDAZINA, CLORIDRATO 10 MG COMPRIMIDO"
  },
  {
    "code" : "BR0272089U0123",
    "display" : "SULFADIAZINA DE PRATA 1% CREME  500 G"
  },
  {
    "code" : "BR0268222U0004",
    "display" : "BICARBONATO DE SÓDIO 8,4 % SOLUÇÃO INJETÁVEL 10 ML"
  },
  {
    "code" : "BR0273310",
    "display" : "HIDROXIZINA, CLORIDRATO 25 MG COMPRIMIDO"
  },
  {
    "code" : "BR0308225",
    "display" : "METILFENIDATO, CLORIDRATO 54 MG COMPRIMIDO"
  },
  {
    "code" : "BR0282222-2",
    "display" : "CARBOCISTEÍNA 20 MG/ML XAROPE  80 ML"
  },
  {
    "code" : "BR0348002-2",
    "display" : "ÁCIDOS GRAXOS ESSENCIAIS SOLUÇÃO 200 ML"
  },
  {
    "code" : "BR0270713",
    "display" : "TENECTEPLASE 40 MG PÓ PARA SOLUÇÃO INJETÁVEL 8 ML"
  },
  {
    "code" : "BR0278260",
    "display" : "TIOPENTAL SÓDICO 500 MG PÓ LIOFILIZADO"
  },
  {
    "code" : "BR0271003",
    "display" : "DICLOFENACO SÓDICO 25 MG/ML SOLUÇÃO INJETÁVEL 3 ML"
  },
  {
    "code" : "BR0272487",
    "display" : "DIDANOSINA 25 MG COMPRIMIDO"
  },
  {
    "code" : "BR0272488",
    "display" : "DIDANOSINA 100 MG COMPRIMIDO"
  },
  {
    "code" : "BR0337473",
    "display" : "INSULINA DETEMIR 100 UI/ML SOLUÇÃO INJETÁVEL 3 ML ELENCO ESTADUAL"
  },
  {
    "code" : "BR0272580",
    "display" : "DORZOLAMIDA 2 % SOLUÇÃO OFTÁLMICA 5 ML ELENCO ESTADUAL"
  },
  {
    "code" : "BR0268456",
    "display" : "ENOXAPARINA SÓDICA  100 MG SOLUÇÃO INJETÁVEL 1 ML"
  },
  {
    "code" : "BR0269991",
    "display" : "ERITROMICINA, ESTEARATO 250 MG COMPRIMIDO"
  },
  {
    "code" : "BR0272362U0013",
    "display" : "PROTAMINA, CLORIDRATO 10 MG/ML SOLUÇÃO INJETÁVEL 5 ML"
  },
  {
    "code" : "INATIVO VI",
    "display" : "INATIVO-LANATOSÍDEO C 0,2 MG/ML SOLUÇÃO INJETÁVEL  2 ML"
  },
  {
    "code" : "BR0302748U0074",
    "display" : "PIRAZINAMIDA 30 MG/ML SUSPENSÃO ORAL  150 ML"
  },
  {
    "code" : "BR0272343",
    "display" : "TIAMINA, CLORIDRATO 100 MG/ML SOLUÇÃO INJETÁVEL  1 ML"
  },
  {
    "code" : "BR0271110",
    "display" : "CIPROTERONA + ETINILESTRADIOL 2 + 0,035 MG  DRÁGEA"
  },
  {
    "code" : "BR0274115",
    "display" : "GELATINA 3,5 % SOLUÇÃO INJETÁVEL  500 ML"
  },
  {
    "code" : "BR0394865",
    "display" : "ÁCIDO TIÓCTICO 600 MG COMPRIMIDO"
  },
  {
    "code" : "BR0403359-1",
    "display" : "INSULINA GLULISINA 100 UI/ML SOLUÇÃO INJETÁVEL 3 ML ELENCO ESTADUAL"
  },
  {
    "code" : "BR0272572",
    "display" : "BUSPIRONA, CLORIDRATO 5 MG COMPRIMIDO"
  },
  {
    "code" : "BR0272044",
    "display" : "CLONIDINA, CLORIDRATO 0,15 mg  COMPRIMIDO"
  },
  {
    "code" : "BR0267569",
    "display" : "DILTIAZEM, CLORIDRATO 30 MG COMPRIMIDO"
  },
  {
    "code" : "BR0267571-1",
    "display" : "DILTIAZEM, CLORIDRATO 90 MG COMPRIMIDO"
  },
  {
    "code" : "BR0276375",
    "display" : "DILTIAZEM, CLORIDRATO 300 MG CÁPSULA DURA DE LIBERAÇÃO PROLONGADA"
  },
  {
    "code" : "BR0268222U0090",
    "display" : "BICARBONATO DE SÓDIO 8,4 % SOLUÇÃO INJETÁVEL 250 ML"
  },
  {
    "code" : "BR0278304U0135",
    "display" : "VACINA HUMANA, HAEMOPHILUS INFLUENZA TIPO B (HIB)  SOLUÇÃO INJETÁVEL"
  },
  {
    "code" : "BR0271168",
    "display" : "LISINOPRIL 10 MG COMPRIMIDO"
  },
  {
    "code" : "BR0271391",
    "display" : "MORFINA, SULFATO 30 MG COMPRIMIDO"
  },
  {
    "code" : "BR0270096",
    "display" : "BUPIVACAÍNA + EPINEFRINA 0,5 % SOLUÇÃO INJETÁVEL  20 ML"
  },
  {
    "code" : "BR0272931",
    "display" : "FLUNITRAZEPAM 1 MG COMPRIMIDO"
  },
  {
    "code" : "BR0271790-3",
    "display" : "FENILEFRINA, CLORIDRATO 10 % SOLUÇÃO OFTÁLMICA 15 ML"
  },
  {
    "code" : "BR0268202",
    "display" : "ACARBOSE 50 MG COMPRIMIDO"
  },
  {
    "code" : "BR0277526-1",
    "display" : "DIDANOSINA 400 MG COMPRIMIDO"
  },
  {
    "code" : "BR0273836-2",
    "display" : "INSULINA GLARGINA 100 UI/ML SOLUÇÃO INJETÁVEL 10 ML ELENCO ESTADUAL"
  },
  {
    "code" : "BR0268812U0042",
    "display" : "EFAVIRENZ 600 MG COMPRIMIDO"
  },
  {
    "code" : "BR0268808U0077",
    "display" : "EFAVIRENZ 30 MG/ML SOLUÇÃO ORAL 180 ML"
  },
  {
    "code" : "BR0268469",
    "display" : "ISOFLURANO 100 MG/ML SOLUÇÃO PARA INALAÇÃO 100 ML"
  },
  {
    "code" : "BR0350588",
    "display" : "LOPINAVIR + RITONAVIR 133,3 + 33 MG CÁPSULA"
  },
  {
    "code" : "BR0291951",
    "display" : "NITRATO DE PRATA 10 MG/ML SOLUÇÃO OFTÁLMICA 3 ML"
  },
  {
    "code" : "BR0268504",
    "display" : "ONDANSETRONA, CLORIDRATO 2 MG/ML SOLUÇÃO INJETÁVEL 2 ML"
  },
  {
    "code" : "BR0395720",
    "display" : "CARNITINA 1 G CÁPSULA"
  },
  {
    "code" : "BR0267418 -3",
    "display" : "TIABENDAZOL 50 MG/G POMADA 45 G"
  },
  {
    "code" : "BR0272326U0005",
    "display" : "NALOXONA, CLORIDRATO 0,4 MG/ML SOLUÇÃO INJETÁVEL 1 ML"
  },
  {
    "code" : "BR0324587",
    "display" : "MANIDIPINO 20 MG COMPRIMIDO"
  },
  {
    "code" : "BR0272329",
    "display" : "PETIDINA 50 MG/ML SOLUÇÃO INJETÁVEL 2 ML"
  },
  {
    "code" : "BR0292237",
    "display" : "MESALAZINA 400 MG COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0279271U0042",
    "display" : "VARFARINA SÓDICA  1 MG COMPRIMIDO"
  },
  {
    "code" : "BR0267425U0042",
    "display" : "VERAPAMIL, CLORIDRATO 80 MG COMPRIMIDO"
  },
  {
    "code" : "BR0278281",
    "display" : "ADENOSINA, FOSFATO 3 MG/ML SOLUÇÃO INJETÁVEL 2 ML"
  },
  {
    "code" : "BR0268396",
    "display" : "ATRACÚRIO 10 MG/ML SOLUÇÃO INJETÁVEL  5 ML"
  },
  {
    "code" : "BR0268228",
    "display" : "CEFALOTINA 1 G  PÓ PARA SOLUÇÃO INJETÁVEL"
  },
  {
    "code" : "BR0292382",
    "display" : "TRAMADOL, CLORIDRATO 50 MG/ML SOLUÇÃO INJETÁVEL  2 ML"
  },
  {
    "code" : "BR0272853",
    "display" : "VIGABATRINA 500 MG COMPRIMIDO"
  },
  {
    "code" : "BR0268361U0086",
    "display" : "ZIDOVUDINA 10 MG/ML SOLUÇÃO INJETÁVEL 20 ML"
  },
  {
    "code" : "BR0340101",
    "display" : "CETOPROFENO 100 mg  PÓ PARA SUSPENSÃO INJETÁVEL"
  },
  {
    "code" : "BR0335104",
    "display" : "CLORANFENICOL 30 MG/ML SUSPENSÃO ORAL  60 ML"
  },
  {
    "code" : "BR0274497",
    "display" : "CLORTALIDONA 25 MG  COMPRIMIDO"
  },
  {
    "code" : "BR0268958-2",
    "display" : "COLAGENASE 0,6 UI/G POMADA 30 G"
  },
  {
    "code" : "BR0271154U0137",
    "display" : "INSULINA HUMANA REGULAR 100 UI/ML SOLUÇÃO INJETÁVEL 3 ML"
  },
  {
    "code" : "BR0266788-1",
    "display" : "NISTATINA 25.000 UI/G CREME VAGINAL  50 G"
  },
  {
    "code" : "BR0267378U0110",
    "display" : "NISTATINA 100.000 UI/ML SUSPENSÃO ORAL  60  ML"
  },
  {
    "code" : "BR0267776-1",
    "display" : "PARACETAMOL  100 MG/ML SOLUÇÃO ORAL 10 ML"
  },
  {
    "code" : "BR0268150U0062",
    "display" : "PREDNISOLONA 3 MG/ML SOLUÇÃO ORAL 100 ML"
  },
  {
    "code" : "BR0268150U0067",
    "display" : "PREDNISOLONA 3 MG/ML SOLUÇÃO ORAL 120 ML"
  },
  {
    "code" : "BR0267776-2",
    "display" : "PARACETAMOL  100 MG/ML SUSPENSÃO ORAL  15 ML"
  },
  {
    "code" : "BR0328364U0042",
    "display" : "TRATAMENTO PAUCIBACILAR ADULTO COMPRIMIDO"
  },
  {
    "code" : "BR0376107U0140",
    "display" : "NICOTINA 21 MG ADESIVO TRANSDÉRMICO"
  },
  {
    "code" : "BR0376105U0140",
    "display" : "NICOTINA 7 MG ADESIVO TRANSDÉRMICO"
  },
  {
    "code" : "BR0376106U0140",
    "display" : "NICOTINA 14 MG ADESIVO TRANSDÉRMICO"
  },
  {
    "code" : "BR0382197",
    "display" : "TRIMETAZIDINA 35 MG COMPRIMIDO"
  },
  {
    "code" : "BR0327766-2",
    "display" : "CARBONATO DE CÁLCIO + COLECALCIFEROL  600 MG + 200 UI COMPRIMIDO EFERVESCENTE"
  },
  {
    "code" : "BR0268315U0042",
    "display" : "ABACAVIR 300 MG COMPRIMIDO"
  },
  {
    "code" : "BR0268374U0118",
    "display" : "ACICLOVIR 250 MG PÓ PARA SOLUÇÃO INJETÁVEL ELENCO ESTADUAL"
  },
  {
    "code" : "BR0267511",
    "display" : "AMINOFILINA 100 MG COMPRIMIDO"
  },
  {
    "code" : "BR0268322",
    "display" : "AMPRENAVIR 15 MG/ML MG/ML PÓ PARA SOLUÇÃO 240 ML"
  },
  {
    "code" : "BR0268819",
    "display" : "ATAZANAVIR 150 MG CÁPSULA"
  },
  {
    "code" : "BR0380419",
    "display" : "BIMATOPROSTA + TIMOLOL 0,03 + 0,5 MG/ML SOLUÇÃO OFTÁLMICA 3 ML"
  },
  {
    "code" : "BR0268540",
    "display" : "VANCOMICINA 500 MG PÓ PARA SOLUÇÃO INJETÁVEL"
  },
  {
    "code" : "BR0272901",
    "display" : "CLOBAZAM 10 MG  COMPRIMIDO"
  },
  {
    "code" : "BR0299129U0041",
    "display" : "CLOFAZIMINA 100 MG CÁPSULA"
  },
  {
    "code" : "BR0268069U0013",
    "display" : "CLORPROMAZINA, CLORIDRATO 5 MG/ML SOLUÇÃO INJETÁVEL 5 ML"
  },
  {
    "code" : "BR0271157U0063",
    "display" : "INSULINA HUMANA NPH 100 UI/ML SUSPENSÃO INJETÁVEL 10 ML ELENCO ESTADUAL"
  },
  {
    "code" : "BR0272334-1",
    "display" : "DIMENIDRINATO + PIRIDOXINA 50 + 50 MG/ML SOLUÇÃO INJETÁVEL 1 ML"
  },
  {
    "code" : "BR0267107U0013",
    "display" : "FENITOÍNA SÓDICA  50 MG/ML SOLUÇÃO INJETÁVEL 5 ML"
  },
  {
    "code" : "BR0305247-1",
    "display" : "LACTULOSE 667 MG/ML SOLUÇÃO ORAL  120 ML"
  },
  {
    "code" : "BR0268128",
    "display" : "LEVOMEPROMAZINA 25 MG COMPRIMIDO"
  },
  {
    "code" : "BR0350589U0042",
    "display" : "LOPINAVIR + RITONAVIR 200 + 50 MG COMPRIMIDO"
  },
  {
    "code" : "BR0327212",
    "display" : "LUGOL 5 % SOLUÇÃO 1000 ML"
  },
  {
    "code" : "BR0267625U0042",
    "display" : "CEFALEXINA 500 MG  COMPRIMIDO"
  },
  {
    "code" : "BR0267515-2",
    "display" : "AMPICILINA 500 MG COMPRIMIDO"
  },
  {
    "code" : "BR0268273-2",
    "display" : "NITROFURANTOÍNA 100 MG COMPRIMIDO"
  },
  {
    "code" : "BR0348660U0106",
    "display" : "SORO ANTI-RÁBICO SOLUÇÃO INJETÁVEL 5 ML"
  },
  {
    "code" : "BR0287473",
    "display" : "LOSARTANA POTÁSSICA 100 MG COMPRIMIDO"
  },
  {
    "code" : "BR0275428",
    "display" : "NEOMICINA + CLOSTEBOL 5 + 5 MG/G CREME  30 G"
  },
  {
    "code" : "BR0274036-1",
    "display" : "PIROXICAM 20 MG COMPRIMIDO"
  },
  {
    "code" : "BR0337478-2",
    "display" : "SALMETEROL, XINAFOATO + FLUTICASONA 50 + 100 MCG PÓ PARA INALAÇÃO ORAL 120 DOSES"
  },
  {
    "code" : "BR0267503U0042",
    "display" : "ÁCIDO FÓLICO 5 MG COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0267504U0042",
    "display" : "ÁCIDO VALPRÓICO (VALPROATO DE SÓDIO)  250 MG COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0392264",
    "display" : "CARBAMAZEPINA  20 MG/ML XAROPE  100 ML"
  },
  {
    "code" : "BR0270895U0042",
    "display" : "CARBONATO DE CÁLCIO (CÁLCIO ELEMENTAR) 500 MG COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0267566U0042",
    "display" : "CARVEDILOL 3,125 MG  COMPRIMIDO"
  },
  {
    "code" : "BR0267523U0042",
    "display" : "CLOMIPRAMINA, CLORIDRATO 10 MG  COMPRIMIDO"
  },
  {
    "code" : "BR0267635U0042",
    "display" : "CLORPROMAZINA, CLORIDRATO 25 MG  COMPRIMIDO"
  },
  {
    "code" : "BR0267643U0015",
    "display" : "DEXAMETASONA  0,1 % CREME  10 G"
  },
  {
    "code" : "BR0268243U0067",
    "display" : "DEXAMETASONA  0,1 MG/ML ELIXIR 120 ML"
  },
  {
    "code" : "BR0267646U0062",
    "display" : "DEXCLORFENIRAMINA, MALEATO 0,4 MG/ML SOLUÇÃO ORAL 100 ML"
  },
  {
    "code" : "BR0298454U0067",
    "display" : "DEXCLORFENIRAMINA, MALEATO 0,4 MG/ML XAROPE  120 ML"
  },
  {
    "code" : "BR0269994-1",
    "display" : "ERITROMICINA, ESTEARATO 50 MG/ML SUSPENSÃO ORAL  50 ML"
  },
  {
    "code" : "BR0272789U0042",
    "display" : "LEVONORGESTREL + ETINILESTRADIOL  0,15 + 0,03 MG COMPRIMIDO"
  },
  {
    "code" : "BR0267663U0042",
    "display" : "FUROSEMIDA 40 MG COMPRIMIDO"
  },
  {
    "code" : "BR0372372U0106",
    "display" : "GENTAMICINA, SULFATO 5 MG/ML SOLUÇÃO OFTÁLMICA 5 ML"
  },
  {
    "code" : "BR0291174",
    "display" : "GENTAMICINA, SULFATO 5 MG/G POMADA 3,5 G"
  },
  {
    "code" : "BR0269622U0103",
    "display" : "GLICEROL   120 MG/ML ENEMA  500 ML"
  },
  {
    "code" : "BR0268185",
    "display" : "GLICEROL   95% INFANTIL SUPOSITÓRIO"
  },
  {
    "code" : "BR0292195U0063",
    "display" : "HALOPERIDOL 2 MG/ML SOLUÇÃO ORAL 10 ML"
  },
  {
    "code" : "BR0267670U0042",
    "display" : "HALOPERIDOL 1 MG COMPRIMIDO"
  },
  {
    "code" : "BR0271653-1",
    "display" : "HIDROXOCOBALAMINA, ACETATO 1 MG/ML SOLUÇÃO INJETÁVEL 1 ML"
  },
  {
    "code" : "BR0373910-2",
    "display" : "HIPROMELOSE 2 MG/ML SOLUÇÃO OFTÁLMICA 4 ML"
  },
  {
    "code" : "BR0373909U0106",
    "display" : "HIPROMELOSE 3 MG/ML SOLUÇÃO OFTÁLMICA 5 ML"
  },
  {
    "code" : "BR0373909U0063",
    "display" : "HIPROMELOSE 3 MG/ML SOLUÇÃO OFTÁLMICA 10 ML"
  },
  {
    "code" : "BR0373909U0075",
    "display" : "HIPROMELOSE 3 MG/ML SOLUÇÃO OFTÁLMICA 15 ML"
  },
  {
    "code" : "BR0267676U0042",
    "display" : "IBUPROFENO  600 MG COMPRIMIDO"
  },
  {
    "code" : "BR0268332U0084",
    "display" : "IPRATRÓPIO, BROMETO  0,02 MG/DOSE PÓ PARA INALAÇÃO ORAL 200 DOSES"
  },
  {
    "code" : "BR0273395U0042",
    "display" : "ISOSSORBIDA, DINITRATO 5 MG COMPRIMIDO SUBLINGUAL"
  },
  {
    "code" : "BR0270127-1",
    "display" : "INATIVO- LEVODOPA + BENSERAZIDA  100 + 25 MG COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0270128",
    "display" : "LEVODOPA + BENSERAZIDA  100 + 25 MG COMPRIMIDO PARA  SUSPENSÃO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0270130U0042",
    "display" : "LEVODOPA + CARBIDOPA  250 + 25 MG COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0440865U0112",
    "display" : "LIDOCAÍNA, CLORIDRATO 100 MG/ML SOLUÇÃO TÓPICA 70 ML"
  },
  {
    "code" : "BR0273466U0042",
    "display" : "LORATADINA 10 MG COMPRIMIDO"
  },
  {
    "code" : "BR0273467U0062",
    "display" : "LORATADINA 1 MG/ML XAROPE  100 ML"
  },
  {
    "code" : "BR0286864",
    "display" : "ACETILCISTEÍNA 100 MG GRANULADO 5 G"
  },
  {
    "code" : "BR0267694",
    "display" : "MEBENDAZOL 20 MG/ML SUSPENSÃO ORAL  30 ML"
  },
  {
    "code" : "BR0271444",
    "display" : "MEDROXIPROGESTERONA, ACETATO 2,5 MG COMPRIMIDO"
  },
  {
    "code" : "BR0271445U0042",
    "display" : "MEDROXIPROGESTERONA, ACETATO 10 MG COMPRIMIDO"
  },
  {
    "code" : "BR0267691U0042",
    "display" : "METFORMINA, CLORIDRATO 850 MG COMPRIMIDO"
  },
  {
    "code" : "BR0267689U0042",
    "display" : "METILDOPA  250 MG MG COMPRIMIDO"
  },
  {
    "code" : "BR0267310U0005",
    "display" : "METOCLOPRAMIDA, CLORIDRATO 5 MG/ML SOLUÇÃO INJETÁVEL 1 ML"
  },
  {
    "code" : "BR0276656U0042",
    "display" : "METOPROLOL, SUCCINATO 25 MG COMPRIMIDO DE LIBERAÇÃO PROLONGADA"
  },
  {
    "code" : "BR0276658U0042",
    "display" : "METOPROLOL, SUCCINATO 100 MG COMPRIMIDO DE LIBERAÇÃO PROLONGADA"
  },
  {
    "code" : "BR0267717U0042",
    "display" : "METRONIDAZOL 250 MG COMPRIMIDO"
  },
  {
    "code" : "BR0266863U0067",
    "display" : "METRONIDAZOL (BENZOILMETRONIDAZOL) 40 MG/ML SUSPENSÃO ORAL  120 ML"
  },
  {
    "code" : "BR0268162U0031",
    "display" : "MICONAZOL, NITRATO 2 % CREME VAGINAL  80 G"
  },
  {
    "code" : "BR0268269U0027",
    "display" : "MICONAZOL, NITRATO 2 % GEL 40 G"
  },
  {
    "code" : "BR0268268U0096",
    "display" : "MICONAZOL, NITRATO 2 % PÓ 30 G"
  },
  {
    "code" : "BR0267378U0097",
    "display" : "NISTATINA 100.000 UI/ML SUSPENSÃO ORAL  30 ML"
  },
  {
    "code" : "BR0267378U0105",
    "display" : "NISTATINA 100.000 UI/ML SUSPENSÃO ORAL  50  ML"
  },
  {
    "code" : "BR0305714U0067",
    "display" : "NITROFURANTOÍNA 5 MG/ML SUSPENSÃO ORAL  120  ML"
  },
  {
    "code" : "BR0267733U0042",
    "display" : "NORETISTERONA 0,35 MG COMPRIMIDO"
  },
  {
    "code" : "BR0267772U0042",
    "display" : "PROPRANOLOL, CLORIDRATO 40 MG COMPRIMIDO"
  },
  {
    "code" : "BR0308884U0067",
    "display" : "SULFAMETOXAZOL + TRIMETOPRIMA  40MG/ML + 8MG/ML SUSPENSÃO ORAL  120 ML"
  },
  {
    "code" : "BR0268155",
    "display" : "TIABENDAZOL 500 MG COMPRIMIDO"
  },
  {
    "code" : "BR0268859",
    "display" : "LEVOTIROXINA SÓDICA 75 MCG COMPRIMIDO"
  },
  {
    "code" : "BR0276966",
    "display" : "TELMISARTANA 80 MG COMPRIMIDO"
  },
  {
    "code" : "BR0269069U0063",
    "display" : "ÁCIDO TRICLOROACÉTICO 90 % SOLUÇÃO 10 ML"
  },
  {
    "code" : "BR0268320",
    "display" : "AMPRENAVIR 150 MG CÁPSULA"
  },
  {
    "code" : "BR0267628",
    "display" : "CINARIZINA 25 mg  COMPRIMIDO"
  },
  {
    "code" : "BR0267378U0101",
    "display" : "NISTATINA 100.000 UI/ML SUSPENSÃO ORAL  40  ML"
  },
  {
    "code" : "BR0271610-1",
    "display" : "NORTRIPTILINA, CLORIDRATO 50 MG COMPRIMIDO"
  },
  {
    "code" : "BR0272832",
    "display" : "QUETIAPINA, FUMARATO 100 MG COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0351480",
    "display" : "ETODOLACO 300 MG COMPRIMIDO"
  },
  {
    "code" : "BR0351479",
    "display" : "ETODOLACO 400 MG COMPRIMIDO"
  },
  {
    "code" : "BR0305415",
    "display" : "GINKGO BILOBA 40 MG CÁPSULA"
  },
  {
    "code" : "BR0312860",
    "display" : "FLUORMETOLONA 1 MG/ML SOLUÇÃO OFTÁLMICA 10 ML"
  },
  {
    "code" : "BR0331389",
    "display" : "SITAGLIPTINA, FOSFATO 100 MG COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0331388",
    "display" : "SITAGLIPTINA, FOSFATO 50 MG COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0271748",
    "display" : "BENCICLANO, FUMARATO 200 MG COMPRIMIDO"
  },
  {
    "code" : "BR0271166",
    "display" : "FUROSEMIDA + AMILORIDA 40 + 10 MG COMPRIMIDO"
  },
  {
    "code" : "BR0268107",
    "display" : "GABAPENTINA 300 MG CÁPSULA  ELENCO ESTADUAL"
  },
  {
    "code" : "BR0268256-1",
    "display" : "GENTAMICINA, SULFATO 40 MG/ML SOLUÇÃO INJETÁVEL  1 ML ELENCO ESTADUAL"
  },
  {
    "code" : "BR0268256-2",
    "display" : "GENTAMICINA, SULFATO 40 MG/ML SOLUÇÃO INJETÁVEL  1,5 ML"
  },
  {
    "code" : "BR0268256-3",
    "display" : "GENTAMICINA, SULFATO 40 MG/ML SOLUÇÃO INJETÁVEL  2 ML ELENCO ESTADUAL"
  },
  {
    "code" : "BR0273120",
    "display" : "GLIMEPIRIDA  1 MG COMPRIMIDO"
  },
  {
    "code" : "BR0268112U0046",
    "display" : "HIDRALAZINA, CLORIDRATO 50 MG DRÁGEA"
  },
  {
    "code" : "BR0267531",
    "display" : "INDAPAMIDA 2,5 MG COMPRIMIDO"
  },
  {
    "code" : "BR0273389",
    "display" : "IRBESARTANA + HIDROCLOROTIAZIDA 150 + 12,5 MG COMPRIMIDO"
  },
  {
    "code" : "BR0294417",
    "display" : "LATANOPROSTA 50 MCG/ML SOLUÇÃO OFTÁLMICA 2,5 ML ELENCO ESTADUAL"
  },
  {
    "code" : "BR0268113",
    "display" : "LEFLUNOMIDA 100 MG COMPRIMIDO"
  },
  {
    "code" : "BR0332987U0042",
    "display" : "LEVOFLOXACINO 250 MG COMPRIMIDO"
  },
  {
    "code" : "BR0268492",
    "display" : "LINCOMICINA, CLORIDRATO 300 MG/ML SOLUÇÃO INJETÁVEL  1 ML"
  },
  {
    "code" : "BR0268492-1",
    "display" : "LINCOMICINA, CLORIDRATO 300 MG/ML SOLUÇÃO INJETÁVEL 2 ML"
  },
  {
    "code" : "BR0392662",
    "display" : "CETOPROFENO 160 MG MG CÁPSULA DURA DE LIBERAÇÃO PROLONGADA"
  },
  {
    "code" : "BR0392663",
    "display" : "CETOPROFENO 320 MG  CÁPSULA DURA DE LIBERAÇÃO PROLONGADA"
  },
  {
    "code" : "BR0273470",
    "display" : "LORATADINA + PSEUDOEFEDRINA, SULFATO 5 MG + 120 MG COMPRIMIDO"
  },
  {
    "code" : "BR0273471",
    "display" : "LORATADINA + PSEUDOEFEDRINA, SULFATO 1 MG + 12 MG/ML XAROPE  60 ML"
  },
  {
    "code" : "BR0273473",
    "display" : "LORAZEPAM 2 MG COMPRIMIDO"
  },
  {
    "code" : "BR0270786",
    "display" : "LOSARTANA POTÁSSICA 25 MG COMPRIMIDO"
  },
  {
    "code" : "BR0268038",
    "display" : "LOVASTATINA 20 MG COMPRIMIDO"
  },
  {
    "code" : "BR0274575",
    "display" : "BRONFENIRAMINA, MALEATO + FENILEFRINA, CLORIDRATO 12 + 15 MG COMPRIMIDO"
  },
  {
    "code" : "BR0268262",
    "display" : "METILERGOMETRINA, MALEATO 0,2 MG/ML SOLUÇÃO INJETÁVEL 1 ML"
  },
  {
    "code" : "BR0270606",
    "display" : "MEBENDAZOL + TIABENDAZOL 100 MG + 166 MG COMPRIMIDO"
  },
  {
    "code" : "BR0270605",
    "display" : "MEBENDAZOL + TIABENDAZOL 100 MG + 166 MG/5ML SUSPENSÃO ORAL  30 ML"
  },
  {
    "code" : "BR0273554",
    "display" : "MELOXICAM 15 MG COMPRIMIDO"
  },
  {
    "code" : "BR0287469",
    "display" : "OXICONAZOL, NITRATO 10 MG/G CREME  20 G"
  },
  {
    "code" : "BR0275477",
    "display" : "OFLOXACINO 3 % SOLUÇÃO OFTÁLMICA 5 ML"
  },
  {
    "code" : "BR0368919",
    "display" : "ÁCIDO ACÉTICO 5 % SOLUÇÃO 50 ML"
  },
  {
    "code" : "BR0268207",
    "display" : "AMPICILINA 1000 MG PÓ PARA SOLUÇÃO INJETÁVEL"
  },
  {
    "code" : "BR0272837U0041",
    "display" : "RIFAMPICINA 300 MG CÁPSULA"
  },
  {
    "code" : "BR0270143",
    "display" : "BROMOCRIPTINA, MESILATO 2,5 MG COMPRIMIDO"
  },
  {
    "code" : "BR0292208-3",
    "display" : "RIFAMPICINA 20 MG/ML SUSPENSÃO ORAL  100 ML"
  },
  {
    "code" : "BR0268830U0042",
    "display" : "RITONAVIR 100 MG COMPRIMIDO"
  },
  {
    "code" : "BR0273839",
    "display" : "SIBUTRAMINA, CLORIDRATO 15 MG COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0269960",
    "display" : "CEFOXITINA 1G PÓ PARA SOLUÇÃO INJETÁVEL"
  },
  {
    "code" : "INATIVO 23",
    "display" : "INATIVO-CLORETO DE SÓDIO 0,9 % SOLUÇÃO INJETÁVEL  1000 ML SISTEMA FECHADO"
  },
  {
    "code" : "BR0368654U0004",
    "display" : "CLORETO DE SÓDIO 0,9% SOLUÇÃO INJETÁVEL 10 ML ELENCO ESTADUAL"
  },
  {
    "code" : "INATIVO 24",
    "display" : "INATIVO-CLORETO DE SÓDIO 0,9 % SOLUÇÃO INJETÁVEL  500 ML"
  },
  {
    "code" : "BR0269818",
    "display" : "TERBUTALINA 0,5 MG/ML SOLUÇÃO INJETÁVEL  1 ML"
  },
  {
    "code" : "INATIVO 32",
    "display" : "INATIVO-GLICOSE 5 % SOLUÇÃO INJETÁVEL  250 ML"
  },
  {
    "code" : "BR0276867",
    "display" : "TIOCONAZOL + TINIDAZOL 20 + 30 MG/G CREME VAGINAL  35 G"
  },
  {
    "code" : "BR0272796U0106",
    "display" : "HEPARINA SÓDICA 5000 UI/ML SOLUÇÃO INJETÁVEL  5 ML"
  },
  {
    "code" : "BR0379469-2",
    "display" : "CLORAL, HIDRATO 10% SOLUÇÃO ORAL 100 ML"
  },
  {
    "code" : "BR0268005",
    "display" : "TRAVOPROSTA 0,04 MG/ML SOLUÇÃO OFTÁLMICA 2,5 ML ELENCO ESTADUAL"
  },
  {
    "code" : "BR0272327",
    "display" : "OXIBUTININA, CLORIDRATO 5 MG COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0268344",
    "display" : "INDINAVIR, SULFATO 400 MG CÁPSULA"
  },
  {
    "code" : "BR0267424U0009",
    "display" : "VERAPAMIL, CLORIDRATO 2,5 MG/ML SOLUÇÃO INJETÁVEL 2 ML"
  },
  {
    "code" : "BR0272093-1",
    "display" : "VITAMINAS DO COMPLEXO B (B1,B2,B3,B6,B12) SOLUÇÃO INJETÁVEL  2 ML"
  },
  {
    "code" : "BR0268158U0042",
    "display" : "PIRIMETAMINA 25 MG COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0267729",
    "display" : "NIFEDIPINO 20 MG COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0299128U0041",
    "display" : "CLOFAZIMINA 50 MG CÁPSULA"
  },
  {
    "code" : "BR0354317",
    "display" : "ACARBOSE 100 MG COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0272476",
    "display" : "DAPSONA 100 MG COMPRIMIDO"
  },
  {
    "code" : "BR0385436",
    "display" : "BETAMETASONA 2 MG COMPRIMIDO"
  },
  {
    "code" : "BR0272760",
    "display" : "SOLUÇÃO PARA DIÁLISE PERITONEAL, GLICOSE A 4,25 % SOLUÇÃO INJETÁVEL"
  },
  {
    "code" : "BR0267194U0009",
    "display" : "DIAZEPAM 5 MG/ML SOLUÇÃO INJETÁVEL 2 ML"
  },
  {
    "code" : "BR0277525-1",
    "display" : "DIDANOSINA 250 MG COMPRIMIDO"
  },
  {
    "code" : "BR0395730-2",
    "display" : "HIDRÓXIDO DE ALUMÍNIO + HIDRÓXIDO DE MAGNÉSIO 60 + 40 MG/ML SUSPENSÃO ORAL  150 ML"
  },
  {
    "code" : "BR0267162U0004",
    "display" : "CLORETO DE POTÁSSIO 19,10% SOLUÇÃO INJETÁVEL 10 ML"
  },
  {
    "code" : "BR0274393",
    "display" : "IPRATRÓPIO, BROMETO + SALBUTAMOL, SULFATO 20 + 120 MCG/DOSE AEROSSOL 200 DOSES"
  },
  {
    "code" : "BR0268350",
    "display" : "NELFINAVIR, MESILATO 50 MG/G PÓ PARA SOLUÇÃO"
  },
  {
    "code" : "BR0269848U0009",
    "display" : "LIDOCAÍNA, CLORIDRATO + GLICOSE 50 + 75 MG/ML SOLUÇÃO INJETÁVEL 2 ML"
  },
  {
    "code" : "BR0272166",
    "display" : "CICLOBENZAPRINA, CLORIDRATO 5 MG COMPRIMIDO"
  },
  {
    "code" : "BR0282149",
    "display" : "BETAMETASONA 4 MG/ML SOLUÇÃO INJETÁVEL  1 ML"
  },
  {
    "code" : "BR0271660-1",
    "display" : "AMBROXOL, CLORIDRATO 3 MG/ML XAROPE  100 ML"
  },
  {
    "code" : "BR0271659-2",
    "display" : "AMBROXOL, CLORIDRATO 6 MG/ML XAROPE  120 ML"
  },
  {
    "code" : "BR0385446",
    "display" : "BETAMETASONA 0,5 MG/ML SOLUÇÃO ORAL  15 ML"
  },
  {
    "code" : "BR0271392",
    "display" : "MORFINA, SULFATO 10 MG COMPRIMIDO"
  },
  {
    "code" : "BR0274502",
    "display" : "CEFACLOR 50 MG/ML SUSPENSÃO ORAL  80  ML"
  },
  {
    "code" : "BR0273596",
    "display" : "TIORIDAZINA, CLORIDRATO 200 MG COMPRIMIDO DE LIBERAÇÃO CONTROLADA"
  },
  {
    "code" : "BR0270796",
    "display" : "FEXOFENADINA + PSEUDOEFEDRINA 60 + 120 MG COMPRIMIDO DE LIBERAÇÃO CONTROLADA"
  },
  {
    "code" : "BR0284428",
    "display" : "COLCHICINA 1 MG  COMPRIMIDO"
  },
  {
    "code" : "BR0352911",
    "display" : "DIVALPROATO DE SÓDIO 125 MG CÁPSULA"
  },
  {
    "code" : "BR0272782",
    "display" : "CODEÍNA 30 MG  COMPRIMIDO"
  },
  {
    "code" : "BR0272369U0042",
    "display" : "VALACICLOVIR, CLORIDRATO 500 MG COMPRIMIDO"
  },
  {
    "code" : "BR0448838U0067",
    "display" : "ACEBROFILINA 5 MG/ML XAROPE  120 ML"
  },
  {
    "code" : "BR0396853-2",
    "display" : "FENILEFRINA + TETRACAINA 1 + 10 MG/ML SOLUÇÃO OFTÁLMICA 10 ML"
  },
  {
    "code" : "BR0271645",
    "display" : "OXIMETAZOLINA, CLORIDRATO 0,5 MG/ML SOLUÇÃO NASAL 20 ML"
  },
  {
    "code" : "BR0357066",
    "display" : "VILDAGLIPTINA + METFORMINA, CLORIDRATO 50 + 850 MG COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0267627",
    "display" : "CIMETIDINA 200 MG  COMPRIMIDO"
  },
  {
    "code" : "BR0276871-2",
    "display" : "FLUORURACILA 50 MG/G CREME  15 G"
  },
  {
    "code" : "BR0368922",
    "display" : "ÁCIDO ACÉTICO 2 % SOLUÇÃO 50 ML"
  },
  {
    "code" : "BR0277529",
    "display" : "AZUL DE METILENO 1 % SOLUÇÃO INJETÁVEL  2 ML"
  },
  {
    "code" : "BR0270138U0005",
    "display" : "BIPERIDENO, LACTATO 5 MG/ML SOLUÇÃO INJETÁVEL 1 ML"
  },
  {
    "code" : "BR0268265-1",
    "display" : "IODETO DE POTÁSSIO 2 % XAROPE  100 ML"
  },
  {
    "code" : "BR0282222-1",
    "display" : "CARBOCISTEÍNA 20 MG/ML XAROPE  100 ML"
  },
  {
    "code" : "BR0332789",
    "display" : "SALMETEROL, XINAFOATO + FLUTICASONA 25 + 50 MCG/DOSE AEROSSOL 120 DOSES"
  },
  {
    "code" : "BR0268820U0041",
    "display" : "ATAZANAVIR 200 MG CÁPSULA"
  },
  {
    "code" : "BR0296717",
    "display" : "RISEDRONATO SÓDICO 35 MG COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0268521",
    "display" : "ROCURÔNIO, BROMETO 10 MG/ML SOLUÇÃO INJETÁVEL  5 ML"
  },
  {
    "code" : "BR0272365",
    "display" : "SERTRALINA, CLORIDRATO 50 MG COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0292196U0005",
    "display" : "HALOPERIDOL 5 MG/ML SOLUÇÃO INJETÁVEL 1 ML"
  },
  {
    "code" : "BR0278257",
    "display" : "TINIDAZOL 500 MG COMPRIMIDO"
  },
  {
    "code" : "BR0268292U0042",
    "display" : "ÁCIDO FOLÍNICO (FOLINATO DE CÁLCIO) 15 MG COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0276839U0103",
    "display" : "ÁGUA DESTILADA SOLUÇÃO INJETÁVEL 500 ML"
  },
  {
    "code" : "BR0268376",
    "display" : "ALBUMINA HUMANA 20 % SOLUÇÃO INJETÁVEL 50 ML"
  },
  {
    "code" : "BR0271725",
    "display" : "PIPERACILINA SÓDICA + TAZOBACTAM SÓDICA  4 G + 500 MG PÓ PARA SOLUÇÃO INJETÁVEL"
  },
  {
    "code" : "BR0305325",
    "display" : "MOXIFLOXACINO, CLORIDRATO 400 MG SOLUÇÃO INJETÁVEL 250 ML"
  },
  {
    "code" : "BR0268481-2",
    "display" : "MIDAZOLAM, MALEATO 5 MG/ML SOLUÇÃO INJETÁVEL 10 ML"
  },
  {
    "code" : "BR0267540",
    "display" : "GLICOSE 25 % SOLUÇÃO INJETÁVEL 10 ML"
  },
  {
    "code" : "BR0392714",
    "display" : "ÓXIDO DE ZINCO 200 MG/G CREME"
  },
  {
    "code" : "BR0318668U0118",
    "display" : "VACINA SARAMPO, CAXUMBA, RUBÉOLA SUSPENSÃO INJETÁVEL"
  },
  {
    "code" : "BR0306947U0041",
    "display" : "OSELTAMIVIR, FOSFATO 75 MG CÁPSULA"
  },
  {
    "code" : "BR0267737",
    "display" : "RANITIDINA, CLORIDRATO  300 MG COMPRIMIDO"
  },
  {
    "code" : "BR0270495-1",
    "display" : "COLAGENASE + CLORANFENICOL 0,6 UI + 10 MG/G POMADA 30 G"
  },
  {
    "code" : "BR0268299",
    "display" : "SECNIDAZOL 1.000 MG COMPRIMIDO"
  },
  {
    "code" : "BR0270220U0118",
    "display" : "HIDROCORTISONA, SUCCINATO SÓDICO 100MG PÓ PARA SOLUÇÃO INJETÁVEL"
  },
  {
    "code" : "BR0269628",
    "display" : "ALBENDAZOL 200 MG COMPRIMIDO"
  },
  {
    "code" : "BR0278348",
    "display" : "ANASTROZOL 1 MG COMPRIMIDO"
  },
  {
    "code" : "BR0270616U0118",
    "display" : "BENZILPENICILINA POTÁSSICA 5.000.000 UI PÓ PARA SOLUÇÃO INJETÁVEL"
  },
  {
    "code" : "INATIVO",
    "display" : "INATIVO-SALBUTAMOL, SULFATO 0,4 MG/ML XAROPE  100 INATIVO ML"
  },
  {
    "code" : "BR0330114",
    "display" : "GANCICLOVIR SÓDICO 50 MG/ML SOLUÇÃO INJETÁVEL  10 ML"
  },
  {
    "code" : "BR0292030",
    "display" : "TIBOLONA 2,5 MG COMPRIMIDO"
  },
  {
    "code" : "BR0273135",
    "display" : "PROPATILNITRATO 10 MG COMPRIMIDO"
  },
  {
    "code" : "BR0292205U0042",
    "display" : "ISONIAZIDA 100 MG COMPRIMIDO"
  },
  {
    "code" : "BR0313592",
    "display" : "POLICRESULENO 36 % SOLUÇÃO 12 ML"
  },
  {
    "code" : "BR0267421",
    "display" : "TIANFENICOL GRANULADO 2,5 G"
  },
  {
    "code" : "BR0311143",
    "display" : "BENZOATO DE BENZILA 100 MG/G SABONETE 50 G"
  },
  {
    "code" : "BR0273311",
    "display" : "HIDROXIZINA, CLORIDRATO 10 MG COMPRIMIDO"
  },
  {
    "code" : "BR0268866",
    "display" : "CELECOXIBE 200 MG CÁPSULA"
  },
  {
    "code" : "BR0272902",
    "display" : "CLOBAZAM 20 MG  MG COMPRIMIDO"
  },
  {
    "code" : "BR0320825",
    "display" : "BENAZEPRIL, CLORIDRATO 10 MG COMPRIMIDO"
  },
  {
    "code" : "BR0272573",
    "display" : "BUSPIRONA, CLORIDRATO 10 MG COMPRIMIDO"
  },
  {
    "code" : "BR0272043",
    "display" : "CLONIDINA, CLORIDRATO 0,1 MG  COMPRIMIDO"
  },
  {
    "code" : "BR0394263-1",
    "display" : "HIDROXIZINA, CLORIDRATO 2 MG/ML XAROPE  100 ML"
  },
  {
    "code" : "BR0329610",
    "display" : "ALFATOCOFEROL (VITAMINA E) 400 MG CÁPSULA  ELENCO ESTADUAL"
  },
  {
    "code" : "BR0276856",
    "display" : "NORETISTERONA 10 MG COMPRIMIDO"
  },
  {
    "code" : "BR0267283",
    "display" : "ESCOPOLAMINA, BUTILBROMETO 10 MG COMPRIMIDO"
  },
  {
    "code" : "BR0348002-3",
    "display" : "ÁCIDOS GRAXOS ESSENCIAIS SOLUÇÃO 250 ML"
  },
  {
    "code" : "BR0276839U0063",
    "display" : "ÁGUA DESTILADA SOLUÇÃO INJETÁVEL 10 ML"
  },
  {
    "code" : "BR0268277",
    "display" : "OCITOCINA 5 UI/ML UI/ML SOLUÇÃO INJETÁVEL 1 ML"
  },
  {
    "code" : "BR0268129",
    "display" : "LEVOMEPROMAZINA 100 MG COMPRIMIDO"
  },
  {
    "code" : "BR0269603",
    "display" : "BISACODIL 5 MG DRÁGEA"
  },
  {
    "code" : "BR0272366",
    "display" : "TIORIDAZINA, CLORIDRATO 50 MG COMPRIMIDO"
  },
  {
    "code" : "BR0268994",
    "display" : "BUPROPIONA, CLORIDRATO 150 MG COMPRIMIDO"
  },
  {
    "code" : "BR0271028-1",
    "display" : "DICLOFENACO RESINATO 15 MG/ML SUSPENSÃO ORAL  10 ML"
  },
  {
    "code" : "BR0271028-2",
    "display" : "DICLOFENACO RESINATO 15 MG/ML SUSPENSÃO ORAL  20 ML"
  },
  {
    "code" : "BR0291802",
    "display" : "DIACEREÍNA 50 MG CÁPSULA"
  },
  {
    "code" : "BR0268860",
    "display" : "LEVOTIROXINA SÓDICA 125 MCG COMPRIMIDO"
  },
  {
    "code" : "BR0272041",
    "display" : "CLOMIPRAMINA, CLORIDRATO 75 MG COMPRIMIDO DE LIBERAÇÃO PROLONGADA"
  },
  {
    "code" : "BR0353333",
    "display" : "AMOXICILINA + CLAVULANATO DE POTÁSSIO 875 MG + 125 MG COMPRIMIDO"
  },
  {
    "code" : "BR0308729",
    "display" : "BEZAFIBRATO 400 MG COMPRIMIDO DE LIBERAÇÃO CONTROLADA"
  },
  {
    "code" : "BR0267506U0042",
    "display" : "ALBENDAZOL 400 MG COMPRIMIDO MASTIGÁVEL"
  },
  {
    "code" : "BR0271606U0041",
    "display" : "NORTRIPTILINA, CLORIDRATO 25 MG CÁPSULA"
  },
  {
    "code" : "BR0271610U0041",
    "display" : "NORTRIPTILINA, CLORIDRATO 50 MG CÁPSULA"
  },
  {
    "code" : "BR0233632U0062",
    "display" : "ÓLEO MINERAL (PETROLATO)  SOLUÇÃO ORAL 100 ML"
  },
  {
    "code" : "BR0233632U0067",
    "display" : "ÓLEO MINERAL (VASELINA LÍQUIDA / PETROLATO) SOLUÇÃO ORAL 120 ML"
  },
  {
    "code" : "BR0233632U0103",
    "display" : "ÓLEO MINERAL (VASELINA LÍQUIDA / PETROLATO) SOLUÇÃO ORAL 500 ML"
  },
  {
    "code" : "BR0267712U0041",
    "display" : "OMEPRAZOL 20 MG CÁPSULA"
  },
  {
    "code" : "BR0267778U0042",
    "display" : "PARACETAMOL  500 MG COMPRIMIDO"
  },
  {
    "code" : "BR0267777U0075",
    "display" : "PARACETAMOL  200 MG/ML SOLUÇÃO ORAL 15 ML"
  },
  {
    "code" : "BR0274648U0023",
    "display" : "PASTA DÁGUA PASTA  30 G"
  },
  {
    "code" : "BR0274648U0027",
    "display" : "PASTA DÁGUA PASTA  40 G"
  },
  {
    "code" : "BR0267773U0110",
    "display" : "PERMETRINA 10 MG/ML LOÇÃO 60 ML"
  },
  {
    "code" : "BR0267773U0062",
    "display" : "PERMETRINA 10 MG/ML LOÇÃO 100 ML"
  },
  {
    "code" : "BR0363597U0062",
    "display" : "PERMETRINA 50 MG/ML LOÇÃO 100 ML"
  },
  {
    "code" : "BR0366861U0030",
    "display" : "PERÓXIDO DE BENZOÍLA 5 % GEL 60 G"
  },
  {
    "code" : "BR0271353U0106",
    "display" : "PILOCARPINA, CLORIDRATO 2 % SOLUÇÃO OFTÁLMICA 5 ML"
  },
  {
    "code" : "BR0376695",
    "display" : "PIRIDOXINA, CLORIDRATO 50 MG COMPRIMIDO"
  },
  {
    "code" : "BR0267741U0042",
    "display" : "PREDNISONA  5 MG COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0267743U0042",
    "display" : "PREDNISONA  20 MG COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0273589U0042",
    "display" : "PROPILTIOURACILA 100 MG COMPRIMIDO"
  },
  {
    "code" : "BR0267771U0042",
    "display" : "PROPRANOLOL, CLORIDRATO 10 MG COMPRIMIDO"
  },
  {
    "code" : "BR0329508U0041",
    "display" : "RETINOL, PALMITATO 200.000 UI CÁPSULA"
  },
  {
    "code" : "BR0293839U0052",
    "display" : "SAIS PARA REIDRATAÇÃO ORAL (NaCl 3,5G + Glicose 20G + Citrato Na 2,9G + KCl 1,5G)  PÓ PARA SOLUÇÃO 8,5 G"
  },
  {
    "code" : "BR0267746U0042",
    "display" : "SINVASTATINA  10 MG COMPRIMIDO"
  },
  {
    "code" : "BR0267745U0042",
    "display" : "SINVASTATINA  40 MG COMPRIMIDO"
  },
  {
    "code" : "BR0267765U0042",
    "display" : "SULFADIAZINA 500 MG COMPRIMIDO"
  },
  {
    "code" : "BR0272089-2",
    "display" : "SULFADIAZINA DE PRATA 1 % PASTA  50 G"
  },
  {
    "code" : "BR0272089U0121",
    "display" : "SULFADIAZINA DE PRATA 1 % PASTA  100 G"
  },
  {
    "code" : "BR0272089U0146",
    "display" : "SULFADIAZINA DE PRATA 1 % PASTA  400 G"
  },
  {
    "code" : "BR0394807U0013",
    "display" : "SORO ANTIESCORPIÔNICO SOLUÇÃO INJETÁVEL 5 ML"
  },
  {
    "code" : "BR0268110",
    "display" : "HIDROXIURÉIA 500 MG CÁPSULA  ELENCO ESTADUAL"
  },
  {
    "code" : "BR0266707U0066",
    "display" : "BUDESONIDA 64 MCG/DOSE SUSPENSÃO NASAL 120 DOSES"
  },
  {
    "code" : "BR0269965",
    "display" : "LANSOPRAZOL 30 MG CÁPSULA"
  },
  {
    "code" : "BR0270231",
    "display" : "DEXAMETASONA + NEOMICINA + POLIMIXINA B 1 MG + 5 MG + 6.000 UI/G POMADA 3,5 G"
  },
  {
    "code" : "BR0361791",
    "display" : "DICLOFENACO DIETILAMONIO 11,6 MG/G GEL 60 G"
  },
  {
    "code" : "BR0365454",
    "display" : "SORBITOL + LAURILSULFATO DE SÓDIO 714 + 7,7 MG/G SUPOSITÓRIO  6,5 G"
  },
  {
    "code" : "BR0332468U0062",
    "display" : "SULFATO FERROSO (5MG/ML DE FERRO ELEMENTAR) 25 MG/ML XAROPE  100 ML"
  },
  {
    "code" : "BR0272341U0042",
    "display" : "TIAMINA, CLORIDRATO 300 MG COMPRIMIDO"
  },
  {
    "code" : "BR0273467U0067",
    "display" : "LORATADINA 1 MG/ML XAROPE  120 ML"
  },
  {
    "code" : "BR0267502U0042",
    "display" : "ÁCIDO ACETILSALICÍLICO  100 MG COMPRIMIDO"
  },
  {
    "code" : "BR0267501U0042",
    "display" : "ÁCIDO ACETILSALICÍLICO  500 MG COMPRIMIDO"
  },
  {
    "code" : "BR0267504U0041",
    "display" : "ÁCIDO VALPRÓICO (VALPROATO DE SÓDIO)  250 MG CÁPSULA"
  },
  {
    "code" : "BR0267505U0042",
    "display" : "ÁCIDO VALPRÓICO (VALPROATO DE SÓDIO)  500 MG COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0267507U0063",
    "display" : "ALBENDAZOL 40 MG/ML SUSPENSÃO ORAL  10 ML"
  },
  {
    "code" : "BR0269462U0042",
    "display" : "ALENDRONATO DE SÓDIO  70 MG COMPRIMIDO"
  },
  {
    "code" : "BR0267509U0042",
    "display" : "ALOPURINOL 300 MG COMPRIMIDO"
  },
  {
    "code" : "BR0267510U0042",
    "display" : "AMIODARONA, CLORIDRATO 200 MG COMPRIMIDO"
  },
  {
    "code" : "BR0267512U0042",
    "display" : "AMITRIPTILINA, CLORIDRATO 25 MG COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0271089U0041",
    "display" : "AMOXICILINA 500 MG CÁPSULA"
  },
  {
    "code" : "BR0271089U0042",
    "display" : "AMOXICILINA 500 MG COMPRIMIDO"
  },
  {
    "code" : "BR0271111U0110",
    "display" : "AMOXICILINA 50 MG/ML PÓ PARA SUSPENSÃO 60 ML"
  },
  {
    "code" : "BR0271111U0074",
    "display" : "AMOXICILINA 50 MG/ML PÓ PARA SUSPENSÃO 150 ML"
  },
  {
    "code" : "BR0281135U0113",
    "display" : "AMOXICILINA + CLAVULANATO DE POTÁSSIO 50 MG+ 12,5 MG/ML SUSPENSÃO ORAL  75 ML"
  },
  {
    "code" : "BR0281135U0062",
    "display" : "AMOXICILINA + CLAVULANATO DE POTÁSSIO 50 MG+ 12,5 MG/ML SUSPENSÃO ORAL  100 ML"
  },
  {
    "code" : "BR0272434U0042",
    "display" : "ANLODIPINO, BESILATO 5 MG COMPRIMIDO"
  },
  {
    "code" : "BR0268896U0042",
    "display" : "ANLODIPINO, BESILATO 10 MG COMPRIMIDO"
  },
  {
    "code" : "INATIVO 38",
    "display" : "ACETAZOLAMIDA 100 MG COMPRIMIDO"
  },
  {
    "code" : "BR0314517U0117",
    "display" : "AZITROMICINA 40 MG/ML 900 MG PÓ PARA SUSPENSÃO 22,5 ML"
  },
  {
    "code" : "BR0267140U0042",
    "display" : "AZITROMICINA 500 MG COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0346586U0084",
    "display" : "BECLOMETASONA, DIPROPIONATO 50 MCG/DOSE AEROSSOL ORAL 200 DOSES"
  },
  {
    "code" : "BR0267581U0084",
    "display" : "BECLOMETASONA, DIPROPIONATO 250 MCG/DOSE SOLUÇÃO ORAL 200 DOSES"
  },
  {
    "code" : "BR0270612U0118",
    "display" : "BENZILPENICILINA BENZATINA 1.200.000 UI PÓ PARA SUSPENSÃO INJETÁVEL"
  },
  {
    "code" : "BR0270140U0042",
    "display" : "BIPERIDENO, CLORIDRATO  2 MG COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0440867U0067",
    "display" : "CARBAMAZEPINA  20 MG/ML SUSPENSÃO ORAL  120 ML"
  },
  {
    "code" : "BR0267565U0042",
    "display" : "CARVEDILOL 6,25 MG  COMPRIMIDO"
  },
  {
    "code" : "BR0267567U0042",
    "display" : "CARVEDILOL 25 MG  COMPRIMIDO"
  },
  {
    "code" : "BR0331555U0110",
    "display" : "CEFALEXINA 50 MG/ML SUSPENSÃO ORAL  60 ML"
  },
  {
    "code" : "BR0271103U0062",
    "display" : "CETOCONAZOL 2% XAMPU  100 ML"
  },
  {
    "code" : "BR0267632U0042",
    "display" : "CIPROFLOXACINO, CLORIDRATO 500 MG  COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0269986U0042",
    "display" : "CLARITROMICINA 250 MG  COMPRIMIDO"
  },
  {
    "code" : "BR0268436U0041",
    "display" : "CLINDAMICINA, CLORIDRATO 300 MG CÁPSULA"
  },
  {
    "code" : "BR0270120U0086",
    "display" : "CLONAZEPAM 2,5 MG/ML SOLUÇÃO ORAL 20 ML"
  },
  {
    "code" : "BR0267638U0042",
    "display" : "CLORPROMAZINA, CLORIDRATO 100 MG  COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0269388U0042",
    "display" : "DEXAMETASONA  4 MG COMPRIMIDO"
  },
  {
    "code" : "BR0268243U0062",
    "display" : "DEXAMETASONA  0,1 MG/ML ELIXIR 100 ML"
  },
  {
    "code" : "BR0267187U0106",
    "display" : "DEXAMETASONA  1 MG/ML SOLUÇÃO OFTÁLMICA 5 ML"
  },
  {
    "code" : "BR0440863U0074",
    "display" : "DEXCLORFENIRAMINA, MALEATO 0,4 MG/ML SOLUÇÃO ORAL 150 ML"
  },
  {
    "code" : "BR0267195U0042",
    "display" : "DIAZEPAM 5 MG COMPRIMIDO"
  },
  {
    "code" : "BR0267647U0042",
    "display" : "DIGOXINA  0,25 MG COMPRIMIDO"
  },
  {
    "code" : "BR0267205U0063",
    "display" : "DIPIRONA SÓDICA  500 MG/ML SOLUÇÃO ORAL 10 ML"
  },
  {
    "code" : "BR0267205U0086",
    "display" : "DIPIRONA SÓDICA  500 MG/ML SOLUÇÃO ORAL 20 ML"
  },
  {
    "code" : "BR0267651U0042",
    "display" : "ENALAPRIL, MALEATO 10 MG COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0269992-1",
    "display" : "ERITROMICINA, ESTEARATO 500 MG CÁPSULA"
  },
  {
    "code" : "BR0269992-2",
    "display" : "ERITROMICINA, ESTEARATO 500 MG COMPRIMIDO"
  },
  {
    "code" : "BR0269994-3",
    "display" : "ERITROMICINA, ESTEARATO 50 MG/ML SUSPENSÃO ORAL  100 ML"
  },
  {
    "code" : "BR0267653U0042",
    "display" : "ESPIRONOLACTONA  25 MG COMPRIMIDO"
  },
  {
    "code" : "BR0267654U0042",
    "display" : "ESPIRONOLACTONA  100 MG COMPRIMIDO"
  },
  {
    "code" : "BR0356602U0042",
    "display" : "ESTROGÊNIOS CONJUGADOS 0,3 MG COMPRIMIDO"
  },
  {
    "code" : "BR0266587",
    "display" : "FENITOÍNA SÓDICA  25 MG/ML SUSPENSÃO ORAL  120 ML"
  },
  {
    "code" : "BR0267660U0042",
    "display" : "FENOBARBITAL  100 MG COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0267661U0041",
    "display" : "FLUCONAZOL 100 MG CÁPSULA  ELENCO ESTADUAL"
  },
  {
    "code" : "BR0267662U0041",
    "display" : "FLUCONAZOL 150 MG CÁPSULA"
  },
  {
    "code" : "BR0273009U0042",
    "display" : "FLUOXETINA, CLORIDRATO 20 MG COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0269622U0090",
    "display" : "GLICEROL   120 MG/ML ENEMA  250 ML"
  },
  {
    "code" : "BR0268186",
    "display" : "GLICEROL   95% ADULTO SUPOSITÓRIO"
  },
  {
    "code" : "BR0273115U0042",
    "display" : "GLICLAZIDA 80 MG COMPRIMIDO"
  },
  {
    "code" : "BR0267669U0042",
    "display" : "HALOPERIDOL 5 MG COMPRIMIDO"
  },
  {
    "code" : "BR0268111U0046",
    "display" : "HIDRALAZINA, CLORIDRATO 25 MG DRÁGEA"
  },
  {
    "code" : "BR0267674U0042",
    "display" : "HIDROCLOROTIAZIDA  25MG COMPRIMIDO"
  },
  {
    "code" : "BR0345240U0023",
    "display" : "HIDROCORTISONA, ACETATO 10MG/G CREME  30 G"
  },
  {
    "code" : "BR0271653-2",
    "display" : "HIDROXOCOBALAMINA, ACETATO 1 MG/ML SOLUÇÃO INJETÁVEL 2 ML"
  },
  {
    "code" : "BR0373910-3",
    "display" : "HIPROMELOSE 2 MG/ML SOLUÇÃO OFTÁLMICA 15 ML"
  },
  {
    "code" : "BR0271134-1",
    "display" : "IBUPROFENO  20 MG/ML SUSPENSÃO ORAL  100 ML"
  },
  {
    "code" : "BR0271134-2",
    "display" : "IBUPROFENO  20 MG/ML SUSPENSÃO ORAL  200 ML"
  },
  {
    "code" : "BR0294648U0042",
    "display" : "IBUPROFENO  200 MG COMPRIMIDO"
  },
  {
    "code" : "BR0267677U0042",
    "display" : "IBUPROFENO  300 MG COMPRIMIDO"
  },
  {
    "code" : "BR0268331U0075",
    "display" : "IPRATRÓPIO, BROMETO  0,25 MG/ML SOLUÇÃO PARA INALAÇÃO 15 ML"
  },
  {
    "code" : "BR0268331U0086",
    "display" : "IPRATRÓPIO, BROMETO  0,25 MG/ML SOLUÇÃO PARA INALAÇÃO 20 ML"
  },
  {
    "code" : "BR0273401U0042",
    "display" : "ISOSSORBIDA, MONONITRATO 40 MG COMPRIMIDO"
  },
  {
    "code" : "BR0268861U0041",
    "display" : "ITRACONAZOL 100 MG CÁPSULA"
  },
  {
    "code" : "BR0273328U0042",
    "display" : "IVERMECTINA 6 MG COMPRIMIDO"
  },
  {
    "code" : "BR0295853U0042",
    "display" : "LEVONORGESTREL 1,5 MG COMPRIMIDO"
  },
  {
    "code" : "BR0268124U0042",
    "display" : "LEVOTIROXINA SÓDICA 25 MCG COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0268123U0042",
    "display" : "LEVOTIROXINA SÓDICA 50 MCG COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0268125U0042",
    "display" : "LEVOTIROXINA SÓDICA 100 MCG COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0269846U0023",
    "display" : "LIDOCAÍNA, CLORIDRATO 20 MG/G GEL 30 G"
  },
  {
    "code" : "BR0269845U0105",
    "display" : "LIDOCAÍNA, CLORIDRATO 100 MG/ML SOLUÇÃO TÓPICA 50 ML"
  },
  {
    "code" : "BR0295040",
    "display" : "LAMOTRIGINA 25 MG COMPRIMIDO"
  },
  {
    "code" : "BR0272809",
    "display" : "LAMOTRIGINA 100 MG COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0286246",
    "display" : "PIMOZIDA 1 MG COMPRIMIDO"
  },
  {
    "code" : "BR0286247",
    "display" : "PIMOZIDA 4 MG COMPRIMIDO"
  },
  {
    "code" : "BR0274041",
    "display" : "PIROXICAM 5 MG/G GEL 30 G"
  },
  {
    "code" : "BR0271710U0010",
    "display" : "AMIODARONA, CLORIDRATO 50 MG/ML SOLUÇÃO INJETÁVEL 3 ML"
  },
  {
    "code" : "BR0296792-2",
    "display" : "SALMETEROL, XINAFOATO + FLUTICASONA 50 + 250 MCG/DOSE AEROSSOL 120 DOSES"
  },
  {
    "code" : "BR0271982",
    "display" : "CEFADROXILA 500 MG  CÁPSULA"
  },
  {
    "code" : "BR0339846",
    "display" : "CEFEPIMA, CLORIDRATO 1 G PÓ PARA SOLUÇÃO INJETÁVEL"
  },
  {
    "code" : "BR0267574U0004",
    "display" : "CLORETO DE SÓDIO 20% SOLUÇÃO INJETÁVEL 10 ML"
  },
  {
    "code" : "BR0272846U0042",
    "display" : "TALIDOMIDA 100 MG COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0267541U0004",
    "display" : "GLICOSE 50 % SOLUÇÃO INJETÁVEL 10 ML"
  },
  {
    "code" : "BR0267393U0041",
    "display" : "TETRACICLINA, CLORIDRATO 500 MG COMPRIMIDO"
  },
  {
    "code" : "BR0267544U0039",
    "display" : "GLICOSE 10 % SOLUÇÃO INJETÁVEL 500 ML SISTEMA FECHADO"
  },
  {
    "code" : "BR0267649",
    "display" : "DIGOXINA  0,5 MG/ML SOLUÇÃO ORAL 10 ML"
  },
  {
    "code" : "BR0268352-2",
    "display" : "BRIMONIDINA, TARTARATO 0,2 % SOLUÇÃO OFTÁLMICA 10 ML"
  },
  {
    "code" : "BR0274191-2",
    "display" : "BRIMONIDINA, TARTARATO 0,15 % SOLUÇÃO OFTÁLMICA 10 ML"
  },
  {
    "code" : "BR0279493-3",
    "display" : "ÓXIDO DE ZINCO + COLECALCIFEROL + RETINOL 150 + 5000 + 900 MG + UI + UI/G POMADA 90 G"
  },
  {
    "code" : "BR0279493-5",
    "display" : "ÓXIDO DE ZINCO + COLECALCIFEROL + RETINOL 150 + 5000+ 900 (MG + UI + UI/G) POMADA 135 G"
  },
  {
    "code" : "BR0357062",
    "display" : "VALSARTANA + ANLODIPINO, BESILATO 160 + 5 MG COMPRIMIDO"
  },
  {
    "code" : "BR0271652",
    "display" : "HIDROXOCOBALAMINA, CLORIDRATO 15.000 MCG SOLUÇÃO INJETÁVEL 2 ML"
  },
  {
    "code" : "BR0268151U0110",
    "display" : "PREDNISOLONA 1 MG/ML SOLUÇÃO ORAL 60 ML"
  },
  {
    "code" : "BR0268395U0118",
    "display" : "ANFOTERICINA B 50 MG PÓ PARA SOLUÇÃO INJETÁVEL ELENCO ESTADUAL"
  },
  {
    "code" : "BR0268341",
    "display" : "ESTAVUDINA  30 MG CÁPSULA"
  },
  {
    "code" : "BR0287559U0321",
    "display" : "ESTAVUDINA  1 MG/ML PÓ PARA SOLUÇÃO 210 ML"
  },
  {
    "code" : "BR0269567",
    "display" : "PANCURÔNIO, BROMETO 2 MG/ML SOLUÇÃO INJETÁVEL 2 ML"
  },
  {
    "code" : "BR0268498",
    "display" : "METRONIDAZOL 5 MG/ML SOLUÇÃO INJETÁVEL 100 ML"
  },
  {
    "code" : "BR0340783-1",
    "display" : "HIDRÓXIDO DE ALUMÍNIO 61,5 MG/ML SUSPENSÃO ORAL  60 ML"
  },
  {
    "code" : "BR0305428-2",
    "display" : "CARBOXIMETILCELULOSE SÓDICA 5 MG/ML SOLUÇÃO OFTÁLMICA 15 ML"
  },
  {
    "code" : "BR0267642",
    "display" : "COLCHICINA 0,5 MG  COMPRIMIDO"
  },
  {
    "code" : "BR0268455",
    "display" : "ENOXAPARINA SÓDICA  80 MG SOLUÇÃO INJETÁVEL 0,8 ML"
  },
  {
    "code" : "BR0291770",
    "display" : "ESCITALOPRAM, OXALATO  10 mg COMPRIMIDO"
  },
  {
    "code" : "BR0398268",
    "display" : "VALSARTANA + ANLODIPINO, BESILATO 320 + 10 MG COMPRIMIDO"
  },
  {
    "code" : "BR0271709",
    "display" : "AMIODARONA, CLORIDRATO 100 MG COMPRIMIDO"
  },
  {
    "code" : "BR0271052U0444",
    "display" : "BICARBONATO DE SÓDIO 40 G PÓ"
  },
  {
    "code" : "BR0274561",
    "display" : "TROPICAMIDA 1 % SOLUÇÃO OFTÁLMICA 5 ML"
  },
  {
    "code" : "BR0267688",
    "display" : "METILDOPA  500 MG COMPRIMIDO"
  },
  {
    "code" : "BR0327566",
    "display" : "ÁCIDO TRANEXÂMICO 50 MG/ML SOLUÇÃO INJETÁVEL 5 ML"
  },
  {
    "code" : "BR0268148",
    "display" : "PRAVASTATINA SÓDICA 20 MG COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0285688",
    "display" : "EZETIMIBA + SINVASTATINA 10 + 20 MG COMPRIMIDO"
  },
  {
    "code" : "BR0296647",
    "display" : "CUMARINA + TROXERRUTINA 15 + 90 MG DRÁGEA"
  },
  {
    "code" : "BR0305488",
    "display" : "METILFENIDATO, CLORIDRATO 20 MG CÁPSULA  ELENCO ESTADUAL"
  },
  {
    "code" : "BR0276234-2",
    "display" : "INSULINA ASPARTE 100 UI/ML SOLUÇÃO INJETÁVEL 3 ML ELENCO ESTADUAL"
  },
  {
    "code" : "BR0273266",
    "display" : "NALTREXONA  50 MG COMPRIMIDO"
  },
  {
    "code" : "BR0284105",
    "display" : "RISPERIDONA 3 MG COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0268415U0118",
    "display" : "CEFTRIAXONA SÓDICA 1G PÓ PARA SOLUÇÃO INJETÁVEL   IM"
  },
  {
    "code" : "BR0272839",
    "display" : "RISPERIDONA 1 MG COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0270472",
    "display" : "HEXAMIDINA, ISETIONATO + TETRACAÍNA, CLORIDRATO 1 + 0,5 MG/ML AEROSSOL 50 ML"
  },
  {
    "code" : "BR0272587",
    "display" : "DISSULFIRAM 250 MG COMPRIMIDO"
  },
  {
    "code" : "BR0272644",
    "display" : "ENOXAPARINA SÓDICA  20 MG SOLUÇÃO INJETÁVEL 0,2 ML"
  },
  {
    "code" : "BR0272645",
    "display" : "ENOXAPARINA SÓDICA  40 MG SOLUÇÃO INJETÁVEL 0,4 ML ELENCO ESTADUAL"
  },
  {
    "code" : "BR0362661-1",
    "display" : "CLINDAMICINA, FOSFATO 20 MG/G CREME  20 G"
  },
  {
    "code" : "BR0318338U0118",
    "display" : "VACINA FEBRE AMARELA (ATENUADA) SOLUÇÃO INJETÁVEL"
  },
  {
    "code" : "BR0274990",
    "display" : "SACARATO DE SÓDIO FÉRRICO 100 MG SOLUÇÃO INJETÁVEL IM 2 ML"
  },
  {
    "code" : "BR0298445",
    "display" : "CROMOGLICATO DE SÓDIO 2 % SOLUÇÃO OFTÁLMICA 5 ML"
  },
  {
    "code" : "BR0337468-2",
    "display" : "DESLORATADINA 0,5 MG/ML XAROPE  60 ML"
  },
  {
    "code" : "BR0339847",
    "display" : "CEFEPIMA, CLORIDRATO 2 G PÓ PARA SOLUÇÃO INJETÁVEL"
  },
  {
    "code" : "BR0335098",
    "display" : "CLORANFENICOL 500 MG  COMPRIMIDO"
  },
  {
    "code" : "BR0273167-2",
    "display" : "NEOMICINA + BACITRACINA 5 + 250 MG + UI/G POMADA 15 G"
  },
  {
    "code" : "BR0292427U0006",
    "display" : "DEXAMETASONA, FOSFATO DISSÓDICO 4 MG/ML SOLUÇÃO INJETÁVEL AMPOLA 2,5  ML"
  },
  {
    "code" : "BR0274105",
    "display" : "PENFLURIDOL 20 MG COMPRIMIDO"
  },
  {
    "code" : "BR0270503-2",
    "display" : "FIBRINOLISINA + DESOXIRRIBONUCLEASE + CLORANFENICOL POMADA 30 G"
  },
  {
    "code" : "BR0292331-1",
    "display" : "SALBUTAMOL, SULFATO 0,4 MG/ML XAROPE  100 ML"
  },
  {
    "code" : "BR0379469-1",
    "display" : "CLORAL, HIDRATO 10% SOLUÇÃO ORAL 50 ML"
  },
  {
    "code" : "BR0272410",
    "display" : "FLUOCINOLONA + NAFAZOLINA + ZINCO + NEOMICINA 0,25 + 0,5 + 4 + 7 MG/ML SOLUÇÃO OFTÁLMICA 5 ML"
  },
  {
    "code" : "BR0379604",
    "display" : "VACINA HUMANA, HAEMÓPHILUS INFLUENZA TIPO A (H1N1) SUSPENSÃO INJETÁVEL"
  },
  {
    "code" : "BR0272363",
    "display" : "SERTRALINA, CLORIDRATO 100 MG COMPRIMIDO"
  },
  {
    "code" : "BR0274647",
    "display" : "SOTALOL, CLORIDRATO 160 MG COMPRIMIDO"
  },
  {
    "code" : "BR0272737U0013",
    "display" : "MEGLUMINA, ANTIMONIATO 300 MG/ML SOLUÇÃO INJETÁVEL 5 ML"
  },
  {
    "code" : "BR0305489",
    "display" : "METILFENIDATO, CLORIDRATO 40 MG CÁPSULA  ELENCO ESTADUAL"
  },
  {
    "code" : "BR0267309",
    "display" : "MEDROXIPROGESTERONA, ACETATO 5 MG COMPRIMIDO"
  },
  {
    "code" : "BR0295856",
    "display" : "LEVONORGESTREL 52 MG SISTEMA INTRAUTERINO"
  },
  {
    "code" : "BR0268300",
    "display" : "SECNIDAZOL 500 MG COMPRIMIDO"
  },
  {
    "code" : "BR0268372",
    "display" : "ACICLOVIR 400 MG COMPRIMIDO"
  },
  {
    "code" : "BR0300252",
    "display" : "GLICOSE + CLORETO DE SÓDIO 20 + 0,9 % SOLUÇÃO INJETÁVEL  1000 ML"
  },
  {
    "code" : "BR0347116-2",
    "display" : "PAPAÍNA 8 % CREME  80 G"
  },
  {
    "code" : "BR0276862",
    "display" : "TIOCONAZOL 65 MG/G CREME VAGINAL  4,62 G"
  },
  {
    "code" : "BR0272851",
    "display" : "TOPIRAMATO 100 MG COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0272367",
    "display" : "TIORIDAZINA, CLORIDRATO 100 MG COMPRIMIDO"
  },
  {
    "code" : "BR0270548",
    "display" : "ÁCIDO ACETILSALICÍLICO  325 MG COMPRIMIDO"
  },
  {
    "code" : "BR0268255U0005",
    "display" : "EPINEFRINA 1 MG/ML SOLUÇÃO INJETÁVEL 1 ML"
  },
  {
    "code" : "BR0269571-1",
    "display" : "PROXIMETACAÍNA, CLORIDRATO 0,5 % SOLUÇÃO OFTÁLMICA 5 ML"
  },
  {
    "code" : "BR0268961",
    "display" : "ESTREPTOQUINASE  SOLUÇÃO INJETÁVEL 1.500.000 UI"
  },
  {
    "code" : "BR0313593",
    "display" : "POLICRESULENO 0,09 G ÓVULO"
  },
  {
    "code" : "BR0276866",
    "display" : "TIOCONAZOL 10 MG/ML LOÇÃO  30 G"
  },
  {
    "code" : "BR0268956U0042",
    "display" : "LEVONORGESTREL 0,75 MG COMPRIMIDO"
  },
  {
    "code" : "BR0273167-3",
    "display" : "NEOMICINA + BACITRACINA 5 + 250 MG + UI/G POMADA 30 G"
  },
  {
    "code" : "BR0271154U0063",
    "display" : "INSULINA HUMANA REGULAR 100 UI/ML SOLUÇÃO INJETÁVEL 10 ML ELENCO ESTADUAL"
  },
  {
    "code" : "BR0343607",
    "display" : "ETANERCEPTE  25 MG PÓ PARA SOLUÇÃO INJETÁVEL ELENCO ESTADUAL"
  },
  {
    "code" : "BR0273400U0042",
    "display" : "ISOSSORBIDA, MONONITRATO 20 MG COMPRIMIDO"
  },
  {
    "code" : "BR0268150U0110",
    "display" : "PREDNISOLONA 3 MG/ML SOLUÇÃO ORAL 60 ML"
  },
  {
    "code" : "BR0285686",
    "display" : "EZETIMIBA 10 MG COMPRIMIDO"
  },
  {
    "code" : "BR0270118",
    "display" : "CLONAZEPAM 0,5 MG COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0271620",
    "display" : "OLANZAPINA 5 MG COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0333496",
    "display" : "SOTALOL, CLORIDRATO 120 MG COMPRIMIDO"
  },
  {
    "code" : "BR0273404",
    "display" : "ISOSSORBIDA, MONONITRATO 10 MG/ML SOLUÇÃO INJETÁVEL  1 ML"
  },
  {
    "code" : "BR0299690-1",
    "display" : "METILPREDNISOLONA, ACETATO 40 MG/ML SUSPENSÃO INJETÁVEL 1 ML"
  },
  {
    "code" : "BR0270895-2",
    "display" : "CARBONATO DE CÁLCIO (CÁLCIO ELEMENTAR) 500 MG COMPRIMIDO MASTIGÁVEL"
  },
  {
    "code" : "BR0271140",
    "display" : "RIFAMICINA SV SÓDICA 10 MG/ML SOLUÇÃO TÓPICA 20 ML"
  },
  {
    "code" : "INATIVO IV",
    "display" : "INATIVO-LATANOPROSTA + BENZALCÔNIO, CLORETO 50 MCG + 0,2 MG/ML SOLUÇÃO OFTÁLMICA 2,5 ML"
  },
  {
    "code" : "BR0308736-2",
    "display" : "CETOCONAZOL 2% CREME  30 G"
  },
  {
    "code" : "BR0271659-1",
    "display" : "AMBROXOL, CLORIDRATO 6 MG/ML XAROPE  100 ML"
  },
  {
    "code" : "BR0273712",
    "display" : "NIMESULIDA 10 MG/ML SUSPENSÃO ORAL  60 ML"
  },
  {
    "code" : "BR0271581",
    "display" : "TOBRAMICINA 0,3 % SOLUÇÃO OFTÁLMICA 5 ML"
  },
  {
    "code" : "BR0296594",
    "display" : "NORGESTIMATO + ESTRADIOL  1 + 90 MG COMPRIMIDO"
  },
  {
    "code" : "BR0286631",
    "display" : "CLOXAZOLAM 4 MG  COMPRIMIDO"
  },
  {
    "code" : "BR0299766U0042",
    "display" : "ETAMBUTOL, CLORIDRATO 400 MG COMPRIMIDO"
  },
  {
    "code" : "BR0267472",
    "display" : "ALFAPEGINTERFERONA 2B 80 MCG PÓ LIOFILIZADO PARA SOLUÇÃO INJETÁVEL 1 ML ELENCO ESTADUAL"
  },
  {
    "code" : "BR0269996U0042",
    "display" : "ERITROMICINA, ESTOLATO 500 MG COMPRIMIDO"
  },
  {
    "code" : "BR0273455",
    "display" : "MUPIROCINA 20 mg/g CREME  15 G"
  },
  {
    "code" : "BR0271774",
    "display" : "BROMAZEPAM 6 MG COMPRIMIDO"
  },
  {
    "code" : "BR0292208U0105",
    "display" : "RIFAMPICINA 20 MG/ML SUSPENSÃO ORAL  50 ML"
  },
  {
    "code" : "BR0271357",
    "display" : "ALPRAZOLAM 0,5 MG COMPRIMIDO"
  },
  {
    "code" : "BR0357063",
    "display" : "VALSARTANA + ANLODIPINO, BESILATO 320 + 5 MG COMPRIMIDO"
  },
  {
    "code" : "BR0268253",
    "display" : "DIPIRIDAMOL 75 MG COMPRIMIDO"
  },
  {
    "code" : "BR0300722",
    "display" : "FENOBARBITAL  200 MG/ML SOLUÇÃO INJETÁVEL 1 ML"
  },
  {
    "code" : "BR0268373",
    "display" : "ACICLOVIR 30 MG/G OFTÁLMICA POMADA 4,5 G"
  },
  {
    "code" : "BR0308721U0042",
    "display" : "ALENDRONATO DE SÓDIO  10 MG COMPRIMIDO"
  },
  {
    "code" : "BR0267527",
    "display" : "CLOXAZOLAM 2 COMPRIMIDO"
  },
  {
    "code" : "BR0273711",
    "display" : "NIMESULIDA 50 MG/ML SOLUÇÃO ORAL 15 ML"
  },
  {
    "code" : "BR0395837U0018",
    "display" : "ALCATRÃO MINERAL 1% POMADA"
  },
  {
    "code" : "BR0287481U0140",
    "display" : "NICOTINA 2 MG GOMA DE MASCAR"
  },
  {
    "code" : "BR0364037U0042",
    "display" : "RIFAMPICINA 150MG + ISONIAZIDA 75MG + PIRAZINAMIDA 400MG + ETAMBUTOL 275MG 150 MG + 75MG + 400MG + 275MG COMPRIMIDO"
  },
  {
    "code" : "INATIVO II",
    "display" : "INATIVO-ADRENALINA 1 MG/ML SOLUÇÃO INJETÁVEL  1 ML"
  },
  {
    "code" : "BR0271358",
    "display" : "ALPRAZOLAM 0,25 MG COMPRIMIDO"
  },
  {
    "code" : "BR0266705-4",
    "display" : "BUDESONIDA 100 MCG/DOSE AEROSSOL NASAL 200 DOSES"
  },
  {
    "code" : "BR0271101",
    "display" : "CALCITRIOL 0,25 MCG CÁPSULA  ELENCO ESTADUAL"
  },
  {
    "code" : "BR0270020",
    "display" : "CLORETO DE BENZALCÔNIO+ CLORETO DE SÓDIO 0,1 + 9 MG/ML SOLUÇÃO NASAL 30 ML"
  },
  {
    "code" : "BR0272470",
    "display" : "DALTEPARINA SÓDICA 2500 UI SOLUÇÃO INJETÁVEL 0,2 ML"
  },
  {
    "code" : "BR0300252-1",
    "display" : "GLICOSE + CLORETO DE SÓDIO 20 + 0,9 % SOLUÇÃO INJETÁVEL  500 ML"
  },
  {
    "code" : "BR0282299",
    "display" : "SULPIRIDA 50 MG COMPRIMIDO"
  },
  {
    "code" : "BR0348670U0004",
    "display" : "SORO ANTICROTÁLICO SOLUÇÃO INJETÁVEL"
  },
  {
    "code" : "BR0272340",
    "display" : "TIAMINA, CLORIDRATO 100 MG CÁPSULA"
  },
  {
    "code" : "BR0335112",
    "display" : "PENTOXIFILINA 20 MG/ML SOLUÇÃO INJETÁVEL 5 ML"
  },
  {
    "code" : "BR0268446U0007",
    "display" : "DOBUTAMINA, CLORIDRATO 12,5 MG/ML SOLUÇÃO INJETÁVEL 20 ML"
  },
  {
    "code" : "BR0268960U0004",
    "display" : "DOPAMINA, CLORIDRATO 5 MG/ML SOLUÇÃO INJETÁVEL 10 ML"
  },
  {
    "code" : "INATIVO IX",
    "display" : "INATIVO-ESTREPTOMICINA, CLORIDRATO PÓ PARA SOLUÇÃO INJETÁVEL 1000 MG"
  },
  {
    "code" : "BR0268970-2",
    "display" : "NITROGLICERINA 5 MG/ML SOLUÇÃO INJETÁVEL 10 ML"
  },
  {
    "code" : "BR0273457",
    "display" : "NEOSTIGMINA, METILSULFATO 0,5 MG/ML SOLUÇÃO INJETÁVEL 1 ML"
  },
  {
    "code" : "BR0268414U0118",
    "display" : "CEFTRIAXONA SÓDICA 1G PÓ PARA SOLUÇÃO INJETÁVEL   IV"
  },
  {
    "code" : "BR0267641",
    "display" : "CLORPROPAMIDA 250 MG  COMPRIMIDO"
  },
  {
    "code" : "BR0272423",
    "display" : "CLOTRIMAZOL 10 MG/G CREME  20 G"
  },
  {
    "code" : "BR0266706U0066",
    "display" : "BUDESONIDA 32 MCG/DOSE SUSPENSÃO NASAL 120 DOSES"
  },
  {
    "code" : "BR0272457",
    "display" : "CARBAMAZEPINA  400 MG COMPRIMIDO DE LIBERAÇÃO CONTROLADA"
  },
  {
    "code" : "BR0292236",
    "display" : "MESALAZINA 500 MG COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0327794",
    "display" : "CIPROFLOXACINO + DEXAMETASONA 3,5 + 1 MG/G POMADA 3,5 G"
  },
  {
    "code" : "BR0272589",
    "display" : "DIVALPROATO DE SÓDIO 500 MG COMPRIMIDO"
  },
  {
    "code" : "BR0272364",
    "display" : "SERTRALINA, CLORIDRATO 25 MG COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0268236U0034",
    "display" : "CLORETO DE SÓDIO 0,9% SOLUÇÃO INJETÁVEL 100 ML SISTEMA FECHADO"
  },
  {
    "code" : "BR0268864",
    "display" : "TICLOPIDINA, CLORIDRATO 250 MG COMPRIMIDO"
  },
  {
    "code" : "BR0267418 -1",
    "display" : "TIABENDAZOL 50 MG/G POMADA 20 G"
  },
  {
    "code" : "BR0352226U0238",
    "display" : "VACINA PNEUMOCÓCICA 23-VALENTE (POLISSACARÍDICA) SOLUÇÃO INJETÁVEL"
  },
  {
    "code" : "BR0273119",
    "display" : "GLIMEPIRIDA  2 MG COMPRIMIDO"
  },
  {
    "code" : "BR0273121",
    "display" : "GLIMEPIRIDA  4 MG COMPRIMIDO"
  },
  {
    "code" : "BR0268422",
    "display" : "CETOPROFENO 50 MG  CÁPSULA"
  },
  {
    "code" : "BR0340105",
    "display" : "CETOPROFENO 100 MG  COMPRIMIDO"
  },
  {
    "code" : "BR0276377",
    "display" : "CILOSTAZOL 50 MG  COMPRIMIDO"
  },
  {
    "code" : "BR0276378",
    "display" : "CILOSTAZOL 100 MG  COMPRIMIDO"
  },
  {
    "code" : "BR0272458",
    "display" : "CARBAMAZEPINA  200 MG COMPRIMIDO DE LIBERAÇÃO CONTROLADA"
  },
  {
    "code" : "BR0291231U0118",
    "display" : "ESTREPTOMICINA, SULFATO 1000 MG PÓ PARA SOLUÇÃO INJETÁVEL 5 ML"
  },
  {
    "code" : "BR0352912",
    "display" : "DIVALPROATO DE SÓDIO 500 MG COMPRIMIDO DE LIBERAÇÃO PROLONGADA"
  },
  {
    "code" : "BR0271162",
    "display" : "AMILORIDA, CLORIDRATO + HIDROCLOROTIAZIDA 5  MG+ 50 MG COMPRIMIDO"
  },
  {
    "code" : "BR0267572",
    "display" : "DILTIAZEM, CLORIDRATO 120 MG COMPRIMIDO"
  },
  {
    "code" : "BR0267568",
    "display" : "DILTIAZEM, CLORIDRATO 60 MG COMPRIMIDO"
  },
  {
    "code" : "BR0268093",
    "display" : "METADONA, CLORIDRATO 10 MG COMPRIMIDO"
  },
  {
    "code" : "BR0278649",
    "display" : "METFORMINA, CLORIDRATO + GLIBENCLAMIDA 500 MG + 5 MG COMPRIMIDO"
  },
  {
    "code" : "BR0274918-1",
    "display" : "RETINOL + AMINOÁCIDOS + METIONINA + CLORANFENICOL 10.000 UI + 25 + 5 + 5 MG/G POMADA 3 G"
  },
  {
    "code" : "BR0269835-2",
    "display" : "LIDOCAÍNA, CLORIDRATO + PRILOCAÍNA 2,5 % + 2,5 % CREME  30 G"
  },
  {
    "code" : "BR0362718",
    "display" : "BISOPROLOL, FUMARATO 5 MG COMPRIMIDO"
  },
  {
    "code" : "BR0267516",
    "display" : "ATENOLOL 25 MG COMPRIMIDO"
  },
  {
    "code" : "BR0276258",
    "display" : "RAMIPRIL 5 MG COMPRIMIDO"
  },
  {
    "code" : "BR0305258",
    "display" : "LEUPRORRELINA, ACETATO 7,5 MG PÓ LIOFILIZADO"
  },
  {
    "code" : "BR0305259",
    "display" : "LEUPRORRELINA, ACETATO 22,5 MG PÓ LIOFILIZADO"
  },
  {
    "code" : "BR0298444",
    "display" : "CROMOGLICATO DE SÓDIO 4 % % SOLUÇÃO NASAL 15 ML"
  },
  {
    "code" : "BR0276283",
    "display" : "DESLANOSÍDEO 0,2 MG/ML SOLUÇÃO INJETÁVEL  2 ML"
  },
  {
    "code" : "BR0337468-3",
    "display" : "DESLORATADINA 0,5 MG/ML XAROPE  100 ML"
  },
  {
    "code" : "BR0287529",
    "display" : "DESLORATADINA 5 MG COMPRIMIDO"
  },
  {
    "code" : "BR0292767",
    "display" : "PROPRANOLOL, CLORIDRATO + HIDROCLOROTIAZIDA 80 + 12,5 MG COMPRIMIDO"
  },
  {
    "code" : "BR0271171",
    "display" : "ENALAPRIL, MALEATO + HIDROCLOROTIAZIDA 20 + 12,5 MG COMPRIMIDO"
  },
  {
    "code" : "BR0276871-1",
    "display" : "FLUORURACILA 50 MG/G CREME  10 G"
  },
  {
    "code" : "BR0272423-1",
    "display" : "CLOTRIMAZOL 10 MG/G CREME  30 G"
  },
  {
    "code" : "BR0282224-2",
    "display" : "CARBOCISTEÍNA 50 MG/ML XAROPE  80 ML"
  },
  {
    "code" : "BR0271000",
    "display" : "DICLOFENACO SÓDICO 50 MG COMPRIMIDO"
  },
  {
    "code" : "BR0270992",
    "display" : "DICLOFENACO POTÁSSICO 50 MG COMPRIMIDO"
  },
  {
    "code" : "BR0340167",
    "display" : "CIMETIDINA 150 MG/ML SOLUÇÃO INJETÁVEL 2 ML"
  },
  {
    "code" : "BR0267615",
    "display" : "CAPTOPRIL  50 MG COMPRIMIDO"
  },
  {
    "code" : "BR0270792",
    "display" : "ATENOLOL + CLORTALIDONA 50 + 12,5 MG COMPRIMIDO"
  },
  {
    "code" : "BR0267294",
    "display" : "IMIPRAMINA, PAMOATO 75 MG CÁPSULA"
  },
  {
    "code" : "BR0272423-2",
    "display" : "CLOTRIMAZOL 10 MG/G CREME  35 G"
  },
  {
    "code" : "BR0278647",
    "display" : "METFORMINA, CLORIDRATO + GLIBENCLAMIDA 250 MG + 1,25 MG COMPRIMIDO"
  },
  {
    "code" : "BR0392708",
    "display" : "SITAGLIPTINA, FOSFATO + METFORMINA, CLORIDRATO 50 + 850 MG COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0268856U0042",
    "display" : "LOSARTANA POTÁSSICA 50 MG COMPRIMIDO"
  },
  {
    "code" : "BR0271670",
    "display" : "ÁCIDO MEFENÂMICO 500 MG COMPRIMIDO"
  },
  {
    "code" : "BR0273221",
    "display" : "MEMANTINA, CLORIDRATO 10 MG COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0267631U0042",
    "display" : "CIPROFLOXACINO, CLORIDRATO 250 MG  COMPRIMIDO"
  },
  {
    "code" : "BR0268289",
    "display" : "ÁCIDO BÓRICO  (ÁGUA BORICADA) 2% SOLUÇÃO 100 ML"
  },
  {
    "code" : "BR0269954-1",
    "display" : "BROMOPRIDA 10 MG MG CÁPSULA"
  },
  {
    "code" : "BR0285081",
    "display" : "TANSULOSINA, CLORIDRATO 0,4 MG COMPRIMIDO"
  },
  {
    "code" : "BR0302443",
    "display" : "DULOXETINA, CLORIDRATO 60 MG CÁPSULA"
  },
  {
    "code" : "BR0267644",
    "display" : "DEXAMETASONA  0,5 MG COMPRIMIDO"
  },
  {
    "code" : "BR0357061",
    "display" : "VALSARTANA + ANLODIPINO, BESILATO 80 + 5 MG COMPRIMIDO"
  },
  {
    "code" : "BR0268242",
    "display" : "DELTAMETRINA 0,2 MG/ML XAMPU  100 ML"
  },
  {
    "code" : "BR0343573",
    "display" : "BETAISTINA, DICLORIDRATO 24 MG COMPRIMIDO"
  },
  {
    "code" : "BR0282882",
    "display" : "ROSUVASTATINA CÁLCICA 20 MG COMPRIMIDO"
  },
  {
    "code" : "BR0267629",
    "display" : "CINARIZINA 75 MG  COMPRIMIDO"
  },
  {
    "code" : "BR0296741",
    "display" : "OLMESARTANA 20 MG COMPRIMIDO"
  },
  {
    "code" : "BR0271124-3",
    "display" : "CETOTIFENO, FUMARATO 0,2 MG/ML XAROPE  150 ML"
  },
  {
    "code" : "BR0267159",
    "display" : "CLORETO DE POTÁSSIO 600 MG  COMPRIMIDO DE LIBERAÇÃO PROLONGADA"
  },
  {
    "code" : "BR0273396",
    "display" : "ISOSSORBIDA, DINITRATO 10 MG COMPRIMIDO"
  },
  {
    "code" : "BR0272333",
    "display" : "DIMENIDRINATO + PIRIDOXINA 50 + 10 MG COMPRIMIDO"
  },
  {
    "code" : "BR0267526",
    "display" : "CLOXAZOLAM 1 MG  COMPRIMIDO"
  },
  {
    "code" : "BR0280947",
    "display" : "OFLOXACINO 200 MG COMPRIMIDO"
  },
  {
    "code" : "INATIVO I",
    "display" : "INATIVO-MEPERIDINA 50 MG/ML SOLUÇÃO INJETÁVEL  2 ML"
  },
  {
    "code" : "BR0272469",
    "display" : "DALTEPARINA SÓDICA 5000 UI SOLUÇÃO INJETÁVEL 0,2 ML"
  },
  {
    "code" : "BR0269963U0085",
    "display" : "DOMPERIDONA 1 MG/ML SUSPENSÃO ORAL  200 ML"
  },
  {
    "code" : "BR0269843U0086",
    "display" : "LIDOCAÍNA, CLORIDRATO 20 MG/ML SOLUÇÃO INJETÁVEL 20 ML"
  },
  {
    "code" : "BR0349666",
    "display" : "NITRATO DE PRATA BASTÃO 5 G"
  },
  {
    "code" : "BR0268286U0020",
    "display" : "MICONAZOL, NITRATO 2 % CREME  28 G"
  },
  {
    "code" : "BR0271004",
    "display" : "DICLOFENACO SÓDICO 75 MG/ML SOLUÇÃO INJETÁVEL 3 ML"
  },
  {
    "code" : "BR0300745",
    "display" : "PANCREATINA 25.000 UI CÁPSULA  ELENCO ESTADUAL"
  },
  {
    "code" : "BR0278490",
    "display" : "ÁCIDO FÓLICO 0,4 MG/ML SOLUÇÃO ORAL 100 ML"
  },
  {
    "code" : "BR0348002U0062",
    "display" : "ÁCIDOS GRAXOS ESSENCIAIS SOLUÇÃO 100 ML"
  },
  {
    "code" : "BR0267777U0086",
    "display" : "PARACETAMOL  200 MG/ML SOLUÇÃO ORAL 20 ML"
  },
  {
    "code" : "BR0268079",
    "display" : "AMANTADINA 100 MG COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0273434",
    "display" : "MANITOL + SORBITOL 0,54 % + 2,7 % SOLUÇÃO INJETÁVEL 1000 ML"
  },
  {
    "code" : "BR0285953",
    "display" : "TEOFILINA 300 MG CÁPSULA"
  },
  {
    "code" : "BR0395886",
    "display" : "TRICLOSANA 1 % SABONETE 80 G"
  },
  {
    "code" : "BR0356452-1",
    "display" : "TRAVOPROSTA + TIMOLOL, MALEATO 0,04+5 MG/ML SOLUÇÃO OFTÁLMICA 5 ML"
  },
  {
    "code" : "BR0330335",
    "display" : "SORAFENIBE, TOSILATO 200 MG COMPRIMIDO"
  },
  {
    "code" : "BR0345783-1",
    "display" : "URÉIA 100 MG/G CREME  100 G"
  },
  {
    "code" : "BR0308654",
    "display" : "OMALIZUMABE 150 MG PÓ LIOFILIZADO PARA SOLUÇÃO INJETÁVEL ELENCO ESTADUAL"
  },
  {
    "code" : "BR0309530-1",
    "display" : "GLICOSAMINA, SULFATO 1,5 G PÓ 3,95 G"
  },
  {
    "code" : "BR0309530-2",
    "display" : "GLICOSAMINA, SULFATO 1,5 G PÓ 4,13 G"
  },
  {
    "code" : "BR0372204",
    "display" : "DUTASTERIDA 0,5 MG COMPRIMIDO"
  },
  {
    "code" : "BR0305492",
    "display" : "PIOGLITAZONA, CLORIDRATO 30 MG COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0296825",
    "display" : "ÁCIDO FÓLICO + FERRO AMINOÁCIDO QUELATO 5 MG + 150 MG COMPRIMIDO"
  },
  {
    "code" : "BR0293879",
    "display" : "TOLTERODINA, TARTARATO 1 MG COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0279298",
    "display" : "FENOTEROL, BROMIDRATO + IPRATRÓPIO, BROMETO 0,1 + 0,04 MG/DOSE AEROSSOL ORAL ELENCO ESTADUAL"
  },
  {
    "code" : "BR0352395",
    "display" : "BUDESONIDA 200 MCG CÁPSULA  REFIL ELENCO ESTADUAL"
  },
  {
    "code" : "BR0268520-1",
    "display" : "RITUXIMABE 10 MG/ML SOLUÇÃO INJETÁVEL 10 ML ELENCO ESTADUAL"
  },
  {
    "code" : "BR0272603",
    "display" : "DROPROPIZINA 1,5 MG/ML XAROPE  60 ML"
  },
  {
    "code" : "BR0272602",
    "display" : "DROPROPIZINA 3 MG/ML XAROPE  100 ML"
  },
  {
    "code" : "BR0271354",
    "display" : "PILOCARPINA, CLORIDRATO 4 % SOLUÇÃO OFTÁLMICA 10 ML"
  },
  {
    "code" : "BR0306146",
    "display" : "VALSARTANA 320 MG COMPRIMIDO"
  },
  {
    "code" : "BR0394023-2",
    "display" : "VASELINA (PETROLATO, PURO) POMADA 50 G"
  },
  {
    "code" : "BR0395631U0062",
    "display" : "MIKANIA GLOMERATA (GUACO) 0,05 ML/ML XAROPE  100 ML"
  },
  {
    "code" : "BR0273639-3",
    "display" : "MULTIVITAMINAS + SAIS MINERAIS DRÁGEA"
  },
  {
    "code" : "BR0272337U0042",
    "display" : "PIRIDOXINA, CLORIDRATO 100 MG COMPRIMIDO"
  },
  {
    "code" : "BR0395835",
    "display" : "PETASITES HYBRIDUS L. 17,8 - 40 MG COMPRIMIDO"
  },
  {
    "code" : "BR0295605",
    "display" : "ALGESTONA ACETOFENIDA + ESTRADIOL, ENANTATO 150 MG + 10 MG/ML SOLUÇÃO INJETÁVEL 1 ML"
  },
  {
    "code" : "BR0284427",
    "display" : "TELMISARTANA + HIDROCLOROTIAZIDA 80 + 12,5 MG COMPRIMIDO"
  },
  {
    "code" : "BR0395950",
    "display" : "DESVENLAFAXINA, SUCCINATO MONOIDRATADO 50 MG COMPRIMIDO"
  },
  {
    "code" : "BR0369179",
    "display" : "EVEROLIMO 1 MG COMPRIMIDO"
  },
  {
    "code" : "BR0273479",
    "display" : "MINOXIDIL 10 MG COMPRIMIDO"
  },
  {
    "code" : "BR0340128",
    "display" : "CETOTIFENO, FUMARATO 0,25 MG/ML SOLUÇÃO OFTÁLMICA 5 ML"
  },
  {
    "code" : "BR0266627",
    "display" : "ALFAEPOETINA 1000 UI SOLUÇÃO INJETÁVEL 1 ML"
  },
  {
    "code" : "BR0266629",
    "display" : "ALFAEPOETINA 4.000 UI SOLUÇÃO INJETÁVEL 1 ML ELENCO ESTADUAL"
  },
  {
    "code" : "BR0396285",
    "display" : "LACTASE 9000 FCC COMPRIMIDO"
  },
  {
    "code" : "BR0272417",
    "display" : "CLOROQUINA, DIFOSFATO 250 MG  COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0388383-2",
    "display" : "TOCILIZUMABE 20 MG/ML SOLUÇÃO INJETÁVEL  10 ML"
  },
  {
    "code" : "BR0388383-1",
    "display" : "TOCILIZUMABE 20 MG/ML SOLUÇÃO INJETÁVEL  4 ML"
  },
  {
    "code" : "BR0371273-5",
    "display" : "CLORETO DE SÓDIO 0,9 % ESTÉRIL SOLUÇÃO 1000 ML NÃO INJETÁVEL"
  },
  {
    "code" : "BR0276670",
    "display" : "MEGLUMINA, IOXITALAMATO E SÓDIO 350 MG/ML SOLUÇÃO INJETÁVEL 50 ML"
  },
  {
    "code" : "BR0272979",
    "display" : "FENAZOPIRIDINA, CLORIDRATO 100 MG COMPRIMIDO"
  },
  {
    "code" : "BR0267614",
    "display" : "CAPTOPRIL  12,5 MG COMPRIMIDO"
  },
  {
    "code" : "BR0329507U0041",
    "display" : "RETINOL, PALMITATO 100.000 UI CÁPSULA"
  },
  {
    "code" : "BR0396555",
    "display" : "BETAMETASONA 0,1 MG/ML ELIXIR 120 ML"
  },
  {
    "code" : "BR0322435",
    "display" : "FANCICLOVIR 500 MG COMPRIMIDO"
  },
  {
    "code" : "BR0271355",
    "display" : "METRONIDAZOL + NISTATINA 100 MG + 20.000 UI/G CREME VAGINAL  50 G"
  },
  {
    "code" : "BR0286846-2",
    "display" : "MULTIVITAMINAS (A, C, D, COMPLEXO B) SOLUÇÃO ORAL 30 ML"
  },
  {
    "code" : "BR0271352",
    "display" : "PILOCARPINA, CLORIDRATO 1 % SOLUÇÃO OFTÁLMICA 10 ML"
  },
  {
    "code" : "INATIVO III",
    "display" : "INATIVO-ERITROPOETINA HUMANA RECOMBINANTE 3000 UI PÓ PARA SOLUÇÃO INJETÁVEL 2 ML"
  },
  {
    "code" : "BR0267894",
    "display" : "RIVASTIGMINA, HIDROGENOTARTARATO 3 MG CÁPSULA"
  },
  {
    "code" : "BR0342319",
    "display" : "ZIPRASIDONA 40 MG CÁPSULA  ELENCO ESTADUAL"
  },
  {
    "code" : "BR0271661-2",
    "display" : "AMBROXOL, CLORIDRATO 7,5 MG/ML SOLUÇÃO ORAL 60 ML"
  },
  {
    "code" : "BR0335101-2",
    "display" : "CLORANFENICOL 5 MG/ML SOLUÇÃO OFTÁLMICA 10 ML"
  },
  {
    "code" : "BR0270999-1",
    "display" : "DICLOFENACO POTÁSSICO 25 MG/ML SOLUÇÃO INJETÁVEL 3 ML"
  },
  {
    "code" : "BR0271120-1",
    "display" : "TETRACICLINA, CLORIDRATO + ANFOTERICINA B 25 + 12,5 MG/G CREME VAGINAL  45 G"
  },
  {
    "code" : "BR0268151U0067",
    "display" : "PREDNISOLONA 1 MG/ML SOLUÇÃO ORAL 120 ML"
  },
  {
    "code" : "BR0282714",
    "display" : "HIDRÓXIDO DE MAGNÉSIO 80 MG/ML SUSPENSÃO ORAL  120 ML"
  },
  {
    "code" : "BR0269958-1",
    "display" : "BROMOPRIDA 5 MG/ML SOLUÇÃO INJETÁVEL 2 ML"
  },
  {
    "code" : "BR0286846-1",
    "display" : "MULTIVITAMINAS (A, C, D, COMPLEXO B) SOLUÇÃO ORAL 20 ML"
  },
  {
    "code" : "BR0268301-1",
    "display" : "SECNIDAZOL 30 MG/ML SUSPENSÃO ORAL  15 ML"
  },
  {
    "code" : "BR0332755-6",
    "display" : "IBUPROFENO  100 MG/ML SUSPENSÃO ORAL  100 ML"
  },
  {
    "code" : "BR0266788-2",
    "display" : "NISTATINA 25.000 UI/G CREME VAGINAL  60 G"
  },
  {
    "code" : "BR0328531",
    "display" : "ÁCIDO VALPRÓICO (VALPROATO DE SÓDIO)  300 MG COMPRIMIDO"
  },
  {
    "code" : "BR0302442",
    "display" : "DULOXETINA, CLORIDRATO 30 MG COMPRIMIDO"
  },
  {
    "code" : "BR0331153",
    "display" : "ÁLCOOL POLIVINÍLICO + POVIDONA 14 MG + 6 MG/ML SOLUÇÃO OFTÁLMICA 0,4 ML"
  },
  {
    "code" : "BR0341108",
    "display" : "CODERGOCRINA, MESILATO 4,5 MG  COMPRIMIDO"
  },
  {
    "code" : "BR0395161",
    "display" : "PIRIBEDIL 50 MG COMPRIMIDO DE LIBERAÇÃO PROLONGADA"
  },
  {
    "code" : "BR0333569U0015",
    "display" : "TACROLIMO 1 MG/G POMADA 10 G"
  },
  {
    "code" : "BR0266700",
    "display" : "BUDESONIDA 200 MCG AEROSSOL ORAL 100 DOSES"
  },
  {
    "code" : "BR0332764U0042",
    "display" : "DARUNAVIR 300 MG COMPRIMIDO"
  },
  {
    "code" : "BR0272786",
    "display" : "DONEPEZILA 10 MG COMPRIMIDO"
  },
  {
    "code" : "BR0376502",
    "display" : "ESTRONCIO, RANELATO 2 G PÓ PARA SUSPENSÃO"
  },
  {
    "code" : "BR0285064",
    "display" : "FELODIPINO 2,5 MG COMPRIMIDO DE LIBERAÇÃO CONTROLADA"
  },
  {
    "code" : "BR0273011",
    "display" : "FLURAZEPAM 30 MG COMPRIMIDO"
  },
  {
    "code" : "BR0268532",
    "display" : "TENOXICAM 20 MG PÓ LIOFILIZADO 2 ML"
  },
  {
    "code" : "BR0380823",
    "display" : "PALIPERIDONA 6 MG COMPRIMIDO DE LIBERAÇÃO PROLONGADA"
  },
  {
    "code" : "BR0390005",
    "display" : "QUETIAPINA, FUMARATO 50 MG COMPRIMIDO DE LIBERAÇÃO PROLONGADA"
  },
  {
    "code" : "BR0341851",
    "display" : "FLUVOXAMINA, MALEATO 100 MG COMPRIMIDO"
  },
  {
    "code" : "BR0298768",
    "display" : "PAROXETINA, CLORIDRATO 10 MG COMPRIMIDO"
  },
  {
    "code" : "BR0296657",
    "display" : "TRIMEBUTINA, MALEATO 200 MG CÁPSULA"
  },
  {
    "code" : "BR0273703",
    "display" : "NAPROXENO SÓDICO 500 MG COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0267378U0067",
    "display" : "NISTATINA 100.000 UI/ML SUSPENSÃO ORAL  120  ML"
  },
  {
    "code" : "BR0388797",
    "display" : "METFORMINA, CLORIDRATO 750 MG COMPRIMIDO DE LIBERAÇÃO CONTROLADA"
  },
  {
    "code" : "BR0280115",
    "display" : "BOSENTANA 125 MG COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0270596",
    "display" : "BETAMETASONA, DIPROPIONATO + GENTAMICINA SULFATO 0,5 + 1 MG/G POMADA 30 G"
  },
  {
    "code" : "BR0270587",
    "display" : "BETAMETASONA, DIPROPIONATO 0,5 MG/G CREME  30 G"
  },
  {
    "code" : "BR0284101",
    "display" : "ARIPIPRAZOL 15 MG COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0309434",
    "display" : "CILAZAPRIL 5 MG COMPRIMIDO"
  },
  {
    "code" : "BR0268534-2",
    "display" : "TRAMADOL, CLORIDRATO 50 MG COMPRIMIDO"
  },
  {
    "code" : "BR0271106",
    "display" : "CICLOSPORINA 50 MG CÁPSULA  ELENCO ESTADUAL"
  },
  {
    "code" : "BR0268181",
    "display" : "ETOFIBRATO 500 MG CÁPSULA"
  },
  {
    "code" : "BR0266752",
    "display" : "IMIGLUCERASE 200 UI PÓ LIOFILIZADO PARA SOLUÇÃO INJETÁVEL"
  },
  {
    "code" : "BR0266823",
    "display" : "IMUNOGLOBULINA HUMANA 1 G PÓ PARA SOLUÇÃO INJETÁVEL"
  },
  {
    "code" : "BR0266824",
    "display" : "IMUNOGLOBULINA HUMANA 3 G PÓ PARA SOLUÇÃO INJETÁVEL"
  },
  {
    "code" : "BR0267668",
    "display" : "GENTAMICINA, SULFATO 10 MG/ML SOLUÇÃO INJETÁVEL  1 ML"
  },
  {
    "code" : "BR0272028",
    "display" : "BAMIFILINA, CLORIDRATO 300 MG DRÁGEA"
  },
  {
    "code" : "BR0267892",
    "display" : "PANTOPRAZOL 40 MG COMPRIMIDO"
  },
  {
    "code" : "BR0271691",
    "display" : "ÁCIDO ASCÓRBICO 500 MG COMPRIMIDO"
  },
  {
    "code" : "BR0393342-1",
    "display" : "PELARGONIUM SIDOIDES 825 MG/ML SOLUÇÃO ORAL 20 ML"
  },
  {
    "code" : "BR0393342-2",
    "display" : "PELARGONIUM SIDOIDES 825 MG/ML SOLUÇÃO ORAL 50 ML"
  },
  {
    "code" : "BR0270893U0042",
    "display" : "CARBONATO DE CÁLCIO + COLECALCIFEROL  500 MG + 200 UI COMPRIMIDO"
  },
  {
    "code" : "BR0269460",
    "display" : "ÁCIDO URSODESOXICÓLICO 150 MG COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0277519",
    "display" : "ÁCIDO URSODESOXICÓLICO 50 MG COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0273148",
    "display" : "DEFLAZACORTE 6 MG COMPRIMIDO"
  },
  {
    "code" : "BR0278316",
    "display" : "ZOLPIDEM, HEMITARTARATO 10 MG COMPRIMIDO"
  },
  {
    "code" : "BR0268092",
    "display" : "METADONA, CLORIDRATO 5 MG MG COMPRIMIDO"
  },
  {
    "code" : "BR0305413",
    "display" : "GINKGO BILOBA 120 MG COMPRIMIDO"
  },
  {
    "code" : "BR0272824",
    "display" : "PRAMIPEXOL, CLORIDRATO 0,125 MG COMPRIMIDO"
  },
  {
    "code" : "BR0335968",
    "display" : "VARDENAFILA, CLORIDRATO 10 MG COMPRIMIDO"
  },
  {
    "code" : "BR0274568",
    "display" : "VITAMINAS DO COMPLEXO B (B7,B9,B12) SOLUÇÃO INJETÁVEL"
  },
  {
    "code" : "BR0383417",
    "display" : "CICLESONIDA 160 MCG SOLUÇÃO PARA INALAÇÃO 120 DOSES"
  },
  {
    "code" : "BR0292418-1",
    "display" : "CIPROFLOXACINO, CLORIDRATO 2 MG/ML SOLUÇÃO INJETÁVEL 100 ML"
  },
  {
    "code" : "BR0271116U0062",
    "display" : "FLUCONAZOL 2 MG/ML SOL INJ (FR) 100 ML"
  },
  {
    "code" : "BR0268115",
    "display" : "HIDRALAZINA, CLORIDRATO 20 MG/ML SOLUÇÃO INJETÁVEL"
  },
  {
    "code" : "BR0271599",
    "display" : "METILPREDNISOLONA, SUCCINATO 500 MG PÓ PARA SOLUÇÃO INJETÁVEL 8 ML"
  },
  {
    "code" : "BR0268816U0087",
    "display" : "NEVIRAPINA 10 MG/ML SUSPENSÃO ORAL  240 ML"
  },
  {
    "code" : "BR0271661-1",
    "display" : "AMBROXOL, CLORIDRATO 7,5 MG/ML SOLUÇÃO ORAL 50 ML"
  },
  {
    "code" : "BR0297787",
    "display" : "CETIRIZINA, DICLORIDRATO 1 MG/ML MG/ML SOLUÇÃO ORAL 75 ML"
  },
  {
    "code" : "BR0392118-1",
    "display" : "DIMETICONA 75 mg/ml SUSPENSÃO ORAL  10 ML"
  },
  {
    "code" : "BR0274648U0239",
    "display" : "PASTA DÁGUA PASTA  100 G"
  },
  {
    "code" : "BR0271123-1",
    "display" : "TETRACICLINA, CLORIDRATO 5 MG/G POMADA OFTÁLMICA  3,5 G"
  },
  {
    "code" : "BR0273593",
    "display" : "VIOLETA DE GENCIANA 1 % SOLUÇÃO TÓPICA 30 ML"
  },
  {
    "code" : "BR0276233-2",
    "display" : "INSULINA LISPRO 100 UI/ML SOLUÇÃO INJETÁVEL 10 ML ELENCO ESTADUAL"
  },
  {
    "code" : "BR0268143",
    "display" : "MICOFENOLATO DE MOFETILA 500 MG COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0268957",
    "display" : "LEVONORGESTREL 30 MCG COMPRIMIDO"
  },
  {
    "code" : "BR0270224",
    "display" : "PREDNISOLONA 1 % SOLUÇÃO OFTÁLMICA 5 ML"
  },
  {
    "code" : "BR0331980",
    "display" : "CIPROTERONA, ACETATO 100 MG COMPRIMIDO"
  },
  {
    "code" : "BR0362058",
    "display" : "RIVASTIGMINA, HIDROGENOTARTARATO 18 MG ADESIVO TRANSDÉRMICO (9,5 MG/24H) ELENCO ESTADUAL"
  },
  {
    "code" : "BR0288001",
    "display" : "CICLOPIROX 80 MG/ML ESMALTE 6 G"
  },
  {
    "code" : "BR0379902U0041",
    "display" : "OSELTAMIVIR, FOSFATO 30 MG CÁPSULA"
  },
  {
    "code" : "BR0379962U0041",
    "display" : "OSELTAMIVIR, FOSFATO 45 MG CÁPSULA"
  },
  {
    "code" : "BR0276264",
    "display" : "RAMIPRIL + ANLODIPINO, BESILATO 5 + 5 MG CÁPSULA"
  },
  {
    "code" : "BR0364917",
    "display" : "ANLODIPINO, BESILATO + BENAZEPRIL, CLORIDRATO 5  MG +20 MG MG CÁPSULA"
  },
  {
    "code" : "BR0268405",
    "display" : "CEFAZOLINA 1 G  PÓ PARA SOLUÇÃO INJETÁVEL"
  },
  {
    "code" : "BR0308726-1",
    "display" : "BENZOATO DE BENZILA 250 MG/ML EMULSÃO TÓPICA 100 ML"
  },
  {
    "code" : "BR0268837",
    "display" : "SACCHAROMYCES BOULARDII - 17 100 MG CÁPSULA"
  },
  {
    "code" : "BR0367693",
    "display" : "ÁCIDO NICOTÍNICO 750 MG COMPRIMIDO DE LIBERAÇÃO PROLONGADA"
  },
  {
    "code" : "BR0356051",
    "display" : "ÁCIDO ZOLEDRÔNICO 50 MCG/ML SOLUÇÃO INJETÁVEL 100 ML ELENCO ESTADUAL"
  },
  {
    "code" : "BR0274506",
    "display" : "CANDESARTANA CILEXETILA 8 MG COMPRIMIDO"
  },
  {
    "code" : "BR0388402",
    "display" : "OLMESARTANA + ANLODIPINO 40 + 10 MG COMPRIMIDO"
  },
  {
    "code" : "BR0395631U0074",
    "display" : "MIKANIA GLOMERATA (GUACO) 0,05 ML/ML XAROPE  150 ML"
  },
  {
    "code" : "BR0273700",
    "display" : "TIAMAZOL 5 MG COMPRIMIDO"
  },
  {
    "code" : "BR0276097",
    "display" : "BICARBONATO DE SÓDIO 10 % SOLUÇÃO INJETÁVEL  10 ML"
  },
  {
    "code" : "BR0270798",
    "display" : "FEXOFENADINA, CLORIDRATO 120 MG COMPRIMIDO"
  },
  {
    "code" : "BR0267087",
    "display" : "GENFIBROZILA 900 MG COMPRIMIDO"
  },
  {
    "code" : "BR0332849-2",
    "display" : "CALCIPOTRIOL 50 MCG/G POMADA 30 G"
  },
  {
    "code" : "BR0437156U0105",
    "display" : "HIPOCLORITO DE SÓDIO 2,0 A 2,5 % SOLUÇÃO 50 ML"
  },
  {
    "code" : "BR0267281-2",
    "display" : "ESCOPOLAMINA, BUTILBROMETO 10 mg/ml SOLUÇÃO ORAL 10 ML"
  },
  {
    "code" : "BR0268080",
    "display" : "ATORVASTATINA CÁLCICA 10 MG COMPRIMIDO"
  },
  {
    "code" : "BR0348669U0013",
    "display" : "SORO ANTIELAPÍDICO (BIVALENTE) 1,5 MG/ML SUSPENSÃO INJETÁVEL"
  },
  {
    "code" : "BR0363537U0238",
    "display" : "VACINA FEBRE TIFÓIDE (POLISSACARÍDICA) 0,025 MCG/DOSE SOLUÇÃO INJETÁVEL 0,5 ML"
  },
  {
    "code" : "BR0363537-1",
    "display" : "INATIVO- VACINA FEBRE TIFÓIDE (ATENUADA) SOLUÇÃO ORAL"
  },
  {
    "code" : "BR0284435-2",
    "display" : "BETAXOLOL, CLORIDRATO 5 % SOLUÇÃO OFTÁLMICA 5 ML ELENCO ESTADUAL"
  },
  {
    "code" : "BR0273719",
    "display" : "NITROPRUSSETO DE SÓDIO 50 MG PÓ LIOFILIZADO PARA SOLUÇÃO INJETÁVEL 2 ML"
  },
  {
    "code" : "BR0305717",
    "display" : "NOREPINEFRINA 1 MG/ML SOLUÇÃO INJETÁVEL 4 ML"
  },
  {
    "code" : "BR0272568",
    "display" : "RETINOL + COLECALCIFEROL 50.000 + 10.000 UI SOLUÇÃO ORAL  10 ML"
  },
  {
    "code" : "BR0290674",
    "display" : "EBASTINA 1 MG/ML SOLUÇÃO ORAL 60 ML"
  },
  {
    "code" : "BR0294536",
    "display" : "MIRTAZAPINA 30 MG COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0340103",
    "display" : "CETOPROFENO 150 MG  COMPRIMIDO DE LIBERAÇÃO PROLONGADA"
  },
  {
    "code" : "BR0276333U0042",
    "display" : "AMITRIPTILINA, CLORIDRATO 75 MG COMPRIMIDO"
  },
  {
    "code" : "BR0270711",
    "display" : "LANSOPRAZOL + CLARITROMICINA + AMOXICILINA 30 + 500 + 500 MG CÁPSULA"
  },
  {
    "code" : "BR0306686",
    "display" : "NICERGOLINA 30 MG COMPRIMIDO"
  },
  {
    "code" : "BR0392423",
    "display" : "DEXPANTENOL 50 MG/G POMADA 10 G"
  },
  {
    "code" : "BR0305629",
    "display" : "CIMICIFUGA RACEMOSA NUTT.  20 MG  COMPRIMIDO"
  },
  {
    "code" : "BR0275989",
    "display" : "SACCHAROMYCES BOULARDII - 17 200 MG PÓ"
  },
  {
    "code" : "BR0292382-1",
    "display" : "TRAMADOL, CLORIDRATO 50 MG/ML SOLUÇÃO INJETÁVEL  1 ML"
  },
  {
    "code" : "BR0269468",
    "display" : "ROPIVACAÍNA, CLORIDRATO 1 % SOLUÇÃO INJETÁVEL  20 ML"
  },
  {
    "code" : "BR0268462-1",
    "display" : "HALOTANO LIQUIDO INALANTE 250 ML"
  },
  {
    "code" : "BR0268393",
    "display" : "AMPICILINA 500 MG PÓ PARA SOLUÇÃO INJETÁVEL"
  },
  {
    "code" : "BR0268541",
    "display" : "VANCOMICINA 1 G PÓ PARA SOLUÇÃO INJETÁVEL"
  },
  {
    "code" : "BR0292778",
    "display" : "METOPROLOL, TARTARATO + HIDROCLOROTIAZIDA 100 MG + 12,5 MG COMPRIMIDO"
  },
  {
    "code" : "BR0290168",
    "display" : "SUXAMETÔNIO, CLORETO 500 MG PÓ PARA SOLUÇÃO INJETÁVEL"
  },
  {
    "code" : "BR0273824",
    "display" : "ÁCIDO FÓLICO 2 MG COMPRIMIDO"
  },
  {
    "code" : "BR0329341",
    "display" : "TADALAFILA 20 MG COMPRIMIDO"
  },
  {
    "code" : "BR0298582",
    "display" : "PINAVÉRIO, BROMETO 100 MG COMPRIMIDO"
  },
  {
    "code" : "BR0273484",
    "display" : "MOMETASONA, FUROATO 1 % CREME  20 G"
  },
  {
    "code" : "BR0395616",
    "display" : "MOMETASONA, FUROATO 400 MCG CÁPSULA"
  },
  {
    "code" : "BR0273931",
    "display" : "ORLISTATE 120 MG CÁPSULA  ELENCO ESTADUAL"
  },
  {
    "code" : "BR0395844",
    "display" : "GLIMEPIRIDA + METFORMINA, CLORIDRATO 2 + 1000 MG COMPRIMIDO"
  },
  {
    "code" : "BR0323548",
    "display" : "SULPIRIDA + BROMAZEPAM 25 + 1 MG COMPRIMIDO"
  },
  {
    "code" : "BR0395910",
    "display" : "VALSARTANA + HIDROCLOROTIAZIDA 320 + 12,5 MG COMPRIMIDO"
  },
  {
    "code" : "BR0297787-1",
    "display" : "CETIRIZINA, DICLORIDRATO 1 MG/ML SOLUÇÃO ORAL 80 ML"
  },
  {
    "code" : "BR0270588",
    "display" : "BETAMETASONA, DIPROPIONATO 0,5 MG/G POMADA 30 G"
  },
  {
    "code" : "BR0318988",
    "display" : "SOMATROPINA 8 UI PÓ + DILUENTE 1 ML"
  },
  {
    "code" : "BR0272792",
    "display" : "ETOSSUXIMIDA 50 MG/ML SOLUÇÃO ORAL  120 ML"
  },
  {
    "code" : "BR0300252-2",
    "display" : "GLICOSE + CLORETO DE SÓDIO 20 + 0,9 % SOLUÇÃO INJETÁVEL  250 ML"
  },
  {
    "code" : "BR0395438",
    "display" : "NAFAZOLINA + MEPIRAMINA + PANTENOL 1 + 0,2 + 5 MG/ML SOLUÇÃO NASAL 15 ML"
  },
  {
    "code" : "BR0270503-1",
    "display" : "FIBRINOLISINA + DESOXIRRIBONUCLEASE + CLORANFENICOL POMADA 10 G"
  },
  {
    "code" : "BR0273555",
    "display" : "MELOXICAM 15 MG/ML SOLUÇÃO INJETÁVEL 1,5 ML"
  },
  {
    "code" : "BR0395438-1",
    "display" : "NAFAZOLINA + MEPIRAMINA + PANTENOL 1 + 0,2 + 5 MG/ML SOLUÇÃO NASAL 30 ML"
  },
  {
    "code" : "BR0267139",
    "display" : "AMPICILINA 50 MG/ML SUSPENSÃO ORAL  60 ML"
  },
  {
    "code" : "BR0272420",
    "display" : "CLORTALIDONA 50 MG  COMPRIMIDO"
  },
  {
    "code" : "BR0268290",
    "display" : "ÁCIDO BÓRICO  (ÁGUA BORICADA) 3 % SOLUÇÃO 100 ML"
  },
  {
    "code" : "BR0352847-1",
    "display" : "PIPOTIAZINA, PALMITATO 25 MG/ML SOLUÇÃO INJETÁVEL 1 ML"
  },
  {
    "code" : "BR0352847-2",
    "display" : "PIPOTIAZINA, PALMITATO 25 MG/ML SOLUÇÃO INJETÁVEL 4 ML"
  },
  {
    "code" : "BR0287824",
    "display" : "TIAMAZOL 10 MG COMPRIMIDO"
  },
  {
    "code" : "BR0395726-1",
    "display" : "OXOMEMAZINA + GUAIFENESINA + BENZOATO DE SÓDIO + PARACETAMOL 0,332+6,66+6,66+6,66 MG/ML XAROPE  100 ML"
  },
  {
    "code" : "BR0270971",
    "display" : "ESCOPOLAMINA, BUTILBROMETO + PARACETAMOL 10 + 500 MG COMPRIMIDO"
  },
  {
    "code" : "BR0273642",
    "display" : "HIDRÓXIDO DE ALUMÍNIO + HIDRÓXIDO DE MAGNÉSIO 200 + 200 MG COMPRIMIDO MASTIGÁVEL"
  },
  {
    "code" : "BR0383660",
    "display" : "TIOTRÓPIO, BROMETO 2,5 MCG SOLUÇÃO PARA INALAÇÃO 60 DOSES ELENCO ESTADUAL"
  },
  {
    "code" : "BR0272088-2",
    "display" : "SULFADIAZINA DE PRATA + NITRATO DE CÉRIO 1 + 0,4 % CREME  100 G"
  },
  {
    "code" : "BR0273810",
    "display" : "OLANZAPINA 2,5 MG COMPRIMIDO"
  },
  {
    "code" : "BR0277526-2",
    "display" : "DIDANOSINA 400 MG CÁPSULA"
  },
  {
    "code" : "BR0273192",
    "display" : "TEMOZOLOMIDA 250 MG CÁPSULA"
  },
  {
    "code" : "BR0384537U0018",
    "display" : "PERÓXIDO DE BENZOÍLA 2,5 % GEL 20 G"
  },
  {
    "code" : "BR0393803",
    "display" : "ÁCIDO FÓLICO 5 MG/ML SOLUÇÃO ORAL 10 ML"
  },
  {
    "code" : "BR0282223",
    "display" : "CARBOCISTEÍNA 50 MG/ML SOLUÇÃO ORAL  20 ML"
  },
  {
    "code" : "BR0268869",
    "display" : "RIZATRIPTANA, BENZOATO 10 MG COMPRIMIDO"
  },
  {
    "code" : "BR0274482",
    "display" : "ISOXSUPRINA, CLORIDRATO 10 MG COMPRIMIDO"
  },
  {
    "code" : "BR0304870-1",
    "display" : "MORFINA, SULFATO 1 MG/ML SOLUÇÃO INJETÁVEL 2 ML"
  },
  {
    "code" : "BR0394754",
    "display" : "HIPROMELOSE + CETRIMIDA 3,2 MG +  0,1 MG/ML SOLUÇÃO OFTÁLMICA 10 ML"
  },
  {
    "code" : "BR0270799",
    "display" : "FEXOFENADINA, CLORIDRATO 180 MG COMPRIMIDO"
  },
  {
    "code" : "BR0357071",
    "display" : "CALCIO, CITRATO + COLECALCIFEROL 500 MG + 200 UI PÓ PARA SUSPENSÃO ORAL  4 G"
  },
  {
    "code" : "BR0272023",
    "display" : "TAMOXIFENO, CITRATO 20 MG COMPRIMIDO"
  },
  {
    "code" : "BR0395620U0041",
    "display" : "GLYCINE MAX (ISOFLAVONA DE SOJA) 150 MG CÁPSULA"
  },
  {
    "code" : "BR337457-1",
    "display" : "MOMETASONA, FUROATO 50 MCG SUSPENSÃO NASAL 60 DOSES"
  },
  {
    "code" : "BR0272833",
    "display" : "QUETIAPINA, FUMARATO 200 MG COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0382563",
    "display" : "CLORETO DE SÓDIO 10% SOLUÇÃO INJETÁVEL 10 ML"
  },
  {
    "code" : "BR0437160U0063",
    "display" : "CLORETO DE SÓDIO 0,9 % SOLUÇÃO NASAL 10 ML"
  },
  {
    "code" : "BR0271353",
    "display" : "PILOCARPINA, CLORIDRATO 2 % SOLUÇÃO OFTÁLMICA 10 ML ELENCO ESTADUAL"
  },
  {
    "code" : "BR0272234",
    "display" : "LEVOBUNOLOL, CLORIDRATO 5 MG/ML SOLUÇÃO OFTÁLMICA 10 ML"
  },
  {
    "code" : "BR0396047",
    "display" : "PROMETAZINA, CLORIDRATO + SULFOGUAIACOL DE POTÁSSIO 0,565 + 9 MG/ML XAROPE  100 ML"
  },
  {
    "code" : "BR0396029",
    "display" : "HIALURONIDASE + BETAMETASONA, VALERATO 150 UTR/G + 2,5 MG/G POMADA 20 G"
  },
  {
    "code" : "BR0268162U0030",
    "display" : "MICONAZOL, NITRATO 2 % CREME VAGINAL  60 G"
  },
  {
    "code" : "BR0268177",
    "display" : "FLUTAMIDA 250 MG COMPRIMIDO"
  },
  {
    "code" : "BR0396081",
    "display" : "AMISSULPRIDA 50 MG COMPRIMIDO"
  },
  {
    "code" : "BR0275475-1",
    "display" : "DIPIRONA + PROMETAZINA + ADIFENINA 500 + 5 + 10 MG SOLUÇÃO ORAL 15 ML"
  },
  {
    "code" : "BR0267582U0084",
    "display" : "BECLOMETASONA, DIPROPIONATO 50 MCG/DOSE AEROSSOL NASAL 200 DOSES"
  },
  {
    "code" : "BR038719",
    "display" : "ACITRETINA 10 MG CÁPSULA"
  },
  {
    "code" : "BR0396087",
    "display" : "AMINAFTONA 75 MG COMPRIMIDO"
  },
  {
    "code" : "BR0271666",
    "display" : "ACECLOFENACO 100 MG COMPRIMIDO"
  },
  {
    "code" : "BR0272490",
    "display" : "DIETILESTILBESTROL  1 MG COMPRIMIDO"
  },
  {
    "code" : "BR0387985",
    "display" : "ZUCLOPENTIXOL 25 MG COMPRIMIDO"
  },
  {
    "code" : "BR0267079",
    "display" : "ALFAEPOETINA 3.000 UI SOLUÇÃO INJETÁVEL 1 ML"
  },
  {
    "code" : "BR0292416",
    "display" : "CALCITRIOL 1 MCG CÁPSULA"
  },
  {
    "code" : "BR0271105",
    "display" : "CICLOSPORINA 10 MG CÁPSULA  ELENCO ESTADUAL"
  },
  {
    "code" : "BR0272784",
    "display" : "CODEÍNA 3 MG/ML SOLUÇÃO ORAL 120 ML"
  },
  {
    "code" : "BR0272835",
    "display" : "RIBAVIRINA 250 MG CÁPSULA  ELENCO ESTADUAL"
  },
  {
    "code" : "BR0270907",
    "display" : "PARACETAMOL + CODEÍNA, FOSFATO 500 MG + 30 MG COMPRIMIDO"
  },
  {
    "code" : "BR0270906",
    "display" : "PARACETAMOL + CODEÍNA, FOSFATO 500 MG + 7,5 MG COMPRIMIDO"
  },
  {
    "code" : "BR0301956",
    "display" : "DERIVADO PROTÊICO PURIFICADO (TUBERCULINA) 2 UTR SOLUÇÃO INJETÁVEL 1,5 ML"
  },
  {
    "code" : "BR0288275",
    "display" : "TINIDAZOL + MICONAZOL, NITRATO 30 + 20 MG/G CREME VAGINAL  45 G"
  },
  {
    "code" : "BR0299247",
    "display" : "DIDANOSINA 2 G PÓ PARA SUSPENSÃO"
  },
  {
    "code" : "BR0269810",
    "display" : "AMINOFILINA 200 MG COMPRIMIDO"
  },
  {
    "code" : "BR0395728U0062",
    "display" : "MIKANIA GLOMERATA (GUACO) 0,25 ML/ML XAROPE  100 ML"
  },
  {
    "code" : "BR0345638",
    "display" : "CLORANFENICOL 4 MG/ML SOLUÇÃO OFTÁLMICA 10 ML"
  },
  {
    "code" : "BR0394910-1",
    "display" : "CLORETO DE SÓDIO 4,5 MG/G GEL 30 G"
  },
  {
    "code" : "BR0273195",
    "display" : "TEMOZOLOMIDA 100 MG CÁPSULA"
  },
  {
    "code" : "BR0273821",
    "display" : "SILDENAFILA, CITRATO 50 MG COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0395518",
    "display" : "PARACETAMOL + CODEÍNA, FOSFATO 500 MG + 15 MG CÁPSULA"
  },
  {
    "code" : "BR0395519",
    "display" : "IBUPROFENO + PARACETAMOL + PIRIDOXINA + CARISOPRODOL 400 MG + 400 MG + 50 MG + 200 MG CÁPSULA"
  },
  {
    "code" : "BR0268126",
    "display" : "LEVOTIROXINA SÓDICA 150 MCG COMPRIMIDO"
  },
  {
    "code" : "BR0296649",
    "display" : "LEVOTIROXINA SÓDICA 88 MCG COMPRIMIDO"
  },
  {
    "code" : "BR0276336",
    "display" : "AMITRIPTILINA, CLORIDRATO + CLORDIAZEPÓXIDO 12,5 MG + 5 MG CÁPSULA"
  },
  {
    "code" : "BR0271126",
    "display" : "CETOTIFENO, FUMARATO 1 MG  COMPRIMIDO"
  },
  {
    "code" : "BR0395146",
    "display" : "COBAMAMIDA 5 MG  MG COMPRIMIDO MASTIGÁVEL"
  },
  {
    "code" : "BR0267731",
    "display" : "NIFEDIPINO 20 MG MG CÁPSULA DURA DE LIBERAÇÃO PROLONGADA"
  },
  {
    "code" : "BR0385153",
    "display" : "TROMETAMOL, CETOROLACO 10 MG COMPRIMIDO SUBLINGUAL"
  },
  {
    "code" : "BR0272092-1",
    "display" : "VITAMINAS DO COMPLEXO B (B1,B2,B3,B6,B12) SOLUÇÃO ORAL  20 ML"
  },
  {
    "code" : "BR0277973",
    "display" : "ERGOMETRINA 0,2 MG COMPRIMIDO"
  },
  {
    "code" : "BR0400436",
    "display" : "ÁCIDO VALPRÓICO (VALPROATO DE SÓDIO)  500 MG COMPRIMIDO DE LIBERAÇÃO PROLONGADA"
  },
  {
    "code" : "BR0395719",
    "display" : "FLUOXETINA, CLORIDRATO 60 MG CÁPSULA"
  },
  {
    "code" : "BR0395952",
    "display" : "LACTASE 3000 UI CÁPSULA"
  },
  {
    "code" : "BR0272944",
    "display" : "FLUORESCEÍNA SÓDICA 1 % SOLUÇÃO OFTÁLMICA 3 ML"
  },
  {
    "code" : "BR0395945",
    "display" : "GERMEN DE SOJA 150 MG CÁPSULA"
  },
  {
    "code" : "INATIVO VII",
    "display" : "INATIVO-SULFATO FERROSO 125 MG/ML SOLUÇÃO ORAL  30 ML"
  },
  {
    "code" : "BR0292732",
    "display" : "FUROSEMIDA + CLORETO DE POTÁSSIO 40 + 100 MG COMPRIMIDO"
  },
  {
    "code" : "BR0287253",
    "display" : "NICOTINA 4 MG PASTILHA"
  },
  {
    "code" : "BR0282298",
    "display" : "SULPIRIDA 20 MG/ML SOLUÇÃO ORAL  30 ML"
  },
  {
    "code" : "BR0354632",
    "display" : "OLOPATADINA 1 MG/ML SOLUÇÃO OFTÁLMICA 5 ML"
  },
  {
    "code" : "BR0342501",
    "display" : "FENOFIBRATO 250 MG CÁPSULA DE LIBERAÇÃO CONTROLADA"
  },
  {
    "code" : "BR0272848",
    "display" : "TOLCAPONA 200 MG COMPRIMIDO"
  },
  {
    "code" : "BR0308718",
    "display" : "ACITRETINA 25 MG CÁPSULA"
  },
  {
    "code" : "BR0292401",
    "display" : "ALFACALCIDOL 1 MCG CÁPSULA"
  },
  {
    "code" : "BR0266767",
    "display" : "ALFAINTERFERONA 2B 3.000.000 UI PÓ LIOFILIZADO PARA SOLUÇÃO INJETÁVEL ELENCO ESTADUAL"
  },
  {
    "code" : "BR0267471",
    "display" : "ALFAPEGINTERFERONA 2B 120 MCG PÓ LIOFILIZADO PARA SOLUÇÃO INJETÁVEL ELENCO ESTADUAL"
  },
  {
    "code" : "BR0302942",
    "display" : "CICLOSPORINA 100 MG/ML SOLUÇÃO ORAL 50 ML ELENCO ESTADUAL"
  },
  {
    "code" : "BR0272429",
    "display" : "CLOZAPINA 25 MG  COMPRIMIDO"
  },
  {
    "code" : "BR0268103",
    "display" : "CODEÍNA 60 MG  COMPRIMIDO"
  },
  {
    "code" : "BR0272473",
    "display" : "DANAZOL 100 MG COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0268074",
    "display" : "DESMOPRESSINA, ACETATO 0,1 MG/ML SPRAY  NASAL 2,5 ML ELENCO ESTADUAL"
  },
  {
    "code" : "BR0267083",
    "display" : "FLUVASTATINA SÓDICA 20 MG CÁPSULA"
  },
  {
    "code" : "BR0266599",
    "display" : "FORMOTEROL, FUMARATO 12 MCG PÓ PARA INALAÇÃO ORAL 60 DOSES"
  },
  {
    "code" : "BR0266825",
    "display" : "IMUNOGLOBULINA HUMANA 0,5 G PÓ PARA SOLUÇÃO INJETÁVEL"
  },
  {
    "code" : "BR0272807",
    "display" : "ISOTRETINOÍNA 10 MG CÁPSULA"
  },
  {
    "code" : "BR0272092-2",
    "display" : "VITAMINAS DO COMPLEXO B (B1,B2,B3,B6,B12) SOLUÇÃO ORAL 100 ML"
  },
  {
    "code" : "BR0332468U0110",
    "display" : "SULFATO FERROSO (5MG/ML DE FERRO ELEMENTAR) 25 MG/ML XAROPE  60 ML"
  },
  {
    "code" : "BR0267161",
    "display" : "CLORETO DE POTÁSSIO 10% SOLUÇÃO INJETÁVEL 10 ML"
  },
  {
    "code" : "BR0272431",
    "display" : "CLOZAPINA 100 MG  COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0272785",
    "display" : "DONEPEZILA 5 MG COMPRIMIDO"
  },
  {
    "code" : "BR0272808",
    "display" : "ISOTRETINOÍNA 20 MG CÁPSULA  ELENCO ESTADUAL"
  },
  {
    "code" : "BR0268114",
    "display" : "LEFLUNOMIDA 20 MG COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0271621",
    "display" : "OLANZAPINA 10 MG COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0274928",
    "display" : "MULTIVITAMINAS (A, B2, C, B6, B5, E) SOLUÇÃO ORAL 20 ML"
  },
  {
    "code" : "BR0273639-4",
    "display" : "MULTIVITAMINAS + SAIS MINERAIS SOLUÇÃO ORAL 20 ML"
  },
  {
    "code" : "BR0273639-6",
    "display" : "MULTIVITAMINAS + SAIS MINERAIS SOLUÇÃO ORAL 120 ML"
  },
  {
    "code" : "BR0392593",
    "display" : "HIDRÓXIDO DE MAGNÉSIO + CARBONATO DE CÁLCIO + HIDRÓXIDO DE ALUMÍNIO  185 + 231,5 + 178 MG PASTILHA"
  },
  {
    "code" : "BR0272602-3",
    "display" : "DROPROPIZINA 3 MG/ML XAROPE  120 ML"
  },
  {
    "code" : "BR0277934-1",
    "display" : "ATROPINA, SULFATO 0,5 MG/ML SOLUÇÃO INJETÁVEL  1 ML"
  },
  {
    "code" : "BR0274996-2",
    "display" : "FERRIPOLIMALTOSE 10 MG/ML XAROPE  120 ML"
  },
  {
    "code" : "BR0305491",
    "display" : "PIOGLITAZONA, CLORIDRATO 45 MG COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0393034",
    "display" : "SAXAGLIPTINA 5 MG COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0268520",
    "display" : "RITUXIMABE 10 MG/ML SOLUÇÃO INJETÁVEL 50 ML ELENCO ESTADUAL"
  },
  {
    "code" : "BR0394910",
    "display" : "CLORETO DE SÓDIO 4,5 MG/G GEL 15 G"
  },
  {
    "code" : "BR0274808",
    "display" : "CLORTALIDONA 12,5 MG  COMPRIMIDO"
  },
  {
    "code" : "BR0270228",
    "display" : "POLIMIXINA B + NEOMICINA + HIDROCORTISONA 10.000 + 5 + 10 UI + MG + MG/ML SUSPENSÃO OTOLÓGICA 10 ML"
  },
  {
    "code" : "BR0275118",
    "display" : "PREDNISOLONA 5 MG COMPRIMIDO"
  },
  {
    "code" : "BR0395162",
    "display" : "VALSARTANA + HIDROCLOROTIAZIDA 320 + 25 MG COMPRIMIDO"
  },
  {
    "code" : "BR0395144",
    "display" : "FLUFENAZINA, CLORIDRATO 5 MG COMPRIMIDO"
  },
  {
    "code" : "INATIVO X",
    "display" : "INATIVO-DEXAMETASONA 0,1 MG/ML ELIXIR 100 ML"
  },
  {
    "code" : "BR0272787",
    "display" : "ALFADORNASE 1 MG/ML SOLUÇÃO PARA INALAÇÃO 2,5 ML"
  },
  {
    "code" : "BR0366861U0018",
    "display" : "PERÓXIDO DE BENZOÍLA 5 % GEL 20 G"
  },
  {
    "code" : "BR0269823",
    "display" : "BROMEXINA, CLORIDRATO 2 MG/ML SOLUÇÃO ORAL  50 ML"
  },
  {
    "code" : "BR0389802",
    "display" : "GESTODENO + ETINILESTRADIOL 0,06 + 0,015 MG COMPRIMIDO"
  },
  {
    "code" : "BR0285055",
    "display" : "ÁCIDO ACETILSALICÍLICO  81 MG COMPRIMIDO"
  },
  {
    "code" : "BR0366884",
    "display" : "ALISQUIRENO, HEMIFUMARATO 300 MG COMPRIMIDO"
  },
  {
    "code" : "BR0344014",
    "display" : "CLONAZEPAM 0,25 MG COMPRIMIDO SUBLINGUAL"
  },
  {
    "code" : "BR0271165",
    "display" : "AMILORIDA, CLORIDRATO + HIDROCLOROTIAZIDA 2,5  MG + 25 MG COMPRIMIDO"
  },
  {
    "code" : "BR0268482",
    "display" : "MIDAZOLAM, CLORIDRATO 1 MG/ML SOLUÇÃO INJETÁVEL 5 ML"
  },
  {
    "code" : "BR0268829U0041",
    "display" : "TERIZIDONA 250 MG CÁPSULA"
  },
  {
    "code" : "BR0354242",
    "display" : "METOXISALENO 10 MG CÁPSULA"
  },
  {
    "code" : "BR0272400-1",
    "display" : "NAFAZOLINA, CLORIDRATO 0,5 MG/ML SOLUÇÃO NASAL 30 ML"
  },
  {
    "code" : "BR0366861U0028",
    "display" : "PERÓXIDO DE BENZOÍLA 5 % GEL 45 G"
  },
  {
    "code" : "BR0395608",
    "display" : "PINAVÉRIO, BROMETO 50 MG COMPRIMIDO"
  },
  {
    "code" : "BR0358449",
    "display" : "DARIFENACINA, BROMIDRATO 7,5 MG COMPRIMIDO DE LIBERAÇÃO PROLONGADA"
  },
  {
    "code" : "BR0332755-3",
    "display" : "IBUPROFENO  100 MG/ML SUSPENSÃO ORAL  20 ML"
  },
  {
    "code" : "BR0273167-4",
    "display" : "NEOMICINA + BACITRACINA 5 + 250 MG + UI/G POMADA 50 G"
  },
  {
    "code" : "BR0284106",
    "display" : "RISPERIDONA 1 MG/ML SOLUÇÃO ORAL  30 ML"
  },
  {
    "code" : "BR0271167",
    "display" : "LISINOPRIL 5 MG COMPRIMIDO"
  },
  {
    "code" : "BR0276393",
    "display" : "TROMETAMOL, CETOROLACO 5 % SOLUÇÃO OFTÁLMICA 5 ML"
  },
  {
    "code" : "BR0305464-1",
    "display" : "FLUOXETINA, CLORIDRATO 10 MG COMPRIMIDO"
  },
  {
    "code" : "BR0272791",
    "display" : "ETOSSUXIMIDA 250 MG COMPRIMIDO"
  },
  {
    "code" : "BR0275989-1",
    "display" : "SACCHAROMYCES BOULARDII - 17 200 MG CÁPSULA"
  },
  {
    "code" : "BR0269591",
    "display" : "DIMETICONA 125 mg CÁPSULA"
  },
  {
    "code" : "BR0394650U0042",
    "display" : "METOPROLOL, TARTARATO 100 MG COMPRIMIDO"
  },
  {
    "code" : "BR0396051",
    "display" : "INSULINA ASPARTE 100 UI/ML SOLUÇÃO INJETÁVEL COM SISTEMA DE APLICAÇÃO 3 ML ELENCO ESTADUAL"
  },
  {
    "code" : "BR0273567U0098",
    "display" : "IMUNOGLOBULINA ANTI-HEPATITE B 1000 UI SOLUÇÃO INJETÁVEL"
  },
  {
    "code" : "BR0396168",
    "display" : "IMUNOGLOBULINA HUMANA 0,6 G SOLUÇÃO INJETÁVEL"
  },
  {
    "code" : "BR0292279",
    "display" : "PERGOLIDA, MESILATO 1 MG COMPRIMIDO"
  },
  {
    "code" : "BR0272082",
    "display" : "SEVELÂMER, CLORIDRATO 400 MG COMPRIMIDO"
  },
  {
    "code" : "BR0267328",
    "display" : "FOSFATO DE SÓDIO MONOBÁSICO + FOSFATO DE SÓDIO DIBÁSICO 16 + 6 % ENEMA  130 ML"
  },
  {
    "code" : "BR0272431U0042",
    "display" : "CLOZAPINA 100 MG COMP GRUPO 1.A"
  },
  {
    "code" : "BR0308718U0041",
    "display" : "ACITRETINA 25 MG CAP GRUPO 1.B"
  },
  {
    "code" : "BR0292401U0041",
    "display" : "ALFACALCIDOL 1 MCG CAP GRUPO 2"
  },
  {
    "code" : "BR0266627U0118",
    "display" : "ALFAEPOETINA 1.000 UI SOL INJ (FR-AMP) GRUPO 1.A"
  },
  {
    "code" : "BR0272472U0041",
    "display" : "DANAZOL 200 MG CAP GRUPO 1.B"
  },
  {
    "code" : "BR0266630U0118",
    "display" : "ALFAEPOETINA 10.000 UI SOL INJ (FR-AMP) GRUPO 1.A"
  },
  {
    "code" : "BR0266628U0118",
    "display" : "ALFAEPOETINA 2.000 UI SOL INJ (FR-AMP) GRUPO 1.A"
  },
  {
    "code" : "BR0325838U0042",
    "display" : "DEFERASIROX 125 MG COMP GRUPO 1.A"
  },
  {
    "code" : "BR0361382U0042",
    "display" : "DEFERIPRONA 500 MG COMP GRUPO 1.B"
  },
  {
    "code" : "BR0267092U0042",
    "display" : "LOVASTATINA 40 MG COMP GRUPO 2"
  },
  {
    "code" : "BR0267473U0118",
    "display" : "ALFAPEGINTERFERONA 2B 100 MCG PÓ LIOF INJ (FR-AMP) GRUPO 1.A"
  },
  {
    "code" : "BR0268148U0042",
    "display" : "PRAVASTATINA 20 MG COMP GRUPO 2"
  },
  {
    "code" : "BR0315088U0042",
    "display" : "ENTECAVIR 0,5 MG COMP GRUPO 1.A"
  },
  {
    "code" : "BR0278482U0042",
    "display" : "PRIMIDONA 250 MG COMP GRUPO 2"
  },
  {
    "code" : "BR0272831U0042",
    "display" : "QUETIAPINA 25 MG COMP GRUPO 1.A"
  },
  {
    "code" : "BR0268081U0042",
    "display" : "ATORVASTATINA 20 MG COMP GRUPO 2"
  },
  {
    "code" : "BR0369179U0042",
    "display" : "EVEROLIMO 1 MG COMP GRUPO 1.A"
  },
  {
    "code" : "BR0292240U0136",
    "display" : "MESALAZINA 1000 MG SUPOS GRUPO 2"
  },
  {
    "code" : "BR0267081U0041",
    "display" : "FENOFIBRATO 200 MG CAP GRUPO 2"
  },
  {
    "code" : "BR0284105U0042",
    "display" : "RISPERIDONA 3 MG COMP GRUPO 1.B"
  },
  {
    "code" : "BR0292239U0136",
    "display" : "MESALAZINA 250 MG SUPOS GRUPO 2"
  },
  {
    "code" : "BR0267897U0041",
    "display" : "RIVASTIGMINA 4,5 MG CAP GRUPO 1.A"
  },
  {
    "code" : "BR0268073U0042",
    "display" : "SELEGILINA 10 MG COMP GRUPO 1.B"
  },
  {
    "code" : "BR0285818U0046",
    "display" : "SIROLIMO 2 MG DRÁGEA GRUPO 1.A"
  },
  {
    "code" : "BR0308729U0042",
    "display" : "BEZAFIBRATO 400 MG COMP DE DESINT LENTA GRUPO 2"
  },
  {
    "code" : "BR0338883U0391",
    "display" : "CALCITONINA 200 UI POR DOSE SPRAY NAS (FR) GRUPO 2"
  },
  {
    "code" : "BR0271620U0042",
    "display" : "OLANZAPINA 5 MG COMP GRUPO 1.A"
  },
  {
    "code" : "BR0268109U0135",
    "display" : "GOSSERRELINA 3,6 MG DEPOT (SER PREENC) GRUPO 1.B"
  },
  {
    "code" : "BR0277319",
    "display" : "PERÓXIDO DE HIDROGÊNIO (ÁGUA OXIGENADA 10VOL) 3 % SOLUÇÃO 1000 ML"
  },
  {
    "code" : "BR0275117",
    "display" : "NITRENDIPINO 20 MG COMPRIMIDO"
  },
  {
    "code" : "BR0268403",
    "display" : "CAPECITABINA 500 MG COMPRIMIDO"
  },
  {
    "code" : "BR0267744",
    "display" : "SINVASTATINA  80 MG COMPRIMIDO"
  },
  {
    "code" : "BR0397912",
    "display" : "AGOMELATINA 25 MG COMPRIMIDO"
  },
  {
    "code" : "BR0292239",
    "display" : "MESALAZINA 250 MG SUPOSITÓRIO  ELENCO ESTADUAL"
  },
  {
    "code" : "BR0275852-2",
    "display" : "PIMECROLIMO 10 MG/G CREME  30 G"
  },
  {
    "code" : "BR0276456",
    "display" : "SILIMARINA + METIONINA 70 + 100 MG DRÁGEA"
  },
  {
    "code" : "BR0273317",
    "display" : "IMATINIBE, MESILATO 100 MG COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0269943U0114",
    "display" : "ÁLCOOL ETÍLICO 70% GEL 800 ML"
  },
  {
    "code" : "BR0276263",
    "display" : "RAMIPRIL + ANLODIPINO, BESILATO 5 + 2,5 MG COMPRIMIDO"
  },
  {
    "code" : "BR0375387-2",
    "display" : "POLIETILENOGLICOL 400 + PROPILENOGLICOL 3 + 4 mg/ml SOLUÇÃO OFTÁLMICA 10 ML"
  },
  {
    "code" : "BR0403359-2",
    "display" : "INSULINA GLULISINA 100 UI/ML SOLUÇÃO INJETÁVEL  10 ML"
  },
  {
    "code" : "BR0292399-2",
    "display" : "FITOMENADIONA 10 MG/ML SOLUÇÃO INJETÁVEL  1 ML IV"
  },
  {
    "code" : "BR0342445-1",
    "display" : "INSULINA NPH + REGULAR 70 % + 30 % 100 UI/ML SOLUÇÃO INJETÁVEL 3 ML"
  },
  {
    "code" : "BR0399412U0041",
    "display" : "MAYTENUS ILICIFOLIA (ESPINHEIRA SANTA) 500 MG MG CÁPSULA"
  },
  {
    "code" : "BR0343608U0118",
    "display" : "ETANERCEPTE  50 MG PÓ LIOF INJ (FR-AMP OU SER PREENC) GRUPO 1.A"
  },
  {
    "code" : "BR0268443U0009",
    "display" : "CODEÍNA 30 MG/ML SOL INJ (AMP) 2 ML GRUPO 2"
  },
  {
    "code" : "BR0292400U0041",
    "display" : "ALFACALCIDOL 0,25 MCG CAP GRUPO 2"
  },
  {
    "code" : "BR0272787U0006",
    "display" : "ALFADORNASE 2,5 MG AMP GRUPO 1.A"
  },
  {
    "code" : "BR0286765E",
    "display" : "BROMOCRIPTINA 5 MG CAP DE LIB RETARD GRUPO 1.B"
  },
  {
    "code" : "BR0271953-1",
    "display" : "DROPERIDOL 2,5 MG/ML SOLUÇÃO INJETÁVEL 1 ML"
  },
  {
    "code" : "BR0276452",
    "display" : "SILIMARINA 70 MG DRÁGEA"
  },
  {
    "code" : "BR0285817",
    "display" : "SIROLIMO 1 MG DRÁGEA ELENCO ESTADUAL"
  },
  {
    "code" : "BR0399065",
    "display" : "TRIEXIFENIDIL, CLORIDRATO 2 MG COMPRIMIDO"
  },
  {
    "code" : "BR0337457-2",
    "display" : "MOMETASONA, FUROATO 50 mcg SUSPENSÃO NASAL 120 DOSES"
  },
  {
    "code" : "BR0371273-4",
    "display" : "CLORETO DE SÓDIO 0,9% ESTÉRIL SOLUÇÃO 500 ML NÃO INJETÁVEL"
  },
  {
    "code" : "BR0268424",
    "display" : "CETOPROFENO 20 MG/ML SOLUÇÃO ORAL 20 ML"
  },
  {
    "code" : "BR0374816",
    "display" : "TESTOSTERONA, CIPIONATO 100 MG/ML SOLUÇÃO INJETÁVEL  2 ML"
  },
  {
    "code" : "BR0320829",
    "display" : "BENAZEPRIL, CLORIDRATO + HIDROCLOROTIAZIDA 10 + 12,5 MG COMPRIMIDO"
  },
  {
    "code" : "BR0298574-5",
    "display" : "BAMBUTEROL, CLORIDRATO 1 MG/ML SOL ORAL (FR) 20 ML"
  },
  {
    "code" : "BR0345866",
    "display" : "LEVODOPA + CARBIDOPA + ENTACAPONA 100 + 25 + 200 MG COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0271644",
    "display" : "OXIMETOLONA 50 mg COMPRIMIDO"
  },
  {
    "code" : "BR0273838",
    "display" : "SIBUTRAMINA, CLORIDRATO 10 MG COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0272689",
    "display" : "NANDROLONA, DECANOATO 25 MG/ML SOLUÇÃO INJETÁVEL 1 ML"
  },
  {
    "code" : "BR0318969",
    "display" : "DIIDROERGOCRISTINA, MESILATO + FLUNARIZINA, DICLORIDRATO 3 + 10 MG COMPRIMIDO"
  },
  {
    "code" : "BR0292764",
    "display" : "PROPRANOLOL, CLORIDRATO + HIDROCLOROTIAZIDA 40 + 12,5 MG COMPRIMIDO"
  },
  {
    "code" : "BR0290058U0135",
    "display" : "ADALIMUMABE 40 MG/ML SOL INJ (SER PREENC) GRUPO 1.A"
  },
  {
    "code" : "BR0272429U0042",
    "display" : "CLOZAPINA 25 MG COMP GRUPO 1.A"
  },
  {
    "code" : "BR0280205E",
    "display" : "ADEFOVIR 10 MG COMP GRUPO 1.A"
  },
  {
    "code" : "BR0272784U0067",
    "display" : "CODEÍNA 3 MG/ML SOL ORAL (FR) 120 ML GRUPO 2"
  },
  {
    "code" : "BR0267499U0042",
    "display" : "COMPLEMENTO ALIMENTAR P/ PACIENTE FENILCETONURICO MENOR DE 1 ANO - FORMULA DE AMINOÁCIDOS ISENTA DE FENILALANINA 1 G PÓ GRUPO 2"
  },
  {
    "code" : "BR0272471E",
    "display" : "DANAZOL 50 MG CAP GRUPO 1.B"
  },
  {
    "code" : "BR0266736U0118",
    "display" : "DESFERROXAMINA 500 MG PÓ LIOF INJ (FR-AMP) GRUPO 1.B"
  },
  {
    "code" : "BR0266767U0118",
    "display" : "ALFAINTERFERONA 2B 3.000.000 UI PÓ LIOF INJ (FR-AMP) GRUPO 1.A"
  },
  {
    "code" : "BR0268074U0081",
    "display" : "DESMOPRESSINA 0,1 MG/ML SOL OU SPRAY NAS (FR) 2,5 ML GRUPO 1.A"
  },
  {
    "code" : "BR0267470U0118",
    "display" : "ALFAPEGINTERFERONA 2A 180 MCG SOL INJ (FR-AMP) GRUPO 1.A"
  },
  {
    "code" : "BR0292249-1E",
    "display" : "METOTREXATO 25 MG/ML SOL INJ (AMP) 20 ML GRUPO 2"
  },
  {
    "code" : "BR0292256E",
    "display" : "MOLGRAMOSTIM 300 MCG PÓ LIOF INJ (FR) GRUPO 1.B"
  },
  {
    "code" : "BR0271394U0110",
    "display" : "MORFINA 10 MG/ML SOL ORAL (FR) 60 ML GRUPO 2"
  },
  {
    "code" : "BR0305725U0005",
    "display" : "OCTREOTIDA 0,1 MG/ML SOL INJ (AMP) GRUPO 1.B"
  },
  {
    "code" : "BR0342981U0118",
    "display" : "OCTREOTIDA LAR 30 MG PÓ P/ SUSP INJ (FR-AMP) GRUPO 1.A"
  },
  {
    "code" : "BR0342980U0118",
    "display" : "OCTREOTIDA LAR 20 MG PÓ P/ SUSP INJ (FR-AMP) GRUPO 1.A"
  },
  {
    "code" : "BR0267077U0042",
    "display" : "BEZAFIBRATO 200 MG DRÁGEA OU COMP GRUPO 2"
  },
  {
    "code" : "BR0268084U0042",
    "display" : "CABERGOLINA 0,5 MG COMP GRUPO 1.A"
  },
  {
    "code" : "BR0271373U0041",
    "display" : "FORMOTEROL 12 MCG CAP INAL GRUPO 2"
  },
  {
    "code" : "BR0437156U0110",
    "display" : "HIPOCLORITO DE SÓDIO 2,0 A 2,5 % SOLUÇÃO 60 ML"
  },
  {
    "code" : "BR0268581U0118",
    "display" : "PAMIDRONATO 60 MG PÓ LIOF INJ (FR-AMP) GRUPO 2"
  },
  {
    "code" : "BR0268152E",
    "display" : "SIROLIMO 1 MG/ML SOL ORAL (FR) 60 ML GRUPO 1.A"
  },
  {
    "code" : "BR0285817U0046",
    "display" : "SIROLIMO 1 MG DRÁGEA GRUPO 1.A"
  },
  {
    "code" : "BR0268098U0041",
    "display" : "TACROLIMO 1 MG CAP GRUPO 1.A"
  },
  {
    "code" : "BR0272847U0042",
    "display" : "TOLCAPONA 100 MG COMP GRUPO 1.B"
  },
  {
    "code" : "BR0272850U0042",
    "display" : "TOPIRAMATO 50 MG COMP GRUPO 2"
  },
  {
    "code" : "BR0272852U0042",
    "display" : "TRIEXIFENIDIL 5 MG COMP GRUPO 1.B"
  },
  {
    "code" : "BR0276388U0041",
    "display" : "GALANTAMINA 8 MG CAP DE LIB PROL GRUPO 1.A"
  },
  {
    "code" : "BR0268108U0135",
    "display" : "GOSSERRELINA 10,8 MG DEPOT (SER PREENC) GRUPO 1.B"
  },
  {
    "code" : "BR0268110U0041",
    "display" : "HIDROXIURÉIA 500 MG CAP GRUPO 1.B"
  },
  {
    "code" : "BR0294881U0005",
    "display" : "ILOPROSTA 10 MCG/ML SOL P/ NEBUL (AMP) 1 ML GRUPO 1.B"
  },
  {
    "code" : "BR0273567U0010",
    "display" : "IMUNOGLOBULINA ANTI-HEPATITE B 600 UI SOL INJ (FR) GRUPO 1.A"
  },
  {
    "code" : "BR0266824U0118",
    "display" : "IMUNOGLOBULINA HUMANA 3 G INJ (FR) GRUPO 1.B"
  },
  {
    "code" : "BR0298734",
    "display" : "CICLOSPORINA 0,5 MG/ML MG/ML SOLUÇÃO OFTÁLMICA 0,4 ML"
  },
  {
    "code" : "BR0285687",
    "display" : "EZETIMIBA + SINVASTATINA 10+10 MG COMPRIMIDO"
  },
  {
    "code" : "BR0360826",
    "display" : "PALIPERIDONA 9 MG COMPRIMIDO DE LIBERAÇÃO PROLONGADA"
  },
  {
    "code" : "BR0282757",
    "display" : "TESTOSTERONA (DECANOATO + FEMPROPIONATO + ISOCAPROATO + PROPIONATO) 100+60+60+30 MG/ML SOLUÇÃO INJETÁVEL  1 ML"
  },
  {
    "code" : "BR0292416U0005",
    "display" : "CALCITRIOL 1 MCG SOL INJ (AMP) GRUPO 2"
  },
  {
    "code" : "BR0271107U0041",
    "display" : "CICLOSPORINA 100 MG CAP GRUPO 2"
  },
  {
    "code" : "BR0271104U0041",
    "display" : "CICLOSPORINA 25 MG CAP GRUPO 2"
  },
  {
    "code" : "BR0271106U0041",
    "display" : "CICLOSPORINA 50 MG CAP GRUPO 2"
  },
  {
    "code" : "BR0272780U0042",
    "display" : "CLOROQUINA 150 MG COMP GRUPO 2"
  },
  {
    "code" : "BR0273258E",
    "display" : "PAMIDRONATO 90 MG PÓ LIOF INJ (FR-AMP) GRUPO 2"
  },
  {
    "code" : "BR0395716U0023",
    "display" : "SCHINUS TEREBENTHIFOLIUS (AROEIRA) 0,67 ML/G CREME  30 G"
  },
  {
    "code" : "BR0269573U0086",
    "display" : "BUPIVACAÍNA, CLORIDRATO 0,25 % SOLUÇÃO INJETÁVEL 20 ML"
  },
  {
    "code" : "BR0276384",
    "display" : "BUDESONIDA 3 MG CÁPSULA DE LIBERAÇÃO CONTROLADA"
  },
  {
    "code" : "BR0392403",
    "display" : "BRIMONIDINA, TARTARATO 0,1 % SOLUÇÃO OFTÁLMICA 5 ML"
  },
  {
    "code" : "BR0368499-2",
    "display" : "VITAMINAS DO COMPLEXO B (B1,B2,B3,B5,B6) SOLUÇÃO ORAL  30 ML"
  },
  {
    "code" : "BR0394316",
    "display" : "BETAINTERFERONA 1B 9.600.000 UI PO LIOFILO PARA INJETÁVEL COM SISTEMA DE APLICAÇÃO"
  },
  {
    "code" : "BR0295393",
    "display" : "MECLIZINA 50 mg COMPRIMIDO"
  },
  {
    "code" : "BR0273314",
    "display" : "CIANOCOBALAMINA 2.500 MCG/ML SOLUÇÃO INJETÁVEL 2 ML"
  },
  {
    "code" : "BR0271604",
    "display" : "METILPREDNISOLONA, ACEPONATO 1 MG/G CREME  15 G"
  },
  {
    "code" : "BR0397674",
    "display" : "CELULOSE NATURAL INERTE 500 MG PÓ 200 DOSES"
  },
  {
    "code" : "281358",
    "display" : "INATIVO- PANAX GINSENG + MULTIVITAMINICOS+ MULTIMINERAIS 29,63 MG CÁPSULA"
  },
  {
    "code" : "BR0399442U0041",
    "display" : "UNCARIA TOMENTOSA (UNHA DE GATO) 100 MG CÁPSULA"
  },
  {
    "code" : "BR0393831",
    "display" : "CICLOBENZAPRINA, CLORIDRATO + LISINA, CLONIXINATO 5 + 125 mg  COMPRIMIDO"
  },
  {
    "code" : "BR0342327",
    "display" : "VARFARINA SÓDICA  7,5 MG COMPRIMIDO"
  },
  {
    "code" : "BR0296743",
    "display" : "OLMESARTANA + HIDROCLOROTIAZIDA 40 + 12,5 MG COMPRIMIDO"
  },
  {
    "code" : "INATIVO XXX",
    "display" : "CODEÍNA INATIVO MG COMP INATIVO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0273387",
    "display" : "IRBESARTANA 150 MG COMPRIMIDO"
  },
  {
    "code" : "BR0272636",
    "display" : "ENFLURANO LIQUIDO INALANTE 100 ML"
  },
  {
    "code" : "BR0271100",
    "display" : "AMOXICILINA + CLAVULANATO DE POTÁSSIO 1 G + 0,2 G SOLUÇÃO INJETÁVEL"
  },
  {
    "code" : "BR0269987",
    "display" : "CLARITROMICINA 25 MG/ML PÓ PARA SUSPENSÃO 60 ML"
  },
  {
    "code" : "BR0272131U0042",
    "display" : "QUININA, SULFATO 500 MG COMPRIMIDO"
  },
  {
    "code" : "BR0394023-3",
    "display" : "VASELINA (PETROLATO, PURO) POMADA 500 G"
  },
  {
    "code" : "BR0268471",
    "display" : "LEVOBUPIVACAINA, CLORIDRATO 0,5 % SOLUÇÃO INJETÁVEL  20 ML"
  },
  {
    "code" : "BR0268236U0033",
    "display" : "CLORETO DE SÓDIO 0,9% SOLUÇÃO INJETÁVEL 1000 ML SISTEMA FECHADO"
  },
  {
    "code" : "BR0390441-2",
    "display" : "ÁCIDO POLIACRÍLICO 3 MG/G OFTALMICO GEL 10 G"
  },
  {
    "code" : "BR0397462-2",
    "display" : "CARBÔMERO + SORBITOL 2+48,5 MG/G GEL OFTÁLMICO 10 G"
  },
  {
    "code" : "BR0272049",
    "display" : "CLORDIAZEPÓXIDO 25 MG  COMPRIMIDO"
  },
  {
    "code" : "INATIVO 22",
    "display" : "INATIVO-CLORETO DE SÓDIO 0,9% SISTEMA FECHADO SOLUÇÃO INJETÁVEL  1000 ML"
  },
  {
    "code" : "BR0298574-1",
    "display" : "BAMBUTEROL, CLORIDRATO 1 MG/ML SOL ORAL (FR) 200 ML"
  },
  {
    "code" : "BR0298574-2",
    "display" : "BAMBUTEROL, CLORIDRATO 1 MG/ML SOL ORAL (FR) 120 ML"
  },
  {
    "code" : "BR0298574-3",
    "display" : "BAMBUTEROL, CLORIDRATO 1 MG/ML SOL ORAL (FR) 100 ML"
  },
  {
    "code" : "BR0298574-4",
    "display" : "BAMBUTEROL, CLORIDRATO 1 MG/ML SOL ORAL (FR) 60 ML"
  },
  {
    "code" : "BR0270779",
    "display" : "ATENOLOL +  NIFEDIPINO 50 + 20 MG COMPRIMIDO"
  },
  {
    "code" : "BR0272220",
    "display" : "FEMPROPOREX, CLORIDRATO 25 MG COMPRIMIDO"
  },
  {
    "code" : "BR0269941U0060",
    "display" : "ÁLCOOL ETÍLICO 70% SOLUÇÃO 1 L"
  },
  {
    "code" : "BR0325837U0042",
    "display" : "DEFERASIROX 500 MG COMP GRUPO 1.A"
  },
  {
    "code" : "BR0266766U0118",
    "display" : "ALFAINTERFERONA 2B 10.000.000 UI PÓ LIOF INJ (FR-AMP) GRUPO 1.A"
  },
  {
    "code" : "BR0268580U0118",
    "display" : "PAMIDRONATO 30 MG PÓ LIOF INJ (FR-AMP) GRUPO 2"
  },
  {
    "code" : "BR0272809U0042",
    "display" : "LAMOTRIGINA 100 MG COMP GRUPO 2"
  },
  {
    "code" : "BR0268114U0042",
    "display" : "LEFLUNOMIDA 20 MG COMP GRUPO 1.A"
  },
  {
    "code" : "BR0305260U0118",
    "display" : "LEUPRORRELINA 11,25 MG PÓ LIOF INJ (SER PREENC) GRUPO 1.B"
  },
  {
    "code" : "BR0268037U0042",
    "display" : "LOVASTATINA 10 MG COMP GRUPO 2"
  },
  {
    "code" : "BR0273893",
    "display" : "BUDESONIDA 0,25 MG/ML SUSPENSÃO PARA NEBULIZAÇÃO 2 ML"
  },
  {
    "code" : "BR0275121",
    "display" : "PIRACETAM 200 MG/ML SOLUÇÃO INJETÁVEL 5 ML"
  },
  {
    "code" : "BR0303292U0037",
    "display" : "RINGER LACTATO SÓDICO SOLUÇÃO INJETÁVEL 250 ML SISTEMA FECHADO"
  },
  {
    "code" : "BR0315089",
    "display" : "ENTECAVIR 1 MG COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0392760",
    "display" : "FLUTICASONA, PROPIONATO 250 MCG AEROSSOL ORAL 60 DOSES"
  },
  {
    "code" : "BR0338883",
    "display" : "CALCITONINA SINTÉTICA DE SALMÃO 200 UI/DOSE SPRAY NASAL 2 ML"
  },
  {
    "code" : "BR0394311",
    "display" : "BETAINTERFERONA 1A 44 MCG SOLUÇÃO INJETÁVEL COM SISTEMA DE APLICAÇÃO"
  },
  {
    "code" : "BR0333569U0017",
    "display" : "TACROLIMO 1 MG/G POMADA 15 G"
  },
  {
    "code" : "BR0352179-1",
    "display" : "BETAMETASONA, VALERATO 1 MG/G CREME  15 G"
  },
  {
    "code" : "BR0271051",
    "display" : "ATROPINA, SULFATO 10 MG/ML SOLUÇÃO OFTÁLMICA 5 ML"
  },
  {
    "code" : "281560",
    "display" : "INATIVO- NEOMICINA + TARTARATO DE BISMUTO E SÓDIO + MENTOL + PROCAÍNA 15 + 25 + 1 + 15 MG/ML SUSPENSÃO ORAL  20 ML"
  },
  {
    "code" : "BR0273474",
    "display" : "MILRINONA 1 MG/ML SOLUÇÃO INJETÁVEL 10 ML"
  },
  {
    "code" : "BR0275124",
    "display" : "PIRACETAM 800 MG COMPRIMIDO"
  },
  {
    "code" : "BR0268970-1",
    "display" : "NITROGLICERINA 5 MG/ML SOLUÇÃO INJETÁVEL 5 ML"
  },
  {
    "code" : "BR0296940",
    "display" : "ESTRADIOL + DIDROGESTERONA 1 + 10 MG COMPRIMIDO"
  },
  {
    "code" : "BR0394023-1",
    "display" : "VASELINA (PETROLATO, PURO) POMADA 30 G"
  },
  {
    "code" : "BR0370525",
    "display" : "VALSARTANA + HIDROCLOROTIAZIDA 160 + 25 MG COMPRIMIDO"
  },
  {
    "code" : "BR0390441-1",
    "display" : "ÁCIDO POLIACRÍLICO 3 MG/G OFTALMICO GEL 5 G"
  },
  {
    "code" : "BR0401321",
    "display" : "AMISSULPRIDA 200 MG COMPRIMIDO"
  },
  {
    "code" : "BR0272089U0029",
    "display" : "SULFADIAZINA DE PRATA 1% CREME  50 G"
  },
  {
    "code" : "BR0272901U0042",
    "display" : "CLOBAZAM 10 MG COMP GRUPO 2"
  },
  {
    "code" : "BR0308738U0042",
    "display" : "CIPROFIBRATO 100 MG COMP GRUPO 2"
  },
  {
    "code" : "BR0272782U0042",
    "display" : "CODEÍNA 30 MG COMP GRUPO 2"
  },
  {
    "code" : "BR0268103U0042",
    "display" : "CODEÍNA 60 MG COMP GRUPO 2"
  },
  {
    "code" : "BR0272833U0042",
    "display" : "QUETIAPINA 200 MG COMP GRUPO 1.A"
  },
  {
    "code" : "BR0268080U0042",
    "display" : "ATORVASTATINA 10 MG COMP GRUPO 2"
  },
  {
    "code" : "BR0272835U0041",
    "display" : "RIBAVIRINA 250 MG CAP GRUPO 1.A"
  },
  {
    "code" : "BR0268083U0042",
    "display" : "AZATIOPRINA 50 MG COMP GRUPO 2"
  },
  {
    "code" : "BR0268149U0042",
    "display" : "RISPERIDONA 2 MG COMP GRUPO 1.B"
  },
  {
    "code" : "BR0267896U0041",
    "display" : "RIVASTIGMINA 1,5 MG CAP GRUPO 1.A"
  },
  {
    "code" : "BR0387341U0041",
    "display" : "FORMOTEROL + BUDESONIDA 6 + 200 MCG CAP INAL GRUPO 2"
  },
  {
    "code" : "BR0272851U0042",
    "display" : "TOPIRAMATO 100 MG COMP GRUPO 2"
  },
  {
    "code" : "BR0393705",
    "display" : "SILIMARINA 140 MG CÁPSULA"
  },
  {
    "code" : "BR0273150",
    "display" : "DEFLAZACORTE 30 MG COMPRIMIDO"
  },
  {
    "code" : "BR0318945",
    "display" : "CITALOPRAM 40 MG  COMPRIMIDO"
  },
  {
    "code" : "BR0274036-2",
    "display" : "PIROXICAM 20 MG CÁPSULA"
  },
  {
    "code" : "BR0268097",
    "display" : "TACROLIMO 5 MG CÁPSULA  ELENCO ESTADUAL"
  },
  {
    "code" : "BR0272827U0042",
    "display" : "PRIMAQUINA DIFOSFATO 5 MG COMPRIMIDO"
  },
  {
    "code" : "BR0354498",
    "display" : "LERCANIDIPINO 20 MG COMPRIMIDO"
  },
  {
    "code" : "BR0268440",
    "display" : "CLARITROMICINA 500 MG  PÓ LIOFILIZADO PARA SOLUÇÃO INJETÁVEL"
  },
  {
    "code" : "BR0269572",
    "display" : "BUPIVACAÍNA, CLORIDRATO ISOBÁRICA 0,5 % SOLUÇÃO INJETÁVEL  4 ML"
  },
  {
    "code" : "BR0271357-1",
    "display" : "ALPRAZOLAM 0,5 MG COMPRIMIDO DE LIBERAÇÃO PROLONGADA"
  },
  {
    "code" : "BR0284465-1",
    "display" : "ALPRAZOLAM 2 MG CÁPSULA DURA DE LIBERAÇÃO PROLONGADA"
  },
  {
    "code" : "BR0398269",
    "display" : "ANFEPRAMONA, CLORIDRATO 75 MG COMPRIMIDO DE LIBERAÇÃO PROLONGADA"
  },
  {
    "code" : "BR0292236U0042",
    "display" : "MESALAZINA 500 MG COMP GRUPO 2"
  },
  {
    "code" : "BR0268119U0042",
    "display" : "HIDROXICLOROQUINA 400 MG COMP GRUPO 2"
  },
  {
    "code" : "BR0268153U0042",
    "display" : "SULFASSALAZINA 500 MG COMP GRUPO 2"
  },
  {
    "code" : "BR0271101U0041",
    "display" : "CALCITRIOL 0,25 MCG CAP GRUPO 2"
  },
  {
    "code" : "BR0268427U0046",
    "display" : "CICLOFOSFAMIDA 50 MG DRÁGEA GRUPO 2"
  },
  {
    "code" : "BR0271105U0041",
    "display" : "CICLOSPORINA 10 MG CAP GRUPO 2"
  },
  {
    "code" : "BR0302942U0105",
    "display" : "CICLOSPORINA 100 MG/ML SOL ORAL (FR) 50 ML GRUPO 2"
  },
  {
    "code" : "BR0272902U0042",
    "display" : "CLOBAZAM 20 MG COMP GRUPO 2"
  },
  {
    "code" : "BR0288640U0042",
    "display" : "MICOFENOLATO DE SÓDIO 180 MG COMP GRUPO 1.A"
  },
  {
    "code" : "BR0271392U0042",
    "display" : "MORFINA 10 MG COMP GRUPO 2"
  },
  {
    "code" : "BR0272853U0042",
    "display" : "VIGABATRINA 500 MG COMP GRUPO 2"
  },
  {
    "code" : "BR0267088U0042",
    "display" : "GENFIBROZILA 600 MG COMP GRUPO 2"
  },
  {
    "code" : "BR0342746U0118",
    "display" : "GLATIRAMER 20 MG PÓ LIOF INJ (FR-AMP OU SER PREENC) GRUPO 1.A"
  },
  {
    "code" : "BR0342319U0041",
    "display" : "ZIPRASIDONA 40 MG CAP GRUPO 1.A"
  },
  {
    "code" : "BR0297775U0041",
    "display" : "PANCREATINA 10.000 UI CAP GRUPO 1.B"
  },
  {
    "code" : "BR0300745U0041",
    "display" : "PANCREATINA 25.000 UI CAP GRUPO 1.B"
  },
  {
    "code" : "BR0266715E",
    "display" : "PANCRELIPASE 12.000 UI CAP GRUPO 1.B"
  },
  {
    "code" : "BR0266714E",
    "display" : "PANCRELIPASE 4.500 UI CAP GRUPO 1.B"
  },
  {
    "code" : "BR0271764U0042",
    "display" : "PIRIDOSTIGMINA 60 MG COMP GRUPO 2"
  },
  {
    "code" : "BR0272824U0042",
    "display" : "PRAMIPEXOL 0,125 MG COMP GRUPO 1.A"
  },
  {
    "code" : "BR0396947",
    "display" : "SULFATO FERROSO   10 MG/ML XAROPE  100 ML"
  },
  {
    "code" : "BR0390440",
    "display" : "EXENATIDA 100 MCG/DOSE SOLUÇÃO INJETÁVEL COM SISTEMA DE APLICAÇÃO"
  },
  {
    "code" : "BR0362720",
    "display" : "BISOPROLOL, FUMARATO 2,5 MG COMPRIMIDO"
  },
  {
    "code" : "BR0291691",
    "display" : "REPAGLINIDA 1 MG COMPRIMIDO"
  },
  {
    "code" : "BR0296749",
    "display" : "PROMESTRIENO 10 MG CÁPSULA VAGINAL"
  },
  {
    "code" : "BR0305257",
    "display" : "LEUPRORRELINA 3,75 MG PÓ LIOFILIZADO PARA SOLUÇÃO INJETÁVEL ELENCO ESTADUAL"
  },
  {
    "code" : "BR0340100",
    "display" : "CETOPROFENO 50 MG/ML SOLUÇÃO INJETÁVEL  2 ML"
  },
  {
    "code" : "BR0368919-2",
    "display" : "ÁCIDO ACÉTICO 5 % SOLUÇÃO 1000 ML"
  },
  {
    "code" : "BR0293981",
    "display" : "MACROGOL + BICARBONATO DE SÓDIO + CLORETO DE SÓDIO E POTÁSSIO 13,1225 G + 0,1755 G + 0,0466 G PÓ 14 G"
  },
  {
    "code" : "BR0309095",
    "display" : "FORMOTEROL + BUDESONIDA 6 + 200 MCG PÓ PARA INALAÇÃO ORAL 60 DOSES ELENCO ESTADUAL"
  },
  {
    "code" : "BR0386026",
    "display" : "ÁCIDO FOLÍNICO (FOLINATO DE CÁLCIO) 0,5 MG/ML SOLUÇÃO ORAL 50 ML"
  },
  {
    "code" : "BR0267730",
    "display" : "NIFEDIPINO 10 MG COMPRIMIDO DE LIBERAÇÃO PROLONGADA"
  },
  {
    "code" : "BR0273166",
    "display" : "NEOMICINA 3,5 MG/G POMADA 10 G"
  },
  {
    "code" : "BR0399409U0041",
    "display" : "RHAMNUS PURSHIANA (CÁSCARA SAGRADA) 150 MG CÁPSULA"
  },
  {
    "code" : "BR0287531",
    "display" : "DESONIDA 0,05 % CREME  30 G"
  },
  {
    "code" : "281470",
    "display" : "INATIVO- EZETIMIBA + SINVASTATINA  20 + 10 MG COMPRIMIDO"
  },
  {
    "code" : "BR0399415",
    "display" : "MELILOTUS OFFICINALIS (TREVO AMARELO) 26,7 MG COMPRIMIDO"
  },
  {
    "code" : "BR0274150",
    "display" : "NIFEDIPINO 30 MG COMPRIMIDO"
  },
  {
    "code" : "BR0320338",
    "display" : "SULBUTIAMINA 200 MG DRÁGEA"
  },
  {
    "code" : "BR0293925",
    "display" : "CLOBUTINOL, CLORIDRATO + DOXILAMINA 4 + 075 MG/ML XAROPE  120 ML"
  },
  {
    "code" : "BR0272585",
    "display" : "ZUCLOPENTIXOL, DECANOATO 200 MG/ML SOLUÇÃO INJETÁVEL  1 ML"
  },
  {
    "code" : "BR0332984",
    "display" : "COALTAR 40 MG/ML XAMPU  120 ML"
  },
  {
    "code" : "BR0272381",
    "display" : "VENLAFAXINA, CLORIDRATO 37,5 MG COMPRIMIDO"
  },
  {
    "code" : "BR0332986",
    "display" : "LEVOFLOXACINO 25 MG/ML SOLUÇÃO INJETÁVEL  20 ML"
  },
  {
    "code" : "BR0393740",
    "display" : "LEVONORGESTREL + ETINILESTRADIOL 0,1 + 0,02 MG COMPRIMIDO"
  },
  {
    "code" : "BR0270093-1",
    "display" : "GLICOSE + CLORETO DE SÓDIO 5 + 0,9 % SOLUÇÃO INJETÁVEL  250 ML"
  },
  {
    "code" : "BR0269943U0103",
    "display" : "ÁLCOOL ETÍLICO 70% GEL 500 ML"
  },
  {
    "code" : "BR0273407",
    "display" : "LETROZOL 2,5 MG CÁPSULA"
  },
  {
    "code" : "BR0400443",
    "display" : "CETRIMIDA + ÓLEOS VEGETAIS 2 MG/G CREME  40 G"
  },
  {
    "code" : "BR0267897",
    "display" : "RIVASTIGMINA, HIDROGENOTARTARATO 4,5 MG CÁPSULA"
  },
  {
    "code" : "BR0377008U0354",
    "display" : "ZANAMIVIR 5 MG PÓ PARA INALAÇÃO ORAL 20 DOSES"
  },
  {
    "code" : "BR0273618U0211",
    "display" : "TECLOZANA 10 MG/ML SUSPENSÃO ORAL  90 ML"
  },
  {
    "code" : "284504",
    "display" : "INATIVO- EPINASTINA, CLORIDRATO 0,05 MG/ML SOLUÇÃO OFTÁLMICA 10 ML"
  },
  {
    "code" : "BR0393730",
    "display" : "OXICODONA, CLORIDRATO 20 MG COMPRIMIDO DE LIBERAÇÃO PROLONGADA ELENCO ESTADUAL"
  },
  {
    "code" : "BR0292044",
    "display" : "SACCHAROMYCES CEREVISIAE 100 MILHÕES/ ML SUSPENSÃO ORAL  5 ML"
  },
  {
    "code" : "BR0340148",
    "display" : "CICLOFOSFAMIDA 1 g PÓ LIOFILIZADO PARA SOLUÇÃO INJETÁVEL ELENCO ESTADUAL"
  },
  {
    "code" : "BR0440862U0086",
    "display" : "ALBENDAZOL 40 MG/ML SUSPENSÃO ORAL  20 ML"
  },
  {
    "code" : "BR0268236U0039",
    "display" : "CLORETO DE SÓDIO 0,9 % SOLUÇÃO INJETÁVEL 500 ML SISTEMA FECHADO"
  },
  {
    "code" : "BR0271359",
    "display" : "CARBONATO DE CÁLCIO + LACTOGLICONATO DE CÁLCIO 500 MG COMPRIMIDO EFERVESCENTE"
  },
  {
    "code" : "BR0363778",
    "display" : "FLUNITRAZEPAM 2 MG COMPRIMIDO"
  },
  {
    "code" : "BR0269943U0060",
    "display" : "ÁLCOOL ETÍLICO 70 GEL 1000 ML"
  },
  {
    "code" : "BR0292237U0042",
    "display" : "MESALAZINA 400 MG COMP GRUPO 2"
  },
  {
    "code" : "BR0272785U0042",
    "display" : "DONEPEZILA 5 MG COMP GRUPO 1.A"
  },
  {
    "code" : "BR0271727U0042",
    "display" : "PRAVASTATINA 40 MG COMP GRUPO 2"
  },
  {
    "code" : "BR0272653U0042",
    "display" : "ENTACAPONA 200 MG COMP GRUPO 1.A"
  },
  {
    "code" : "BR0267472U0118",
    "display" : "ALFAPEGINTERFERONA 2B 80 MCG PÓ LIOF INJ (FR-AMP) GRUPO 1.A"
  },
  {
    "code" : "BR0319128U0042",
    "display" : "PRIMIDONA 100 MG COMP GRUPO 2"
  },
  {
    "code" : "BR0270436U0042",
    "display" : "METOTREXATO 2,5 MG COMP GRUPO 1.A"
  },
  {
    "code" : "BR0292264U0041",
    "display" : "MORFINA 60 MG CAP LIBERAÇÃO CONTROLADA GRUPO 2"
  },
  {
    "code" : "BR0292263U0041",
    "display" : "MORFINA 30 MG CAP LIBERAÇÃO CONTROLADA GRUPO 2"
  },
  {
    "code" : "BR0367664U0075",
    "display" : "NATALIZUMABE 300 MG SOL INJ (FR-AMP) GRUPO 1.A"
  },
  {
    "code" : "BR0305726E",
    "display" : "OCTREOTIDA 0,5 MG/ML SOL INJ (AMP) GRUPO 1.B"
  },
  {
    "code" : "BR0266821U0118",
    "display" : "IMUNOGLOBULINA HUMANA 6 G INJ (FR) GRUPO 1.B"
  },
  {
    "code" : "BR0268345U0042",
    "display" : "LAMIVUDINA 150 MG COMP GRUPO 1.A"
  },
  {
    "code" : "BR0328810U0087",
    "display" : "LAMIVUDINA 10 MG/ML SOL ORAL (FR) 240 ML GRUPO 1.A"
  },
  {
    "code" : "BR0295040U0042",
    "display" : "LAMOTRIGINA 25 MG COMP GRUPO 2"
  },
  {
    "code" : "BR0270612U0391",
    "display" : "BENZILPENICILINA POTÁSSICA 1.200.000 UI SOLUÇÃO INJETÁVEL 2 ML"
  },
  {
    "code" : "BR0270974",
    "display" : "CLORZOXAZONA + PARACETAMOL 200 + 300 MG COMPRIMIDO"
  },
  {
    "code" : "BR0396450U0041",
    "display" : "MAYTENUS ILICIFOLIA (ESPINHEIRA SANTA) 380 MG CÁPSULA"
  },
  {
    "code" : "BR0396702",
    "display" : "NEBIVOLOL 5 MG COMPRIMIDO"
  },
  {
    "code" : "BR0396561",
    "display" : "HIDROMORFONA 16 MG COMPRIMIDO DE LIBERAÇÃO CONTROLADA"
  },
  {
    "code" : "BR0280201",
    "display" : "BORTEZOMIBE 3,5 MG PÓ LIOFILIZADO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0273557",
    "display" : "OXITOCINA 5 ui/ml SOLUÇÃO INJETÁVEL 1 ML"
  },
  {
    "code" : "280003",
    "display" : "INATIVO- BRONFENIRAMINA, MALEATO + FENILEFRINA, CLORIDRATO 2 + 5 MG/5ML XAROPE  120 ML"
  },
  {
    "code" : "BR0276259",
    "display" : "RAMIPRIL 10 MG COMPRIMIDO"
  },
  {
    "code" : "BR0271866-2",
    "display" : "BRINZOLAMIDA 10 MG/ML SOLUÇÃO OFTÁLMICA 10 ML"
  },
  {
    "code" : "BR0338297",
    "display" : "VORICONAZOL 200 MG COMPRIMIDO"
  },
  {
    "code" : "BR0393339U0042",
    "display" : "HARPAGOPHYTUM PROCUBENS (GARRA DO DIABO) 400 MG COMPRIMIDO"
  },
  {
    "code" : "BR0334712",
    "display" : "FULVESTRANTO 50 MG/ML SOLUÇÃO INJETÁVEL  5 ML"
  },
  {
    "code" : "BR0353398-1",
    "display" : "FRAÇÃO FOSFOLIPÍDICA DE PULMÃO PORCINO (SURFACTANTE PULMONAR) 80 MG/ML SUSPENSÃO INJETÁVEL 1,5 ML"
  },
  {
    "code" : "BR0400390",
    "display" : "BUCLIZINA, CLORIDRATO 25 MG COMPRIMIDO"
  },
  {
    "code" : "BR0273619U0042",
    "display" : "TECLOZANA 500 MG COMPRIMIDO"
  },
  {
    "code" : "BR0270092U0034",
    "display" : "GLICOSE 5 % SOLUÇÃO INJETÁVEL 100 ML SISTEMA FECHADO"
  },
  {
    "code" : "BR0363561",
    "display" : "DEXAMETASONA + DIPIRONA + HIDROXOCOBALAMINA 1,5 + 500 + 5 MG/ML SOLUÇÃO INJETÁVEL"
  },
  {
    "code" : "BR0357213",
    "display" : "METOCLOPRAMIDA + DIMETICONA + PEPSINA 7 MG + 40 MG + 50 MG CÁPSULA"
  },
  {
    "code" : "BR0356701",
    "display" : "DESOGESTREL 75 MCG COMPRIMIDO"
  },
  {
    "code" : "BR0352395U0084",
    "display" : "BUDESONIDA 200 MCG PÓ INAL OU AER BUCAL (FR DE 200 DOSES) GRUPO 2"
  },
  {
    "code" : "BR0338888U0005",
    "display" : "CALCITONINA 50 UI SOL INJ (AMP) GRUPO 2"
  },
  {
    "code" : "BR0268825U0042",
    "display" : "TENOFOVIR 300 MG COMP GRUPO 1.A"
  },
  {
    "code" : "BR0305464-2",
    "display" : "FLUOXETINA, CLORIDRATO 10 MG CÁPSULA"
  },
  {
    "code" : "BR0395728-3",
    "display" : "(INATIVO) MIKANIA GLOMERATA (GUACO) (INATIVO) 0,1 ML/ML XAROPE  120 ML"
  },
  {
    "code" : "BR0397434",
    "display" : "FORMOTEROL + BUDESONIDA 12 + 200 MCG CÁPSULA"
  },
  {
    "code" : "BR0277649",
    "display" : "ANAGRELIDA, CLORIDRATO 0,5 MG COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0274187",
    "display" : "ESOMEPRAZOL, MAGNÉSIO 40 MG CÁPSULA"
  },
  {
    "code" : "BR0267082",
    "display" : "FLUVASTATINA 80 MG COMPRIMIDO DE LIBERAÇÃO CONTROLADA"
  },
  {
    "code" : "BR0351444",
    "display" : "RABEPRAZOL SÓDICO 20 MG COMPRIMIDO"
  },
  {
    "code" : "BR0367724",
    "display" : "LEVODOPA + CARBIDOPA + ENTACAPONA 150 + 37,5 + 200 MG COMPRIMIDO"
  },
  {
    "code" : "BR0268494",
    "display" : "DOXAZOSINA, MESILATO 1 MG COMPRIMIDO"
  },
  {
    "code" : "BR0373949",
    "display" : "PINDOLOL 10 MG COMPRIMIDO"
  },
  {
    "code" : "BR0275475-3",
    "display" : "DIPIRONA + PROMETAZINA + ADIFENINA 500 + 5 + 10 MG COMPRIMIDO"
  },
  {
    "code" : "BR0353641",
    "display" : "HILANO GF-20 8 MG/ML SOLUÇÃO INJETÁVEL 2 ML"
  },
  {
    "code" : "BR0396414-4",
    "display" : "PLANTAGO OVATA (PSYLLIUM) PÓ PARA DISPERSÃO ORAL 5,85 G"
  },
  {
    "code" : "BR0272896",
    "display" : "DEXCLORFENIRAMINA, MALEATO + BETAMETASONA, VALERATO 0,4 + 0,05 MG/ML XAROPE  120 ML"
  },
  {
    "code" : "BR0389637-2",
    "display" : "FEXOFENADINA, CLORIDRATO 6 MG/ML SUSPENSÃO ORAL  150 ML"
  },
  {
    "code" : "BR0399636U0041",
    "display" : "RHAMNUS PURSHIANA (CÁSCARA SAGRADA) 75 MG CÁPSULA"
  },
  {
    "code" : "BR0309062",
    "display" : "AESCULUS HIPPOCASTANUM L. (CASTANHA DA ÍNDIA) 100 MG CÁPSULA"
  },
  {
    "code" : "BR0270423",
    "display" : "MERCAPTOPURINA 50 MG COMPRIMIDO"
  },
  {
    "code" : "BR0274922",
    "display" : "CODERGOCRINA, MESILATO 1 MG  CÁPSULA"
  },
  {
    "code" : "BR0275119",
    "display" : "PREDNISOLONA 20 MG COMPRIMIDO"
  },
  {
    "code" : "BR0266665U0005",
    "display" : "ARTEMETER 80 MG/ML SOLUÇÃO INJETÁVEL 1  ML"
  },
  {
    "code" : "BR0400471",
    "display" : "LISADO BACTERIANO 7 MG CÁPSULA"
  },
  {
    "code" : "BR0274704",
    "display" : "IMATINIBE, MESILATO 400 MG COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0400927",
    "display" : "DIOSMINA + HESPERIDINA 900 + 100 mg GRANULADO 5 G"
  },
  {
    "code" : "BR0271600",
    "display" : "METILPREDNISOLONA, SUCCINATO 125 MG PÓ LIOFILIZADO PARA SOLUÇÃO INJETÁVEL"
  },
  {
    "code" : "BR0397462-1",
    "display" : "CARBÔMERO + SORBITOL 2+48,5 MG/G GEL OFTÁLMICO 5 G"
  },
  {
    "code" : "BR0369176U0042",
    "display" : "EVEROLIMO 0,5 MG COMP GRUPO 1.A"
  },
  {
    "code" : "BR0296717U0042",
    "display" : "RISEDRONATO 35 MG COMP GRUPO 2"
  },
  {
    "code" : "BR0272839U0042",
    "display" : "RISPERIDONA 1 MG COMP GRUPO 1.B"
  },
  {
    "code" : "BR0267894U0041",
    "display" : "RIVASTIGMINA 3 MG CAP GRUPO 1.A"
  },
  {
    "code" : "BR0352414U0136",
    "display" : "MESALAZINA 500 MG SUPOS GRUPO 2"
  },
  {
    "code" : "BR0267083U0041",
    "display" : "FLUVASTATINA 20 MG CAP GRUPO 2"
  },
  {
    "code" : "BR0268072U0042",
    "display" : "SELEGILINA 5 MG COMP GRUPO 1.B"
  },
  {
    "code" : "BR0292249U0391",
    "display" : "METOTREXATO 25 MG/ML SOL INJ (AMP) 2 ML GRUPO 1.A"
  },
  {
    "code" : "BR0352394U0041",
    "display" : "BUDESONIDA 400 MCG CAP INAL GRUPO 2"
  },
  {
    "code" : "BR0266700U0061",
    "display" : "BUDESONIDA 200 MCG PÓ INAL OU AER BUCAL (FR DE 100 DOSES) GRUPO 2"
  },
  {
    "code" : "BR0315735U0041",
    "display" : "GALANTAMINA 16 MG CAP DE LIB PROL GRUPO 1.A"
  },
  {
    "code" : "BR0315734U0041",
    "display" : "GALANTAMINA 24 MG CAP DE LIB PROL GRUPO 1.A"
  },
  {
    "code" : "BR0266752U0118",
    "display" : "IMIGLUCERASE 200 U PÓ LIOF INJ (FR-AMP) GRUPO 1.A"
  },
  {
    "code" : "BR0266822U0118",
    "display" : "IMUNOGLOBULINA HUMANA 2,5 G INJ (FR) GRUPO 1.B"
  },
  {
    "code" : "BR0333447U0118",
    "display" : "INFLIXIMABE 10 MG/ML PÓ LIOF INJ (FR-AMP) 10 ML GRUPO 1.A"
  },
  {
    "code" : "BR0272808U0041",
    "display" : "ISOTRETINOÍNA 20 MG CAP GRUPO 2"
  },
  {
    "code" : "BR0274226",
    "display" : "FEMPROCUMONA 3 MG COMPRIMIDO"
  },
  {
    "code" : "BR0397438",
    "display" : "GLIMEPIRIDA  6 MG COMPRIMIDO"
  },
  {
    "code" : "BR0312569",
    "display" : "ERLOTINIBE 150 mg COMPRIMIDO"
  },
  {
    "code" : "BR0395716U0015",
    "display" : "SCHINUS TEREBENTHIFOLIUS (AROEIRA) 0,67 ML/G CREME  10 G"
  },
  {
    "code" : "BR0299236-2",
    "display" : "DEXPANTENOL 50 MG/G POMADA 30 G"
  },
  {
    "code" : "BR0268098",
    "display" : "TACROLIMO 1 MG CÁPSULA  ELENCO ESTADUAL"
  },
  {
    "code" : "BR0272653",
    "display" : "ENTACAPONA 200 MG COMPRIMIDO"
  },
  {
    "code" : "BR0295302",
    "display" : "TRASTUZUMABE 440 MG PÓ LIOFILIZADO PARA SOLUÇÃO INJETÁVEL ELENCO ESTADUAL"
  },
  {
    "code" : "BR0335091",
    "display" : "ACETILCISTEÍNA 100 MG/ML  SOLUÇÃO INJETÁVEL 3 ML ELENCO ESTADUAL"
  },
  {
    "code" : "BR0272328",
    "display" : "OXIBUTININA, CLORIDRATO 1 MG/ML XAROPE  120 ML ELENCO ESTADUAL"
  },
  {
    "code" : "BR0271064",
    "display" : "HIDRÓXIDO DE ALUMÍNIO + HIDRÓXIDO DE MAGNÉSIO + DIMETICONA 40 + 30 + 5 MG/ML SUSPENSÃO ORAL  200 ML"
  },
  {
    "code" : "BR0291549",
    "display" : "ATORVASTATINA CÁLCICA 80 MG COMPRIMIDO"
  },
  {
    "code" : "BR0305450",
    "display" : "CITRATO DE POTÁSSIO 1080 MG  COMPRIMIDO DE LIBERAÇÃO PROLONGADA"
  },
  {
    "code" : "BR0270834",
    "display" : "ESTRADIOL 1 MG PÓ"
  },
  {
    "code" : "BR0371273-1",
    "display" : "CLORETO DE SÓDIO 0,9% SOLUÇÃO 100 ML NÃO INJETÁVEL"
  },
  {
    "code" : "282061",
    "display" : "INATIVO- HIDRÓXIDO DE ALUMÍNIO + HIDRÓXIDO DE MAGNÉSIO + METILCELULOSE 40 + 30 + 10 MG/ML SUSPENSÃO ORAL  200 ML"
  },
  {
    "code" : "BR0357657U0042",
    "display" : "ETRAVIRINA 100 MG COMPRIMIDO"
  },
  {
    "code" : "BR0400480",
    "display" : "ESTRADIOL + DROSPIRENONA 1 + 2 MG COMPRIMIDO"
  },
  {
    "code" : "BR0305429",
    "display" : "CARBOXIMETILCELULOSE SÓDICA 10 MG/ML SOLUÇÃO OFTÁLMICA 15 ML"
  },
  {
    "code" : "BR0292418-2",
    "display" : "CIPROFLOXACINO, CLORIDRATO 2 MG/ML SOLUÇÃO INJETÁVEL 200 ML"
  },
  {
    "code" : "BR0400921",
    "display" : "BENZALCÔNIO, CLORETO + CETRIMÔNIO, BROMETO 0,2 + 2 MG CREME  40 G"
  },
  {
    "code" : "BR0268862",
    "display" : "FOSINOPRIL 10 MG COMPRIMIDO"
  },
  {
    "code" : "BR0388399",
    "display" : "OLMESARTANA + ANLODIPINO 20 + 5 MG COMPRIMIDO"
  },
  {
    "code" : "BR0270092U0037",
    "display" : "GLICOSE 5 % SOLUÇÃO INJETÁVEL 250 ML SISTEMA FECHADO"
  },
  {
    "code" : "BR0270092U0039",
    "display" : "GLICOSE 5 % SOLUÇÃO INJETÁVEL 500 ML SISTEMA FECHADO"
  },
  {
    "code" : "BR0383272U0118",
    "display" : "IMIGLUCERASE 400 U PÓ LIOF INJ (FR-AMP) GRUPO 1.A"
  },
  {
    "code" : "BR0394103",
    "display" : "RIVAROXABANA 10 MG COMPRIMIDO"
  },
  {
    "code" : "BR0350613",
    "display" : "IMIQUIMODE 50 MG/G CREME  0,25 G"
  },
  {
    "code" : "BR0272832U0042",
    "display" : "QUETIAPINA 100 MG COMP GRUPO 1.A"
  },
  {
    "code" : "BR0291549U0042",
    "display" : "ATORVASTATINA 80 MG COMP GRUPO 2"
  },
  {
    "code" : "BR0272834U0042",
    "display" : "RALOXIFENO 60 MG COMP GRUPO 2"
  },
  {
    "code" : "BR0272838U0042",
    "display" : "RILUZOL 50 MG COMP GRUPO 1.A"
  },
  {
    "code" : "BR0296715U0042",
    "display" : "RISEDRONATO 5 MG COMP GRUPO 2"
  },
  {
    "code" : "BR0266750U0067",
    "display" : "RIVASTIGMINA 2 MG/ML SOL ORAL (FR) 120 ML GRUPO 1.B"
  },
  {
    "code" : "BR0267084U0041",
    "display" : "FLUVASTATINA 40 MG CAP GRUPO 2"
  },
  {
    "code" : "BR0268093U0042",
    "display" : "METADONA 10 MG COMP GRUPO 2"
  },
  {
    "code" : "BR0267907E",
    "display" : "BECLOMETASONA 400 MCG CAP INAL GRUPO 2"
  },
  {
    "code" : "BR0267590E",
    "display" : "BECLOMETASONA 250 MCG SPRAY (FR DE 200 DOSES) GRUPO 2"
  },
  {
    "code" : "BR0266963U0118",
    "display" : "SOMATROPINA 12 UI SOL INJ OU PÓ LIOF INJ (FR-AMP) GRUPO 1.B"
  },
  {
    "code" : "BR0266962U0118",
    "display" : "SOMATROPINA 4 UI SOL INJ OU PÓ LIOF INJ (FR-AMP) GRUPO 1.A"
  },
  {
    "code" : "BR0291692",
    "display" : "REPAGLINIDA 2 MG COMPRIMIDO"
  },
  {
    "code" : "BR0274567",
    "display" : "VITAMINAS DO COMPLEXO B (B1, B6, B12) SOLUÇÃO INJETÁVEL  3 ML"
  },
  {
    "code" : "BR0269073",
    "display" : "ÁCIDO TRICLOROACÉTICO 80 % SOLUÇÃO 5 ML"
  },
  {
    "code" : "BR0381880",
    "display" : "OMEPRAZOL MAGNÉSIO 20,6 mg COMPRIMIDO"
  },
  {
    "code" : "BR0285015",
    "display" : "TRAMADOL, CLORIDRATO + PARACETAMOL 37,5 + 325 MG COMPRIMIDO"
  },
  {
    "code" : "BR0292790",
    "display" : "VALSARTANA + HIDROCLOROTIAZIDA 80 + 12,5  MG COMPRIMIDO"
  },
  {
    "code" : "BR0272330",
    "display" : "PIPERIDOLATO, CLORIDRATO + HESPERIDINA + ÁCIDO ASCÓRBICO 100 MG + 50 MG + 50 MG DRÁGEA"
  },
  {
    "code" : "BR0280876",
    "display" : "ESPIRONOLACTONA + HIDROCLOROTIAZIDA 50 + 50 MG COMPRIMIDO"
  },
  {
    "code" : "BR0273412U0042",
    "display" : "LINEZOLIDA 600 MG COMPRIMIDO"
  },
  {
    "code" : "BR0370119U0042",
    "display" : "ARTESUNATO + MEFLOQUINA 25 + 55 MG COMPRIMIDO"
  },
  {
    "code" : "BR0272828U0042",
    "display" : "PRIMAQUINA DIFOSFATO 15 MG COMPRIMIDO"
  },
  {
    "code" : "BR0353398-2",
    "display" : "FRAÇÃO FOSFOLIPÍDICA DE PULMÃO PORCINO (SURFACTANTE PULMONAR) 80 MG/ML SUSPENSÃO PARA INSTILAÇÃO 3 ML"
  },
  {
    "code" : "BR0299692",
    "display" : "AMOROLFINA, CLORIDRATO 50 MG/ML ESMALTE 2,5 ML"
  },
  {
    "code" : "BR0272489U0042",
    "display" : "DIETILCARBAMAZINA, CITRATO 50 MG COMPRIMIDO"
  },
  {
    "code" : "BR0296302",
    "display" : "PAROXETINA, CLORIDRATO 25 MG COMPRIMIDO DE LIBERAÇÃO PROLONGADA"
  },
  {
    "code" : "BR03426",
    "display" : "INATIVO 11,25 MG SUSP INJ (FR-AMP) GRUPO 1.B"
  },
  {
    "code" : "BR0271950-2",
    "display" : "FENTANILA, CITRATO 0,05 MG/ML SOLUÇÃO INJETÁVEL  5 ML"
  },
  {
    "code" : "BR0292419U0009",
    "display" : "CLINDAMICINA, FOSFATO 150 MG/ML SOLUÇÃO INJETÁVEL 2 ML"
  },
  {
    "code" : "BR0268163U0042",
    "display" : "MINOCICLINA, CLORIDRATO 100 MG COMPRIMIDO"
  },
  {
    "code" : "BR0270773-2",
    "display" : "ISOCONAZOL, NITRATO 10 MG/G CREME VAGINAL  40 G"
  },
  {
    "code" : "BR0330113-1",
    "display" : "GANCICLOVIR SÓDICO 1 MG/ML SOLUÇÃO INJETÁVEL 250 ML ELENCO ESTADUAL"
  },
  {
    "code" : "BR0279338-1",
    "display" : "ÁCIDO POLIACRÍLICO 2 MG/G OFTALMICO GEL 5 G"
  },
  {
    "code" : "BR0326057",
    "display" : "FERRO QUELATO GLICINATO 300 MG COMPRIMIDO"
  },
  {
    "code" : "BR0267271U0042",
    "display" : "HIDRÓXIDO DE ALUMÍNIO 300 MG COMP GRUPO 2"
  },
  {
    "code" : "BR0266825U0118",
    "display" : "IMUNOGLOBULINA HUMANA 0,5 G INJ (FR) GRUPO 1.B"
  },
  {
    "code" : "BR0266823U0118",
    "display" : "IMUNOGLOBULINA HUMANA 1 G INJ (FR) GRUPO 1.B"
  },
  {
    "code" : "BR0273944",
    "display" : "PERINDOPRIL 4 MG COMPRIMIDO"
  },
  {
    "code" : "BR0282151",
    "display" : "EXEMESTANO 25 MG DRÁGEA"
  },
  {
    "code" : "BR0393808",
    "display" : "VALSARTANA + ANLODIPINO, BESILATO 160 + 10 MG COMPRIMIDO"
  },
  {
    "code" : "BR0319763",
    "display" : "BRONFENIRAMINA, MALEATO + FENILEFRINA, CLORIDRATO 0,4 + 1 MG/ML XAROPE  120 ML"
  },
  {
    "code" : "BR0333568",
    "display" : "TACROLIMO 3 MG/G CREME  10 G"
  },
  {
    "code" : "BR0398578",
    "display" : "PLANTAGO OVATA + SENNA ALEXANDRINA GRANULADO 250 G"
  },
  {
    "code" : "BR0318993",
    "display" : "TRIFLUSAL 300 MG CÁPSULA"
  },
  {
    "code" : "BR0269852U0013",
    "display" : "LIDOCAÍNA, CLORIDRATO + EPINEFRINA 20 MG/ML + 1:200.000 UI SOLUÇÃO INJETÁVEL 5 ML"
  },
  {
    "code" : "BR0309097",
    "display" : "FORMOTEROL + BUDESONIDA 6 + 100 MCG/DOSE PÓ PARA INALAÇÃO ORAL 120 DOSES"
  },
  {
    "code" : "BR0343608",
    "display" : "ETANERCEPTE  50 MG PÓ PARA SOLUÇÃO INJETÁVEL ELENCO ESTADUAL"
  },
  {
    "code" : "BR0371273-2",
    "display" : "CLORETO DE SÓDIO 0,9% SOLUÇÃO 125 ML NÃO INJETÁVEL"
  },
  {
    "code" : "BR0308883",
    "display" : "SULFAMETOXAZOL + TRIMETOPRIMA  800 + 160 MG COMPRIMIDO"
  },
  {
    "code" : "BR0328535-1",
    "display" : "ÁCIDO VALPRÓICO (VALPROATO DE SÓDIO)  200 MG/ML GOTAS SOLUÇÃO ORAL 40 ML"
  },
  {
    "code" : "BR0362259",
    "display" : "TRAZODONA, CLORIDRATO 100 MG COMPRIMIDO"
  },
  {
    "code" : "BR0338411",
    "display" : "ÁCIDO ZOLEDRÔNICO 4 MG PÓ LIOFILIZADO PARA SOLUÇÃO INJETÁVEL 5 ML"
  },
  {
    "code" : "BR0270813U0009",
    "display" : "CIANOCOBALAMINA + TIAMINA + PIRIDOXINA 5 MG + 100 MG + 100 MG SOLUÇÃO INJETÁVEL 2 ML"
  },
  {
    "code" : "BR0270878",
    "display" : "ANLODIPINO, BESILATO + ENALAPRIL, MALEATO 5 MG + 10 MG CÁPSULA"
  },
  {
    "code" : "BR0319883",
    "display" : "SILDENAFILA, CITRATO 20 MG COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0271006",
    "display" : "DICLOFENACO SÓDICO 1 MG/ML SOLUÇÃO OFTÁLMICA 5 ML"
  },
  {
    "code" : "BR0299656",
    "display" : "LIDOCAÍNA, CLORIDRATO + CLORETO DE BENZALCÔNIO 20 + 1,3 MG/ML SPRAY TÓPICO 50 ML"
  },
  {
    "code" : "BR0269470",
    "display" : "ROPIVACAÍNA, CLORIDRATO 7,5 % SOLUÇÃO INJETÁVEL  20 ML"
  },
  {
    "code" : "BR0271608",
    "display" : "NORTRIPTILINA, CLORIDRATO 2 MG/ML SOLUÇÃO ORAL 100 ML"
  },
  {
    "code" : "BR0315089U0042",
    "display" : "ENTECAVIR 1 MG COMP GRUPO 1.A"
  },
  {
    "code" : "INATIVO 21",
    "display" : "INATIVO-CLORETO DE SÓDIO 0,9% SISTEMA FECHADO SOLUÇÃO INJETÁVEL  250 ML"
  },
  {
    "code" : "BR0292373U0118",
    "display" : "TOXINA BOTULINICA TIPO A 500 U PÓ LIOF INJ (FR-AMP) GRUPO 1.A"
  },
  {
    "code" : "BR0270986",
    "display" : "CLORFENAMINA + PARACETAMOL + FENILEFRINA 4 + 400 + 4 MG  COMPRIMIDO"
  },
  {
    "code" : "BR0341829",
    "display" : "ZOPICLONA 7,5 MG COMPRIMIDO"
  },
  {
    "code" : "BR0272178",
    "display" : "CLOBUTINOL, CLORIDRATO 4 MG/ML  XAROPE  120 ML"
  },
  {
    "code" : "BR0284459",
    "display" : "CLOBETASOL, PROPIONATO 0,05 MG/G POMADA 30 G"
  },
  {
    "code" : "BR0276839U0090",
    "display" : "ÁGUA DESTILADA SOLUÇÃO INJETÁVEL 250 ML"
  },
  {
    "code" : "BR0398382",
    "display" : "CICLESONIDA 50 MCG/DOSE SUSPENSÃO NASAL 120 DOSES"
  },
  {
    "code" : "BR0270990",
    "display" : "COLESTIRAMINA 4 G PÓ"
  },
  {
    "code" : "BR0271050",
    "display" : "ATROPINA, SULFATO 5 MG/ML SOLUÇÃO OFTÁLMICA 5 ML"
  },
  {
    "code" : "BR0312388",
    "display" : "PERMETRINA 10 mg/ml XAMPU"
  },
  {
    "code" : "BR0281453U0062",
    "display" : "RHAMNUS PURSHIANA (CÁSCARA SAGRADA) 10 MG/ML TINTURA 100 ML"
  },
  {
    "code" : "BR0429303U0062",
    "display" : "CYNARA SCOLYMUS (ALCACHOFRA) 1,5 MG/ML TINTURA 100 ML"
  },
  {
    "code" : "BR0297775",
    "display" : "PANCREATINA 10.000 UI CÁPSULA  ELENCO ESTADUAL"
  },
  {
    "code" : "BR0315735",
    "display" : "GALANTAMINA, BROMIDRATO 16 MG COMPRIMIDO DE LIBERAÇÃO CONTROLADA"
  },
  {
    "code" : "BR0271109",
    "display" : "LEVONORGESTREL + ETINILESTRADIOL 0,05 + 0,25 MCG COMPRIMIDO"
  },
  {
    "code" : "BR0275852-1",
    "display" : "PIMECROLIMO 10 MG/G CREME  15 G"
  },
  {
    "code" : "BR0270556",
    "display" : "AMPICILINA + SULBACTAM 1 G + 500 MG PÓ PARA SOLUÇÃO INJETÁVEL"
  },
  {
    "code" : "BR0278338U0042",
    "display" : "ÁCIDO TRANEXÂMICO 250 MG COMPRIMIDO"
  },
  {
    "code" : "BR0333446U0118",
    "display" : "PALIVIZUMABE 100 MG PÓ LIOF INJ (FR-AMP) 1 ML"
  },
  {
    "code" : "BR0269759",
    "display" : "GENTAMICINA, SULFATO 80 MG/ML SOLUÇÃO INJETÁVEL  2 ML ELENCO ESTADUAL"
  },
  {
    "code" : "BR0268337U0041",
    "display" : "EFAVIRENZ 200 MG CÁPSULA"
  },
  {
    "code" : "BR0374155U0042",
    "display" : "ISONIAZIDA + RIFAMPICINA 75 + 150 MG COMPRIMIDO"
  },
  {
    "code" : "BR0274467-1",
    "display" : "HIALURONATO DE SÓDIO 1 % SOLUÇÃO INJETÁVEL  2 ML ELENCO ESTADUAL"
  },
  {
    "code" : "BR0341064",
    "display" : "PODOFILOTOXINA 1,5 MG/G CREME  5 G"
  },
  {
    "code" : "BR0395845",
    "display" : "URÉIA 50 MG/G CREME  50 G"
  },
  {
    "code" : "BR0368919-1",
    "display" : "ÁCIDO ACÉTICO 5 % SOLUÇÃO 500 ML"
  },
  {
    "code" : "BR0269069U0086",
    "display" : "ÁCIDO TRICLOROACÉTICO 90 % SOLUÇÃO 20 ML"
  },
  {
    "code" : "BR0328205",
    "display" : "CODERGOCRINA, MESILATO 1 MG/ML SOLUÇÃO ORAL 30 ML"
  },
  {
    "code" : "BR0266716E",
    "display" : "PANCRELIPASE 18.000 UI CAP GRUPO 1.B"
  },
  {
    "code" : "BR0272815U0041",
    "display" : "PENICILAMINA 250 MG CAP GRUPO 1.B"
  },
  {
    "code" : "BR0272825U0042",
    "display" : "PRAMIPEXOL 0,25 MG COMP GRUPO 1.A"
  },
  {
    "code" : "BR0284426",
    "display" : "TELMISARTANA + HIDROCLOROTIAZIDA 40 + 12,5 MG COMPRIMIDO"
  },
  {
    "code" : "BR0388712",
    "display" : "PREGABALINA 75 MG CÁPSULA"
  },
  {
    "code" : "BR0397566",
    "display" : "CEFALEXINA 100 MG/ML PÓ PARA SUSPENSÃO 15 ML"
  },
  {
    "code" : "BR0273626",
    "display" : "FENOBARBITAL  50 MG COMPRIMIDO"
  },
  {
    "code" : "BR0268953U0042",
    "display" : "BENZNIDAZOL 100 MG COMPRIMIDO"
  },
  {
    "code" : "BR0392114",
    "display" : "RISPERIDONA 0,5 MG COMPRIMIDO"
  },
  {
    "code" : "BR0272972U0110",
    "display" : "FENOXIMETILPENICILINA POTÁSSICA 80.000 UI/ML PÓ PARA SOLUÇÃO 60 ML ELENCO ESTADUAL"
  },
  {
    "code" : "BR0341109",
    "display" : "CODERGOCRINA, MESILATO 0,3 MG/ML SOLUÇÃO INJETÁVEL 1 ML"
  },
  {
    "code" : "BR0272005",
    "display" : "CITICOLINA 500 MG  COMPRIMIDO"
  },
  {
    "code" : "INATIVO 29",
    "display" : "INATIVO-BETAINTERFERONA 1A 6.000.000 UI PÓ LIOFILIZADO"
  },
  {
    "code" : "BR0341882",
    "display" : "CIANOCOBALAMINA 500 MCG/ML SOLUÇÃO INJETÁVEL 2 ML"
  },
  {
    "code" : "BR0399441U0233",
    "display" : "UNCARIA TOMENTOSA (UNHA DE GATO) 50 MG/G GEL 5 G"
  },
  {
    "code" : "BR0292770",
    "display" : "EXTRATO DE ÓLEO INSAPONIFICÁVEL DE ABACATE (GLYCINE MAX) E SOJA (PERSEA GRATISSIMA) 100 + 200 MG CÁPSULA"
  },
  {
    "code" : "BR0370120U0042",
    "display" : "ARTESUNATO + MEFLOQUINA 100 + 220 MG COMPRIMIDO"
  },
  {
    "code" : "BR0328513U0118",
    "display" : "ARTESUNATO DE SÓDIO 60 MG PÓ PARA SOLUÇÃO INJETÁVEL"
  },
  {
    "code" : "BR0380545U0042",
    "display" : "LOPINAVIR + RITONAVIR 100 + 25 MG COMPRIMIDO"
  },
  {
    "code" : "BR0383791",
    "display" : "ALENDRONATO DE SÓDIO + COLECALCIFEROL 70 MG + 2.800 UI COMPRIMIDO"
  },
  {
    "code" : "BR0340764",
    "display" : "BETAMETASONA, DIPROPIONATO + GENTAMICINA SULFATO 1 + 3 MG/ML SOLUÇÃO OTO-OFTÁLMICA 10 ML"
  },
  {
    "code" : "BR0350587U0183",
    "display" : "LOPINAVIR + RITONAVIR 80 + 20 MG/ML SOLUÇÃO ORAL 160 ML"
  },
  {
    "code" : "BR0269622",
    "display" : "INATIVO- GLICEROL 120 MG/ML ENEMA  500 ML"
  },
  {
    "code" : "BR0268270",
    "display" : "MONOSSULFIRAM 250 MG/ML SOLUÇÃO TÓPICA 100 ML"
  },
  {
    "code" : "BR0402625",
    "display" : "MINOCICLINA, CLORIDRATO 100 MG CÁPSULA"
  },
  {
    "code" : "BR0308877-1",
    "display" : "SEVOFLURANO 1 MG/ML SOLUÇÃO PARA INALAÇÃO 100 ML"
  },
  {
    "code" : "INATIVO 20",
    "display" : "INATIVO-CLORETO DE SÓDIO 0,9% SISTEMA FECHADO SOLUÇÃO INJETÁVEL  500  ML"
  },
  {
    "code" : "BR0299693",
    "display" : "AMOROLFINA, CLORIDRATO 2,5 MG/G CREME  20 G"
  },
  {
    "code" : "BR0393139",
    "display" : "EVEROLIMO 10 MG COMPRIMIDO"
  },
  {
    "code" : "BR0404075",
    "display" : "CÁLCIO AMINOÁCIDO QUELATO 250 MG PÓ 3,5 G"
  },
  {
    "code" : "BR0345001U0041",
    "display" : "MIGLUSTATE 100 MG CAP GRUPO 1.A"
  },
  {
    "code" : "BR0403473",
    "display" : "RETINOL, PALMITATO 10 MG/G GEL OFTÁLMICO 10 G"
  },
  {
    "code" : "BR0394678U0118",
    "display" : "ALFAVELAGLICERASE 400 U PÓ LIOF INJ (FR-AMP) GRUPO 1.A"
  },
  {
    "code" : "BR0268509",
    "display" : "FLUDARABINA, FOSFATO 50 MG SOLUÇÃO INJETÁVEL"
  },
  {
    "code" : "BR0273194",
    "display" : "TEMOZOLOMIDA 20 MG CÁPSULA"
  },
  {
    "code" : "BR0387628",
    "display" : "ASPARTATO, L-ARGININA 250 MG COMPRIMIDO"
  },
  {
    "code" : "BR0269574-1",
    "display" : "BUPIVACAÍNA, CLORIDRATO 0,5 % SOLUÇÃO INJETÁVEL 4 ML"
  },
  {
    "code" : "BR0394677U0118",
    "display" : "ALFAVELAGLICERASE 200 U PÓ LIOF INJ (FR-AMP) GRUPO 1.A"
  },
  {
    "code" : "BR0270445",
    "display" : "CLORAMBUCILA 2 MG  COMPRIMIDO"
  },
  {
    "code" : "BR0291559",
    "display" : "PIRACETAM + DIIDROERGOCRISTINA MESILATO 1 + 400 mg COMPRIMIDO"
  },
  {
    "code" : "BR0404405",
    "display" : "PASSIFLORA INCARNATA 360 MG COMPRIMIDO"
  },
  {
    "code" : "BR0404425-1",
    "display" : "BENZOCAÍNA + TRICLOSANA + MENTOL (45+5+5) MG/G CREME  20 G"
  },
  {
    "code" : "BR0404425-2",
    "display" : "BENZOCAÍNA + TRICLOSANA + MENTOL (45+5+5) MG/G CREME  30 G"
  },
  {
    "code" : "BR0404421U0017",
    "display" : "STRYPHNODENDRON BARBATIMAN MART. 60 MG/G POMADA 15 G"
  },
  {
    "code" : "BR0404406",
    "display" : "SILYBUM MARIANUM (L.) GAERTN 100 MG COMPRIMIDO"
  },
  {
    "code" : "BR0397475",
    "display" : "DIGOXINA, BETAMETILDIGOXINA 0,1 MG COMPRIMIDO"
  },
  {
    "code" : "BR0288300-1",
    "display" : "MOXIFLOXACINO, CLORIDRATO 5 MG/ML SOLUÇÃO OFTÁLMICA 3 ML"
  },
  {
    "code" : "BR0288300-2",
    "display" : "MOXIFLOXACINO, CLORIDRATO 5 MG/ML SOLUÇÃO OFTÁLMICA 5 ML"
  },
  {
    "code" : "BR0396668",
    "display" : "CODERGOCRINA, MESILATO 6 MG  CÁPSULA DURA DE LIBERAÇÃO PROLONGADA"
  },
  {
    "code" : "BR0394023-4",
    "display" : "VASELINA (PETROLATO, PURO) POMADA 80 G"
  },
  {
    "code" : "BR0390008-1",
    "display" : "CETUXIMABE 5 MG/ML SOLUÇÃO INJETÁVEL 10 ML"
  },
  {
    "code" : "BR0340202-1",
    "display" : "CLADRIBINA 1 MG/ML SOLUÇÃO INJETÁVEL 5 ML"
  },
  {
    "code" : "BR0340202-2",
    "display" : "CLADRIBINA 1 MG/ML SOLUÇÃO INJETÁVEL 10 ML"
  },
  {
    "code" : "BR0382939",
    "display" : "DECITABINA 50 MG PÓ LIOFILIZADO PARA SOLUÇÃO INJETÁVEL"
  },
  {
    "code" : "BR0399996",
    "display" : "PAZOPANIBE 400 MG COMPRIMIDO"
  },
  {
    "code" : "BR0399997",
    "display" : "PAZOPANIBE 200 MG COMPRIMIDO"
  },
  {
    "code" : "BR0369176",
    "display" : "EVEROLIMO 0,5 MG COMPRIMIDO"
  },
  {
    "code" : "BR0342981",
    "display" : "OCTREOTIDA LAR 30 MG PÓ PARA SUSPENSÃO INJETÁVEL  ELENCO ESTADUAL"
  },
  {
    "code" : "BR0342193-1",
    "display" : "DOCETAXEL 40 MG/ML SOLUÇÃO INJETÁVEL 0,5 ML"
  },
  {
    "code" : "BR0342193-2",
    "display" : "DOCETAXEL 40 MG/ML SOLUÇÃO INJETÁVEL 2 ML"
  },
  {
    "code" : "BR0278587-2",
    "display" : "ÁCIDO MUCOPOLISSACARÍDEO POLISSULFÚRICO 5 MG/G GEL 40 G"
  },
  {
    "code" : "BR0278587-1",
    "display" : "ÁCIDO MUCOPOLISSACARÍDEO POLISSULFÚRICO 5 MG/G GEL 20 G"
  },
  {
    "code" : "BR0278588-1",
    "display" : "ÁCIDO MUCOPOLISSACARÍDEO POLISSULFÚRICO 5 MG/G POMADA 20 G"
  },
  {
    "code" : "BR0331296",
    "display" : "TEGASERODE 6 MG COMPRIMIDO"
  },
  {
    "code" : "BR0404404",
    "display" : "HYPERICUM PERFORATUM L. 300 MG CÁPSULA"
  },
  {
    "code" : "BR0342979",
    "display" : "OCTREOTIDA 10 MG PÓ LIOFILIZADO PARA SOLUÇÃO INJETÁVEL"
  },
  {
    "code" : "BR0313000U0041",
    "display" : "TIPRANAVIR 250 MG CÁPSULA"
  },
  {
    "code" : "BR0367765",
    "display" : "GELATINA 3,5 % SOLUÇÃO INJETÁVEL  500 ML SISTEMA FECHADO"
  },
  {
    "code" : "BR0402259",
    "display" : "DABIGATRANA, ETEXILATO 150 MG CÁPSULA"
  },
  {
    "code" : "BR0272815",
    "display" : "PENICILAMINA 250 MG CÁPSULA  ELENCO ESTADUAL"
  },
  {
    "code" : "BR0274527",
    "display" : "NITROFURAL 2 MG/ML SOLUÇÃO TÓPICA 500 ML"
  },
  {
    "code" : "BR0390680-2",
    "display" : "PAPAÍNA 10 % CREME  500 G"
  },
  {
    "code" : "BR0272194",
    "display" : "ESMOLOL, CLORIDRATO 10 MG/ML SOLUÇÃO INJETÁVEL 10 ML"
  },
  {
    "code" : "BR0269833U0165",
    "display" : "PRILOCAÍNA + FELIPRESSINA 3 % + 0,03 UI/ML SOLUÇÃO INJETÁVEL 1,8 ML"
  },
  {
    "code" : "BR0319128",
    "display" : "PRIMIDONA 100 MG COMPRIMIDO"
  },
  {
    "code" : "BR0404421U0015",
    "display" : "STRYPHNODENDRON BARBATIMAN MART. 60 MG/G POMADA 10 G"
  },
  {
    "code" : "BR0272320-1",
    "display" : "METILFENIDATO, CLORIDRATO 10 MG CAP LIBERAÇÃO CONTROLADA ELENCO ESTADUAL"
  },
  {
    "code" : "BR02667158",
    "display" : "PANCRELIPASE 12.000 UI CÁPSULA"
  },
  {
    "code" : "BR0266714",
    "display" : "PANCRELIPASE 4.500 UI CÁPSULA"
  },
  {
    "code" : "BR0266713",
    "display" : "PANCRELIPASE 20.000 UI CÁPSULA"
  },
  {
    "code" : "BR0273675",
    "display" : "METARAMINOL 10 MG/ML SOLUÇÃO INJETÁVEL 100 ML"
  },
  {
    "code" : "BR0404429",
    "display" : "GLICINATO DE MAGNÉSIO + PIRIDOXINA, CLORIDRATO 722,22 + 1,0 MG COMPRIMIDO"
  },
  {
    "code" : "BR0281470",
    "display" : "CANDESARTANA CILEXETILA + HIDROCLOROTIAZIDA 8 + 12,5 MG COMPRIMIDO"
  },
  {
    "code" : "BR0383272",
    "display" : "IMIGLUCERASE 400 U PÓ LIOFILIZADO PARA SOLUÇÃO INJETÁVEL"
  },
  {
    "code" : "BR0391938",
    "display" : "COLECALCIFEROL  3.300 UI/ML SOLUÇÃO ORAL 10 ML"
  },
  {
    "code" : "BR0367699",
    "display" : "COMPLEXO OSSEÍNA HIDROXIAPATITA 800 MG COMPRIMIDO"
  },
  {
    "code" : "BR0325837",
    "display" : "DEFERASIROX 500 MG COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0266736",
    "display" : "DESFERROXAMINA 500 MG PÓ LIOFILIZADO PARA SOLUÇÃO INJETÁVEL ELENCO ESTADUAL"
  },
  {
    "code" : "BR0288640",
    "display" : "MICOFENOLATO DE SÓDIO 180 MG COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0392118-3",
    "display" : "DIMETICONA 75 mg/ml SUSPENSÃO ORAL  30 ML"
  },
  {
    "code" : "BR0342258",
    "display" : "IMIPENÉM + CILASTATINA SÓDICA 500 MG PÓ LIOFILIZADO"
  },
  {
    "code" : "BR0305938U0009",
    "display" : "QUININA, DICLORIDRATO 300 MG/ML SOLUÇÃO INJETÁVEL 2 ML"
  },
  {
    "code" : "BR0267376",
    "display" : "MIDAZOLAM, CLORIDRATO 7,5 MG COMPRIMIDO"
  },
  {
    "code" : "BR0342682",
    "display" : "TRIPTORRELINA, ACETATO 3,75 MG SOL INJ (AMP)"
  },
  {
    "code" : "BR0367664",
    "display" : "NATALIZUMABE 20 MG/ML SOLUÇÃO INJETÁVEL 15 ML"
  },
  {
    "code" : "BR0270430",
    "display" : "GENCITABINA 1 G PÓ LIOFILIZADO PARA SOLUÇÃO INJETÁVEL"
  },
  {
    "code" : "BR0273702",
    "display" : "NAPROXENO SÓDICO 250 MG COMPRIMIDO"
  },
  {
    "code" : "BR0282040",
    "display" : "GEFITINIBE 250 MG COMPRIMIDO"
  },
  {
    "code" : "BR0266820",
    "display" : "IMUNOGLOBULINA HUMANA 5 G PÓ PARA SOLUÇÃO INJETÁVEL ELENCO ESTADUAL"
  },
  {
    "code" : "BR0380017",
    "display" : "INSULINA GLULISINA 100 UI/ML COM SISTEMA DE APLICAÇÃO CARPULE 3 ML ELENCO ESTADUAL"
  },
  {
    "code" : "BR0268296-1",
    "display" : "ÁCIDO NALIDÍXICO 50 MG/ML SUSPENSÃO ORAL  60 ML"
  },
  {
    "code" : "BR0268490",
    "display" : "IMUNOGLOBULINA ANTI-RHO (D) 250 MCG SOLUÇÃO INJETÁVEL"
  },
  {
    "code" : "BR0404403",
    "display" : "MANIDIPINO, CLORIDRATO + DELAPRIL, CLORIDRATO 10 MG + 30 MG COMPRIMIDO"
  },
  {
    "code" : "BR0394915",
    "display" : "ANLODIPINO, BESILATO + BENAZEPRIL, CLORIDRATO 2,5 MG+ 10 MG CÁPSULA"
  },
  {
    "code" : "BR0391336",
    "display" : "TALIGLUCERASE ALFA 200 U PÓ LIOFILIZADO"
  },
  {
    "code" : "BR0266962",
    "display" : "SOMATROPINA 4 UI PÓ LIOFILIZADO PARA SOLUÇÃO INJETÁVEL ELENCO ESTADUAL"
  },
  {
    "code" : "BR0394314",
    "display" : "BETAINTERFERONA 1A 30 MCG SOL INJ (FR-AMP OU SER PREENC) ELENCO ESTADUAL"
  },
  {
    "code" : "BR0325836",
    "display" : "DEFERASIROX 250 MG COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0272838",
    "display" : "RILUZOL 50 MG COMPRIMIDO"
  },
  {
    "code" : "BR0266750",
    "display" : "RIVASTIGMINA 2 MG/ML SOLUÇÃO ORAL  120 ML"
  },
  {
    "code" : "BR0285818",
    "display" : "SIROLIMO 2 MG DRÁGEA ELENCO ESTADUAL"
  },
  {
    "code" : "BR0268951",
    "display" : "AZITROMICINA 1 G COMPRIMIDO"
  },
  {
    "code" : "BR0401324",
    "display" : "INSULINA LISPRO + LISPRO PROTAMINA 50 + 50  % SOLUÇÃO INJETÁVEL  3 ML"
  },
  {
    "code" : "BR0395721U0189",
    "display" : "CARVÃO VEGETAL ATIVADO PÓ 1000 G"
  },
  {
    "code" : "BR0404508",
    "display" : "PANAX GINSENG + SULFATO FERROSO + MULTIVITAMINAS DRÁGEA"
  },
  {
    "code" : "BR0404690U0041",
    "display" : "GLYCINE MAX (ISOFLAVONA DE SOJA) 75 MG COMP"
  },
  {
    "code" : "BR0368704",
    "display" : "VITIS VINIFERA L. 150 MG COMPRIMIDO"
  },
  {
    "code" : "BR0266701U0084",
    "display" : "BUDESONIDA 50 MCG/DOSE SUSPENSÃO NASAL 200 DOSES"
  },
  {
    "code" : "BR0288300-3",
    "display" : "MOXIFLOXACINO, CLORIDRATO 5 MG/ML SOLUÇÃO OFTÁLMICA 10 ML"
  },
  {
    "code" : "BR0266701-2",
    "display" : "INATIVO- BUDESONIDA 50 MCG AEROSSOL NASAL 200 DOSES"
  },
  {
    "code" : "BR0397333",
    "display" : "OTILONIO, BROMETO 40 MG COMPRIMIDO"
  },
  {
    "code" : "BR0342746",
    "display" : "GLATIRÂMER, ACETATO 20 MG SOLUÇÃO INJETÁVEL COM SISTEMA DE APLICAÇÃO"
  },
  {
    "code" : "BR0394310",
    "display" : "BETAINTERFERONA 1A 22 MCG SOLUÇÃO INJETÁVEL COM SISTEMA DE APLICAÇÃO"
  },
  {
    "code" : "BR0369178",
    "display" : "EVEROLIMO 0,75 MG COMPRIMIDO"
  },
  {
    "code" : "BR0404511",
    "display" : "ECHINACEA PURPUREA MOENCH 40 MG/ML XAROPE  100 ML"
  },
  {
    "code" : "BR0292416-1",
    "display" : "CALCITRIOL 1 MCG SOLUÇÃO INJETÁVEL  1 ML"
  },
  {
    "code" : "BR0399010",
    "display" : "INSULINA GLARGINA 100 UI/ML SOLUÇÃO INJETÁVEL 3 ML COM SISTEMA DE APLICAÇÃO   ELENCO ESTADUAL"
  },
  {
    "code" : "BR0279285-2",
    "display" : "IODO 2 % TINTURA 1 L"
  },
  {
    "code" : "BR0401325",
    "display" : "INSULINA LISPRO + LISPRO PROTAMINA 50 + 50 % SOLUÇÃO INJETÁVEL COM SISTEMA DE APLICAÇÃO 3 ML"
  },
  {
    "code" : "BR0404346",
    "display" : "INDACATEROL, MALEATO 150 MCG CÁPSULA  ELENCO ESTADUAL"
  },
  {
    "code" : "BR0270494",
    "display" : "COLAGENASE + CLORANFENICOL 0,6 UI + 10 MG/G CREME VAGINAL  50 G"
  },
  {
    "code" : "BR0292373",
    "display" : "TOXINA BOTULINICA TIPO A 500 UI PÓ LIOFILIZADO PARA SOLUÇÃO INJETÁVEL ELENCO ESTADUAL"
  },
  {
    "code" : "BR0271578",
    "display" : "TOBRAMICINA, SULFATO 50 MG/ML SOLUÇÃO INJETÁVEL  1,5 ML"
  },
  {
    "code" : "BR0269842U0086",
    "display" : "LIDOCAÍNA, CLORIDRATO 10 MG/ML SOLUÇÃO INJETÁVEL 20 ML"
  },
  {
    "code" : "BR0275402U0086",
    "display" : "LIDOCAÍNA, CLORIDRATO + EPINEFRINA 10 MG/ML + 1.200.000  UI SOLUÇÃO INJETÁVEL 20 ML"
  },
  {
    "code" : "BR0333663-1",
    "display" : "PAPAÍNA 6 % CREME  100 G"
  },
  {
    "code" : "BR0271686",
    "display" : "ÁCIDO ASCÓRBICO 2 G COMPRIMIDO EFERVESCENTE"
  },
  {
    "code" : "BR0272482",
    "display" : "ZUCLOPENTIXOL 10 MG COMPRIMIDO"
  },
  {
    "code" : "BR0390680",
    "display" : "INATIVO- PAPAÍNA 10 % CREME"
  },
  {
    "code" : "BR0305415-1",
    "display" : "GINKGO BILOBA 40 MG COMPRIMIDO"
  },
  {
    "code" : "BR0305414-1",
    "display" : "GINKGO BILOBA 80 MG COMPRIMIDO"
  },
  {
    "code" : "BR0271064-1",
    "display" : "HIDRÓXIDO DE ALUMÍNIO + HIDRÓXIDO DE MAGNÉSIO + DIMETICONA 40+30+5 MG/ML SOLUÇÃO 240 ML"
  },
  {
    "code" : "BR0357059",
    "display" : "INATIVO- IBANDRONATO DE SÓDIO 150 MG COMPRIMIDO"
  },
  {
    "code" : "BR0294520",
    "display" : "LACIDIPINO 2 MG COMPRIMIDO"
  },
  {
    "code" : "BR0294521",
    "display" : "LACIDIPINO 4 MG COMPRIMIDO"
  },
  {
    "code" : "BR0337472",
    "display" : "INSULINA DETEMIR 100 UI/ML COM SISTEMA DE APLICAÇÃO SOLUÇÃO INJETÁVEL 3 ML ELENCO ESTADUAL"
  },
  {
    "code" : "BR0390440-1",
    "display" : "EXENATIDA 250 MCG/ML SOLUÇÃO INJETÁVEL COM SISTEMA DE APLICAÇÃO 1,20 ML"
  },
  {
    "code" : "BR0390440-2",
    "display" : "EXENATIDA 250 MCG/ML SOLUÇÃO INJETÁVEL COM SISTEMA DE APLICAÇÃO 2,4 ML"
  },
  {
    "code" : "BR0269842U0013",
    "display" : "LIDOCAÍNA, CLORIDRATO 10 MG/ML SOLUÇÃO INJETÁVEL 5 ML"
  },
  {
    "code" : "BR0269842U0105",
    "display" : "LIDOCAÍNA, CLORIDRATO 10 MG/ML SOLUÇÃO INJETÁVEL 50 ML"
  },
  {
    "code" : "BR0274648U0344",
    "display" : "PASTA DÁGUA PASTA  90 G"
  },
  {
    "code" : "BR0395846",
    "display" : "PAPAÍNA 2 % CREME  30 G"
  },
  {
    "code" : "BR0370119-1",
    "display" : "ARTESUNATO + MEFLOQUINA 25 + 55 MG COMPRIMIDO (3 COMP) 6 A 11 MESES"
  },
  {
    "code" : "BR0271946",
    "display" : "FENTANILA, CITRATO 25 MCG ADESIVO TRANSDÉRMICO"
  },
  {
    "code" : "BR0404443",
    "display" : "ARGININA + ORNITINA + CITRULINA 185 MG + 60 MG + 5 MG COMPRIMIDO"
  },
  {
    "code" : "BR0272022",
    "display" : "TAMOXIFENO, CITRATO 10 MG COMPRIMIDO"
  },
  {
    "code" : "BR0271657",
    "display" : "CASPOFUNGINA 50 MG  INJ (FR) ELENCO ESTADUAL"
  },
  {
    "code" : "BR0270877",
    "display" : "ANLODIPINO, BESILATO + ENALAPRIL, MALEATO 2,5 MG + 10MG CÁPSULA"
  },
  {
    "code" : "BR0393729",
    "display" : "OXICODONA, CLORIDRATO 10 MG COMPRIMIDO DE LIBERAÇÃO PROLONGADA ELENCO ESTADUAL"
  },
  {
    "code" : "BR0355794",
    "display" : "MOXIFLOXACINO, CLORIDRATO + DEXAMETASONA, FOSFATO DISSÓDICO 5 + 1 MG/ML SUSPENSÃO OFTÁLMICA 5 ML"
  },
  {
    "code" : "BR0345001",
    "display" : "MIGLUSTATE 100 MG CÁPSULA"
  },
  {
    "code" : "BR0278378",
    "display" : "TRETINOÍNA 0,025 % GEL 25 G"
  },
  {
    "code" : "BR0406013",
    "display" : "ESTRADIOL, VALERATO 1 MG DRÁGEA"
  },
  {
    "code" : "BR0406231",
    "display" : "SOLIFENACINA, SUCCINATO 10 MG COMPRIMIDO"
  },
  {
    "code" : "BR0388403",
    "display" : "GLIMEPIRIDA  3 MG COMPRIMIDO"
  },
  {
    "code" : "BR0305449",
    "display" : "CITRATO DE POTÁSSIO 540 MG  COMPRIMIDO DE LIBERAÇÃO PROLONGADA"
  },
  {
    "code" : "BR0387981",
    "display" : "RISPERIDONA 25 MG PÓ LIOFILIZADO"
  },
  {
    "code" : "BR0389398",
    "display" : "TRIÓXIDO DE ARSÊNIO 1 MG/ML SOLUÇÃO INJETÁVEL  10 ML"
  },
  {
    "code" : "BR0406477",
    "display" : "DEXAMETASONA + NEOMICINA 1 + 5 MG/G CREME  15 G"
  },
  {
    "code" : "BR0406485",
    "display" : "BETAEPOETINA 50 MCG SOLUÇÃO INJETÁVEL  0,3 ML"
  },
  {
    "code" : "BR0404448",
    "display" : "INDACATEROL, MALEATO 300 MCG CÁPSULA  ELENCO ESTADUAL"
  },
  {
    "code" : "BR0274573",
    "display" : "FENILEFRINA, CLORIDRATO 10 MG/ML SOLUÇÃO INJETÁVEL  1 ML"
  },
  {
    "code" : "BR0386846",
    "display" : "POLICARBOFILA CÁLCICA 500 MG COMPRIMIDO"
  },
  {
    "code" : "BR0273320",
    "display" : "INDOMETACINA 50 MG CÁPSULA"
  },
  {
    "code" : "BR0408470",
    "display" : "MESALAZINA 1200 MG COMPRIMIDO DE LIBERAÇÃO CONTROLADA"
  },
  {
    "code" : "BR0365048",
    "display" : "LENALIDOMIDA 10 MG COMPRIMIDO"
  },
  {
    "code" : "BR0279297-1",
    "display" : "NISTATINA + ÓXIDO DE ZINCO 100.000 + 200 UI + MG/G CREME  40 G"
  },
  {
    "code" : "BR0275888",
    "display" : "COLISTIMETATO DE SODIO (POLIMIXINA E) 150 MG  PÓ LIOFILIZADO PARA SOLUÇÃO INJETÁVEL ELENCO ESTADUAL"
  },
  {
    "code" : "BR0404846",
    "display" : "SOMATROPINA 12 UI PÓ LIOFILIZADO PARA SUSPENSÃO INJETÁVEL 2 ML ELENCO ESTADUAL"
  },
  {
    "code" : "BR0390008-2",
    "display" : "CETUXIMABE 5 mg/ml SOLUÇÃO INJETÁVEL 20 ML"
  },
  {
    "code" : "BR0271949",
    "display" : "FENTANILA, CITRATO 50 MCG ADESIVO TRANSDÉRMICO"
  },
  {
    "code" : "BR0344564",
    "display" : "SUNITINIBE, MALATO 50 MG CÁPSULA"
  },
  {
    "code" : "BR0269390",
    "display" : "FUROSEMIDA 10 MG/ML SOLUÇÃO ORAL  100 ML"
  },
  {
    "code" : "BR0270782",
    "display" : "ETORICOXIBE 60 MG COMPRIMIDO"
  },
  {
    "code" : "BR0271656",
    "display" : "CASPOFUNGINA 70 MG  INJ (FR) ELENCO ESTADUAL"
  },
  {
    "code" : "BR0387983",
    "display" : "RISPERIDONA 50 MG PÓ LIOFILIZADO"
  },
  {
    "code" : "BR0360824",
    "display" : "PALIPERIDONA 3 MG COMPRIMIDO DE LIBERAÇÃO PROLONGADA"
  },
  {
    "code" : "BR0332795",
    "display" : "GESTODENO + ETINILESTRADIOL 0,075 + 0,030 MG COMPRIMIDO"
  },
  {
    "code" : "BR0274467-2",
    "display" : "HIALURONATO DE SÓDIO 1 % SOLUÇÃO INJETÁVEL COM SISTEMA DE APLICAÇÃO 2,5 ML"
  },
  {
    "code" : "BR0402991",
    "display" : "SAXAGLIPTINA 2,5 MG COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0405965",
    "display" : "INSULINA LISPRO + LISPRO PROTAMINA 25 + 75 % SOLUÇÃO INJETÁVEL 3 ML COM SISTEMA DE APLICAÇÃO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0304875",
    "display" : "DIGOXINA  0,125 MG COMPRIMIDO"
  },
  {
    "code" : "BR0272690",
    "display" : "NANDROLONA, DECANOATO 50 MG/ML SOLUÇÃO INJETÁVEL 1 ML"
  },
  {
    "code" : "BR0275651",
    "display" : "GONADOTROPINA, CORIÔNICA ALFA HCG RECOMBINANTE, CORIOGONADOTROPINA ALFA 250 MCG SOLUÇÃO INJETÁVEL COM SISTEMA DE APLICAÇÃO 0,5 ML"
  },
  {
    "code" : "BR0397543",
    "display" : "FOLITROPINA, ALFA RECOMBINANTE (33 MCG) 450 UI SOLUÇÃO INJETÁVEL COM SISTEMA DE APLICAÇÃO 0,75 ML"
  },
  {
    "code" : "BR0305261",
    "display" : "LEUPRORRELINA, ACETATO 5 MG/ML SOLUÇÃO INJETÁVEL  2,8 ML"
  },
  {
    "code" : "BR0277184",
    "display" : "VALGANCICLOVIR, CLORIDRATO 450 MG COMPRIMIDO"
  },
  {
    "code" : "BR0322033",
    "display" : "ALFALUTROPINA 75 UI PÓ LIOFILIZADO PARA SOLUÇÃO INJETÁVEL"
  },
  {
    "code" : "BR0397074",
    "display" : "LIDOCAÍNA, CLORIDRATO + CLORETO DE BENZETÔNIO 21 + 1,33 MG/ML SPRAY TÓPICO 50 ML"
  },
  {
    "code" : "BR0394804",
    "display" : "PACLITAXEL 6 MG/ML SOLUÇÃO INJETÁVEL 16,7 ML"
  },
  {
    "code" : "BR0368168",
    "display" : "DEXAMETASONA, ACETATO + DEXAMETASONA, FOSFATO DISSÓDICO 8 + 2 MG/ML SUSPENSÃO INJETÁVEL 1 ML"
  },
  {
    "code" : "BR0269954-2",
    "display" : "BROMOPRIDA 10 MG COMPRIMIDO"
  },
  {
    "code" : "BR0364789",
    "display" : "ISOTRETINOÍNA 0,5 MG/G GEL 30 G"
  },
  {
    "code" : "BR0305428",
    "display" : "CARMELOSE SÓDICA 5 MG/ML SOLUÇÃO OFTÁLMICA 15 ML"
  },
  {
    "code" : "BR0346231",
    "display" : "LACTATO DE AMONIO + ALANTOINA 120 + 1 MG/ML LOÇÃO  120 ML"
  },
  {
    "code" : "BR0288002",
    "display" : "CICLOPIROX OLAMINA 10 MG/G CREME  20 G"
  },
  {
    "code" : "BR0290891U0350",
    "display" : "OXAMNIQUINA 50 MG/ML SUSPENSÃO ORAL  12  ML"
  },
  {
    "code" : "BR0400852",
    "display" : "TICAGRELOR 90 MG COMPRIMIDO"
  },
  {
    "code" : "BR0398939",
    "display" : "ÁCIDO IBANDRÔNICO (IBANDRONATO DE SÓDIO) 1 MG/ML SOLUÇÃO INJETÁVEL 3 ML"
  },
  {
    "code" : "BR0400564-4",
    "display" : "ARTEMETER + LUMEFANTRINA 20 + 120 MG COMPRIMIDO 35 KG (BLISTER C/24 COMPRIMIDOS)"
  },
  {
    "code" : "BR0269634",
    "display" : "PRAZIQUANTEL 150 MG COMPRIMIDO"
  },
  {
    "code" : "BR0311390-1",
    "display" : "BEVACIZUMABE 25 MG/ML SOLUÇÃO INJETÁVEL  4 ML"
  },
  {
    "code" : "BR0388866",
    "display" : "ALENTUZUMABE 30 MG/ML SOLUÇÃO INJETÁVEL 1 ML"
  },
  {
    "code" : "BR0361174",
    "display" : "LAPATINIBE, DITOSILATO 250 MG COMPRIMIDO"
  },
  {
    "code" : "BR0393953",
    "display" : "TEMOZOLOMIDA 140 MG CÁPSULA"
  },
  {
    "code" : "BR0344563",
    "display" : "SUNITINIBE, MALATO 12,5 MG CÁPSULA"
  },
  {
    "code" : "BR0365451",
    "display" : "ABATACEPTE 250 MG PÓ LIOFILIZADO PARA SOLUÇÃO INJETÁVEL ELENCO ESTADUAL"
  },
  {
    "code" : "BR0343126",
    "display" : "ANLODIPINO, BESILATO + LOSARTANA POTÁSSICA 5 MG + 100 MG CÁPSULA"
  },
  {
    "code" : "BR0314373-2",
    "display" : "CUMARINA + HEPARINA SÓDICA 5 + 50 MG/ML CREME  80 ML"
  },
  {
    "code" : "BR0272201",
    "display" : "ETILEFRINA, CLORIDRATO 7,5 MG/ML SOLUÇÃO ORAL 20 ML"
  },
  {
    "code" : "BR0406015-2",
    "display" : "OXIBUTININA, CLORIDRATO, FORMULAÇÃO ESPECIALMENTE MANIPULADA 1 MG/ML SOLUÇÃO ORAL 1000 ML"
  },
  {
    "code" : "BR0330113-2",
    "display" : "GANCICLOVIR SÓDICO 1 MG/ML SOLUÇÃO INJETÁVEL 500 ML ELENCO ESTADUAL"
  },
  {
    "code" : "BR0268404",
    "display" : "CAPECITABINA 150 MG COMPRIMIDO"
  },
  {
    "code" : "BR0404174",
    "display" : "VIMINOL, HIDROXIBENZOATO 70 MG CÁPSULA"
  },
  {
    "code" : "BR0406799",
    "display" : "SULFATO FERROSO (13,7 MG/ML DE FERRO ELEMENTAR) 68 MG/ML SOLUÇÃO ORAL 30 ML"
  },
  {
    "code" : "BR0406602",
    "display" : "ALISQUIRENO, HEMIFUMARATO + HIDROCLOROTIAZIDA 300 MG + 12,5 MG COMPRIMIDO"
  },
  {
    "code" : "BR0407013",
    "display" : "MENTOL + CÂNFORA + SALICILATO DE METILA + ÓLEO DE EUCALIPTO 150 MG+ 100 MG + 80 MG + 50 MG/G POMADA 100 G"
  },
  {
    "code" : "BR0407039",
    "display" : "CIPROEPTADINA, CLORIDRATO + COBAMAMIDA 0,8 + 0,2 MG/ML XAROPE  100 ML"
  },
  {
    "code" : "BR0407066",
    "display" : "GLIMEPIRIDA + METFORMINA, CLORIDRATO 4 + 1000 MG COMPRIMIDO"
  },
  {
    "code" : "BR0390333U0352",
    "display" : "TIPRANAVIR 100 MG/ML SOLUÇÃO ORAL 95 ML"
  },
  {
    "code" : "BR0407327",
    "display" : "LISDEXANFETAMINA, MESILATO 50 MG CÁPSULA"
  },
  {
    "code" : "BR0304788",
    "display" : "CINACALCETE 30 MG COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0402195",
    "display" : "DROSPIRENONA + ETINILESTRADIOL 3 + 0,03 MG COMPRIMIDO"
  },
  {
    "code" : "BR0300259",
    "display" : "LEVODROPROPIZINA 30 MG/ML SOLUÇÃO ORAL  20 ML"
  },
  {
    "code" : "BR0270833",
    "display" : "ESTRADIOL 2 MG COMPRIMIDO"
  },
  {
    "code" : "BR0352944",
    "display" : "BORAGO OFFICIALIS 900 MG CÁPSULA"
  },
  {
    "code" : "BR0301493",
    "display" : "HIDROCORTISONA 5 MG COMPRIMIDO"
  },
  {
    "code" : "BR0364816",
    "display" : "LENALIDOMIDA 25 MG COMPRIMIDO"
  },
  {
    "code" : "BR0305484",
    "display" : "MAPROTILINA, CLORIDRATO 75 MG COMPRIMIDO"
  },
  {
    "code" : "BR0347115-1",
    "display" : "PAPAÍNA 4 % CREME  50 G"
  },
  {
    "code" : "BR0333663",
    "display" : "PAPAÍNA 6 % CREME  50 G"
  },
  {
    "code" : "BR0408845",
    "display" : "XILAZINA, CLORIDRATO 20 MG/ML SOLUÇÃO INJETÁVEL  10 ML"
  },
  {
    "code" : "BR0278646",
    "display" : "ACIDO AMINOCAPRÓICO 50 MG/ML SUSPENSÃO INJETÁVEL 20 ML"
  },
  {
    "code" : "BR0266532-1",
    "display" : "FENOTEROL, BROMIDRATO 200 MCG AEROSSOL 200 DOSES ELENCO ESTADUAL"
  },
  {
    "code" : "BR0271913",
    "display" : "RETINOL, PALMITATO 50.000 UI DRÁGEA ELENCO ESTADUAL"
  },
  {
    "code" : "BR0274576",
    "display" : "DIIDROERGOCRISTINA, MESILATO  6 MG CÁPSULA"
  },
  {
    "code" : "BR0270229",
    "display" : "POLIMIXINA B + NEOMICINA + FLUOCINOLONA + LIDOCAÍNA 11000U + 3,85 + 0,275 + 20 MG/ML SOLUÇÃO OTOLÓGICA 5 ML"
  },
  {
    "code" : "INATIVO 34",
    "display" : "INATIVO-BECLOMETASONA, DIPROPIONATO 50 MCG/ML AEROSSOL ORAL INATIVO, USAR BR0346586-2 DOSES"
  },
  {
    "code" : "BR0269391U0067",
    "display" : "FENITOÍNA SÓDICA  20 MG/ML SUSPENSÃO ORAL  120 ML"
  },
  {
    "code" : "BR0359286",
    "display" : "HEDERA HELIX - EXTRATO SECO 7 MG/ML XAROPE  100 ML"
  },
  {
    "code" : "BR0383436",
    "display" : "AZACITIDINA 100 MG PÓ PARA SOLUÇÃO INJETÁVEL"
  },
  {
    "code" : "BR0405962",
    "display" : "NIMOTUZUMABE 5 MG/ML SOLUÇÃO INJETÁVEL 10 ML"
  },
  {
    "code" : "BR0405997",
    "display" : "BIMATOPROSTA 0,1 MG/ML SOLUÇÃO OFTÁLMICA 3 ML"
  },
  {
    "code" : "INATIVO 26",
    "display" : "INATIVO-CLORETO DE SÓDIO, NÃO INJETÁVEL 0,9 % SOLUÇÃO ESTÉRIL 500 ML"
  },
  {
    "code" : "BR0300257",
    "display" : "LEVODROPROPIZINA 6 MG/ML XAROPE  120 ML"
  },
  {
    "code" : "BR0271103U0067",
    "display" : "CETOCONAZOL 2% XAMPU  120 ML"
  },
  {
    "code" : "BR0269895",
    "display" : "LIDOCAÍNA, CLORIDRATO + NOREPINEFRINA 2% + 1:50.000 SOLUÇÃO INJETÁVEL"
  },
  {
    "code" : "BR0406487",
    "display" : "LEVOCETIRIZINA, DIPROPIONATO 5 MG COMPRIMIDO"
  },
  {
    "code" : "BR0407043",
    "display" : "MULTIVITAMINAS (B1, B2, B3, B5, B6, E) + LACTATO DE CALCIO + CLORIDRATO DE LISINA XAROPE  200 ML"
  },
  {
    "code" : "BR0407214",
    "display" : "LINAGLIPTINA 5 MG COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0267728U0041",
    "display" : "NIFEDIPINO 10 MG CÁPSULA"
  },
  {
    "code" : "BR0270916",
    "display" : "PARACETAMOL + CARISOPRODOL + FENILBUTAZONA 300 MG + 150 MG + 75 MG COMPRIMIDO"
  },
  {
    "code" : "BR0309432",
    "display" : "CILAZAPRIL 1 MG COMPRIMIDO"
  },
  {
    "code" : "BR0394916",
    "display" : "ANLODIPINO, BESILATO + BENAZEPRIL, CLORIDRATO 5 MG + 10 MG CÁPSULA"
  },
  {
    "code" : "BR0340153",
    "display" : "CICLOPIROX OLAMINA 10  MG/ML SOLUÇÃO TÓPICA 15 ML"
  },
  {
    "code" : "BR0271948",
    "display" : "FENTANILA, CITRATO 100 MCG ADESIVO TRANSDÉRMICO"
  },
  {
    "code" : "BR0393138",
    "display" : "EVEROLIMO 5 MG COMPRIMIDO"
  },
  {
    "code" : "BR0275116",
    "display" : "NITRENDIPINO 100.000 + 200 UI + MG/G COMPRIMIDO"
  },
  {
    "code" : "BR0304790",
    "display" : "CINACALCETE 60 MG  COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0268488",
    "display" : "MEROPENÉM 1 G PÓ PARA SOLUÇÃO INJETÁVEL"
  },
  {
    "code" : "BR0268303U0063",
    "display" : "SALBUTAMOL, SULFATO 5 MG/ML SOLUÇÃO PARA NEBULIZAÇÃO 10 ML"
  },
  {
    "code" : "BR0270114-1",
    "display" : "CETAMINA, CLORIDRATO DE  50 MG/ML SOLUÇÃO INJETÁVEL 2 ML"
  },
  {
    "code" : "BR0328106",
    "display" : "CLOMIFENO, CITRATO 50 MG COMPRIMIDO"
  },
  {
    "code" : "BR0370120-2",
    "display" : "ARTESUNATO + MEFLOQUINA 100 + 220 MG COMPRIMIDO (6 COMP) 12 ANOS OU MAIS"
  },
  {
    "code" : "BR0305727",
    "display" : "OCTREOTIDA 0,05 MG/ML SOLUÇÃO INJETÁVEL 1 ML"
  },
  {
    "code" : "BR0305808",
    "display" : "PASSIFLORA INCARNATA + CRATAEGUS OXYACANTHA + SALIX ALBA 100 MG + 30 MG + 100 MG COMPRIMIDO"
  },
  {
    "code" : "BR0294912-2",
    "display" : "IRINOTECANO, CLORIDRATO 20 MG/ML SOLUÇÃO INJETÁVEL  5 ML"
  },
  {
    "code" : "BR0294912-1",
    "display" : "IRINOTECANO, CLORIDRATO 20 MG/ML AMP 2 ML"
  },
  {
    "code" : "BR0318990",
    "display" : "SOMATROPINA 36 UI PÓ LIOFILIZADO + SUSPENSÃO INJETÁVEL"
  },
  {
    "code" : "BR0266701U0066",
    "display" : "BUDESONIDA 50 MCG/DOSE SUSPENSÃO NASAL 120 DOSES"
  },
  {
    "code" : "BR0397549",
    "display" : "MENOTROPINA 75 UI PÓ LIOFILIZADO PARA SOLUÇÃO INJETÁVEL"
  },
  {
    "code" : "BR0406518",
    "display" : "DOCETAXEL 20 MG/ML SOLUÇÃO INJETÁVEL 1 ML"
  },
  {
    "code" : "BR0407007",
    "display" : "PARACETAMOL + CARISOPRODOL + NIMESULIDE + TIZANIDINA + FAMOTIDINA + CAFEÍNA 350 MG + 150 MG + 200 MG + 2 MG + 40 MG + 50 MG CÁPSULA"
  },
  {
    "code" : "BR0407030U0388",
    "display" : "MAGNÉSIO, SULFATO 990 MG/G PÓ PARA SOLUÇÃO ORAL 15 G"
  },
  {
    "code" : "BR0407034",
    "display" : "MULTIVITAMINAS (B1, B6, B12) + SAIS MINERAIS + ÁC. GLUTÂMICO + AC AMINUBUTÍRICO DRÁGEA"
  },
  {
    "code" : "BR0342737",
    "display" : "HEPARINA SÓDICA 200 UI/G GEL 40 G"
  },
  {
    "code" : "BR0278259",
    "display" : "TIOCOLCHICOSÍDEO 4 MG COMPRIMIDO"
  },
  {
    "code" : "BR0270458",
    "display" : "NAFAZOLINA + DEXAMETASONA, FOSFATO DISSÓDICO + NEOMICINA 0,75 + 0,5 + 5 MG/ML SOLUÇÃO NASAL 20 ML"
  },
  {
    "code" : "BR0273952",
    "display" : "PROGESTERONA 200 MG CÁPSULA"
  },
  {
    "code" : "BR0410047",
    "display" : "CRANBERRY (VACCINIUM MACROCARPOM) 400 MG MG CÁPSULA"
  },
  {
    "code" : "BR0390006",
    "display" : "QUETIAPINA 300 MG COMPRIMIDO DE LIBERAÇÃO PROLONGADA ELENCO ESTADUAL"
  },
  {
    "code" : "BR0296744",
    "display" : "OLMESARTANA + HIDROCLOROTIAZIDA 40 + 25 MG COMPRIMIDO"
  },
  {
    "code" : "BR0293880",
    "display" : "TOLTERODINA, TARTARATO 2 MG COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0270889",
    "display" : "ESCINA AMORFA + ESCINA POLISSULFONADA SÓDICA + SALICILATO DE DIETILAMINA 10 + 10 + 50 MG/G GEL 30 G"
  },
  {
    "code" : "BR0332794",
    "display" : "GESTODENO + ETINILESTRADIOL 0,075 + 0,02 MG COMPRIMIDO"
  },
  {
    "code" : "BR0370119-2",
    "display" : "ARTESUNATO + MEFLOQUINA 25 + 55 MG COMPRIMIDO (6 COMP) 1 A 5 ANOS"
  },
  {
    "code" : "BR0292043",
    "display" : "SACCHAROMYCES CEREVISIAE 50 MILHÕES/ ML SUSPENSÃO ORAL  5 ML"
  },
  {
    "code" : "BR0381066",
    "display" : "RAMIPRIL + ANLODIPINO, BESILATO 10 + 5 MG CÁPSULA"
  },
  {
    "code" : "BR0279285-1",
    "display" : "IODO 2 % TINTURA 100 ML"
  },
  {
    "code" : "BR0394662",
    "display" : "NEOMICINA 5 MG/G POMADA 20 G"
  },
  {
    "code" : "BR0370117",
    "display" : "DABIGATRANA, ETEXILATO 110 MG CÁPSULA"
  },
  {
    "code" : "BR0310452",
    "display" : "CONTRASTE RADIOLÓGICO, A BASE DE ÓLEO DE PAPOULA IODADO 480 MG / ML SOLUÇÃO INJETÁVEL 10 ML"
  },
  {
    "code" : "BR0352397",
    "display" : "BUDESONIDA 200 MG CÁPSULA  COM  INALADOR"
  },
  {
    "code" : "BR0272331",
    "display" : "DIMENIDRINATO 100 MG COMPRIMIDO"
  },
  {
    "code" : "BR0268528",
    "display" : "TEICOPLANINA 400 MG PÓ LIOFILIZADO"
  },
  {
    "code" : "BR0272088-1",
    "display" : "SULFADIAZINA DE PRATA + NITRATO DE CÉRIO 1 + 0,4 % CREME  50 G"
  },
  {
    "code" : "BR0400563U0164",
    "display" : "USTEQUINUMABE 90 MG/ML SOLUÇÃO INJETÁVEL 0,5 ML"
  },
  {
    "code" : "BR0294729",
    "display" : "VORICONAZOL 50 MG COMPRIMIDO"
  },
  {
    "code" : "BR0269073-1",
    "display" : "ÁCIDO TRICLOROACÉTICO 80 % SOLUÇÃO 100 ML"
  },
  {
    "code" : "BR0406930",
    "display" : "SOMATROPINA 24 UI PÓ LIOFILIZADO"
  },
  {
    "code" : "BR0406953",
    "display" : "CARBONATO DE CÁLCIO + COLECALCIFEROL  50 MG + 0,25 UI PASTILHA"
  },
  {
    "code" : "BR0270495-2",
    "display" : "COLAGENASE + CLORANFENICOL 0,6 UI + 10  MG/G POMADA 50 G"
  },
  {
    "code" : "BR0407008",
    "display" : "PARACETAMOL + CARISOPRODOL + NIMESULIDE + TIZANIDINA + FAMOTIDINA + CICLOBENZAPRINA 350 MG + 150 MG + 200 MG + 2 MG + 40 MG + 10 MG CÁPSULA"
  },
  {
    "code" : "BR0406992",
    "display" : "NIMESULIDA 200 MG CÁPSULA DURA DE LIBERAÇÃO PROLONGADA"
  },
  {
    "code" : "BR0381288U0041",
    "display" : "RIFABUTINA 150 MG CÁPSULA"
  },
  {
    "code" : "BR0290675",
    "display" : "EBASTINA + PSEUDOEFEDRINA 10 + 120 MG CÁPSULA"
  },
  {
    "code" : "BR0407328",
    "display" : "LISDEXANFETAMINA, MESILATO 30 MG CÁPSULA"
  },
  {
    "code" : "BR0407441",
    "display" : "BECLOMETASONA, DIPROPIONATO + FORMOTEROL, FUMARATO 100 + 6 MCG/DOSE AEROSSOL ORAL 120 DOSES"
  },
  {
    "code" : "BR0286278",
    "display" : "ARIPIPRAZOL 30 MG COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0273631-1",
    "display" : "MULTIVITAMINAS B2, B6, B12, C, NICOTINAMIDA E FRUTOSE SOLUÇÃO ORAL 150 ML"
  },
  {
    "code" : "BR0337679",
    "display" : "ÁCIDO ACETILSALICÍLICO  300 MG COMPRIMIDO DE LIBERAÇÃO PROLONGADA"
  },
  {
    "code" : "BR0405220",
    "display" : "CANDESARTANA + FELODIPINO 0,16 + 5 MG COMPRIMIDO"
  },
  {
    "code" : "BR0404790",
    "display" : "BOCEPREVIR 200 MG CÁPSULA"
  },
  {
    "code" : "BR0410989",
    "display" : "BENFOTIAMINA 150 MG DRÁGEA"
  },
  {
    "code" : "BR0400476",
    "display" : "PARICALCITOL 5 MCG/ML SOLUÇÃO INJETÁVEL 1 ML ELENCO ESTADUAL"
  },
  {
    "code" : "BR0368694",
    "display" : "ECULIZUMABE 10 MG/ML SOLUÇÃO INJETÁVEL 30 ML"
  },
  {
    "code" : "BR0362266",
    "display" : "APREPITANTO 2 CAP 80 MG + CÁPSULA  1 CAP 125 MG"
  },
  {
    "code" : "BR040521",
    "display" : "PEMETREXEDE 100 MG PÓ LIOFILIZADO PARA SOLUÇÃO INJETÁVEL"
  },
  {
    "code" : "BR0401891",
    "display" : "CIANOCOBALAMINA + TIAMINA + PIRIDOXINA 1 + 100 + 100 mg SOLUÇÃO INJETÁVEL 1 ML"
  },
  {
    "code" : "BR0275964",
    "display" : "FINASTERIDA 1 MG COMPRIMIDO"
  },
  {
    "code" : "BR0404444",
    "display" : "BISMUTO MONOBÁSICO, SALICILATO 500 MG CÁPSULA"
  },
  {
    "code" : "BR0344562",
    "display" : "SUNITINIBE, MALATO 25 MG CÁPSULA"
  },
  {
    "code" : "BR0400486",
    "display" : "BORTEZOMIBE 1 MG PÓ LIOF INJ (FR-AMP)"
  },
  {
    "code" : "BR0363933U0042",
    "display" : "MARAVIROQUE 150 MG COMPRIMIDO"
  },
  {
    "code" : "BR0363934",
    "display" : "MARAVIROQUE 300 MG COMPRIMIDO"
  },
  {
    "code" : "BR0305725",
    "display" : "OCTREOTIDA 0,1 MG/ML SOL INJ (FR-AMP)"
  },
  {
    "code" : "BR0276959",
    "display" : "ALFATIROTROPINA (TIROTROFINA) 1,1 MG PÓ LIOF INJ (FR-AMP) 1,2 ML"
  },
  {
    "code" : "BR0359135",
    "display" : "DASATINIBE 20 MG COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0359136",
    "display" : "DASATINIBE 50 MG COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0278265",
    "display" : "HIDROXIQUINOLINA, BORATO + TROLAMINA 0,04 + 140 MG/ML SOLUÇÃO OTOLÓGICA 8 ML"
  },
  {
    "code" : "BR0405998",
    "display" : "INSULINA LISPRO 100 UI/ML SOLUÇÃO INJETÁVEL 3 ML COM SISTEMA DE APLICAÇÃO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0305935-1",
    "display" : "PROPOFOL 10 MG/ML EMULSÃO INJETÁVEL 10 ML"
  },
  {
    "code" : "BR0393493",
    "display" : "ACETILCISTEÍNA + TUAMINOEPTANO 10 MG + 5 MG/ML SOLUÇÃO NASAL"
  },
  {
    "code" : "BR0368799",
    "display" : "UBIDECARENONA (COENZIMA Q10) 50 MG COMPRIMIDO"
  },
  {
    "code" : "BR0278589-1",
    "display" : "ÁCIDO MUCOPOLISSACARÍDEO POLISSULFÚRICO 3 MG/G GEL 20 G"
  },
  {
    "code" : "BR0278589-2",
    "display" : "ÁCIDO MUCOPOLISSACARÍDEO POLISSULFÚRICO 3 MG/G GEL 40 G"
  },
  {
    "code" : "BR0340206",
    "display" : "CLONIDINA, CLORIDRATO 0,15 mg/ml SOLUÇÃO INJETÁVEL 1 ML"
  },
  {
    "code" : "BR0298769",
    "display" : "PAROXETINA, CLORIDRATO 40 MG COMPRIMIDO"
  },
  {
    "code" : "BR0406994",
    "display" : "PASSIFLORA INCARNATA 300 MG COMPRIMIDO"
  },
  {
    "code" : "BR0407033",
    "display" : "ÁCIDO VALPRÓICO (VALPROATO DE SÓDIO)  300 MG COMPRIMIDO DE LIBERAÇÃO PROLONGADA"
  },
  {
    "code" : "BR0406941",
    "display" : "FERRO QUELATO GLICINATO (30 MG FERRO ELEMENTAR) 150 MG COMPRIMIDO"
  },
  {
    "code" : "BR0367725",
    "display" : "POLICRESULENO + CINCHOCAÍNA, CLORIDRATO 50 + 10 MG/G POMADA RETAL 30 G"
  },
  {
    "code" : "BR0332985",
    "display" : "LEVOFLOXACINO 5 MG/ML SOLUÇÃO INJETÁVEL  100 ML"
  },
  {
    "code" : "BR0273112",
    "display" : "GRISEOFULVINA 500 MG COMPRIMIDO"
  },
  {
    "code" : "BR0294537",
    "display" : "MIRTAZAPINA 45 MG COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0384298",
    "display" : "HIDROCORTISONA 10 MG COMPRIMIDO"
  },
  {
    "code" : "BR0309433",
    "display" : "CILAZAPRIL 2,5 MG COMPRIMIDO"
  },
  {
    "code" : "BR0405219",
    "display" : "CANDESARTANA + FELODIPINO 0,16 + 2,5 MG COMPRIMIDO"
  },
  {
    "code" : "BR0347116-1",
    "display" : "PAPAÍNA 8 % CREME  50 G"
  },
  {
    "code" : "BR0394667",
    "display" : "NIFEDIPINO 60 MG COMPRIMIDO DE LIBERAÇÃO CONTROLADA"
  },
  {
    "code" : "BR0400854",
    "display" : "IVABRADINA, CLORIDRATO 7,5 MG COMPRIMIDO"
  },
  {
    "code" : "BR0373792",
    "display" : "IBUPROFENO + ARGININA 400 + 370 mg GRANULADO 3 G"
  },
  {
    "code" : "BR0368899",
    "display" : "CLINDAMICINA, CLORIDRATO + PERÓXIDO DE BENZOÍLA 10 + 50 mg/g GEL 30 G"
  },
  {
    "code" : "BR0393779U0042",
    "display" : "DARUNAVIR 75 MG COMPRIMIDO"
  },
  {
    "code" : "BR0383786-1",
    "display" : "VINORELBINA, TARTARATO 10 MG/ML SOLUÇÃO INJETÁVEL  5 ML"
  },
  {
    "code" : "BR0342445",
    "display" : "INSULINA NPH + REGULAR 70% + 30% SOLUÇÃO INJETÁVEL 10 ML"
  },
  {
    "code" : "BR0271172",
    "display" : "ENALAPRIL, MALEATO + HIDROCLOROTIAZIDA 10+ 25 MG COMPRIMIDO"
  },
  {
    "code" : "BR0335969",
    "display" : "VARDENAFILA, CLORIDRATO 20 MG COMPRIMIDO"
  },
  {
    "code" : "BR0390008-4",
    "display" : "CETUXIMABE 5 MG/ML SOLUÇÃO INJETÁVEL  100 ML"
  },
  {
    "code" : "BR0412376",
    "display" : "OSELTAMIVIR, FOSFATO 20 MG CÁPSULA"
  },
  {
    "code" : "BR0308736-3",
    "display" : "CETOCONAZOL 2% CREME  50 G"
  },
  {
    "code" : "BR0412431",
    "display" : "RUPATADINA 10 MG COMPRIMIDO"
  },
  {
    "code" : "BR0274648U0031",
    "display" : "PASTA DÁGUA PASTA  80 G"
  },
  {
    "code" : "BR0412840",
    "display" : "BILASTINA 20 MG COMPRIMIDO"
  },
  {
    "code" : "BR0412961",
    "display" : "LACTASE 300 MG CÁPSULA"
  },
  {
    "code" : "BR0268377",
    "display" : "ALBUMINA HUMANA 20 % SOL INJ (FR-AMP) COM EQUIPO 50 ML"
  },
  {
    "code" : "BR0284841",
    "display" : "FOLITROPINA, ALFA RECOMBINANTE 450 UI PÓ LIOF INJ (FR-AMP OU SER PREENC) 1 ML"
  },
  {
    "code" : "BR0268529",
    "display" : "TEICOPLANINA 200 MG SOL INJ (FR-AMP)"
  },
  {
    "code" : "BR0340320",
    "display" : "CONTRASTE RADIOLÓGICO, NÃO IÔNICO, À BASE DE IOVERSOL 320MG DE IODO ML SOL INJ (SER PREENC) 125 ML"
  },
  {
    "code" : "BR0394026",
    "display" : "LEVOBUPIVACAINA,  CLORIDRATO + EPINEFRINA BITARTARATO  0,25% + 9,1 MCG/ML SOLUÇÃO INJETÁVEL  20 ML"
  },
  {
    "code" : "BR0305265",
    "display" : "LEVOBUPIVACAINA,  CLORIDRATO + EPINEFRINA BITARTARATO 0,75% + 9,1 MCG/ML SOLUÇÃO INJETÁVEL  20 ML"
  },
  {
    "code" : "BR0271986",
    "display" : "CEFUROXIMA 25 MG/ML SUSPENSÃO ORAL  50 ML"
  },
  {
    "code" : "BR0333130-1",
    "display" : "CEFUROXIMA 50 MG/ML SUSPENSÃO ORAL  50 ML"
  },
  {
    "code" : "BR0388555",
    "display" : "ORNITINA, ASPARTATO 500 MG/ML SOLUÇÃO INJETÁVEL 10 ML"
  },
  {
    "code" : "BR0407326",
    "display" : "LISDEXANFETAMINA, MESILATO 70 MG CÁPSULA"
  },
  {
    "code" : "BR0414455",
    "display" : "ARGININA 400 MG/ML XAROPE  450 ML"
  },
  {
    "code" : "BR0414454",
    "display" : "CARNITINA 50 MG/ML XAROPE  450 ML"
  },
  {
    "code" : "BR0278429-1",
    "display" : "BUPIVACAÍNA + EPINEFRINA 0,25 % + 1/200.000 UI SOLUÇÃO INJETÁVEL  20 ML"
  },
  {
    "code" : "BR0267544U0033",
    "display" : "GLICOSE 10 % SOLUÇÃO INJETÁVEL 1000 ML SISTEMA FECHADO"
  },
  {
    "code" : "BR0345241",
    "display" : "HIDROCORTISONA 10 MG/G POMADA 30 G"
  },
  {
    "code" : "BR0366914",
    "display" : "NAFAZOLINA, CLORIDRATO 0,12 MG/ML SOLUÇÃO OFTÁLMICA 15 ML"
  },
  {
    "code" : "BR0313595",
    "display" : "POLICRESULENO + CINCHOCAÍNA, CLORIDRATO 100 + 10 MG/G POMADA RETAL 30 G"
  },
  {
    "code" : "BR0387359",
    "display" : "PAPAÍNA 2 % GEL 100 G"
  },
  {
    "code" : "BR0414848",
    "display" : "TERCONAZOL 8 MG/G CREME VAGINAL  30 G"
  },
  {
    "code" : "BR0272475",
    "display" : "DANTROLENO SODICO 20 MG SOL INJ OU PÓ LIOF INJ (FR-AMP)"
  },
  {
    "code" : "BR0267770",
    "display" : "PROPRANOLOL, CLORIDRATO 80 MG COMPRIMIDO"
  },
  {
    "code" : "BR0412414",
    "display" : "URÉIA + ALANTOÍNA + ÓLEO AMENDOAS DOCES + LACTATO AMÔNIO 10 + 2 + 8 + 12 % POMADA 500 MG"
  },
  {
    "code" : "BR0266705-2",
    "display" : "BUDESONIDA 100 MCG/DOSE AEROSSOL NASAL 100 DOSES"
  },
  {
    "code" : "BR0266703-2",
    "display" : "BUDESONIDA 100 MCG/DOSE PÓ PARA INALAÇÃO ORAL 120 DOSES"
  },
  {
    "code" : "BR0395730-3",
    "display" : "HIDRÓXIDO DE ALUMÍNIO + HIDRÓXIDO DE MAGNÉSIO 60 + 40 MG/ML SUSPENSÃO ORAL  240 ML"
  },
  {
    "code" : "BR0412963",
    "display" : "SIMETICONA 40 MG COMPRIMIDO"
  },
  {
    "code" : "BR0397542",
    "display" : "FOLITROPINA, ALFA RECOMBINANTE (22MCG) 300 UI SOLUÇÃO INJETÁVEL COM SISTEMA DE APLICAÇÃO 0,5 ML"
  },
  {
    "code" : "BR0284842",
    "display" : "FOLITROPINA, ALFA RECOMBINANTE 1050 UI PÓ + DILUENTE 2 ML"
  },
  {
    "code" : "BR0331539",
    "display" : "TIGECICLINA 50 MG PÓ LIOF INJ (FR-AMP)"
  },
  {
    "code" : "BR0270115",
    "display" : "REMIFENTANILA, CLORIDRATO 1 MG PÓ LIOF INJ (FR-AMP)"
  },
  {
    "code" : "BR0305751",
    "display" : "ONDANSETRONA, CLORIDRATO 8 MG/ML SOLUÇÃO INJETÁVEL 4 ML"
  },
  {
    "code" : "BR0273939",
    "display" : "PARECOXIBE, SODICO 40 MG SOL INJ (FR-AMP)"
  },
  {
    "code" : "BR0375387-1",
    "display" : "POLIETILENOGLICOL 400 + PROPILENOGLICOL 3 + 4 mg/ml SOLUÇÃO OFTÁLMICA 5 ML"
  },
  {
    "code" : "BR0375387-3",
    "display" : "POLIETILENOGLICOL 400 + PROPILENOGLICOL 3 + 4 MG/ML SOLUÇÃO OFTÁLMICA 15 ML"
  },
  {
    "code" : "BR0352204",
    "display" : "DEXMEDETOMIDINA, CLORIDRATO 100 MCG/ML SOLUÇÃO INJETÁVEL 2 ML"
  },
  {
    "code" : "BR0391324",
    "display" : "HIDROQUINONA +  FLUOCINOLONA + TRETINOÍNA 4 + 0,01 + 0,05 % CREME  15 G"
  },
  {
    "code" : "BR0397450",
    "display" : "MODAFINILA 100 MG COMPRIMIDO"
  },
  {
    "code" : "BR0267206",
    "display" : "DIPIRONA SÓDICA  50 MG/ML SOLUÇÃO ORAL 100 ML"
  },
  {
    "code" : "BR0294774",
    "display" : "ALFAEPOETINA 40000 UI SERINGA 1 ML SOLUÇÃO INJETÁVEL COM SISTEMA DE APLICAÇÃO"
  },
  {
    "code" : "BR0352932",
    "display" : "ÁCIDO SALICÍLICO 270 MG/G GEL 20 G"
  },
  {
    "code" : "BR0318305",
    "display" : "ÁCIDO SALICÍLICO + ÁCIDO LÁTICO 170 MG + 150 MG/ML SOLUÇÃO TÓPICA 15 ML"
  },
  {
    "code" : "BR0274995-2",
    "display" : "FERRIPOLIMALTOSE 100 MG (FERRO III) SOLUÇÃO INJETÁVEL 5 ML"
  },
  {
    "code" : "BR0343644",
    "display" : "AMINOÁCIDOS, ESSENCIAIS E NÃO ESSENCIAIS À 10%, SEM CARBOHIDRATO, SEM ELETRÓLITOS SOLUÇÃO INJETÁVEL"
  },
  {
    "code" : "BR0308736-1",
    "display" : "CETOCONAZOL 2% CREME  20 G"
  },
  {
    "code" : "BR0267164-2",
    "display" : "CLORETO DE POTÁSSIO 60 MG/ML SOLUÇÃO ORAL 150 ML"
  },
  {
    "code" : "BR0412786",
    "display" : "PIRIDOXINA + ÁCIDO FÓLICO + CIANOCOBALAMINA 4 + 0,8 + 0,4 MG COMPRIMIDO"
  },
  {
    "code" : "BR0269069U0097",
    "display" : "ÁCIDO TRICLOROACÉTICO 90 % SOLUÇÃO 30 ML"
  },
  {
    "code" : "BR0293657",
    "display" : "DOBUTAMINA, CLORIDRATO 1 MG/ML SOLUÇÃO INJETÁVEL 250 ML"
  },
  {
    "code" : "BR0352314",
    "display" : "PANTOPRAZOL 40 MG PÓ LIOFILIZADO PARA SOLUÇÃO INJETÁVEL"
  },
  {
    "code" : "BR0272174",
    "display" : "BENZIDAMINA, CLORIDRATO 30 MG/ML SOLUÇÃO ORAL  20 ML"
  },
  {
    "code" : "BR0268973",
    "display" : "REMIFENTANILA, CLORIDRATO 2 MG PÓ LIOF INJ (FR-AMP)"
  },
  {
    "code" : "BR0271990",
    "display" : "CEFUROXIMA 125 MG COMPRIMIDO"
  },
  {
    "code" : "BR0271989",
    "display" : "CEFUROXIMA 500 MG MG COMPRIMIDO"
  },
  {
    "code" : "BR0271987",
    "display" : "CEFUROXIMA 750 MG MG PÓ PARA SOLUÇÃO INJETÁVEL"
  },
  {
    "code" : "BR0272974",
    "display" : "FENOXIMETILPENICILINA POTÁSSICA 1.200.000 UI SOL INJ (FR-AMP)"
  },
  {
    "code" : "BR0412776",
    "display" : "ABIRATERONA, ACETATO 250 MG COMPRIMIDO"
  },
  {
    "code" : "BR0276823",
    "display" : "ANFOTERICINA B 100 MG SOLUÇÃO INJETÁVEL LIPOSSOMAL 20  ML"
  },
  {
    "code" : "BR0268381U0005",
    "display" : "AMICACINA, SULFATO 250 MG/ML SOLUÇÃO INJETÁVEL 1 ML ELENCO ESTADUAL"
  },
  {
    "code" : "BR0268382-2",
    "display" : "AMICACINA, SULFATO 125 MG/ML SOLUÇÃO INJETÁVEL 2 ML"
  },
  {
    "code" : "BR0394263-2",
    "display" : "HIDROXIZINA, CLORIDRATO 2 MG/ML SOLUÇÃO ORAL 120 ML"
  },
  {
    "code" : "BR0394675-2",
    "display" : "SOLUÇÃO SALINA BALANCEADA SOLUÇÃO INJETÁVEL INTRA-OCULAR 500 ML SISTEMA FECHADO"
  },
  {
    "code" : "BR0268295",
    "display" : "ÁCIDO NALIDÍXICO 500 MG COMPRIMIDO"
  },
  {
    "code" : "BR0327563",
    "display" : "AZUL DE TRYPAN 0,1 % SOLUÇÃO INJETÁVEL  1 ML"
  },
  {
    "code" : "BR0299236-1",
    "display" : "DEXPANTENOL 50 MG/G POMADA 20 G"
  },
  {
    "code" : "BR0415027",
    "display" : "PODOFILINA 25 % SUSPENSÃO TÓPICA 20 ML"
  },
  {
    "code" : "BR0268380",
    "display" : "ALPROSTADIL 20 MCG/ML SOLUÇÃO INJETÁVEL 1 ML"
  },
  {
    "code" : "BR0340178-2",
    "display" : "CISATRACURIO, BESILATO 2 MG/ML MG/ML SOLUÇÃO INJETÁVEL 10 ML"
  },
  {
    "code" : "BR0410714",
    "display" : "CLORAL, HIDRATO 160 MG/ML SOLUÇÃO ORAL 100 ML"
  },
  {
    "code" : "BR0266705-3",
    "display" : "BUDESONIDA 100 MCG/DOSE AEROSSOL NASAL 120 DOSES"
  },
  {
    "code" : "BR0266703-1",
    "display" : "BUDESONIDA 100 MCG/DOSE PÓ PARA INALAÇÃO ORAL 100 DOSES"
  },
  {
    "code" : "BR0266703-3",
    "display" : "BUDESONIDA 100 MCG/DOSE PÓ PARA INALAÇÃO ORAL 200 DOSES"
  },
  {
    "code" : "BR0284429",
    "display" : "BECLOMETASONA, DIPROPIONATO + SALBUTAMOL 50 + 100 MCG/DOSE SUSPENSÃO PARA NEBULIZAÇÃO  COM ESPAÇADOR ORAL 200 DOSES"
  },
  {
    "code" : "BR0338332",
    "display" : "ACETATO DE ZINCO 0,5 MEQ/ML SOLUÇÃO INJETÁVEL 2 ML"
  },
  {
    "code" : "BR0270558-3",
    "display" : "ACETILCISTEÍNA 20 MG/ML XAROPE  120 ML"
  },
  {
    "code" : "BR0276662",
    "display" : "CONTRASTE RADIOLÓGICO, A BASE DE SULFATO DE BÁRIO 100 % SUSPENSÃO ORAL  150 ML"
  },
  {
    "code" : "BR0284839",
    "display" : "FOLITROPINA, ALFA RECOMBINANTE 75 UI PÓ LIOF INJ (FR-AMP)"
  },
  {
    "code" : "BR0272843",
    "display" : "SINVASTATINA  5 MG COMPRIMIDO"
  },
  {
    "code" : "BR0340319",
    "display" : "CONTRASTE RADIOLÓGICO, NÃO IÔNICO, À BASE DE IOVERSOL 350MG DE IODO/ SOL INJ (SER PREENC) 125 ML"
  },
  {
    "code" : "BR0276665-2",
    "display" : "CONTRASTE RADIOLÓGICO, À BASE DE IOBITRIDOL, 76,78%  350MG DE IODO/ ML SOL INJ (FR-AMP) 100 ML"
  },
  {
    "code" : "BR0271988",
    "display" : "CEFUROXIMA 250 MG  COMPRIMIDO"
  },
  {
    "code" : "BR0333130-2",
    "display" : "CEFUROXIMA 50 MG/ML SUSPENSÃO ORAL  70 ML"
  },
  {
    "code" : "BR0272217",
    "display" : "DIFENIDRAMINA, CLORIDRATO 50 MG/ML SOLUÇÃO INJETÁVEL 1 ML"
  },
  {
    "code" : "BR0342980-2",
    "display" : "OCTREOTIDA LAR 20 MG PÓ LIOFILIZADO PARA SOLUÇÃO INJETÁVEL ELENCO ESTADUAL"
  },
  {
    "code" : "BR0284435-1",
    "display" : "BETAXOLOL, CLORIDRATO 5 % SOLUÇÃO OFTÁLMICA 0,3 ML ELENCO ESTADUAL"
  },
  {
    "code" : "BR0272150",
    "display" : "BENZOCAÍNA + BENZOXIQUINA + BENZETÔNIO + MENTOL 4,5 + 1,2 + 0,1 + 0,5 MG AEROSSOL 43 G"
  },
  {
    "code" : "BR0353564U0039",
    "display" : "GLICOSE 50 % SOLUÇÃO INJETÁVEL  500 ML SISTEMA FECHADO"
  },
  {
    "code" : "BR0415778",
    "display" : "ALISQUIRENO, HEMIFUMARATO + HIDROCLOROTIAZIDA 150 MG + 12,5 MG COMPRIMIDO"
  },
  {
    "code" : "BR0356453",
    "display" : "TIANEPTINA 12,5 MG DRÁGEA"
  },
  {
    "code" : "BR0412419",
    "display" : "OSELTAMIVIR, FOSFATO 12 MG CÁPSULA"
  },
  {
    "code" : "BR0278430",
    "display" : "ELIXIR PAREGORICO SOLUÇÃO ORAL 30 ML"
  },
  {
    "code" : "BR0268581",
    "display" : "PAMIDRONATO 60 MG PÓ LIOFILIZADO PARA SOLUÇÃO INJETÁVEL"
  },
  {
    "code" : "BR0393781U0042",
    "display" : "DARUNAVIR 150 MG COMPRIMIDO"
  },
  {
    "code" : "BR0276839U0079",
    "display" : "ÁGUA DESTILADA SOLUÇÃO INJETÁVEL 1 L"
  },
  {
    "code" : "BR0276839-7",
    "display" : "ÁGUA DESTILADA SOLUÇÃO INJETÁVEL 2 L"
  },
  {
    "code" : "BR0269943U0144",
    "display" : "ÁLCOOL ETÍLICO 70% GEL 5000 ML"
  },
  {
    "code" : "BR0274149",
    "display" : "ERTAPENEM SÓDICO 1 G PÓ LIOFILIZADO PARA SOLUÇÃO INJETÁVEL"
  },
  {
    "code" : "BR0284840",
    "display" : "FOLITROPINA, ALFA RECOMBINANTE 150 UI PÓ LIOF INJ (FR-AMP OU SER PREENC)"
  },
  {
    "code" : "BR0313689U0004",
    "display" : "FOSFATO DE POTÁSSIO, MONOBÁSICO E DIBÁSICO 2 MEQ/ML SOLUÇÃO INJETÁVEL 10 ML"
  },
  {
    "code" : "BR0316334-3",
    "display" : "CONTRASTE RADIOLÓGICO, NÃO IÔNICO, À BASE DE IOHEXOL 300MG DE IODO ML SOL INJ (FR-AMP) 100 ML"
  },
  {
    "code" : "BR0316335-1",
    "display" : "CONTRASTE RADIOLÓGICO, NÃO IÔNICO, À BASE DE IOHEXOL 350MG DE IODO ML SOL INJ (FR-AMP) 50 ML"
  },
  {
    "code" : "BR0316335-2",
    "display" : "CONTRASTE RADIOLÓGICO, NÃO IÔNICO, À BASE DE IOHEXOL 350MG DE IODO/ SOL INJ (FR-AMP) 100 ML"
  },
  {
    "code" : "BR0280627",
    "display" : "LEVOBUPIVACAINA, CLORIDRATO 0,25 % SOLUÇÃO INJETÁVEL  20 ML"
  },
  {
    "code" : "BR0305264",
    "display" : "LEVOBUPIVACAINA,  CLORIDRATO + EPINEFRINA BITARTARATO 0,5% + 9,1 MCG/ML SOLUÇÃO INJETÁVEL  20 ML"
  },
  {
    "code" : "BR0398707",
    "display" : "BLEOMICINA, SULFATO 15 UI PÓ LIOFILIZADO"
  },
  {
    "code" : "BR0413882",
    "display" : "ALENDRONATO DE SÓDIO + COLECALCIFEROL 70 MG + 5.600 UI COMPRIMIDO"
  },
  {
    "code" : "BR0269073-2",
    "display" : "ÁCIDO TRICLOROACÉTICO 80 % SOLUÇÃO 20 ML"
  },
  {
    "code" : "BR0284458-1",
    "display" : "CLOBETASOL, PROPIONATO 0,5 MG/G CREME  30 G"
  },
  {
    "code" : "BR0272338",
    "display" : "PIRIDOXINA, CLORIDRATO 300 MG COMPRIMIDO"
  },
  {
    "code" : "BR0268553",
    "display" : "SUFENTANILA, CITRATO 50 MCG/ML SOLUÇÃO INJETÁVEL  1 ML"
  },
  {
    "code" : "BR0328959",
    "display" : "DANTROLENO SODICO 25 MG CÁPSULA"
  },
  {
    "code" : "BR0269843U0165",
    "display" : "LIDOCAÍNA, CLORIDRATO 20 MG/ML SOLUÇÃO INJETÁVEL 1,8 ML"
  },
  {
    "code" : "BR0278341",
    "display" : "ÓLEO DE BORRAGEM (ÁCIDO LINOLÊNICO + ÁCIDO LINOLÊICO + ÁCIDO OLÊICO) + VITAMINA E 1000 + 3 MG CÁPSULA"
  },
  {
    "code" : "BR0389637-1",
    "display" : "FEXOFENADINA, CLORIDRATO 6 MG/ML SOLUÇÃO ORAL  60 ML"
  },
  {
    "code" : "BR0305487",
    "display" : "MEBEVERINA, CLORIDRATO 200 MG CAP LIBERAÇÃO CONTROLADA"
  },
  {
    "code" : "BR0415509",
    "display" : "TAFLUPROSTA 15 MCG/ML SOLUÇÃO OFTÁLMICA 0,03 ML"
  },
  {
    "code" : "BR0415781",
    "display" : "ESTRADIOL, VALERATO + NORETISTERONA, ENANTATO 1 + 0,5 MG COMPRIMIDO"
  },
  {
    "code" : "BR0412375",
    "display" : "OSELTAMIVIR, FOSFATO 25 MG CÁPSULA"
  },
  {
    "code" : "BR0390354U0312",
    "display" : "FOSAMPRENAVIR CÁLCICO 50 MG/ML SUSPENSÃO ORAL  225 ML"
  },
  {
    "code" : "BR0345783-2",
    "display" : "URÉIA 100 MG/G CREME  120 ML"
  },
  {
    "code" : "BR0397544",
    "display" : "FOLITROPINA, ALFA RECOMBINANTE (66MCG) 900 UI SOLUÇÃO INJETÁVEL COM SISTEMA DE APLICAÇÃO 1,5 ML"
  },
  {
    "code" : "BR0284838",
    "display" : "FOLITROPINA, ALFA RECOMBINANTE 37,5 UI PÓ LIOF INJ (FR-AMP)"
  },
  {
    "code" : "BR0276665-1",
    "display" : "CONTRASTE RADIOLÓGICO, À BASE DE IOBITRIDOL, 76,78%  350MG DE IODO/ ML SOL INJ (FR-AMP) 50 ML"
  },
  {
    "code" : "BR0276665-3",
    "display" : "CONTRASTE RADIOLÓGICO, À BASE DE IOBITRIDOL, 76,78%  350MG DE IODO/ ML SOL INJ (FR-AMP) 500 ML"
  },
  {
    "code" : "BR0316334-1",
    "display" : "CONTRASTE RADIOLÓGICO, NÃO IÔNICO, À BASE DE IOHEXOL 300MG DE IODO ML SOL INJ (FR-AMP) 20 ML"
  },
  {
    "code" : "BR0316334-2",
    "display" : "CONTRASTE RADIOLÓGICO, NÃO IÔNICO, À BASE DE IOHEXOL 300MG DE IODO ML SOL INJ (FR-AMP) 50 ML"
  },
  {
    "code" : "BR0268472",
    "display" : "LEVOBUPIVACAINA, CLORIDRATO ISOBÁRICA 0,5 % SOLUÇÃO INJETÁVEL  4 ML"
  },
  {
    "code" : "BR0288785",
    "display" : "LEVOBUPIVACAINA, CLORIDRATO 0,75 % SOLUÇÃO INJETÁVEL  20"
  },
  {
    "code" : "BR0272971",
    "display" : "FENOXIMETILPENICILINA POTÁSSICA 500.000 UI COMPRIMIDO"
  },
  {
    "code" : "BR0284435-3",
    "display" : "BETAXOLOL, CLORIDRATO 5 % SOLUÇÃO OFTÁLMICA 15 ML ELENCO ESTADUAL"
  },
  {
    "code" : "BR0269070-1",
    "display" : "ÁCIDO TRICLOROACÉTICO 30 % SOLUÇÃO 20 ML"
  },
  {
    "code" : "BR0270440",
    "display" : "MELFALANA 2 MG COMPRIMIDO"
  },
  {
    "code" : "BR0304845",
    "display" : "NITROGLICERINA 50 MG ADESIVO TRANSDÉRMICO"
  },
  {
    "code" : "BR0328960",
    "display" : "DANTROLENO SODICO 100 MG CÁPSULA"
  },
  {
    "code" : "BR0268222U0103",
    "display" : "BICARBONATO DE SÓDIO 8,4 % SOLUÇÃO INJETÁVEL 500 ML"
  },
  {
    "code" : "BR0397600",
    "display" : "SITAGLIPTINA, FOSFATO + METFORMINA, CLORIDRATO 50 + 1000 MG COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0272411",
    "display" : "NAFAZOLINA, ASSOC. COM FENOLSULFONATO DE ZINCO E BERBERINA 0,5 + 1 + 0,025 MG/ML SOLUÇÃO OFTÁLMICA 24 ML"
  },
  {
    "code" : "BR0412432",
    "display" : "CLORETO DE SÓDIO 17,55% SOLUÇÃO INJETÁVEL 10 ML"
  },
  {
    "code" : "BR0412833",
    "display" : "TADALAFILA 5 MG COMPRIMIDO"
  },
  {
    "code" : "BR0272382",
    "display" : "VENLAFAXINA, CLORIDRATO 75 MG COMPRIMIDO"
  },
  {
    "code" : "BR0321804",
    "display" : "TOPOTECANA 4 MG PÓ LIOFILIZADO"
  },
  {
    "code" : "BR0412965",
    "display" : "SIMETICONA 75 MG/ML SOLUÇÃO ORAL 15 ML"
  },
  {
    "code" : "BR0399161",
    "display" : "CLEMASTINA, FUMARATO DE + DEXAMETASONA, ACETATO DE 1 + 0,5 MG/G CREME  20 G"
  },
  {
    "code" : "BR0276774U0004",
    "display" : "ACETATO DE SODIO 2 MEQ/ML SOLUÇÃO INJETÁVEL 10 ML"
  },
  {
    "code" : "BR0271099",
    "display" : "AMOXICILINA + CLAVULANATO DE POTÁSSIO 500 MG + 100 MG PÓ PARA SOLUÇÃO INJETÁVEL 10 ML"
  },
  {
    "code" : "BR0268972",
    "display" : "REMIFENTANILA, CLORIDRATO 5 MG PÓ LIOF INJ (FR-AMP)"
  },
  {
    "code" : "BR0280632",
    "display" : "LEVOBUPIVACAINA, CLORIDRATO + EPINEFRINA  0,25% + 1/200.000 SOLUÇÃO INJETÁVEL"
  },
  {
    "code" : "BR0352245",
    "display" : "SILDENAFILA 100 MG COMPRIMIDO"
  },
  {
    "code" : "BR0268094",
    "display" : "METADONA, CLORIDRATO 10 MG/ML SOLUÇÃO INJETÁVEL 1 ML"
  },
  {
    "code" : "BR0414456",
    "display" : "BENZOATO DE SÓDIO 200 MG/ML XAROPE  450 ML"
  },
  {
    "code" : "BR0414657",
    "display" : "TOBRAMICINA, SULFATO 75 MG/ML SOLUÇÃO PARA INALAÇÃO 4 ML ELENCO ESTADUAL"
  },
  {
    "code" : "BR0286359-1",
    "display" : "ÁCIDO TRICLOROACÉTICO 60 % SOLUÇÃO 20 ML"
  },
  {
    "code" : "BR0292263",
    "display" : "MORFINA, SULFATO 30 MG COMPRIMIDO DE LIBERAÇÃO CONTROLADA"
  },
  {
    "code" : "BR0271654",
    "display" : "MEGESTROL, ACETATO 160 MG COMPRIMIDO"
  },
  {
    "code" : "BR0395721U0547",
    "display" : "CARVÃO VEGETAL ATIVADO PÓ 25 G"
  },
  {
    "code" : "BR0414847",
    "display" : "IODENAFILA, CARBONATO 80 MG COMPRIMIDO"
  },
  {
    "code" : "BR0412091",
    "display" : "RIVAROXABANA 20 MG COMPRIMIDO"
  },
  {
    "code" : "BR0295266",
    "display" : "GLICEROFOSFATO DE SODIO 216 MG/ML SUSPENSÃO INJETÁVEL 20 ML"
  },
  {
    "code" : "BR0273483",
    "display" : "MITOTANO 500 MG COMPRIMIDO"
  },
  {
    "code" : "BR0270020-1",
    "display" : "CLORETO DE BENZALCÔNIO+ CLORETO DE SÓDIO 0,1 + 9 MG/ML SOLUÇÃO NASAL 20 ML"
  },
  {
    "code" : "BR0268381U0009",
    "display" : "AMICACINA, SULFATO 250 MG/ ML SOLUÇÃO INJETÁVEL 2 ML ELENCO ESTADUAL"
  },
  {
    "code" : "BR0292399-1",
    "display" : "FITOMENADIONA 10 MG/ML SOLUÇÃO INJETÁVEL 1 ML IM"
  },
  {
    "code" : "BR0328362U0042",
    "display" : "TRATAMENTO MULTIBACILAR INFANTIL COMPRIMIDO"
  },
  {
    "code" : "BR0268349",
    "display" : "NELFINAVIR, MESILATO 250 MG COMPRIMIDO"
  },
  {
    "code" : "BR0272050",
    "display" : "CLORDIAZEPÓXIDO 10 MG  COMPRIMIDO"
  },
  {
    "code" : "BR0344289",
    "display" : "MULTIVITAMINAS (A, C, D, E, COMPLEXO B) SOLUÇÃO ORAL 20 ML"
  },
  {
    "code" : "BR0328363U0032",
    "display" : "TRATAMENTO PAUCIBACILAR INFANTIL COMPRIMIDO"
  },
  {
    "code" : "BR0292402",
    "display" : "AMINOFILINA 24 MG/ML SOLUÇÃO INJETÁVEL 10 ML"
  },
  {
    "code" : "BR0268082",
    "display" : "ATORVASTATINA CÁLCICA 40 MG COMPRIMIDO"
  },
  {
    "code" : "INATIVO 31",
    "display" : "INATIVO-GLICOSE 5 % SOLUÇÃO INJETÁVEL  1000 ML"
  },
  {
    "code" : "BR0267292",
    "display" : "IMIPRAMINA, CLORIDRATO 25 MG COMPRIMIDO"
  },
  {
    "code" : "BR0335100",
    "display" : "CLORANFENICOL, SUCCINATO SÓDICO 1000 MG  PÓ PARA SOLUÇÃO INJETÁVEL"
  },
  {
    "code" : "BR0269852U0086",
    "display" : "LIDOCAÍNA, CLORIDRATO + EPINEFRINA 20 MG/ML + 1:200.000 UI SOLUÇÃO INJETÁVEL 20 ML"
  },
  {
    "code" : "BR0269571-2",
    "display" : "PROXIMETACAÍNA, CLORIDRATO 0,5 % SOLUÇÃO OFTÁLMICA 15 ML"
  },
  {
    "code" : "BR0272579",
    "display" : "DORZOLAMIDA + TIMOLOL 2 + 0,5 % SOLUÇÃO OFTÁLMICA 5 ML ELENCO ESTADUAL"
  },
  {
    "code" : "BR0388556",
    "display" : "ORNITINA, ASPARTATO 3.000 MG GRANULADO 5 G"
  },
  {
    "code" : "BR0279493-1",
    "display" : "ÓXIDO DE ZINCO + COLECALCIFEROL + RETINOL 150 + 5000 + 900 MG + UI + UI/G POMADA 20 G"
  },
  {
    "code" : "BR0269988U0110",
    "display" : "CLARITROMICINA 50 MG/ML PÓ PARA SUSPENSÃO 60 ML"
  },
  {
    "code" : "BR0271609-2",
    "display" : "NORTRIPTILINA, CLORIDRATO 10 MG COMPRIMIDO"
  },
  {
    "code" : "BR0348654U0013",
    "display" : "SORO ANTITETÂNICO SOLUÇÃO INJETÁVEL 5 ML"
  },
  {
    "code" : "BR0271157U0137",
    "display" : "INSULINA HUMANA NPH 100 UI/ML SUSPENSÃO INJETÁVEL 3 ML"
  },
  {
    "code" : "BR0306145",
    "display" : "VALSARTANA 160 MG COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0294550",
    "display" : "UBIDECARENONA (COENZIMA Q10) 20 MG/ML XAROPE  300 ML"
  },
  {
    "code" : "BR0267618U0042",
    "display" : "CARBAMAZEPINA  200 MG COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0272454U0062",
    "display" : "CARBAMAZEPINA  20 MG/ML SUSPENSÃO ORAL  100 ML ELENCO ESTADUAL"
  },
  {
    "code" : "BR0296876U0042",
    "display" : "CARBONATO DE CÁLCIO + COLECALCIFEROL  500 MG + 400 UI COMPRIMIDO"
  },
  {
    "code" : "BR0335103U0110",
    "display" : "CLORANFENICOL 25 MG/ML SUSPENSÃO ORAL  60 ML"
  },
  {
    "code" : "BR0267645U0042",
    "display" : "DEXCLORFENIRAMINA, MALEATO 2 MG COMPRIMIDO"
  },
  {
    "code" : "BR0267646U0067",
    "display" : "DEXCLORFENIRAMINA, MALEATO 0,4 MG/ML SOLUÇÃO ORAL 120 ML"
  },
  {
    "code" : "BR0267205U0075",
    "display" : "DIPIRONA SÓDICA  500 MG/ML SOLUÇÃO ORAL 15 ML"
  },
  {
    "code" : "BR0343494U0042",
    "display" : "ESPIRAMICINA (1,5 MUI) 500 MG COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0267657U0042",
    "display" : "FENITOÍNA SÓDICA  100 MG COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0267671U0042",
    "display" : "GLIBENCLAMIDA 5 MG COMPRIMIDO"
  },
  {
    "code" : "BR0273116U0042",
    "display" : "GLICLAZIDA 30 MG COMPRIMIDO DE LIBERAÇÃO PROLONGADA"
  },
  {
    "code" : "BR0292195U0086",
    "display" : "HALOPERIDOL 2 MG/ML SOLUÇÃO ORAL 20 ML"
  },
  {
    "code" : "BR0373910-1",
    "display" : "HIPROMELOSE 2 MG/ML SOLUÇÃO OFTÁLMICA 2 ML"
  },
  {
    "code" : "BR0270126U0042",
    "display" : "LEVODOPA + BENSERAZIDA  200 + 50 MG COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0270129U0042",
    "display" : "LEVODOPA + CARBIDOPA  200 + 50  MG COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0273467U0110",
    "display" : "LORATADINA 1 MG/ML XAROPE  60 ML"
  },
  {
    "code" : "BR0267692",
    "display" : "MEBENDAZOL 100 MG COMPRIMIDO"
  },
  {
    "code" : "BR0292228U0005",
    "display" : "MEDROXIPROGESTERONA, ACETATO 150 MG/ML SOLUÇÃO INJETÁVEL 1 ML"
  },
  {
    "code" : "BR0267690U0042",
    "display" : "METFORMINA, CLORIDRATO 500 MG COMPRIMIDO"
  },
  {
    "code" : "BR0267312U0042",
    "display" : "METOCLOPRAMIDA, CLORIDRATO 10 MG COMPRIMIDO"
  },
  {
    "code" : "BR0267311U0063",
    "display" : "METOCLOPRAMIDA, CLORIDRATO 4 MG/ML SOLUÇÃO ORAL 10 ML"
  },
  {
    "code" : "BR0273703U0042",
    "display" : "NAPROXENO 500 MG COMP GRUPO 2"
  },
  {
    "code" : "BR0309437",
    "display" : "TRAMADOL, CLORIDRATO 100 MG CÁPSULA DE LIBERAÇÃO CONTROLADA"
  },
  {
    "code" : "BR0278655",
    "display" : "SULFACETAMIDA+TRIETANOLAMINA 74 MG + 21 MG/G POMADA 50 MG"
  },
  {
    "code" : "BR0426668U0118",
    "display" : "PALIVIZUMABE 50 MG PÓ LIOF INJ (FR-AMP) 1 ML"
  },
  {
    "code" : "BR0429055",
    "display" : "DOXAZOSINA + FINASTERIDA 5 MG + 2 MG CÁPSULA"
  },
  {
    "code" : "BR0345300",
    "display" : "METRONIDAZOL 100 MG/G CREME VAGINAL  50 G"
  },
  {
    "code" : "BR0349475",
    "display" : "METILA + ESS. TEREBENTINA + CÂNFORA + MENTOL 0,02 ML + 0,05 ML + 30 MG + 5 MG/G POMADA 30 G"
  },
  {
    "code" : "BR0383409",
    "display" : "CARMELOSE SÓDICA + GLICEROL 5+9 MG/ML SOLUÇÃO OFTÁLMICA 0,4 ML"
  },
  {
    "code" : "284901",
    "display" : "INATIVO- AMINOBENZOATO DE POTÁSSIO 500 MG COMPRIMIDO"
  },
  {
    "code" : "BR0411533U0238",
    "display" : "VACINA HUMANA, ADSORVIDA, DTP + HEPATITE B + HAEMOPHILUS INFLUENZAE TIPO B, PENTAVALENTE, SUSPENSÃO INJETÁVEL 0,5 ML SOLUÇÃO INJETÁVEL 0,5 ML"
  },
  {
    "code" : "BR0363068U0238",
    "display" : "VACINA HUMANA, POLIOMIELITE TIPOS I,II E III, INATIVADA, 40 UD + 8 UD + 32 UD/DOSE, SUSPENSÃO INJETÁVEL 0,5 ML SOLUÇÃO INJETÁVEL 5 ML"
  },
  {
    "code" : "BR0308884U0110",
    "display" : "SULFAMETOXAZOL + TRIMETOPRIMA  40 + 8 MG/ML SUSPENSÃO ORAL  60 ML"
  },
  {
    "code" : "BR0425824",
    "display" : "UBIDECARENONA (COENZIMA Q10) 200MG CÁPSULA"
  },
  {
    "code" : "BR0353334",
    "display" : "PEGVISOMANTO 10 MG PÓ LIOF INJ (AMP)"
  },
  {
    "code" : "BR0353336",
    "display" : "PEGVISOMANTO 15 MG PÓ LIOF INJ (AMP)"
  },
  {
    "code" : "BR0343604",
    "display" : "URÉIA 200 MG/G CREME  200 G"
  },
  {
    "code" : "BR0431098",
    "display" : "COLECALCIFEROL (VITAMINA D3) 50.000 UI CÁPSULA"
  },
  {
    "code" : "BR0431097",
    "display" : "COLECALCIFEROL (VITAMINA D3) 7.000 UI CÁPSULA"
  },
  {
    "code" : "BR0431163",
    "display" : "PODOFILINA 20 % SOLUÇÃO TÓPICA 100 ML"
  },
  {
    "code" : "BR0268451",
    "display" : "DOXORRUBICINA, CLORIDRATO 50 MG PÓ LIOFILIZADO PARA SOLUÇÃO INJETÁVEL"
  },
  {
    "code" : "BR0340122",
    "display" : "VARENICLINA, TARTARATO 0,5 + 1 MG COMPRIMIDO 11 + 154 COMPRIMIDOS"
  },
  {
    "code" : "BR0275475",
    "display" : "DIPIRONA SÓDICA + ADIFENINA + PROMETAZINA 500 + 10 + 5 MG/1,5ML SOLUÇÃO ORAL 10 ML"
  },
  {
    "code" : "BR0431599U0042",
    "display" : "SOFOSBUVIR 400 MG COMP REV GRUPO 1.A"
  },
  {
    "code" : "BR0433975",
    "display" : "XAROPE DE CHAMBÁ ESPECIALMENTE MANIPULADO 5 % XAROPE  100 ML"
  },
  {
    "code" : "BR0433022",
    "display" : "SULFADIAZINA 150 MG/ML SOL ORAL (FR) 60 ML"
  },
  {
    "code" : "BR0367512",
    "display" : "PIRIMETAMINA 5 MG/ML SOL ORAL (FR) 60 ML"
  },
  {
    "code" : "BR0434091",
    "display" : "ÁCIDO FOLÍNICO (FOLINATO DE CÁLCIO) 7,5 MG/ML SOLUÇÃO ORAL 60 ML"
  },
  {
    "code" : "BR0434051U0030",
    "display" : "SCHINUS TEREBENTHIFOLIUS (AROEIRA) 7% CREME VAGINAL  60 G"
  },
  {
    "code" : "BR0430083",
    "display" : "ROSMARINUS OFFICINALIS (ALECRIM) 20 % TINTURA 30 ML"
  },
  {
    "code" : "BR0357788",
    "display" : "MEPIVACAÍNA, CLORIDRATO 30 MG/ML (3%) SOL INJ (FR) 1,8 ML"
  },
  {
    "code" : "BR0386959",
    "display" : "PARACETAMOL  32 MG/ML SUSPENSÃO ORAL  60 ML"
  },
  {
    "code" : "BR0424169",
    "display" : "LEVANLODIPINO, BESILATO 5,0 MG COMPRIMIDO"
  },
  {
    "code" : "BR0368779U0074",
    "display" : "MIKANIA GLOMERATA (GUACO) 117,6 MG/ML XAROPE  150 ML"
  },
  {
    "code" : "BR0432926",
    "display" : "MOMETASONA, FUROATO + FORMOTEROL, FUMARATO 100 MCG + 50 MCG PÓ PARA INALAÇÃO ORAL 120 DOSES"
  },
  {
    "code" : "BR0434505",
    "display" : "CARVÃO VEGETAL ATIVADO 250 MG COMP"
  },
  {
    "code" : "BR0270602-1",
    "display" : "BETAMETASONA, VALERATO + GENTAMICINA, SULFATO + TOLNAFTATO + CLIOQUINOL 0,5 + 1 + 10 + 10 MG/G CREME  15 G"
  },
  {
    "code" : "BR0276657U0042",
    "display" : "METOPROLOL, SUCCINATO 50 MG COMPRIMIDO DE LIBERAÇÃO PROLONGADA"
  },
  {
    "code" : "BR0366913",
    "display" : "GLICOSE + CLORETO DE SÓDIO 5 + 0,9 % SOLUÇÃO INJETÁVEL  500 ML SISTEMA FECHADO"
  },
  {
    "code" : "BR0326613",
    "display" : "FERRO QUELATO GLICINATO 500 MG COMPRIMIDO MASTIGÁVEL"
  },
  {
    "code" : "BR0266765U0118",
    "display" : "ALFAINTERFERONA 2B 5.000.000 UI PÓ LIOF INJ (FR-AMP) GRUPO 1.A"
  },
  {
    "code" : "BR0272826U0042",
    "display" : "PRAMIPEXOL 1 MG COMP GRUPO 1.A"
  },
  {
    "code" : "BR0268147U0042",
    "display" : "PRAVASTATINA 10 MG COMP GRUPO 2"
  },
  {
    "code" : "BR0277435U0135",
    "display" : "BETAINTERFERONA 1A 6.000.000 UI (22MCG) SOL INJ (SER PREENC) GRUPO 1.A"
  },
  {
    "code" : "BR0304871U0005",
    "display" : "MORFINA 10 MG/ML SOL INJ (AMP) 1 ML GRUPO 2"
  },
  {
    "code" : "BR0292262U0041",
    "display" : "MORFINA 100 MG CAP LIBERAÇÃO CONTROLADA GRUPO 2"
  },
  {
    "code" : "BR0342979U0118",
    "display" : "OCTREOTIDA LAR 10 MG PÓ P/ SUSP INJ (FR-AMP) GRUPO 1.B"
  },
  {
    "code" : "BR0271621U0042",
    "display" : "OLANZAPINA 10 MG COMP GRUPO 1.A"
  },
  {
    "code" : "BR0352397U0041",
    "display" : "BUDESONIDA 200 MCG CAP INAL GRUPO 2"
  },
  {
    "code" : "BR0305649U0041",
    "display" : "FORMOTEROL + BUDESONIDA 12 + 400 MCG CAP INAL GRUPO 2"
  },
  {
    "code" : "BR0609095U0109",
    "display" : "FORMOTEROL + BUDESONIDA 6 + 200 MCG PÓ INAL (FR DE 60 DOSES) GRUPO 2"
  },
  {
    "code" : "BR0268097U0041",
    "display" : "TACROLIMO 5 MG CAP GRUPO 1.A"
  },
  {
    "code" : "BR0272849U0042",
    "display" : "TOPIRAMATO 25 MG COMP GRUPO 2"
  },
  {
    "code" : "BR0268106U0041",
    "display" : "GABAPENTINA 400 MG CAP GRUPO 2"
  },
  {
    "code" : "BR0342682U0135",
    "display" : "TRIPTORRELINA 3,75 MG SUSP INJ (FR-AMP) GRUPO 1.B"
  },
  {
    "code" : "BR0340783U0087",
    "display" : "HIDRÓXIDO DE ALUMÍNIO 61,5 MG SUSP ORAL (FR) 240 ML GRUPO 2"
  },
  {
    "code" : "BR0290947",
    "display" : "AMINOÁCIDOS (LISINA 75MG, TREONINA 53MG, TRIPTOFANO 23MG, HISTIDINA 38MG, TIROSINA 30MG) + ANÁLOGOS (ISOLEUCINA 67MG, LEUCINA 101MG, VALINA 85MG, ALFA-HIDROXI-ANÁLOGO DA METIONINA 59MG) TABLETE"
  },
  {
    "code" : "BR0340419",
    "display" : "DIIDROERGOTAMINA + DIPIRONA + CAFEÍNA 1 + 350 + 100 MG COMPRIMIDO"
  },
  {
    "code" : "BR0292409",
    "display" : "BASILIXIMABE 20 MG PÓ LIOFILIZADO"
  },
  {
    "code" : "BR0295624",
    "display" : "ÁCIDO FUSÍDICO 20 MG/G CREME  10 G"
  },
  {
    "code" : "INATIVO 28",
    "display" : "INATIVO- OXIBUTININA, CLORIDRATO 1 MG/ML SOLUÇÃO ORAL 120 (INATIVO) ML ELENCO ESTADUAL"
  },
  {
    "code" : "BR0274186",
    "display" : "ESOMEPRAZOL, MAGNÉSIO 20 MG CÁPSULA"
  },
  {
    "code" : "BR0323260",
    "display" : "DOXORRUBICINA, CLORIDRATO, LIPOSSOMAL PEGUILATO 2 MG/ML SOLUÇÃO INJETÁVEL 10 ML"
  },
  {
    "code" : "BR0332917",
    "display" : "VASOPRESSINA 20 UI/ML SOLUÇÃO INJETÁVEL  1 ML"
  },
  {
    "code" : "BR0399988",
    "display" : "FERRIPOLIMALTOSE + ÁCIDO FÓLICO 100 + 0,35 MG COMPRIMIDO MASTIGÁVEL"
  },
  {
    "code" : "BR0331308",
    "display" : "ANLODIPINO, BESILATO + ATENOLOL 5 MG + 50 MG CÁPSULA"
  },
  {
    "code" : "BR0400877",
    "display" : "ESTRADIOL, VALERATO + LEVONORGESTREL DRÁGEA 2 MG + DRÁGEA 0,25 + 2 MG DRÁGEA"
  },
  {
    "code" : "BR0271556U0063",
    "display" : "MIDAZOLAM, CLORIDRATO 2 MG/ML SOLUÇÃO ORAL 10 ML"
  },
  {
    "code" : "BR0293803",
    "display" : "AMOXICILINA + SULBACTAM 875 MG + 125 MG COMPRIMIDO"
  },
  {
    "code" : "BR0268077U0042",
    "display" : "CIPROTERONA 50 MG COMP GRUPO 1.B"
  },
  {
    "code" : "BR0325836U0042",
    "display" : "DEFERASIROX 250 MG COMP GRUPO 1.A"
  },
  {
    "code" : "BR0272786U0042",
    "display" : "DONEPEZILA 10 MG COMP GRUPO 1.A"
  },
  {
    "code" : "BR0324414U0042",
    "display" : "LAMOTRIGINA 50 MG COMP GRUPO 2"
  },
  {
    "code" : "BR0305257U0118",
    "display" : "LEUPRORRELINA 3,75 MG PÓ LIOF INJ (FR-AMP) GRUPO 1.B"
  },
  {
    "code" : "BR0268038U0042",
    "display" : "LOVASTATINA 20 MG COMP GRUPO 2"
  },
  {
    "code" : "BR0305260",
    "display" : "LEUPRORRELINA 11,25 MG PÓ LIOF INJ (SER PREENC) ELENCO ESTADUAL"
  },
  {
    "code" : "BR0267585U0109",
    "display" : "BECLOMETASONA, DIPROPIONATO 400 MCG CÁPSULA  60 DOSES ELENCO ESTADUAL"
  },
  {
    "code" : "BR0272088-4",
    "display" : "SULFADIAZINA DE PRATA + NITRATO DE CÉRIO 1 + 0,4 % CREME  30 G"
  },
  {
    "code" : "BR0389957-2",
    "display" : "DIPIRONA SÓDICA + ESCOPOLAMINA + HIOSCIAMINA + HOMATROPINA  300  MG + 6,5 MCG + 104 MCG + 1 MG SOLUÇÃO 15 ML"
  },
  {
    "code" : "BR0277319-1",
    "display" : "PERÓXIDO DE HIDROGÊNIO (ÁGUA OXIGENADA 10 VOL) 3 %  SOLUÇÃO 100 ML"
  },
  {
    "code" : "BR0308373",
    "display" : "FLUCITOSINA 500 MG COMPRIMIDO"
  },
  {
    "code" : "BR0431319",
    "display" : "CETILPIRIDÍNIO + BENZOCAÍNA 0,5 MG/ML + 4 MG/ML SOLUÇÃO 100  ML"
  },
  {
    "code" : "BR0431312",
    "display" : "LEVOTIROXINA SÓDICA 137 MCG COMPRIMIDO"
  },
  {
    "code" : "BR0431349",
    "display" : "POLIVITAMINICO + POLIMINERAIS + LISINA XAROPE  240 ML"
  },
  {
    "code" : "BR0296389",
    "display" : "CETOPROFENO 1MG/ML XAROPE  150 ML"
  },
  {
    "code" : "BR0431716",
    "display" : "NAPROXENO + ESOMEPRAZOL MAGNÉSIO TRI-HIDRATADO 500 MG + 20 MG COMPRIMIDO"
  },
  {
    "code" : "BR0417032",
    "display" : "CEFALEXINA 1000 MG  COMPRIMIDO"
  },
  {
    "code" : "BR0352245E",
    "display" : "SILDENAFILA 100 MG COMP ELENCO ESTADUAL"
  },
  {
    "code" : "BR0396414U0541",
    "display" : "PLANTAGO OVATA (PSYLLIUM) PÓ PARA DISPERSÃO ORAL 5,00 G"
  },
  {
    "code" : "BR0305935-3",
    "display" : "PROPOFOL 10 MG/ML EMULSÃO INJETÁVEL 50 ML"
  },
  {
    "code" : "BR0434115",
    "display" : "MORORO 20% TINTURA 30  ML"
  },
  {
    "code" : "BR0434125",
    "display" : "COLECALCIFEROL  1.000UI COMP REV"
  },
  {
    "code" : "BR0375656",
    "display" : "NO MÍNIMO 4 MICROORGANISMOS, LACTOBACILUS: ACIDOPHILUS E CASEI, BIFIDOBACTERIUM 100 MILHÕES A 1 BILHÃO UFC + FOS PÓ 6 G"
  },
  {
    "code" : "BR0342616",
    "display" : "LIDOCAÍNA, CLORIDRATO + FENILEFRINA 20 MG + 0,4 MG/ML SOLUÇÃO INJETÁVEL 1,8 ML"
  },
  {
    "code" : "BR0434406",
    "display" : "LACOSAMIDA 100 MG COMPRIMIDO DE LIBERAÇÃO CONTROLADA"
  },
  {
    "code" : "BR0433257",
    "display" : "HIDRÓXIDO DE ALUMÍNIO 60 MG/ML SUSPENSÃO ORAL  150 ML"
  },
  {
    "code" : "BR0416618",
    "display" : "CLORANFENICOL 50 MG/ML SUSPENSÃO ORAL  100 ML"
  },
  {
    "code" : "BR0267643-1",
    "display" : "DEXAMETASONA  1 % CREME  20 G"
  },
  {
    "code" : "BR0403023",
    "display" : "SALBUTAMOL, SULFATO 1 MG/ML SOLUÇÃO PARA NEBULIZAÇÃO 2,5 ML"
  },
  {
    "code" : "BR0434765U0234",
    "display" : "ABATACEPTE 125 MG/ML SOL INJ (SER PREENC) 1 ML GRUPO 1.A"
  },
  {
    "code" : "BR0430402",
    "display" : "TRASTUZUMABE, ENTANSINA 160 MG PÓ LIOFILIZADO PARA SUSPENSÃO INJETÁVEL"
  },
  {
    "code" : "BR0436703",
    "display" : "GATIFLOXACINO+PREDNISOLONA 3MG/ML + 10MG/ML MG/ML SOLUÇÃO OFTÁLMICA"
  },
  {
    "code" : "BR0436705-1",
    "display" : "BUPRENORFINA 5 MG ADESIVO TRANSDÉRMICO"
  },
  {
    "code" : "BR0435950",
    "display" : "TELMISARTANA + ANLODIPINO 40 + 5   MG COMPRIMIDO"
  },
  {
    "code" : "BR0436705-3",
    "display" : "BUPRENORFINA 20 MG ADESIVO TRANSDÉRMICO"
  },
  {
    "code" : "BR0331309",
    "display" : "ANLODIPINO, BESILATO + ATENOLOL 5 + 25 MG CÁPSULA"
  },
  {
    "code" : "BR0428744-3",
    "display" : "COLECALCIFEROL 2.000 UI/ML SOLUÇÃO ORAL 100 ML"
  },
  {
    "code" : "BR0395558-1",
    "display" : "ÁCIDO SALICÍLICO 20 MG/G POMADA 30 G"
  },
  {
    "code" : "BR0272980",
    "display" : "FENAZOPIRIDINA, CLORIDRATO 200 MG DRÁGEA"
  },
  {
    "code" : "BR0269817",
    "display" : "TERBUTALINA 0,3 MG/ML XAROPE  100 ML"
  },
  {
    "code" : "BR0358754",
    "display" : "MISOPROSTOL  100 MCG COMPRIMIDO"
  },
  {
    "code" : "BR0268478",
    "display" : "FLUORURACILA 50 MG/ML SOLUÇÃO INJETÁVEL  10 ML"
  },
  {
    "code" : "BR0395721U0317",
    "display" : "CARVÃO VEGETAL ATIVADO PÓ 250 G"
  },
  {
    "code" : "BR0335106",
    "display" : "CLORANFENICOL + LIDOCAÍNA, CLORIDRATO 25 + 30 MG/ML SOLUÇÃO OTOLÓGICA 10 ML"
  },
  {
    "code" : "BR0291690",
    "display" : "REPAGLINIDA 0,5 MG COMPRIMIDO"
  },
  {
    "code" : "BR0393161",
    "display" : "LEVOTIROXINA SÓDICA 38 MCG COMPRIMIDO"
  },
  {
    "code" : "BR0272834",
    "display" : "RALOXIFENO, CLORIDRATO 60 MG COMPRIMIDO"
  },
  {
    "code" : "BR0275436",
    "display" : "SUCRALFATO 1 G COMPRIMIDO"
  },
  {
    "code" : "BR0399066U0041",
    "display" : "CYNARA SCOLYMUS (ALCACHOFRA) 500 MG CÁPSULA"
  },
  {
    "code" : "BR0268130-2",
    "display" : "LEVOMEPROMAZINA, MALEATO 40 MG/ML SOLUÇÃO ORAL 20 ML"
  },
  {
    "code" : "BR0292238U0042",
    "display" : "MESALAZINA 800 MG COMP GRUPO 2"
  },
  {
    "code" : "BR0390006U0042",
    "display" : "QUETIAPINA 300 MG COMP GRUPO 1.A"
  },
  {
    "code" : "BR0369175U0052",
    "display" : "MESALAZINA 1 G ENEMA  100 ML GRUPO 2"
  },
  {
    "code" : "BR0268092U0042",
    "display" : "METADONA 5 MG COMP GRUPO 2"
  },
  {
    "code" : "BR0270127U0041",
    "display" : "LEVODOPA + BENSERAZIDA  100 + 25 MG CÁPSULA  ELENCO ESTADUAL"
  },
  {
    "code" : "BR0390007",
    "display" : "QUETIAPINA 200 MG COMPRIMIDO DE LIBERAÇÃO PROLONGADA ELENCO ESTADUAL"
  },
  {
    "code" : "BR0270555",
    "display" : "AMPICILINA + SULBACTAM 2 G + 1 G PÓ PARA SOLUÇÃO INJETÁVEL"
  },
  {
    "code" : "BR0299248U0102",
    "display" : "DIDANOSINA 4 G PÓ PARA SUSPENSÃO"
  },
  {
    "code" : "123456",
    "display" : "INATIVO- HISTAMINA, FOSFATO 1,5 % SOLUÇÃO INJETÁVEL 1,3 ML"
  },
  {
    "code" : "BR0394258",
    "display" : "FERRIPOLIMALTOSE 50 MG/ML SOLUÇÃO ORAL  30 ML"
  },
  {
    "code" : "BR0273631",
    "display" : "MULTIVITAMINAS B2, B6, B12, C, NICOTINAMIDA E FRUTOSE SOLUÇÃO INJETÁVEL 10 ML"
  },
  {
    "code" : "BR0338288",
    "display" : "TESTOSTERONA, UNDECANOATO 250 MG/ML SOLUÇÃO INJETÁVEL  4 ML"
  },
  {
    "code" : "BR0291702",
    "display" : "GABAPENTINA 100 MG COMPRIMIDO"
  },
  {
    "code" : "BR0273413U0038",
    "display" : "LINEZOLIDA 2 MG/ML SOLUÇÃO INJETÁVEL 300 ML"
  },
  {
    "code" : "BR0273830",
    "display" : "CITIDINA + URIDINA + HIDROXOCOBALAMINA 2,5 + 1,5 + 1 MG  CÁPSULA"
  },
  {
    "code" : "BR0269997U0110",
    "display" : "ERITROMICINA, ESTOLATO 25 MG/ML SUSPENSÃO ORAL  60 ML"
  },
  {
    "code" : "BR0381060",
    "display" : "ÁCIDOS GRAXOS POLIINSATURADOS MARINHOS 1000 MG CÁPSULA"
  },
  {
    "code" : "BR0272229",
    "display" : "LERCANIDIPINO 10 MG COMPRIMIDO"
  },
  {
    "code" : "BR0298530",
    "display" : "ESTRADIOL, VALERATO + NORETISTERONA, ENANTATO 3,2 + 11,2 MG ADESIVO TRANSDÉRMICO"
  },
  {
    "code" : "BR0292195U0097",
    "display" : "HALOPERIDOL 2 MG/ML SOLUÇÃO ORAL 30 ML"
  },
  {
    "code" : "BR0400579",
    "display" : "CORDIA VERBENACEA DC. 5 MG/G AEROSSOL 75 ML"
  },
  {
    "code" : "BR0383409-3",
    "display" : "CARMELOSE SÓDICA + GLICEROL 5 + 9 MG/ML SOLUÇÃO OFTÁLMICA 15 ML"
  },
  {
    "code" : "BR0307780",
    "display" : "GATIFLOXACINO 3 MG/ML SOLUÇÃO OFTÁLMICA 5 ML"
  },
  {
    "code" : "BR0393846",
    "display" : "HIDROXIETILAMIDO + CLORETO DE SÓDIO (130/0,4) 6  SOLUÇÃO INJETÁVEL 500 ML SISTEMA FECHADO"
  },
  {
    "code" : "BR0271360",
    "display" : "CARBONATO DE CÁLCIO + LACTOGLICONATO DE CÁLCIO 1000 MG COMPRIMIDO EFERVESCENTE"
  },
  {
    "code" : "BR0279270",
    "display" : "VARFARINA SÓDICA  2,5 MG COMPRIMIDO"
  },
  {
    "code" : "BR0276262",
    "display" : "RAMIPRIL + HIDROCLOROTIAZIDA 5 MG + 25 MG COMPRIMIDO"
  },
  {
    "code" : "BR0388569",
    "display" : "ÁCIDO IBANDRÔNICO (IBANDRONATO DE SÓDIO) 150 MG COMPRIMIDO"
  },
  {
    "code" : "BR0403991",
    "display" : "BETAMETASONA, DIPROPIONATO + ÁCIDO SALICÍLICO (0,64 + 20) MG/ML SOLUÇÃO TÓPICA 30 ML"
  },
  {
    "code" : "BR0305652U0109",
    "display" : "FORMOTEROL + BUDESONIDA 12 + 400 MCG PÓ INAL (FR DE 60 DOSES) GRUPO 2"
  },
  {
    "code" : "BR0397280U0067",
    "display" : "MIKANIA GLOMERATA (GUACO) 0,1 ML/ML XAROPE  120 ML"
  },
  {
    "code" : "BR0268506U0042",
    "display" : "ONDANSETRONA, CLORIDRATO 4 MG COMPRIMIDO"
  },
  {
    "code" : "BR0272996",
    "display" : "FAMOTIDINA 40 MG COMPRIMIDO"
  },
  {
    "code" : "BR0285063",
    "display" : "FELODIPINO 5 MG COMPRIMIDO DE LIBERAÇÃO CONTROLADA"
  },
  {
    "code" : "BR0388387",
    "display" : "LEVODOPA + CARBIDOPA + ENTACAPONA 50 + 12,5 + 200 MG COMPRIMIDO"
  },
  {
    "code" : "BR0425182",
    "display" : "DEXTROCETAMINA, CLORIDRATO 50 MG/ML SOLUÇÃO INJETÁVEL 10 ML"
  },
  {
    "code" : "BR0352317",
    "display" : "ÁGUA DESTILADA SOLUÇÃO INJETÁVEL 1000 ML SISTEMA FECHADO"
  },
  {
    "code" : "INATIVO BR0269943-4",
    "display" : "INATIVO ÁLCOOL ETÍLICO 70 % GEL 5000  ML"
  },
  {
    "code" : "BR0365451U0118",
    "display" : "ABATACEPTE 250 MG PÓ P/ SUSP INJ (FR-AMP) GRUPO 1.A"
  },
  {
    "code" : "BR0294417U0081",
    "display" : "LATANOPROSTA 0,05 MG/ML SOL OFT (FR) 2,5 ML GRUPO 1.A"
  },
  {
    "code" : "BR0271747",
    "display" : "BENCICLANO, FUMARATO 100 MG COMPRIMIDO"
  },
  {
    "code" : "BR0376502-1",
    "display" : "ESTRONCIO, RANELATO 2 G  PÓ SACHÊ 2G"
  },
  {
    "code" : "BR0407075",
    "display" : "CICLOBENZAPRINA, CLORIDRATO + CAFEINA 5 + 30 MG COMPRIMIDO"
  },
  {
    "code" : "BR0432573",
    "display" : "SENNA ALEXANDRINA MILL. 50 MG CÁPSULA"
  },
  {
    "code" : "BR0368903",
    "display" : "BISACODIL + DOCUSATO DE SÓDIO 5 + 60 MG COMPRIMIDO"
  },
  {
    "code" : "BR0431569",
    "display" : "PINUS PINASTER 50 MG COMP"
  },
  {
    "code" : "BR0428744",
    "display" : "ÓLEO DE AMENDOIM + COLECALCIFEROL + TOCOFEROL 200 UI SOLUÇÃO 10 ML"
  },
  {
    "code" : "BR0436769",
    "display" : "VORTIOXETINA, BROMIDATO 10 MG COMPRIMIDO"
  },
  {
    "code" : "BR0355786-1",
    "display" : "ACETILCISTEÍNA 40 MG/ML XAROPE  120"
  },
  {
    "code" : "BR0269567-1",
    "display" : "PANCURÔNIO, BROMETO 2 MG/ML SOLUÇÃO INJETÁVEL 5 ML"
  },
  {
    "code" : "BR0436234",
    "display" : "ESCITALOPRAM, OXALATO  20 MG/ML SOLUÇÃO ORAL 15 ML"
  },
  {
    "code" : "BR0412094",
    "display" : "FINGOLIMODE,CLORIDRATO 0,5 MG CÁPSULA"
  },
  {
    "code" : "BR0421665",
    "display" : "ÁCIDO FÓLICO + FERRO AMINOÁCIDO QUELATO 0,2 + 30 MG/ML SOLUÇÃO ORAL 30 ML"
  },
  {
    "code" : "BR0424170",
    "display" : "LEVANLODIPINO, BESILATO 2,5  MG COMPRIMIDO"
  },
  {
    "code" : "BR0426759",
    "display" : "CASSIA ANGUSTIFOLIA + TAMARINDUS INDICA + CASSIA FISTULA + CORIANDRUM SATIVUM + GLYCYRRHIZA GLABRA 400 + 23,595 + 23,595 + 10,890+ 4,8 MG GEL 150 G"
  },
  {
    "code" : "BR0354953",
    "display" : "SOMATOSTATINA 3 MG PÓ LIOF INJ (FR)"
  },
  {
    "code" : "BR0355786",
    "display" : "ACETILCISTEÍNA 40 MG/ML XAROPE  100 ML"
  },
  {
    "code" : "BR0395728U0067",
    "display" : "MIKANIA GLOMERATA (GUACO) 0,25 ML/ML XAROPE  120 ML"
  },
  {
    "code" : "BR0369178U0042",
    "display" : "EVEROLIMO 0,75 MG COMP GRUPO 1.A"
  },
  {
    "code" : "BR0272793U0042",
    "display" : "FLUDROCORTISONA 0,1 MG COMP GRUPO 2"
  },
  {
    "code" : "BR0294887E",
    "display" : "SALBUTAMOL 100 MCG AER BUCAL (FR DE 200 DOSES) GRUPO 2"
  },
  {
    "code" : "BR0267587E",
    "display" : "BECLOMETASONA 200 MCG CAP INAL (FR DE 100 DOSES) GRUPO 2"
  },
  {
    "code" : "BR0277434U0135",
    "display" : "BETAINTERFERONA 1A 12.000.000UI (44MCG) SOL INJ (SER PREENC) GRUPO 1.A"
  },
  {
    "code" : "BR0342680U0118",
    "display" : "TRIPTORRELINA 11,25 MG SUSP INJ (FR-AMP) GRUPO 1.B"
  },
  {
    "code" : "BR0267087U0042",
    "display" : "GENFIBROZILA 900 MG COMP GRUPO 2"
  },
  {
    "code" : "BR0260160U0063",
    "display" : "IMUNOGLOBULINA ANTI-HEPATITE B 500 UI SOL INJ (FR) GRUPO 1.A"
  },
  {
    "code" : "BR0272807U0041",
    "display" : "ISOTRETINOÍNA 10 MG CAP GRUPO 2"
  },
  {
    "code" : "BR0392653",
    "display" : "INATIVO- FLUTICASONA, PROPIONATO 50 MCG PÓ"
  },
  {
    "code" : "BR0274936",
    "display" : "TRIANCINOLONA + NEOMICINA + GRAMICIDINA + NISTATINA 1+2,5+0,25MG+100.000 UI/G POMADA 30 G"
  },
  {
    "code" : "BR0305718U0011",
    "display" : "NOREPINEFRINA 2 MG/ML SOLUÇÃO INJETÁVEL 4  ML"
  },
  {
    "code" : "BR0268236U0037",
    "display" : "CLORETO DE SÓDIO 0,9% SOLUÇÃO INJETÁVEL 250 ML SISTEMA FECHADO"
  },
  {
    "code" : "BR0270092U0033",
    "display" : "GLICOSE 5 % SOLUÇÃO INJETÁVEL 1000 ML SISTEMA FECHADO"
  },
  {
    "code" : "BR0269977",
    "display" : "OMEPRAZOL + AMOXICILINA + CLARITROMICINA 20+500+500 MG CÁPSULA"
  },
  {
    "code" : "BR0268082U0042",
    "display" : "ATORVASTATINA 40 MG COMP GRUPO 2"
  },
  {
    "code" : "BR0272792U0067",
    "display" : "ETOSSUXIMIDA 50 MG/ML XPE (FR) 120 ML GRUPO 2"
  },
  {
    "code" : "BR0268118U0135",
    "display" : "FILGRASTIM 300 MCG SOL INJ (FR-AMP OU SER PREENC) GRUPO 1.A"
  },
  {
    "code" : "BR0274989U0013",
    "display" : "SACARATO DE HIDRÓXIDO FÉRRICO  100 MG SOL INJ (FR) 5 ML GRUPO 1.B"
  },
  {
    "code" : "BR0268094U0005",
    "display" : "METADONA 10 MG/ML SOL INJ (AMP) 1 ML GRUPO 2"
  },
  {
    "code" : "BR0267589E",
    "display" : "BECLOMETASONA 400 MCG PÓ INAL (FR DE 100 DOSES) GRUPO 2"
  },
  {
    "code" : "BR0271599U0118",
    "display" : "METILPREDNISOLONA 500 MG PÓ LIOF INJ (AMP) GRUPO 2"
  },
  {
    "code" : "BR0277743U0118",
    "display" : "BETAINTERFERONA 1A 6.000.000 UI (30MCG) PÓ LIOF INJ (FR-AMP OU SER PREENC OU CAN PREENC) GRUPO 1.A"
  },
  {
    "code" : "BR0391336U0118",
    "display" : "ALFATALIGLICERASE 200 UI PÓ LIOF INJ (FR-AMP) GRUPO 1.A"
  },
  {
    "code" : "BR0280877",
    "display" : "FUROSEMIDA + ESPIRONOLACTONA 20 + 100 MG COMPRIMIDO"
  },
  {
    "code" : "BR0398187",
    "display" : "RETINOL + COLECALCIFEROL 3000 + 800 UI/ML SOLUÇÃO ORAL  10 ML"
  },
  {
    "code" : "BR0343125",
    "display" : "ANLODIPINO, BESILATO + LOSARTANA POTÁSSICA 2,5 MG+ 50 MG COMPRIMIDO"
  },
  {
    "code" : "BR0339534",
    "display" : "CLORETO DE SÓDIO 30 MG/ML SOLUÇÃO NASAL 50 ML"
  },
  {
    "code" : "BR0274995-1",
    "display" : "FERRIPOLIMALTOSE 100 MG (FERRO III) SOLUÇÃO INJETÁVEL  2 ML"
  },
  {
    "code" : "BR0260160U0229",
    "display" : "IMUNOGLOBULINA ANTI-HEPATITE B 100 UI SOL INJ (FR) GRUPO 1.A"
  },
  {
    "code" : "BR0271169",
    "display" : "LISINOPRIL 20 MG COMPRIMIDO"
  },
  {
    "code" : "BR0276839U0007",
    "display" : "ÁGUA DESTILADA SOLUÇÃO INJETÁVEL 20 ML"
  },
  {
    "code" : "BR0276664",
    "display" : "IOBITRIDOL (65,81 %) 300 MG/ML SOLUÇÃO INJETÁVEL 50 ML"
  },
  {
    "code" : "BR0288641",
    "display" : "MICOFENOLATO DE SÓDIO 360 MG COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0373909-4",
    "display" : "HIPROMELOSE 0,2 MG/ML SOLUÇÃO OFTÁLMICA 10 ML"
  },
  {
    "code" : "BR0296793-1",
    "display" : "SALMETEROL, XINAFOATO + FLUTICASONA 50 + 500 MCG PÓ PARA INALAÇÃO ORAL 28 DOSES ELENCO ESTADUAL"
  },
  {
    "code" : "BR0397451",
    "display" : "MODAFINILA 200 MG COMPRIMIDO"
  },
  {
    "code" : "BR0368919-3",
    "display" : "ÁCIDO ACÉTICO 5 % SOLUÇÃO 250 ML"
  },
  {
    "code" : "BR0268499U0042",
    "display" : "METRONIDAZOL 400 MG COMPRIMIDO"
  },
  {
    "code" : "BR0266863U0062",
    "display" : "METRONIDAZOL (BENZOILMETRONIDAZOL) 40 MG/ML SUSPENSÃO ORAL  100 ML"
  },
  {
    "code" : "BR0268286U0031",
    "display" : "MICONAZOL, NITRATO 2 % CREME  80 G"
  },
  {
    "code" : "BR0268267",
    "display" : "MICONAZOL, NITRATO 2 % SOLUÇÃO TÓPICA 30 ML"
  },
  {
    "code" : "BR0268273U0041",
    "display" : "NITROFURANTOÍNA 100 MG CÁPSULA"
  },
  {
    "code" : "BR0270846U0005",
    "display" : "NORETISTERONA, ENANTATO DE  + ESTRADIOL, VALERATO DE   50 + 5 MG/ML SOLUÇÃO INJETÁVEL 1 ML"
  },
  {
    "code" : "BR0308884U0105",
    "display" : "SULFAMETOXAZOL + TRIMETOPRIMA  40 + 8 MG/ML SUSPENSÃO ORAL  50 ML"
  },
  {
    "code" : "BR0272582U0106",
    "display" : "TIMOLOL, MALEATO 0,25 % SOLUÇÃO OFTÁLMICA 5 ML ELENCO ESTADUAL"
  },
  {
    "code" : "BR0342153",
    "display" : "ERGOMETRINA 0,2 MG/ML SOLUÇÃO INJETÁVEL 1 ML"
  },
  {
    "code" : "BR0268317U0087",
    "display" : "ABACAVIR 20 MG/ML SOLUÇÃO ORAL 240 ML"
  },
  {
    "code" : "BR0269633",
    "display" : "PIPERAZINA 100 MG/ML SOLUÇÃO ORAL 60 ML"
  },
  {
    "code" : "BR0268118",
    "display" : "FILGRASTIM 300 MCG SOLUÇÃO INJETÁVEL  1 ML"
  },
  {
    "code" : "BR0268302",
    "display" : "SALBUTAMOL, SULFATO 2 MG COMPRIMIDO"
  },
  {
    "code" : "BR0270848",
    "display" : "ENANTATO DE NORETISTERONA + VALERATO DE ESTRADIOL 1 + 2 MG COMPRIMIDO"
  },
  {
    "code" : "BR0305414",
    "display" : "GINKGO BILOBA 80 MG CÁPSULA"
  },
  {
    "code" : "BR0331166",
    "display" : "FLUORMETOLONA 2,5 MG/ML SOLUÇÃO OFTÁLMICA 5 ML"
  },
  {
    "code" : "BR0271125",
    "display" : "CETOTIFENO, FUMARATO 1 MG/ML SOLUÇÃO ORAL 30 ML"
  },
  {
    "code" : "BR0291700",
    "display" : "GABAPENTINA 600 MG COMPRIMIDO"
  },
  {
    "code" : "BR0269761",
    "display" : "GENTAMICINA, SULFATO 20 MG/ML SOLUÇÃO INJETÁVEL  1 ML"
  },
  {
    "code" : "BR0270019",
    "display" : "GLICONATO DE CÁLCIO 10 % SOLUÇÃO INJETÁVEL  10 ML"
  },
  {
    "code" : "BR0270042U0063",
    "display" : "HIPROMELOSE 5 MG/ML SOLUÇÃO OFTÁLMICA 10 ML"
  },
  {
    "code" : "BR0269964",
    "display" : "LANSOPRAZOL 15 MG CÁPSULA"
  },
  {
    "code" : "BR0319764",
    "display" : "BRONFENIRAMINA, MALEATO + FENILEFRINA, CLORIDRATO 2 + 2,5 MG/ML SOLUÇÃO ORAL  20 ML"
  },
  {
    "code" : "BR0325456",
    "display" : "MANIDIPINO 10 MG COMPRIMIDO"
  },
  {
    "code" : "BR0270606-1",
    "display" : "MEBENDAZOL + TIABENDAZOL 200 MG+ 332 MG COMPRIMIDO"
  },
  {
    "code" : "BR0273553",
    "display" : "MELOXICAM 7,5 MG COMPRIMIDO"
  },
  {
    "code" : "BR0287469-1",
    "display" : "OXICONAZOL, NITRATO 10 MG/ML SOLUÇÃO TÓPICA 20 ML"
  },
  {
    "code" : "BR0292208-2",
    "display" : "RIFAMPICINA 20 MG/ML SUSPENSÃO ORAL  60 ML"
  },
  {
    "code" : "BR0269956",
    "display" : "BROMOPRIDA 4 MG/ML SOLUÇÃO ORAL 20 ML"
  },
  {
    "code" : "BR0305650",
    "display" : "FORMOTEROL + BUDESONIDA 12 + 400 MCG CÁPSULA  ELENCO ESTADUAL"
  },
  {
    "code" : "BR0336680",
    "display" : "FOSAMPRENAVIR CÁLCICO 700 MG MG COMPRIMIDO"
  },
  {
    "code" : "BR0308885U0013",
    "display" : "SULFAMETOXAZOL + TRIMETOPRIMA  80MG/ML + 16MG/ML SOLUÇÃO INJETÁVEL 5 ML"
  },
  {
    "code" : "BR0271120-2",
    "display" : "TETRACICLINA, CLORIDRATO + ANFOTERICINA B 25 + 12,5 MG/G CREME VAGINAL  60 G"
  },
  {
    "code" : "BR0268463U0001",
    "display" : "HEPARINA SÓDICA 5000/0,25 UI/ML SOLUÇÃO INJETÁVEL 0,25 ML"
  },
  {
    "code" : "BR0340783U0074",
    "display" : "HIDRÓXIDO DE ALUMÍNIO 61,5 MG/ML SUSPENSÃO ORAL  150 ML"
  },
  {
    "code" : "BR0437156U0097",
    "display" : "HIPOCLORITO DE SÓDIO 2,0 A 2,5 % SOLUÇÃO 30 ML"
  },
  {
    "code" : "BR0276234-1",
    "display" : "INSULINA ASPARTE 100 UI/ML SOLUÇÃO INJETÁVEL  10 ML"
  },
  {
    "code" : "BR0272093-2",
    "display" : "VITAMINAS DO COMPLEXO B (B1,B2,B3,B6,B12) DRÁGEA ELENCO ESTADUAL"
  },
  {
    "code" : "BR0272094U0042",
    "display" : "ZIDOVUDINA + LAMIVUDINA 300MG + 150MG COMPRIMIDO"
  },
  {
    "code" : "BR0272822U0042",
    "display" : "PIRAZINAMIDA 500 MG COMPRIMIDO"
  },
  {
    "code" : "BR0308738",
    "display" : "CIPROFIBRATO 100 mg  COMPRIMIDO"
  },
  {
    "code" : "BR0268958-1",
    "display" : "COLAGENASE 0,6 UI/G POMADA 15 G"
  },
  {
    "code" : "BR0272763",
    "display" : "SOLUÇÃO PARA DIÁLISE PERITONEAL, GLICOSE A 1,5 % SOLUÇÃO INJETÁVEL  2000 ML"
  },
  {
    "code" : "BR0267197U0042",
    "display" : "DIAZEPAM 10 MG COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0392118-2",
    "display" : "DIMETICONA 75 MG/ML SUSPENSÃO ORAL  15 ML"
  },
  {
    "code" : "BR0268340",
    "display" : "ESTAVUDINA  40 MG CÁPSULA"
  },
  {
    "code" : "BR0396414-3",
    "display" : "PLANTAGO OVATA (PSYLLIUM) PÓ PARA DISPERSÃO ORAL 5,40 G"
  },
  {
    "code" : "BR0272089-7",
    "display" : "SULFADIAZINA DE PRATA 1 % CREME  400 G"
  },
  {
    "code" : "BR0404151-1",
    "display" : "PAPAÍNA 6 % GEL 100 G"
  },
  {
    "code" : "BR0399413U0041",
    "display" : "RHAMNUS PURSHIANA (CÁSCARA SAGRADA) 500 MG MG CÁPSULA"
  },
  {
    "code" : "BR0378055",
    "display" : "FOSFOMICINA TROMETAMOL 3 G GRANULADO 8 G"
  },
  {
    "code" : "BR0272435",
    "display" : "ANLODIPINO, BESILATO 2,5 MG COMPRIMIDO"
  },
  {
    "code" : "BR0357064",
    "display" : "VILDAGLIPTINA + METFORMINA, CLORIDRATO 50 + 500 MG COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0331223",
    "display" : "TERIPARATIDA 250 MCG/ML SOLUÇÃO INJETÁVEL 3 ML ELENCO ESTADUAL"
  },
  {
    "code" : "BR0348362",
    "display" : "PIRIMETAMINA 2 MG/ML SUSPENSÃO ORAL  70 ML"
  },
  {
    "code" : "BR0399410U0041",
    "display" : "HARPAGOPHYTUM PROCUBENS (GARRA DO DIABO) 500 MG CÁPSULA"
  },
  {
    "code" : "BR0279338-2",
    "display" : "ÁCIDO POLIACRÍLICO 2 MG/G OFTALMICO GEL 10 G"
  },
  {
    "code" : "BR0338890U0005",
    "display" : "CALCITONINA 100 UI SOL INJ (AMP) GRUPO 2"
  },
  {
    "code" : "BR0266713E",
    "display" : "PANCRELIPASE 20.000 UI CAP GRUPO 1.B"
  },
  {
    "code" : "BR0267732",
    "display" : "VITELINATO DE PRATA 10 % SOLUÇÃO OFTÁLMICA 5 ML"
  },
  {
    "code" : "BR0352192",
    "display" : "RINGER SIMPLES SOLUÇÃO INJETÁVEL  500 ML SISTEMA FECHADO"
  },
  {
    "code" : "BR0305493",
    "display" : "PIOGLITAZONA, CLORIDRATO 15 MG COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0397910",
    "display" : "CISTINA + ÁCIDO AMINOBENZÓICO + PANTOTENATO DE CÁLCIO + NITRATO DE TIAMINA + LEVEDURA + QUERATINA 60 + 20 + 60 + 100 + 20 + 20 MG  CÁPSULA"
  },
  {
    "code" : "BR0275440-3",
    "display" : "TRIANCINOLONA, ACETONIDA 20 MG/ML SOLUÇÃO INJETÁVEL  5 ML"
  },
  {
    "code" : "BR0268394U0118",
    "display" : "ANFOTERICINA B LIPOSSOMAL PÓ PARA SOLUÇÃO INJETÁVEL 50 MG ELENCO ESTADUAL"
  },
  {
    "code" : "BR0270839",
    "display" : "ESTRADIOL 0,75 MG GEL 80 G"
  },
  {
    "code" : "BR0403990",
    "display" : "ROFLUMILASTE 500 MCG COMPRIMIDO"
  },
  {
    "code" : "BR0270558-1",
    "display" : "ACETILCISTEÍNA 20 MG/ML XAROPE  80 ML"
  },
  {
    "code" : "BR0275884",
    "display" : "COLISTIMETATO DE SODIO (POLIMIXINA E) 1.000.000 UI PÓ LIOFILIZADO PARA SOLUÇÃO INJETÁVEL ELENCO ESTADUAL"
  },
  {
    "code" : "BR0268152",
    "display" : "SIROLIMO 1 MG/ML SOLUÇÃO ORAL 60 ML ELENCO ESTADUAL"
  },
  {
    "code" : "BR0331938",
    "display" : "PEMETREXEDE 500 mg PÓ LIOFILIZADO PARA SOLUÇÃO INJETÁVEL"
  },
  {
    "code" : "BR0312568",
    "display" : "ERLOTINIBE 100 MG COMPRIMIDO"
  },
  {
    "code" : "BR0406518-1",
    "display" : "DOCETAXEL 20 MG/ML SOLUÇÃO INJETÁVEL 4 ML"
  },
  {
    "code" : "BR0407036",
    "display" : "VALERIANA OFFICINALIS L + HUMULUS LUPULUS L 250 + 60 MG COMPRIMIDO"
  },
  {
    "code" : "BR0269851",
    "display" : "LIDOCAÍNA, CLORIDRATO + EPINEFRINA 2% + 1:100.000 UI SOLUÇÃO INJETÁVEL 1,8 ML"
  },
  {
    "code" : "BR0403033",
    "display" : "PANITUMUMABE 20 MG/ML SOLUÇÃO INJETÁVEL 5 ML"
  },
  {
    "code" : "BR0273704",
    "display" : "NAPROXENO SÓDICO 275 MG COMPRIMIDO"
  },
  {
    "code" : "BR0301748",
    "display" : "PARACETAMOL + FENILEFRINA, CLORIDRATO ; PARACETAMOL + CARBINOXAMINA, MALEATO 400+20; 400+4 MG COMPRIMIDO 1 AMARELO + 1 LARANJA"
  },
  {
    "code" : "BR0394023-5(INATIVO)",
    "display" : "VASELINA (PETROLATO, PURO) POMADA 15 G"
  },
  {
    "code" : "BR0375237",
    "display" : "MULTIVITAMINAS + SAIS MINIERAIS + LUTEÍNA + ZEAXANTINA COMPRIMIDO"
  },
  {
    "code" : "BR0308071",
    "display" : "DIMETICONA + HOMATROPINA, METILBROMETO 80 + 2,5 MG/ML SOLUÇÃO ORAL 20 ML"
  },
  {
    "code" : "BR0273193",
    "display" : "TEMOZOLOMIDA 5 MG CÁPSULA"
  },
  {
    "code" : "BR0400973",
    "display" : "GLICINATO FÉRRICO 250 MG/ML SOLUÇÃO ORAL  30 ML"
  },
  {
    "code" : "BR0268959-2",
    "display" : "COLAGENASE 1,2 UI/G POMADA 30 G"
  },
  {
    "code" : "BR0400002",
    "display" : "CABAZITAXEL 40 MG/ML SOLUÇÃO INJETÁVEL  1,5 ML"
  },
  {
    "code" : "BR0404603U0135",
    "display" : "LANREOTIDA 60 MG SOL INJ (SER PREENC) GRUPO 1.B"
  },
  {
    "code" : "BR0404605U0135",
    "display" : "LANREOTIDA 90 MG SOL INJ (SER PREENC) GRUPO 1.B"
  },
  {
    "code" : "BR0272790U0042",
    "display" : "ETIONAMIDA 250 MG COMPRIMIDO"
  },
  {
    "code" : "BR0270116",
    "display" : "ETOMIDATO 2 MG/ML SOLUÇÃO INJETÁVEL  10 ML"
  },
  {
    "code" : "BR0273255",
    "display" : "OXCARBAZEPINA 6  % SUSPENSÃO ORAL  100 ML ELENCO ESTADUAL"
  },
  {
    "code" : "BR0268130U0086",
    "display" : "LEVOMEPROMAZINA 40 MG/ML SOLUÇÃO ORAL 20 ML"
  },
  {
    "code" : "BR0296792-1",
    "display" : "SALMETEROL, XINAFOATO + FLUTICASONA 50 + 250 MCG/DOSE PÓ PARA INALAÇÃO ORAL 60 DOSES ELENCO ESTADUAL"
  },
  {
    "code" : "BR0271660-2",
    "display" : "AMBROXOL, CLORIDRATO 3 MG/ML XAROPE  120"
  },
  {
    "code" : "BR0267282",
    "display" : "ESCOPOLAMINA, BUTILBROMETO 20 MG/ML SOLUÇÃO INJETÁVEL 1 ML"
  },
  {
    "code" : "BR0305490",
    "display" : "METILFENIDATO, CLORIDRATO 30 MG CAP LIBERAÇÃO CONTROLADA ELENCO ESTADUAL"
  },
  {
    "code" : "BR0271790-2",
    "display" : "FENILEFRINA, CLORIDRATO 10 % SOLUÇÃO OFTÁLMICA 10 ML"
  },
  {
    "code" : "BR0393886 (INATIVO)",
    "display" : "ENFUVIRTIDA  108 MG PÓ PARA SOLUÇÃO INJETÁVEL"
  },
  {
    "code" : "BR0292227U0005",
    "display" : "MEDROXIPROGESTERONA, ACETATO 50 MG/ML SOLUÇÃO INJETÁVEL 1 ML"
  },
  {
    "code" : "BR0278648",
    "display" : "METFORMINA, CLORIDRATO + GLIBENCLAMIDA 500 MG + 2,5 MG COMPRIMIDO"
  },
  {
    "code" : "BR0272336",
    "display" : "DIMENIDRINATO + PIRIDOXINA + GLICOSE + FRUTOSE 3 + 5 + 100 + 100 MG/ML SOLUÇÃO INJETÁVEL 10 ML"
  },
  {
    "code" : "BR0268352-1",
    "display" : "BRIMONIDINA, TARTARATO 0,2 % SOLUÇÃO OFTÁLMICA 5 ML"
  },
  {
    "code" : "BR0395721U0329",
    "display" : "CARVÃO VEGETAL ATIVADO PÓ 50 G"
  },
  {
    "code" : "BR0273820",
    "display" : "SILDENAFILA, CITRATO 25 MG COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0349269U0118",
    "display" : "VACINA RAIVA (INATIVADA) PÓ PARA SOLUÇÃO INJETÁVEL 0,5 ML"
  },
  {
    "code" : "BR0269070",
    "display" : "ÁCIDO TRICLOROACÉTICO 30 % SOLUÇÃO 3 ML"
  },
  {
    "code" : "BR0269843U0013",
    "display" : "LIDOCAÍNA, CLORIDRATO 20 MG/ML SOLUÇÃO INJETÁVEL 5 ML"
  },
  {
    "code" : "BR0304872",
    "display" : "MORFINA, SULFATO 0,2 MG/ML SOLUÇÃO INJETÁVEL 1 ML"
  },
  {
    "code" : "BR0270119",
    "display" : "CLONAZEPAM 2 MG  COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0318750U0238",
    "display" : "VACINA MENINGOCÓCICA C (CONJUGADA) SUSPENSÃO INJETÁVEL"
  },
  {
    "code" : "BR0268505U0042",
    "display" : "ONDANSETRONA, CLORIDRATO 8 MG COMPRIMIDO"
  },
  {
    "code" : "BR0270633",
    "display" : "DIPIRONA + ISOMETEPTENO + CAFEÍNA 300 + 30 + 30 MG COMPRIMIDO"
  },
  {
    "code" : "BR0282881",
    "display" : "ROSUVASTATINA CÁLCICA 10 MG COMPRIMIDO"
  },
  {
    "code" : "BR0291771",
    "display" : "ESCITALOPRAM, OXALATO  20 mg COMPRIMIDO"
  },
  {
    "code" : "BR0268952",
    "display" : "AZITROMICINA 500 MG PÓ PARA SOLUÇÃO INJETÁVEL"
  },
  {
    "code" : "BR0271848-2",
    "display" : "BIMATOPROSTA 0,3 MG/ML SOLUÇÃO OFTÁLMICA 5 ML"
  },
  {
    "code" : "BR0266597",
    "display" : "FORMOTEROL, FUMARATO 12 MCG CÁPSULA  ELENCO ESTADUAL"
  },
  {
    "code" : "BR0268971",
    "display" : "POLIMIXINA B, SULFATO 500.000 UI PÓ PARA SOLUÇÃO INJETÁVEL"
  },
  {
    "code" : "BR0268375U0015",
    "display" : "ACICLOVIR 5 % CREME  10 G"
  },
  {
    "code" : "BR0267936",
    "display" : "BETAISTINA, DICLORIDRATO 16 MG COMPRIMIDO"
  },
  {
    "code" : "BR0329352",
    "display" : "PIZOTIFENO 0,5 MG COMPRIMIDO"
  },
  {
    "code" : "BR0270602",
    "display" : "BETAMETASONA, VALERATO + GENTAMICINA, SULFATO + TOLNAFTATO + CLIOQUINOL 0,5 + 1 + 10 + 10 MG/G CREME  20 G"
  },
  {
    "code" : "BR0272400",
    "display" : "NAFAZOLINA, CLORIDRATO 0,5 MG/ML SOLUÇÃO NASAL 15 ML"
  },
  {
    "code" : "BR0270788",
    "display" : "LOSARTANA POTÁSSICA + HIDROCLOROTIAZIDA 50 MG + 12,5 MG COMPRIMIDO"
  },
  {
    "code" : "BR0273940",
    "display" : "PAROXETINA, CLORIDRATO 20 MG COMPRIMIDO"
  },
  {
    "code" : "BR0308726",
    "display" : "BENZOATO DE BENZILA 250 MG/ML EMULSÃO TÓPICA 60 ML"
  },
  {
    "code" : "BR0271609U0041",
    "display" : "NORTRIPTILINA, CLORIDRATO 10 MG CÁPSULA"
  },
  {
    "code" : "BR0271607U0041",
    "display" : "NORTRIPTILINA, CLORIDRATO 75 MG CÁPSULA"
  },
  {
    "code" : "BR0233632U0085",
    "display" : "ÓLEO MINERAL (VASELINA LÍQUIDA / PETROLATO) SOLUÇÃO ORAL 200 ML"
  },
  {
    "code" : "BR0267711U0041",
    "display" : "OMEPRAZOL 10 MG CÁPSULA"
  },
  {
    "code" : "BR0404606U0135",
    "display" : "LANREOTIDA 120 MG SOL INJ (SER PREENC) GRUPO 1.B"
  },
  {
    "code" : "BR0342180-1",
    "display" : "CETUXIMABE 2 MG/ML SOLUÇÃO INJETÁVEL 50 ML"
  },
  {
    "code" : "BR0352933-1",
    "display" : "LEVETIRACETAM 100 MG/G SOLUÇÃO ORAL  300 ML"
  },
  {
    "code" : "BR0340195-2",
    "display" : "CITARABINA 100 MG/ML SOLUÇÃO INJETÁVEL 5 ML"
  },
  {
    "code" : "BR0406975-1",
    "display" : "ÁCIDO VALPRÓICO (VALPROATO DE SÓDIO)  100 MG/ML SOLUÇÃO INJETÁVEL 2 ML"
  },
  {
    "code" : "BR0314373-3",
    "display" : "CUMARINA + HEPARINA SÓDICA 5 + 50 MG/ML CREME  120 ML"
  },
  {
    "code" : "BR0273579",
    "display" : "DIFENIDRAMINA + PARACETAMOL + PSEUDOEFEDRINA + DROPROPIZINA 1,5 + 12 + 1,5 + 1,5 MG/ML XAROPE  120 ML"
  },
  {
    "code" : "BR0407558",
    "display" : "CARBOMERO + GLICEROL + ÁCIDO BÓRICO + ÓLEO DE RÍCINO EMULSÃO OFTÁLMICA 15 ML"
  },
  {
    "code" : "BR0407531",
    "display" : "LIRAGLUTIDA 6 MG/ML SOLUÇÃO INJETÁVEL 3 ML"
  },
  {
    "code" : "BR0337678",
    "display" : "ÁCIDO ACETILSALICÍLICO  100 MG COMPRIMIDO DE LIBERAÇÃO PROLONGADA"
  },
  {
    "code" : "BR0398255-1",
    "display" : "PAPAÍNA 10 % CREME  50 G"
  },
  {
    "code" : "BR0271077",
    "display" : "PIDOLATO DE MAGNÉSIO 150 mg/ml SOLUÇÃO ORAL 10 ML"
  },
  {
    "code" : "BR0343437",
    "display" : "ESTRADIOL HEMI-HIDRATADO 1 MG/G GEL PERCUTÂNEO 50 G"
  },
  {
    "code" : "BR0398711",
    "display" : "SALMETEROL, XINAFOATO + FLUTICASONA 25 + 125 MCG/DOSE AEROSSOL 60 DOSES ELENCO ESTADUAL"
  },
  {
    "code" : "BR0400564-2",
    "display" : "ARTEMETER + LUMEFANTRINA 20 MG + 120 MG COMPRIMIDO 15 - 24 KG (BLISTER C/12 COMPRIMIDOS)"
  },
  {
    "code" : "BR0393845",
    "display" : "HIDROXIETILAMIDO + CLORETO DE SÓDIO (200/0,5) 10 % SOLUÇÃO INJETÁVEL 500 ML SISTEMA FECHADO"
  },
  {
    "code" : "BR0405210",
    "display" : "METILPREDNISOLONA, ACETATO 0,12 % SUSPENSÃO OFTÁLMICA 10 ML"
  },
  {
    "code" : "BR0305428-3",
    "display" : "CARMELOSE SÓDICA 5 MG/ML SOLUÇÃO OFTÁLMICA 10 ML"
  },
  {
    "code" : "BR0339979",
    "display" : "SOMATROPINA 5 MG SOLUÇÃO INJETÁVEL COM SISTEMA DE APLICAÇÃO 1,5 ML"
  },
  {
    "code" : "BR0314373-1",
    "display" : "CUMARINA + HEPARINA SÓDICA 5 + 50 MG/ML CREME  40 ML"
  },
  {
    "code" : "BR0275423",
    "display" : "ALTEPLASE 50 MG PÓ PARA SOLUÇÃO INJETÁVEL"
  },
  {
    "code" : "BR0359766",
    "display" : "HIALURONATO DE SÓDIO 0,08 % SOLUÇÃO INJETÁVEL  50 ML"
  },
  {
    "code" : "BR0408498",
    "display" : "PASSIFLORA INCARNATA + CRATAEGUS OXYACANTHA + SALIX ALBA 50 MG + 0,10 + 0,7 ML/ML SOLUÇÃO ORAL  100 ML"
  },
  {
    "code" : "BR0267415",
    "display" : "TEOFILINA 100 MG COMPRIMIDO"
  },
  {
    "code" : "BR0370120-1",
    "display" : "ARTESUNATO + MEFLOQUINA 100 + 220  MG COMPRIMIDO (3 COMP) 6 A 11 ANOS"
  },
  {
    "code" : "BR0311390-2",
    "display" : "BEVACIZUMABE 25 MG/ML SOLUÇÃO INJETÁVEL  16 ML"
  },
  {
    "code" : "BR0271129",
    "display" : "BISOPROLOL, FUMARATO + HIDROCLOROTIAZIDA 5 + 6,25 MG COMPRIMIDO"
  },
  {
    "code" : "BR0315604",
    "display" : "MONOSSIALOGANGLIOSÍDEO 20 MG/ML SOLUÇÃO INJETÁVEL 5 ML"
  },
  {
    "code" : "BR0386482U0042",
    "display" : "FOSFATO DE CÁLCIO TRIBÁSICO + COLECALCIFEROL 600 MG + 400 UI COMPRIMIDO"
  },
  {
    "code" : "BR0332888",
    "display" : "ANFOTERICINA B 100 MG PÓ LIOFILIZADO PARA SOLUÇÃO INJETÁVEL ELENCO ESTADUAL"
  },
  {
    "code" : "BR0370560",
    "display" : "ALFA-1 ANTITRIPSINA (AAT) 20 MG/ML SOLUÇÃO INJETÁVEL 50 ML ELENCO ESTADUAL"
  },
  {
    "code" : "BR0400564-3",
    "display" : "ARTEMETER + LUMEFANTRINA 20 MG + 120 MG COMPRIMIDO 25 - 34 KG (BLISTER C/18 COMPRIMIDOS)"
  },
  {
    "code" : "BR0267419-1",
    "display" : "TIABENDAZOL 50 MG/ML SUSPENSÃO ORAL  60 ML"
  },
  {
    "code" : "BR0294202",
    "display" : "DEXRAZOXANO 500 MG PÓ LIOFILIZADO PARA SOLUÇÃO INJETÁVEL"
  },
  {
    "code" : "BR0294927",
    "display" : "PROMESTRIENO 10 MG/G CREME VAGINAL  30 G"
  },
  {
    "code" : "BR0272383",
    "display" : "VENLAFAXINA, CLORIDRATO 50 MG COMPRIMIDO"
  },
  {
    "code" : "BR0314373-4",
    "display" : "CUMARINA + HEPARINA SÓDICA 5 + 50 MG/ML CREME  240 ML"
  },
  {
    "code" : "BR0406003",
    "display" : "KAVA-KAVA (PIPER METHYSTICUM) 234 MG CÁPSULA"
  },
  {
    "code" : "BR0390643",
    "display" : "TENSIROLIMO 25 MG/ML SOLUÇÃO INJETÁVEL  1,2 ML ELENCO ESTADUAL"
  },
  {
    "code" : "BR0353813",
    "display" : "MIRTAZAPINA 15 MG COMPRIMIDO PARA  SUSPENSÃO"
  },
  {
    "code" : "BR0269595",
    "display" : "PICOSSULFATO SODICO 7,5 MG/ML SOL ORAL (FR) 20 ML"
  },
  {
    "code" : "BR0368190",
    "display" : "FERROCARBONILA + ÁCIDO FÓLICO + MULTIVITAMINAS COMPRIMIDO"
  },
  {
    "code" : "BR0272580U0106",
    "display" : "DORZOLAMIDA 20 MG/ML SOL OFT (FR) 5 ML GRUPO 2"
  },
  {
    "code" : "BR0268410U0118",
    "display" : "CEFOTAXIMA 500 MG  PÓ LIOFILIZADO PARA SOLUÇÃO INJETÁVEL"
  },
  {
    "code" : "BR0285966",
    "display" : "LEVETIRACETAM 500 MG COMPRIMIDO"
  },
  {
    "code" : "BR0291772",
    "display" : "ESCITALOPRAM, OXALATO  15 mg COMPRIMIDO"
  },
  {
    "code" : "BR0340193-2",
    "display" : "CITARABINA 20 MG/ML SOLUÇÃO INJETÁVEL 25 ML"
  },
  {
    "code" : "BR0292788",
    "display" : "BENZIDAMINA, CLORIDRATO 500 MG PÓ SACHE 9,4 G"
  },
  {
    "code" : "BR0295303",
    "display" : "TRASTUZUMABE 150 MG PÓ LIOFILIZADO"
  },
  {
    "code" : "BR0272445",
    "display" : "CICLOFENILA 200 MG COMPRIMIDO"
  },
  {
    "code" : "BR0417571",
    "display" : "TRIOXISALENO 10 MG CÁPSULA"
  },
  {
    "code" : "BR0420463",
    "display" : "UREIA + OLEO DE SEMENTE DE UVA 3% + 5% CREME  150G"
  },
  {
    "code" : "BR0390598-2",
    "display" : "FATOR VIII RECOMBINANTE, CONCENTRADO DE FATOR DE COAGULAÇÃO 500 UI PÓ LIOFILIZADO PARA SOLUÇÃO INJETÁVEL"
  },
  {
    "code" : "BR0352129",
    "display" : "DEXCLORFENIRAMINA, MALEATO 6 MG DRÁGEA"
  },
  {
    "code" : "BR0406015-1",
    "display" : "OXIBUTININA, CLORIDRATO, FORMULAÇÃO ESPECIALMENTE MANIPULADA 1 MG/ML SOLUÇÃO ORAL 450 ML"
  },
  {
    "code" : "BR0273820U0042",
    "display" : "SILDENAFILA 25 MG COMP GRUPO 1.B"
  },
  {
    "code" : "BR0404151",
    "display" : "PAPAÍNA 6 % GEL 50  G"
  },
  {
    "code" : "BR0267777U0063",
    "display" : "PARACETAMOL  200 MG/ML SOLUÇÃO ORAL 10 ML"
  },
  {
    "code" : "BR0327699U0042",
    "display" : "PERMANGANATO DE POTÁSSIO 100 MG COMPRIMIDO"
  },
  {
    "code" : "BR0363597U0110",
    "display" : "PERMETRINA 50 MG/ML LOÇÃO 60 ML"
  },
  {
    "code" : "BR0384537U0030",
    "display" : "PERÓXIDO DE BENZOÍLA 2,5 % GEL 60 G"
  },
  {
    "code" : "BR0271764",
    "display" : "PIRIDOSTIGMINA, BROMETO 60 MG COMPRIMIDO"
  },
  {
    "code" : "BR0268151U0062",
    "display" : "PREDNISOLONA 1 MG/ML SOLUÇÃO ORAL 100 ML"
  },
  {
    "code" : "BR0267769U0009",
    "display" : "PROMETAZINA, CLORIDRATO 25 MG/ML SOLUÇÃO INJETÁVEL 2 ML"
  },
  {
    "code" : "BR0272412U0042",
    "display" : "PROPAFENONA, CLORIDRATO 300 MG COMPRIMIDO"
  },
  {
    "code" : "BR0267736U0042",
    "display" : "RANITIDINA, CLORIDRATO  150 MG COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0272565U0086",
    "display" : "RETINOL, PALMITATO 150.000 UI/ML SOLUÇÃO ORAL 20 ML"
  },
  {
    "code" : "BR0268390U0052",
    "display" : "SAIS PARA REIDRATAÇÃO ORAL (NaCl 3,5G + Glicose 20G + Citrato Na 2,9G + KCl 1,5G)                                 27,9 G PÓ PARA SOLUÇÃO"
  },
  {
    "code" : "BR0268303U0106",
    "display" : "SALBUTAMOL, SULFATO 5 MG/ML SOLUÇÃO PARA NEBULIZAÇÃO 5 ML"
  },
  {
    "code" : "BR0272089U0023",
    "display" : "SULFADIAZINA DE PRATA 1% CREME  30 G"
  },
  {
    "code" : "BR0272089-4",
    "display" : "SULFADIAZINA DE PRATA 1 % PASTA  120 G"
  },
  {
    "code" : "BR0308882U0042",
    "display" : "SULFAMETOXAZOL + TRIMETOPRIMA  400 + 80 MG COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0302748-1",
    "display" : "PIRAZINAMIDA 30 MG/ML SUSPENSÃO ORAL  100 ML"
  },
  {
    "code" : "BR0321234-1",
    "display" : "DEXAMETASONA + NEOMICINA + POLIMIXINA B 1 MG + 5 MG + 6.000 UI/G SOLUÇÃO OFTÁLMICA 5 ML"
  },
  {
    "code" : "BR0270991",
    "display" : "DICLOFENACO COLESTIRAMINA 70 MG CÁPSULA"
  },
  {
    "code" : "BR0363560",
    "display" : "DICLOFENACO SÓDICO + TIAMINA + PIRIDOXINA + CIANOCOBALAMINA 50 + 50 + 50 + 1 MG COMPRIMIDO"
  },
  {
    "code" : "BR0292345U0097",
    "display" : "SULFATO FERROSO (25MG/ML DE FERRO ELEMENTAR) 125 MG/ML SOLUÇÃO ORAL 30 ML ELENCO ESTADUAL"
  },
  {
    "code" : "BR0328596",
    "display" : "ÁLCOOL ETÍLICO >99 % SOLUÇÃO INJETÁVEL 10 ML"
  },
  {
    "code" : "BR0268370U0042",
    "display" : "ACICLOVIR 200 MG COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0278489U0097",
    "display" : "ÁCIDO FÓLICO 0,2 MG/ML SOLUÇÃO ORAL 30 ML"
  },
  {
    "code" : "BR0308732U0062",
    "display" : "ÁCIDO VALPRÓICO (VALPROATO DE SÓDIO)  50 MG/ML XAROPE  100 ML ELENCO ESTADUAL"
  },
  {
    "code" : "BR0271111U0115",
    "display" : "AMOXICILINA 50 MG/ML PÓ PARA SUSPENSÃO 80 ML"
  },
  {
    "code" : "BR0271217U0042",
    "display" : "AMOXICILINA + CLAVULANATO DE POTÁSSIO 500 MG + 125 MG COMPRIMIDO"
  },
  {
    "code" : "BR0314517U0108",
    "display" : "AZITROMICINA 40 MG/ML 600 MG PÓ PARA SUSPENSÃO 15 ML"
  },
  {
    "code" : "BR0314517U0155",
    "display" : "AZITROMICINA 40 MG/ML 1200 MG PÓ PARA SUSPENSÃO 30 ML"
  },
  {
    "code" : "BR0346586U0573",
    "display" : "BECLOMETASONA, DIPROPIONATO 50 MCG/DOSE AEROSSOL ORAL 130 DOSES"
  },
  {
    "code" : "BR0267587U0061",
    "display" : "BECLOMETASONA, DIPROPIONATO 200 MCG/DOSE PÓ PARA INALAÇÃO ORAL 100 DOSES"
  },
  {
    "code" : "BR0270613U0118",
    "display" : "BENZILPENICILINA BENZATINA 600.000 UI PÓ PARA SUSPENSÃO INJETÁVEL"
  },
  {
    "code" : "BR0270614U0118",
    "display" : "BENZILPENICILINA PROCAÍNA + BENZILPENICILINA POTÁSSICA 400.000 UI PÓ PARA SUSPENSÃO INJETÁVEL"
  },
  {
    "code" : "BR0267613U0042",
    "display" : "CAPTOPRIL  25 MG COMPRIMIDO"
  },
  {
    "code" : "BR0267621U0042",
    "display" : "CARBONATO DE LÍTIO 300 MG COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0267625U0041",
    "display" : "CEFALEXINA 500 MG  CÁPSULA"
  },
  {
    "code" : "BR0331555U0062",
    "display" : "CEFALEXINA 50 MG/ML SUSPENSÃO ORAL  100 ML"
  },
  {
    "code" : "BR0269986-1",
    "display" : "CLARITROMICINA 250 MG  CÁPSULA"
  },
  {
    "code" : "BR0267522U0042",
    "display" : "CLOMIPRAMINA, CLORIDRATO 25 MG  COMPRIMIDO"
  },
  {
    "code" : "BR0437160U0097",
    "display" : "CLORETO DE SÓDIO 0,9 % SOLUÇÃO NASAL 30 ML"
  },
  {
    "code" : "BR0340207U0086",
    "display" : "CLORPROMAZINA, CLORIDRATO 40 MG/ML SOLUÇÃO ORAL 20 ML"
  },
  {
    "code" : "BR0270409",
    "display" : "CARBOPLATINA 450 MG SOLUÇÃO INJETÁVEL  45 ML"
  },
  {
    "code" : "BR0367692U0042",
    "display" : "ÁCIDO NICOTÍNICO 500 MG COMP DE LIB PROL GRUPO 2"
  },
  {
    "code" : "BR0269073-3",
    "display" : "ÁCIDO TRICLOROACÉTICO 80 % SOLUÇÃO 15 ML"
  },
  {
    "code" : "BR0426922",
    "display" : "SILYBUM MARIANUM (L.) GAERTN 200 MG CÁPSULA"
  },
  {
    "code" : "BR0309045",
    "display" : "ACIDO AMINOCAPRÓICO 200 MG/ML SUSPENSÃO INJETÁVEL 20 ML"
  },
  {
    "code" : "BR0401411",
    "display" : "ÓXIDO DE ZINCO + COLECALCIFEROL + RETINOL 100+ 1000+ 400 MG + UI/G POMADA 45 G"
  },
  {
    "code" : "BR0290673",
    "display" : "EBASTINA 10 MG COMPRIMIDO"
  },
  {
    "code" : "BR0268458",
    "display" : "GANCICLOVIR SÓDICO 250 MG CÁPSULA  ELENCO ESTADUAL"
  },
  {
    "code" : "BR0268959-1",
    "display" : "COLAGENASE 1,2 UI/G POMADA 15 G"
  },
  {
    "code" : "BR0374967",
    "display" : "NILOTINIBE 200 MG CÁPSULA  ELENCO ESTADUAL"
  },
  {
    "code" : "BR0412470",
    "display" : "TELAPREVIR 375 MG COMPRIMIDO"
  },
  {
    "code" : "BR0322436",
    "display" : "FANCICLOVIR 125 MG COMPRIMIDO"
  },
  {
    "code" : "BR0383786",
    "display" : "VINORELBINA, TARTARATO 10 MG/ML SOLUÇÃO INJETÁVEL  1 ML"
  },
  {
    "code" : "BR0279297-2",
    "display" : "NISTATINA + ÓXIDO DE ZINCO 100.000 + 200 UI + MG/G CREME  60 G"
  },
  {
    "code" : "BR0394675-1",
    "display" : "SOLUÇÃO SALINA BALANCEADA SOLUÇÃO INJETÁVEL INTRA-OCULAR 250 ML SISTEMA FECHADO"
  },
  {
    "code" : "BR0395721U0123",
    "display" : "CARVÃO VEGETAL ATIVADO PÓ 500  G"
  },
  {
    "code" : "BR0363099",
    "display" : "AZUL DE TRYPAN 0,1 % SOLUÇÃO OFTÁLMICA 1 ML"
  },
  {
    "code" : "BR0327695",
    "display" : "AMINOÁCIDOS, A 10%,SOLUÇÃO GLICOSE 50%,SEM TAURINA + OLIGOELEMENTOS, PARA NEONATOS 20% EMULSÃO"
  },
  {
    "code" : "BR0279223",
    "display" : "AMINOÁCIDOS, A 8% P/ HEPATOPATAS, SEM CARBOHIDRATO, SEM ELETRÓLITOS SOLUÇÃO 500 ML"
  },
  {
    "code" : "BR0412718",
    "display" : "ICATIBANTO, ACETATO 10 MG/ML SOLUÇÃO INJETÁVEL 3 ML"
  },
  {
    "code" : "BR0413681U0067",
    "display" : "MIKANIA GLOMERATA (GUACO) 81,5 MG/ML SOLUÇÃO ORAL 120 ML"
  },
  {
    "code" : "BR0319945",
    "display" : "AMINOÁCIDOS, A 10%,SOLUÇÃO GLICOSE 50%,COM TAURINA + OLIGOELEMENTOS, PARA NEONATOS 20% EMULSÃO"
  },
  {
    "code" : "BR0343646",
    "display" : "AMINOÁCIDOS, COM TAURINA E CISTEÍNA, ISENTA DE CARBOHIDRATOS E ELETRÓLITOS 10% SOLUÇÃO INJETÁVEL"
  },
  {
    "code" : "BR0340178-1",
    "display" : "CISATRACURIO, BESILATO 2 MG/ML SOLUÇÃO INJETÁVEL 5 ML"
  },
  {
    "code" : "BR0345259-1",
    "display" : "METOPROLOL, TARTARATO 1 MG/ML COM SISTEMA DE APLICAÇÃO SOLUÇÃO INJETÁVEL 5 ML"
  },
  {
    "code" : "BR0272402",
    "display" : "NAFAZOLINA + BENZALCONIO 0,5 + 0,1 MG/ML SOLUÇÃO NASAL 30 ML"
  },
  {
    "code" : "BR0343649",
    "display" : "AMINOÁCIDOS, C/8 AMINOÁCIDOS ESSENCIAIS + HISTIDINA, SEM CARBOHIDRATO, SEM ELETRÓLITOS 6,5 A 6,9 % DE AA TOTAIS SOLUÇÃO INJETÁVEL"
  },
  {
    "code" : "BR0296792-3",
    "display" : "SALMETEROL, XINAFOATO + FLUTICASONA 50 + 250 MCG/DOSE PÓ PARA INALAÇÃO ORAL 28 DOSES ELENCO ESTADUAL"
  },
  {
    "code" : "BR0384297",
    "display" : "MERCAPTAMINA (CISTEAMINA) 5 MG/ML SOLUÇÃO OFTÁLMICA 5 ML"
  },
  {
    "code" : "BR0333791",
    "display" : "CLODRONATO, DISSÓDICO 60 MG/ML SOLUÇÃO INJETÁVEL 5 ML"
  },
  {
    "code" : "BR0315610",
    "display" : "PALONOSETRONA, CLORIDRATO 0,05 MG/ML SOLUÇÃO INJETÁVEL 5 ML"
  },
  {
    "code" : "BR0268469-2",
    "display" : "ISOFLURANO 100 MG/ML SOLUÇÃO PARA INALAÇÃO 240 ML"
  },
  {
    "code" : "BR0306465",
    "display" : "TROMETAMOL, CETOROLACO 30 MG/ML SOLUÇÃO INJETÁVEL  1 ML"
  },
  {
    "code" : "BR0340177",
    "display" : "CISATRACURIO, BESILATO 5 MG/ML SOLUÇÃO INJETÁVEL 30 ML"
  },
  {
    "code" : "BR0368779",
    "display" : "MIKANIA GLOMERATA (GUACO) 117,6 MG/ML XAROPE  100 ML"
  },
  {
    "code" : "BR0400853",
    "display" : "IVABRADINA, CLORIDRATO 5 MG COMPRIMIDO"
  },
  {
    "code" : "BR0269068-3",
    "display" : "ÁCIDO TRICLOROACÉTICO 50 % SOLUÇÃO 20 ML"
  },
  {
    "code" : "BR0412830",
    "display" : "BRENTUXIMABE VEDOTINA 50 MG PÓ LIOF INJ (FR-AMP)"
  },
  {
    "code" : "BR0269622-4",
    "display" : "GLICEROL   12 % ENEMA  500 ML SISTEMA FECHADO"
  },
  {
    "code" : "BR0368921-3",
    "display" : "ÁCIDO ACÉTICO 3% SOLUÇÃO 100 ML"
  },
  {
    "code" : "BR0431100",
    "display" : "CODEÍNA 45 MG CÁPSULA"
  },
  {
    "code" : "BR0268609",
    "display" : "LEVOSIMENDANA 2,5 MG/ML SOLUÇÃO INJETÁVEL 5 ML"
  },
  {
    "code" : "BR0429102",
    "display" : "Fampridina 10 MG COMPRIMIDO DE LIBERAÇÃO CONTROLADA"
  },
  {
    "code" : "BR0432846",
    "display" : "BRYOPHYLLUM ARGENTO CULTUM SOL ORAL (FR) 50 ML"
  },
  {
    "code" : "BR0432742",
    "display" : "MALGADRATO + DIMETICONA MALGADRATO + DIMETICONA 80 MG/ML + 10 MG/ML SOL ORAL (FR) 240 ML"
  },
  {
    "code" : "BR0433100",
    "display" : "FLUTICASONA, FUROATO + VILANTEROL, TRIFENATATO 100 MCG/DOSE + 25 MCG/DOSE PÓ PARA INALAÇÃO ORAL 30 DOSES"
  },
  {
    "code" : "BR0275428-1",
    "display" : "NEOMICINA + CLOSTEBOL 5 + 5 MG/G CREME  45 G"
  },
  {
    "code" : "BR0431349-1",
    "display" : "POLIVITAMINICO + POLIMINERAIS + LISINA XAROPE  200 ML"
  },
  {
    "code" : "BR0412092",
    "display" : "RIVAROXABANA 15 MG COMPRIMIDO"
  },
  {
    "code" : "BR0284458U0023",
    "display" : "CLOBETASOL 0,5 MG/G CREM (BIS) 30 G GRUPO 2"
  },
  {
    "code" : "BR0272045U0042",
    "display" : "CLOPIDOGREL 75 MG COMP GRUPO 2"
  },
  {
    "code" : "BR0298454U0062",
    "display" : "DEXCLORFENIRAMINA, MALEATO 0,4 MG/ML XAROPE  100 ML"
  },
  {
    "code" : "BR0267648U0110",
    "display" : "DIGOXINA  0,05 MG/ML ELIXIR 60 ML"
  },
  {
    "code" : "BR0267650U0042",
    "display" : "ENALAPRIL, MALEATO 5 MG COMPRIMIDO"
  },
  {
    "code" : "BR0269994-2",
    "display" : "ERITROMICINA, ESTEARATO 50 MG/ML SUSPENSÃO ORAL  60 ML"
  },
  {
    "code" : "BR0269994-4",
    "display" : "ERITROMICINA, ESTEARATO 50 MG/ML SUSPENSÃO ORAL  105 ML"
  },
  {
    "code" : "BR0267208U0029",
    "display" : "ESTRIOL 1 MG/G CREME VAGINAL  50 G"
  },
  {
    "code" : "BR0271435U0019",
    "display" : "ESTROGÊNIOS CONJUGADOS 0,625 MG/G CREME VAGINAL  25 G"
  },
  {
    "code" : "BR0300723U0086",
    "display" : "FENOBARBITAL  40 MG/ML SOLUÇÃO ORAL 20 ML ELENCO ESTADUAL"
  },
  {
    "code" : "BR0273009U0041",
    "display" : "FLUOXETINA, CLORIDRATO 20 MG CÁPSULA  ELENCO ESTADUAL"
  },
  {
    "code" : "BR0269622U0060",
    "display" : "GLICEROL   120 MG/ML ENEMA  1 L"
  },
  {
    "code" : "BR0292194U0005",
    "display" : "HALOPERIDOL,  SAL DECANOATO ,50MG/ML SOLUÇÃO INJETÁVEL 1 ML ELENCO ESTADUAL"
  },
  {
    "code" : "BR0345240U0017",
    "display" : "HIDROCORTISONA, ACETATO 10 MG/G CREME  15 G"
  },
  {
    "code" : "BR0332426",
    "display" : "HIDRÓXIDO DE ALUMÍNIO + HIDRÓXIDO DE MAGNÉSIO 37 + 35,6 MG/ML SUSPENSÃO ORAL  240 ML"
  },
  {
    "code" : "BR0271689-1",
    "display" : "ÁCIDO ASCÓRBICO 200 MG/ML SOLUÇÃO ORAL 20 ML"
  },
  {
    "code" : "BR0267531-1",
    "display" : "PERINDOPRIL + INDAPAMIDA 4 + 1,25 MG COMPRIMIDO"
  },
  {
    "code" : "BR0400312U0013",
    "display" : "SORO ANTIARACNÍDICO SOLUÇÃO INJETÁVEL 5 ML"
  },
  {
    "code" : "BR0333142",
    "display" : "ALPROSTADIL 500 MCG/ML SOLUÇÃO INJETÁVEL 1 ML"
  },
  {
    "code" : "BR0319000-2",
    "display" : "BRIMONIDINA, TARTARATO + TIMOLOL, MALEATO 0,2 + 0,5 % SOLUÇÃO OFTÁLMICA 10 ML ELENCO ESTADUAL"
  },
  {
    "code" : "BR0271980",
    "display" : "CEFADROXILA 50 MG/ML SOLUÇÃO ORAL 100 ML"
  },
  {
    "code" : "INATIVO 25",
    "display" : "INATIVO-CLORETO DE SÓDIO 0,9 % SOLUÇÃO INJETÁVEL  250 ML"
  },
  {
    "code" : "BR0274227",
    "display" : "GLICOSAMINA, SULFATO + CONDROITINA, SULFATO 500 + 400 MG CÁPSULA"
  },
  {
    "code" : "BR0267544U0037",
    "display" : "GLICOSE 10 % SOLUÇÃO INJETÁVEL 250 ML SISTEMA FECHADO"
  },
  {
    "code" : "BR0345259",
    "display" : "METOPROLOL, TARTARATO 1 MG/ML SOLUÇÃO INJETÁVEL 5 ML"
  },
  {
    "code" : "BR0363379",
    "display" : "QUININA, CLORIDRATO + PAPAVERINA 100 + 40 MG COMPRIMIDO"
  },
  {
    "code" : "BR0342134U0118",
    "display" : "HIDROCORTISONA, SUCCINATO SÓDICO 500MG PÓ PARA SOLUÇÃO INJETÁVEL"
  },
  {
    "code" : "BR0279493-4",
    "display" : "ÓXIDO DE ZINCO + COLECALCIFEROL + RETINOL 150 + 5000+ 900 (MG + UI + UI/G) POMADA 100 G"
  },
  {
    "code" : "BR0267907",
    "display" : "BECLOMETASONA, DIPROPIONATO 400 MCG/ML SUSPENSÃO PARA AEROSSOLTERAPIA 2 ML"
  },
  {
    "code" : "BR0427442U0045",
    "display" : "HIDROXOCOBALAMINA, CLORIDRATO 5G PÓ LIOF INJ (FR-AMP)"
  },
  {
    "code" : "BR0279269U0042",
    "display" : "VARFARINA SÓDICA  5 MG COMPRIMIDO"
  },
  {
    "code" : "BR0268383",
    "display" : "AMICACINA, SULFATO 50 MG/ML SOLUÇÃO INJETÁVEL 2 ML ELENCO ESTADUAL"
  },
  {
    "code" : "BR0268481-1",
    "display" : "MIDAZOLAM, MALEATO 5 MG/ML SOLUÇÃO INJETÁVEL 3 ML"
  },
  {
    "code" : "BR0276095",
    "display" : "LEVOTIROXINA SÓDICA 200 MCG COMPRIMIDO"
  },
  {
    "code" : "BR0273836-1",
    "display" : "INSULINA GLARGINA 100 UI/ML SOLUÇÃO INJETÁVEL 3 ML ELENCO ESTADUAL"
  },
  {
    "code" : "BR0270141U0042",
    "display" : "BIPERIDENO, CLORIDRATO  4 MG COMPRIMIDO DE LIBERAÇÃO PROLONGADA"
  },
  {
    "code" : "BR0267896",
    "display" : "RIVASTIGMINA, HIDROGENOTARTARATO 1,5 MG CÁPSULA"
  },
  {
    "code" : "BR0276948",
    "display" : "TRAZODONA, CLORIDRATO 50 MG COMPRIMIDO"
  },
  {
    "code" : "BR0369106",
    "display" : "VIMPOCETINA 5 MG COMPRIMIDO"
  },
  {
    "code" : "BR0296076",
    "display" : "CANDESARTANA CILEXETILA 16 MG COMPRIMIDO"
  },
  {
    "code" : "BR0270436",
    "display" : "METOTREXATO 2,5 MG COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0395147",
    "display" : "DIAZEPAM 10 MG/ML SOLUÇÃO INJETÁVEL 1 ML"
  },
  {
    "code" : "BR0279493-6",
    "display" : "ÓXIDO DE ZINCO + COLECALCIFEROL + RETINOL 150MG + 5000UI + 900 ui/g POMADA 30 G"
  },
  {
    "code" : "BR0267089",
    "display" : "GENFIBROZILA 300 MG CÁPSULA"
  },
  {
    "code" : "BR0272478",
    "display" : "FLUNARIZINA, DICLORIDRATO 10 MG COMPRIMIDO"
  },
  {
    "code" : "BR0273402",
    "display" : "ISOSSORBIDA, MONONITRATO 5 MG COMPRIMIDO SUBLINGUAL"
  },
  {
    "code" : "BR0276839U0011",
    "display" : "ÁGUA DESTILADA SOLUÇÃO INJETÁVEL 4 ML"
  },
  {
    "code" : "BR0431311",
    "display" : "HIDRÓXIDO DE ALUMÍNIO + HIDRÓXIDO DE MAGNÉSIO + DIMETICONA 37 MG/ML + 40 MG/ML + 5 MG/ML SUSPENSÃO ORAL  240  ML"
  },
  {
    "code" : "BR0397280U0062",
    "display" : "MIKANIA GLOMERATA (GUACO) 0,1 ML/ML XAROPE  100 ML"
  },
  {
    "code" : "BR0434049",
    "display" : "CIDREIRA 8 %  ELIXIR 150 ML"
  },
  {
    "code" : "BR0428080U0042",
    "display" : "RALTEGRAVIR 100 MG COMPRIMIDO"
  },
  {
    "code" : "BR0395721-6",
    "display" : "CARVÃO VEGETAL ATIVADO PÓ 10 G"
  },
  {
    "code" : "BR0272945",
    "display" : "FLUORESCEÍNA SÓDICA 2 % SOLUÇÃO OFTÁLMICA 3 ML"
  },
  {
    "code" : "BR0275963U0042",
    "display" : "FINASTERIDA 5 MG COMPRIMIDO"
  },
  {
    "code" : "BR0276871-3",
    "display" : "FLUORURACILA 50 MG/G CREME  20 G"
  },
  {
    "code" : "BR0270814",
    "display" : "DEXAMETASONA+ B1 + B6 + B12 4 + 100 + 100 + 5 MG SOLUÇÃO INJETÁVEL"
  },
  {
    "code" : "BR0268108",
    "display" : "GOSSERRELINA, ACETATO 10,8 MG SOLUÇÃO INJETÁVEL ELENCO ESTADUAL"
  },
  {
    "code" : "BR0273257",
    "display" : "OXCARBAZEPINA 300 MG COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0268531",
    "display" : "TENOXICAM 20 MG COMPRIMIDO"
  },
  {
    "code" : "BR0282237",
    "display" : "CARNITINA 200 MG/ML XAROPE  300 ML"
  },
  {
    "code" : "BR0270093",
    "display" : "GLICOSE + CLORETO DE SÓDIO 5 + 0,9 % SOLUÇÃO INJETÁVEL  1000 ML"
  },
  {
    "code" : "BR0273430",
    "display" : "MANITOL 20 % SOLUÇÃO INJETÁVEL 250 ML"
  },
  {
    "code" : "BR0268132",
    "display" : "LEVOMEPROMAZINA, CLORIDRATO 5 MG/ML SOLUÇÃO INJETÁVEL  5 ML"
  },
  {
    "code" : "BR0270558-2",
    "display" : "ACETILCISTEÍNA 20 MG/ML XAROPE  100 ML"
  },
  {
    "code" : "BR0362661-2",
    "display" : "CLINDAMICINA, FOSFATO 20 MG/G CREME  40 G"
  },
  {
    "code" : "BR0276867-1",
    "display" : "TIOCONAZOL + TINIDAZOL + SECNIDAZOL 20 + 30 + 1000 MG CREME VAGINAL + COMPRIMIDO 35 G"
  },
  {
    "code" : "BR0270045",
    "display" : "HIPROMELOSE + DEXTRANA 70 3 MG + 1 MG/ML SOLUÇÃO OFTÁLMICA 15 ML"
  },
  {
    "code" : "BR0287687",
    "display" : "EFEDRINA, SULFATO 50 mg/ml SOLUÇÃO INJETÁVEL 1 ML"
  },
  {
    "code" : "BR0269990",
    "display" : "ERITROMICINA, ESTEARATO 25 MG/ML SUSPENSÃO ORAL  60 ML"
  },
  {
    "code" : "BR0271138",
    "display" : "ISONIAZIDA + RIFAMPICINA 200 + 300 MG CÁPSULA"
  },
  {
    "code" : "BR0267418 -2",
    "display" : "TIABENDAZOL 50 MG/G POMADA 30 G"
  },
  {
    "code" : "BR0272850",
    "display" : "TOPIRAMATO 50 MG COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0268263",
    "display" : "METILERGOMETRINA, MALEATO 0,125 MG COMPRIMIDO"
  },
  {
    "code" : "BR0393328",
    "display" : "CLORETO DE POTÁSSIO 60 MG/ML XAROPE  100 ML"
  },
  {
    "code" : "BR0341180",
    "display" : "POLIESTIRENOSSULFONATO DE CÁLCIO 900 MG PÓ 30 G"
  },
  {
    "code" : "BR0282580",
    "display" : "MONOETANOLAMINA, OLEATO 5 % SOLUÇÃO INJETÁVEL 2 ML"
  },
  {
    "code" : "BR0303292U0039",
    "display" : "RINGER LACTATO SÓDICO SOLUÇÃO INJETÁVEL 500 ML SISTEMA FECHADO"
  },
  {
    "code" : "BR0273388",
    "display" : "IRBESARTANA 300 MG COMPRIMIDO"
  },
  {
    "code" : "BR0300989",
    "display" : "PERICIAZINA 4 % SOLUÇÃO ORAL 20 ML"
  },
  {
    "code" : "BR0299690-3",
    "display" : "METILPREDNISOLONA, ACETATO 40 MG/ML SUSPENSÃO INJETÁVEL 5 ML"
  },
  {
    "code" : "BR0276260",
    "display" : "RAMIPRIL 2,5 MG COMPRIMIDO"
  },
  {
    "code" : "BR0272198",
    "display" : "ETILEFRINA, CLORIDRATO 10 MG/ML SOLUÇÃO INJETÁVEL 1 ML"
  },
  {
    "code" : "BR0308874U0118",
    "display" : "PENTAMIDINA, ISETIONATO 300 MG PÓ PARA SOLUÇÃO INJETÁVEL"
  },
  {
    "code" : "BR0292791",
    "display" : "VALSARTANA + HIDROCLOROTIAZIDA 160 + 12,5  MG COMPRIMIDO"
  },
  {
    "code" : "BR0353397-2",
    "display" : "BERACTANTO (TENSOATIVO PULMONAR ORIGEM ANIMAL) 25 MG/ML SUSPENSÃO INJETÁVEL 8 ML"
  },
  {
    "code" : "BR0299675",
    "display" : "MANITOL 20 %  SOLUÇÃO INJETÁVEL 250 ML SISTEMA FECHADO"
  },
  {
    "code" : "BR0284465",
    "display" : "ALPRAZOLAM 2 MG COMPRIMIDO"
  },
  {
    "code" : "BR0395558U0285",
    "display" : "ÁCIDO SALICÍLICO 5 % POMADA"
  },
  {
    "code" : "BR0328361U0042",
    "display" : "TRATAMENTO MULTIBACILAR ADULTO COMPRIMIDO"
  },
  {
    "code" : "BR0268297U0042",
    "display" : "OFLOXACINO 400 MG COMPRIMIDO"
  },
  {
    "code" : "BR0292155",
    "display" : "TRIANCINOLONA, ACETONIDA 55 MCG/DOSE AEROSSOL 15 ML"
  },
  {
    "code" : "BR0269995",
    "display" : "ERITROMICINA, ESTOLATO 250 MG COMPRIMIDO"
  },
  {
    "code" : "BR0268109",
    "display" : "GOSSERRELINA, ACETATO 3,6 MG SUSPENSÃO INJETÁVEL ELENCO ESTADUAL"
  },
  {
    "code" : "BR0272581U0106",
    "display" : "TIMOLOL 5 MG/ML SOL OFT (FR) 5 ML GRUPO 2"
  },
  {
    "code" : "BR0412965-1",
    "display" : "SIMETICONA 75 MG/ML SUSPENSÃO ORAL  10 ML"
  },
  {
    "code" : "BR0309042",
    "display" : "ÁCIDO FOLÍNICO (FOLINATO DE CÁLCIO) 50 MG PÓ LIOFILIZADO PARA SOLUÇÃO INJETÁVEL"
  },
  {
    "code" : "BR0433279",
    "display" : "DIVALPROATO DE SÓDIO 250 MG COMPRIMIDO DE LIBERAÇÃO PROLONGADA"
  },
  {
    "code" : "BR0273639-7",
    "display" : "MULTIVITAMINAS + SAIS MINERAIS SOLUÇÃO ORAL 250 ML"
  },
  {
    "code" : "BR0411397-3",
    "display" : "PALIPERIDONA 100 MG/ML SUSPENSÃO INJETÁVEL 0,75 ML ELENCO ESTADUAL"
  },
  {
    "code" : "BR0434797",
    "display" : "BISOPROLOL, FUMARATO + HIDROCLOROTIAZIDA 10 + 25 MG COMPRIMIDO"
  },
  {
    "code" : "BR0432908",
    "display" : "DAPAGLIFLOZINA 10 MG COMPRIMIDO DE LIBERAÇÃO CONTROLADA"
  },
  {
    "code" : "BR0271116-1",
    "display" : "FLUCONAZOL 2 MG/ML SOL INJ (AMP) 100 ML"
  },
  {
    "code" : "BR0434935",
    "display" : "MULTIVITAMINAS COMPLEXO B, A, C, D3, E, K1; ASSOCIADAS COM SAIS MINERAIS  ZN, SE, NA + COENZIMA Q10 COMPRIMIDO MASTIGÁVEL"
  },
  {
    "code" : "BR0368919-4",
    "display" : "ÁCIDO ACÉTICO 5% SOLUÇÃO TÓPICA 10 ML"
  },
  {
    "code" : "BR0395721-7",
    "display" : "CARVÃO VEGETAL ATIVADO PÓ 15 G"
  },
  {
    "code" : "BR0327212-2",
    "display" : "LUGOL 5% SOLUÇÃO TÓPICA 10 ML"
  },
  {
    "code" : "BR0387359-1",
    "display" : "PAPAÍNA 2% GEL 50 G"
  },
  {
    "code" : "BR0379002",
    "display" : "ANIDULAFUNGINA PÓ LIOF INJ (AMP) 100 MG"
  },
  {
    "code" : "BR0274811",
    "display" : "LISINA, CLONIXINATO 125 MG COMPRIMIDO"
  },
  {
    "code" : "BR0313591",
    "display" : "POLICRESULENO 1,8 % GEL VAGINAL  50 G"
  },
  {
    "code" : "BR0276233-1",
    "display" : "INSULINA LISPRO 100 UI/ML SOLUÇÃO INJETÁVEL 3 ML ELENCO ESTADUAL"
  },
  {
    "code" : "BR0269963",
    "display" : "DOMPERIDONA 1 MG/ML SUSPENSÃO ORAL  100 ML"
  },
  {
    "code" : "BR0267281-1",
    "display" : "ESCOPOLAMINA, BUTILBROMETO 10 MG/ML SOLUÇÃO ORAL 20 ML"
  },
  {
    "code" : "BR0271139",
    "display" : "ISONIAZIDA + RIFAMPICINA 100 + 150 MG CÁPSULA"
  },
  {
    "code" : "BR0267518U0042",
    "display" : "ATENOLOL 100 MG COMPRIMIDO"
  },
  {
    "code" : "BR0294096U0118",
    "display" : "CEFTRIAXONA SÓDICA 250 mg MG PÓ PARA SOLUÇÃO INJETÁVEL   IV"
  },
  {
    "code" : "BR0337862U0170",
    "display" : "VACINA HEPATITE B (RECOMBINANTE) SUSPENSÃO INJETÁVEL"
  },
  {
    "code" : "BR0266699",
    "display" : "BUDESONIDA 50 MCG/DOSE AEROSSOL ORAL 100 DOSES"
  },
  {
    "code" : "BR0393327",
    "display" : "CIPROFLOXACINO + HIDROCORTISONA 2 + 10 MG/ML SUSPENSÃO OTOLÓGICA 5 ML"
  },
  {
    "code" : "BR0272588",
    "display" : "DIVALPROATO DE SÓDIO 250 MG MG COMPRIMIDO"
  },
  {
    "code" : "BR0272364-1",
    "display" : "SERTRALINA, CLORIDRATO 75 MG COMPRIMIDO"
  },
  {
    "code" : "BR0276965",
    "display" : "TELMISARTANA 40 MG COMPRIMIDO"
  },
  {
    "code" : "BR0277513",
    "display" : "FLUOXETINA, CLORIDRATO 20 MG/ML SOLUÇÃO ORAL  20 ML"
  },
  {
    "code" : "BR0276235",
    "display" : "INSULINA LISPRO + LISPRO PROTAMINA 25 + 75 % SOLUÇÃO INJETÁVEL 3 ML ELENCO ESTADUAL"
  },
  {
    "code" : "BR0272320",
    "display" : "METILFENIDATO, CLORIDRATO 10 MG COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0340104",
    "display" : "CETOPROFENO 200 MG  COMPRIMIDO DE LIBERAÇÃO PROLONGADA"
  },
  {
    "code" : "BR0274989",
    "display" : "SACARATO DE HIDRÓXIDO FÉRRICO  20 MG/ML SOLUÇÃO INJETÁVEL EV 5 ML"
  },
  {
    "code" : "BR0365441",
    "display" : "OXIBUTININA, CLORIDRATO 10 MG COMPRIMIDO DE LIBERAÇÃO PROLONGADA"
  },
  {
    "code" : "BR0285007",
    "display" : "ISOSSORBIDA, MONONITRATO + ÁCIDO ACETILSALICÍLICO 40 + 100 MG CÁPSULA"
  },
  {
    "code" : "BR0271687",
    "display" : "ÁCIDO ASCÓRBICO 100 MG/ML SOLUÇÃO INJETÁVEL 5 ML"
  },
  {
    "code" : "BR0272423-3",
    "display" : "CLOTRIMAZOL 10 MG/G CREME  50 G"
  },
  {
    "code" : "BR0267675",
    "display" : "HIDROCLOROTIAZIDA  50 MG COMPRIMIDO"
  },
  {
    "code" : "BR0270622",
    "display" : "ESCOPOLAMINA, BUTILBROMETO + DIPIRONA SÓDICA 6,67 + 333,4 MG/ML SOLUÇÃO ORAL 20 ML"
  },
  {
    "code" : "BR0280873",
    "display" : "CANDESARTANA CILEXETILA + HIDROCLOROTIAZIDA 16 + 12,5 MG COMPRIMIDO"
  },
  {
    "code" : "BR0273472",
    "display" : "LORAZEPAM 1 MG COMPRIMIDO"
  },
  {
    "code" : "BR0292264",
    "display" : "MORFINA, SULFATO 60 MG COMPRIMIDO DE LIBERAÇÃO CONTROLADA"
  },
  {
    "code" : "BR0305428-1",
    "display" : "CARMELOSE SÓDICA 5 MG/ML SOLUÇÃO OFTÁLMICA 5 ML"
  },
  {
    "code" : "BR0381063",
    "display" : "SITAGLIPTINA, FOSFATO + METFORMINA, CLORIDRATO 50 + 500 MG COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0299690-2",
    "display" : "METILPREDNISOLONA, ACETATO 40 MG/ML SUSPENSÃO INJETÁVEL 2 ML"
  },
  {
    "code" : "BR0278588",
    "display" : "ÁCIDO MUCOPOLISSACARÍDEO POLISSULFÚRICO 5 MG/G POMADA 40 G"
  },
  {
    "code" : "BR0274995",
    "display" : "FERRIPOLIMALTOSE 100 MG COMPRIMIDO MASTIGÁVEL"
  },
  {
    "code" : "BR0298446",
    "display" : "CROMOGLICATO DE SÓDIO 4 % SOLUÇÃO OFTÁLMICA 5 ML"
  },
  {
    "code" : "BR0276961",
    "display" : "TIZANIDINA, CLORIDRATO 2 MG COMPRIMIDO"
  },
  {
    "code" : "BR0300733",
    "display" : "DEXAMETASONA, FOSFATO DISSÓDICO 2 MG/ML SOLUÇÃO INJETÁVEL 1 ML"
  },
  {
    "code" : "BR0271124-1",
    "display" : "CETOTIFENO, FUMARATO 0,2 MG/ML XAROPE  100 ML"
  },
  {
    "code" : "BR0356952",
    "display" : "ACETILCISTEÍNA 600 MG COMPRIMIDO EFERVESCENTE"
  },
  {
    "code" : "BR0393331",
    "display" : "DESOGESTREL + ETINILESTRADIOL 0,15 + 0,03 MG COMPRIMIDO"
  },
  {
    "code" : "BR0296745",
    "display" : "OLMESARTANA + HIDROCLOROTIAZIDA 20 + 12,5 MG COMPRIMIDO"
  },
  {
    "code" : "BR0392659",
    "display" : "VACINA HUMANA, CONTRA INFLUENZA, FRAGMENTADA E INATIVADA, INFLUENZA CEPAS TIPO A (H1N1)/(H3N1) E TIPO B SUSPENSÃO INJETÁVEL"
  },
  {
    "code" : "BR0271102",
    "display" : "CARBONATO DE LÍTIO 450 MG COMPRIMIDO"
  },
  {
    "code" : "BR0272903",
    "display" : "CITALOPRAM 20 MG COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0276871-4",
    "display" : "FLUORURACILA 50 MG/G CREME  30 G"
  },
  {
    "code" : "BR0267590",
    "display" : "BECLOMETASONA, DIPROPIONATO 250 MCG/DOSE AEROSSOL NASAL 200 DOSES"
  },
  {
    "code" : "BR0394772U0118",
    "display" : "VACINA HUMANA, CONTRA SARAMPO, CAXUMBA, RUBÉOLA E VARICELA, TETRAVIRAL, MONODOSE, PÓ LIÓFILO P/ INJETÁVEL 0,5 ML SOLUÇÃO INJETÁVEL 5 ML"
  },
  {
    "code" : "BR0433516",
    "display" : "FÓSFORO QUELADO MEDICAMENTOS MANIPULADO CÁPSULA"
  },
  {
    "code" : "BR0332383",
    "display" : "IDURSULFASE 2 MG/ML SOL INJ (FR) 3 ML"
  },
  {
    "code" : "BR0429846",
    "display" : "APIXABANA 5 MG COMP"
  },
  {
    "code" : "BR0389710",
    "display" : "ADAPALENO 3 MG/G GEL 30 G"
  },
  {
    "code" : "BR0435105",
    "display" : "EXTRATO MEDICINAL, POLYPODIUM LEUCOTOMOS 250 MG COMPRIMIDO"
  },
  {
    "code" : "BR0435186",
    "display" : "METOXISALENO 0,1%  FORMULAÇÃO ESPECIALMENTE MANIPULADA CREME  50 G"
  },
  {
    "code" : "BR0435187",
    "display" : "METOXISALENO 0,2% FORMULAÇÃO ESPECIALMENTE MANIPULADA CREME  50 G"
  },
  {
    "code" : "BR0268575U0005",
    "display" : "DESMOPRESSINA, ACETATO 4,0 MCG/ML  AMP 1 ML"
  },
  {
    "code" : "BR0430403",
    "display" : "TRASTUZUMABE, ENTANSINA 100 MG PÓ LIOFILIZADO PARA SUSPENSÃO INJETÁVEL"
  },
  {
    "code" : "BR0422070",
    "display" : "URÉIA + ÁCIDO SALICÍLICO 20 + 3 % CREME  500 G"
  },
  {
    "code" : "BR039680-3",
    "display" : "PAPAÍNA 10 % GEL 100 G"
  },
  {
    "code" : "BR0270620",
    "display" : "ESCOPOLAMINA, BUTILBROMETO + DIPIRONA SÓDICA 10 + 250 MG COMPRIMIDO"
  },
  {
    "code" : "BR0275476",
    "display" : "DIPIRONA + PROMETAZINA + ADIFENINA 750 + 25 + 25 MG SOLUÇÃO INJETÁVEL 2 ML"
  },
  {
    "code" : "BR0268083",
    "display" : "AZATIOPRINA 50 MG COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0312390",
    "display" : "DEXTRANA 70 + HIPROMELOSE + GLICEROL 1 + 3 + 2 MG/ML SOLUÇÃO OFTÁLMICA 15 ML"
  },
  {
    "code" : "BR0395437",
    "display" : "VILDAGLIPTINA + METFORMINA, CLORIDRATO 50 + 1000 MG COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0366883",
    "display" : "ALISQUIRENO, HEMIFUMARATO 150 MG COMPRIMIDO"
  },
  {
    "code" : "BR0395517",
    "display" : "CANAQUINUMABE 150 MG PÓ PARA SOLUÇÃO INJETÁVEL"
  },
  {
    "code" : "BR0270457",
    "display" : "DEXAMETASONA, FOSFATO DISSÓDICO + NEOMICINA 1 + 3,5 MG/ML SOLUÇÃO OFTÁLMICA 5 ML"
  },
  {
    "code" : "BR0273140",
    "display" : "VERAPAMIL, CLORIDRATO 240 MG COMPRIMIDO DE LIBERAÇÃO CONTROLADA"
  },
  {
    "code" : "BR0270590",
    "display" : "BETAMETASONA,DIPROPIONATO + BETAMETASONA, FOSFATO DISSÓDICO 5 + 2 MG/ML SUSPENSÃO INJETÁVEL 1 ML"
  },
  {
    "code" : "BR0395836",
    "display" : "METRONIDAZOL + NISTATINA + CLORETO DE BENZALCÔNICO 250 MG + 100.000 UI + 1,25 MG/G CREME VAGINAL  40 G"
  },
  {
    "code" : "BR0273450U0042",
    "display" : "MOXIFLOXACINO, CLORIDRATO 400 MG COMPRIMIDO"
  },
  {
    "code" : "BR0395908",
    "display" : "LOSARTANA POTÁSSICA + ANLODIPINO, BESILATO 50 MG + 5 MG COMPRIMIDO"
  },
  {
    "code" : "BR0352180",
    "display" : "BETAMETASONA, VALERATO 1 MG/G POMADA 30 G"
  },
  {
    "code" : "BR0268533",
    "display" : "TENOXICAM 40 MG PÓ LIOFILIZADO"
  },
  {
    "code" : "BR0266809",
    "display" : "SALMETEROL, XINAFOATO 50 MCG PÓ PARA INALAÇÃO ORAL 60 DOSES ELENCO ESTADUAL"
  },
  {
    "code" : "BR0266630",
    "display" : "ALFAEPOETINA 10.000 UI SOLUÇÃO INJETÁVEL 1 ML ELENCO ESTADUAL"
  },
  {
    "code" : "BR0268274-2",
    "display" : "NITROFURAL 2 MG/G POMADA 500 G"
  },
  {
    "code" : "BR0305483",
    "display" : "MAPROTILINA, CLORIDRATO 25 MG COMPRIMIDO"
  },
  {
    "code" : "BR0323004",
    "display" : "ISOXSUPRINA, CLORIDRATO 5 MG/ML SOLUÇÃO INJETÁVEL  2 ML"
  },
  {
    "code" : "BR0269846U0015",
    "display" : "LIDOCAÍNA, CLORIDRATO 20 MG/G GEL 10 G"
  },
  {
    "code" : "BR0306355",
    "display" : "DICLOFENACO SÓDICO + CODEÍNA, FOSFATO 50 + 50 MG COMPRIMIDO"
  },
  {
    "code" : "BR0269821",
    "display" : "BROMEXINA, CLORIDRATO 1,6 MG/ML XAROPE  120 ML"
  },
  {
    "code" : "BR0396557",
    "display" : "VALSARTANA + HIDROCLOROTIAZIDA + ANLODIPINO 160 + 12,5 + 5 MG COMPRIMIDO"
  },
  {
    "code" : "BR0268274-1",
    "display" : "NITROFURAL 2 MG/G POMADA 30 G"
  },
  {
    "code" : "BR0387341",
    "display" : "FORMOTEROL + BUDESONIDA 6 + 200 MCG CÁPSULA  ELENCO ESTADUAL"
  },
  {
    "code" : "BR0331306",
    "display" : "MULTIVITAMINAS + SAIS MINIERAIS + LUTEÍNA + ZEAXANTINA 5 + 1 MG COMPRIMIDO"
  },
  {
    "code" : "BR0362721",
    "display" : "BISOPROLOL, FUMARATO 10 MG COMPRIMIDO"
  },
  {
    "code" : "BR0269998U0110",
    "display" : "ERITROMICINA, ESTOLATO 50 MG/ML SUSPENSÃO ORAL  60 ML"
  },
  {
    "code" : "BR0304871",
    "display" : "MORFINA, SULFATO 10 MG/ML SOLUÇÃO INJETÁVEL 1 ML"
  },
  {
    "code" : "BR0331158",
    "display" : "CIPROFLOXACINO, CLORIDRATO 3,5 MG/ML SOLUÇÃO OFTÁLMICA 5 ML"
  },
  {
    "code" : "BR0282889",
    "display" : "SENNA ALEXANDRINA MILL. + CASSIA FISTULA + TAMARINDUS INDICA L. + GLYCYRRHIZA GLABRA L. + CORIANDRUM SATIVUM CÁPSULA"
  },
  {
    "code" : "BR0388796",
    "display" : "METFORMINA, CLORIDRATO 500 MG MG COMPRIMIDO DE LIBERAÇÃO CONTROLADA"
  },
  {
    "code" : "BR0362260",
    "display" : "TRAZODONA, CLORIDRATO 150 MG COMPRIMIDO DE LIBERAÇÃO CONTROLADA"
  },
  {
    "code" : "BR0357058",
    "display" : "PAROXETINA, CLORIDRATO 15 MG COMPRIMIDO"
  },
  {
    "code" : "BR0325327",
    "display" : "RUTINA + CASTANHA DA INDIA + EXTRATO DE MIROTON 300 + 100 MG + 150 UC COMPRIMIDO"
  },
  {
    "code" : "BR0280116",
    "display" : "BOSENTANA 62,5 MG COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0270591",
    "display" : "BETAMETASONA, DIPROPIONATO + GENTAMICINA SULFATO 0,5 + 1 MG/G CREME  30 G"
  },
  {
    "code" : "BR0270443",
    "display" : "IFOSFAMIDA 1 G PÓ LIOFILIZADO PARA SOLUÇÃO INJETÁVEL"
  },
  {
    "code" : "BR0340195-3",
    "display" : "CITARABINA 100 MG/ML SOLUÇÃO INJETÁVEL 10 ML"
  },
  {
    "code" : "BR0431570",
    "display" : "METFORMINA, CLORIDRATO + SAXAGLIPTINA 1000 + 2,5 MG COMPRIMIDO DE LIBERAÇÃO CONTROLADA"
  },
  {
    "code" : "BR0327699-2",
    "display" : "PERMANGANATO DE POTÁSSIO 100 MG PÓ"
  },
  {
    "code" : "BR0274049-1",
    "display" : "FLUTICASONA, PROPIONATO 50 MCG SPRAY NASAL 10 ML"
  },
  {
    "code" : "BR0270376",
    "display" : "VINCRISTINA, SULFATO 1 MG PÓ PARA SOLUÇÃO INJETÁVEL 1 ML"
  },
  {
    "code" : "BR0271104",
    "display" : "CICLOSPORINA 25 MG  CÁPSULA  ELENCO ESTADUAL"
  },
  {
    "code" : "BR0272793",
    "display" : "FLUDROCORTISONA, ACETATO 0,1 MG COMPRIMIDO"
  },
  {
    "code" : "BR0266822",
    "display" : "IMUNOGLOBULINA HUMANA 2,5 G PÓ PARA SOLUÇÃO INJETÁVEL ELENCO ESTADUAL"
  },
  {
    "code" : "BR0268037",
    "display" : "LOVASTATINA 10 MG COMPRIMIDO"
  },
  {
    "code" : "BR0272027",
    "display" : "BAMIFILINA, CLORIDRATO 600 MG COMPRIMIDO"
  },
  {
    "code" : "BR0362057",
    "display" : "RIVASTIGMINA, HIDROGENOTARTARATO 9 MG ADESIVO TRANSDÉRMICO (4,6 MG/24H) ELENCO ESTADUAL"
  },
  {
    "code" : "BR0273167-1",
    "display" : "NEOMICINA + BACITRACINA 5 + 250 MG + UI/G POMADA 10 G"
  },
  {
    "code" : "BR0268237-4",
    "display" : "CLORETO DE SÓDIO 0,9% SUSPENSÃO INJETÁVEL 500 ML"
  },
  {
    "code" : "BR0340783U0062",
    "display" : "HIDRÓXIDO DE ALUMÍNIO 61,5 MG/ML SUSPENSÃO ORAL  100 ML"
  },
  {
    "code" : "BR0395797",
    "display" : "LEVONORGESTREL + ETINILESTRADIOL 50 + 30/75 + 40/125 + 30 MCG COMPRIMIDO"
  },
  {
    "code" : "BR0362059",
    "display" : "RIVASTIGMINA, HIDROGENOTARTARATO 27 MG ADESIVO TRANSDÉRMICO (13,3 MG/24H) ELENCO ESTADUAL"
  },
  {
    "code" : "BR0352193",
    "display" : "TOBRAMICINA + DEXAMETASONA 3+1 MG/ML SOLUÇÃO OFTÁLMICA 5 ML"
  },
  {
    "code" : "BR0313594",
    "display" : "POLICRESULENO + CINCHOCAÍNA, CLORIDRATO 240+24 MG SUPOSITÓRIO"
  },
  {
    "code" : "BR0306971",
    "display" : "OSELTAMIVIR, FOSFATO 15 MG/ML PÓ PARA SOLUÇÃO 50 ML"
  },
  {
    "code" : "BR0343877",
    "display" : "ÁCIDO ACETILSALICÍLICO  200 MG TAMPONADO COMPRIMIDO"
  },
  {
    "code" : "BR0332848",
    "display" : "BETAMETASONA, DIPROPIONATO + CALCIPOTRIOL 0,05 + 0,5 MG/G POMADA 30 G"
  },
  {
    "code" : "BR0367692",
    "display" : "ÁCIDO NICOTÍNICO 500 MG COMPRIMIDO DE LIBERAÇÃO PROLONGADA"
  },
  {
    "code" : "BR0395601",
    "display" : "ÁCIDO NICOTÍNICO 250 MG COMPRIMIDO DE LIBERAÇÃO PROLONGADA"
  },
  {
    "code" : "BR0290058",
    "display" : "ADALIMUMABE 40 MG/ML SOLUÇÃO INJETÁVEL ELENCO ESTADUAL"
  },
  {
    "code" : "BR0271761",
    "display" : "BICALUTAMIDA 50 MG COMPRIMIDO"
  },
  {
    "code" : "BR0270879",
    "display" : "ANLODIPINO, BESILATO + ENALAPRIL, MALEATO 5 MG+ 20 MG COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0296676",
    "display" : "CIPROTERONA, ACETATO + ESTRADIOL, VALERATO 2 + 1 MG  COMPRIMIDO"
  },
  {
    "code" : "BR0306685",
    "display" : "NATEGLINIDA 120 MG COMPRIMIDO"
  },
  {
    "code" : "BR0332849-1",
    "display" : "CALCIPOTRIOL 50 MCG/G POMADA 15 G"
  },
  {
    "code" : "BR0395520",
    "display" : "ASPARTATO DE MAGNÉSIO + CARBONATO DE CALCIO +  RANITIDINA + COLECALCIFEROL 50 + 500 + 150 MG + 400 UI CÁPSULA"
  },
  {
    "code" : "BR0395156",
    "display" : "PIMETIXENO, MALEATO 0,1 MG/ML XAROPE  100 ML"
  },
  {
    "code" : "BR0304182",
    "display" : "TIMOMODULINA 200 MG/ML XAROPE  120 ML"
  },
  {
    "code" : "BR0299317",
    "display" : "FENTANILA, CITRATO + DROPERIDOL 0,05 + 2,5 MG/ML SOLUÇÃO INJETÁVEL  2 ML"
  },
  {
    "code" : "BR0268462",
    "display" : "HALOTANO LIQUIDO INALANTE 100 ML"
  },
  {
    "code" : "BR0268412",
    "display" : "CEFTAZIDIMA 1G PÓ PARA SOLUÇÃO INJETÁVEL"
  },
  {
    "code" : "BR0268504-1",
    "display" : "ONDANSETRONA, CLORIDRATO 2 MG/ML SOLUÇÃO INJETÁVEL 4 ML"
  },
  {
    "code" : "BR0270813U0042",
    "display" : "CIANOCOBALAMINA + TIAMINA + PIRIDOXINA 5MG + 100MG + 100 MG COMPRIMIDO"
  },
  {
    "code" : "BR0328992",
    "display" : "TOLTERODINA, TARTARATO 4 MG COMPRIMIDO DE LIBERAÇÃO PROLONGADA ELENCO ESTADUAL"
  },
  {
    "code" : "BR0275944",
    "display" : "RILMENIDINA 1 MG COMPRIMIDO"
  },
  {
    "code" : "BR0294094",
    "display" : "LATANOPROSTA + TIMOLOL, MALEATO 50 MCG + 5 MG/ML SOLUÇÃO OFTÁLMICA 2,5 ML ELENCO ESTADUAL"
  },
  {
    "code" : "BR0270622-1",
    "display" : "ESCOPOLAMINA, BUTILBROMETO + DIPIRONA SÓDICA 6,67 + 333,4 MG/ML SOLUÇÃO ORAL 10 ML"
  },
  {
    "code" : "BR0352179-2",
    "display" : "BETAMETASONA, VALERATO 1 MG/G CREME  30 G"
  },
  {
    "code" : "BR0271685",
    "display" : "ÁCIDO ASCÓRBICO 1 G COMPRIMIDO EFERVESCENTE"
  },
  {
    "code" : "BR0395949",
    "display" : "RISEDRONATO SÓDICO 150 MG COMPRIMIDO"
  },
  {
    "code" : "BR0395730-1",
    "display" : "HIDRÓXIDO DE ALUMÍNIO + HIDRÓXIDO DE MAGNÉSIO 60 + 40 MG/ML SUSPENSÃO ORAL  100 ML"
  },
  {
    "code" : "BR0276662-2",
    "display" : "CONTRASTE RADIOLÓGICO, A BASE DE SULFATO DE BÁRIO 100 % SUSP ORAL (FR) 200 ML"
  },
  {
    "code" : "BR0410019",
    "display" : "ELTROMBOPAG OLAMINA 25 MG COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0410020",
    "display" : "ELTROMBOPAG OLAMINA 50 MG COMPRIMIDO"
  },
  {
    "code" : "BR0368612",
    "display" : "NITAZOXANIDA 500 MG COMPRIMIDO"
  },
  {
    "code" : "BR0404790E",
    "display" : "BOCEPREVIR 200 MG CAP GRUPO 1.A"
  },
  {
    "code" : "BR0268481-3",
    "display" : "MIDAZOLAM, CLORIDRATO 5 MG/ML SOLUÇÃO INJETÁVEL 10 ML"
  },
  {
    "code" : "BR0395601U0042",
    "display" : "ÁCIDO NICOTÍNICO 250 MG COMP DE LIB PROL GRUPO 2"
  },
  {
    "code" : "BR0367693U0042",
    "display" : "ÁCIDO NICOTÍNICO 750 MG COMP DE LIB PROL GRUPO 2"
  },
  {
    "code" : "BR0268352U0106",
    "display" : "BRIMONIDINA 2 MG/ML SOL OFT (FR) 5 ML GRUPO 2"
  },
  {
    "code" : "BR0271866U0106",
    "display" : "BRINZOLAMIDA 10 MG/ML SUSP OFT (FR) 5 ML GRUPO 2"
  },
  {
    "code" : "BR0267544U0034",
    "display" : "GLICOSE 10 % SOLUÇÃO INJETÁVEL 100 ML SISTEMA FECHADO"
  },
  {
    "code" : "BR0279118",
    "display" : "TICARCILINA + CLAVULANATO DE POTÁSSIO 3 + 100 G + MG PÓ LIOFILIZADO"
  },
  {
    "code" : "BR0354314",
    "display" : "CIMETIDINA 400 MG  MG COMPRIMIDO"
  },
  {
    "code" : "BR0342739",
    "display" : "HEPARINA SÓDICA 10.000 UI/ML SOLUÇÃO TÓPICA 50 ML"
  },
  {
    "code" : "BR0272088-3",
    "display" : "SULFADIAZINA DE PRATA + NITRATO DE CÉRIO 1 + 0,4 % CREME  120 G"
  },
  {
    "code" : "BR0340193-1",
    "display" : "CITARABINA 20 MG/ML SOLUÇÃO INJETÁVEL 5 ML"
  },
  {
    "code" : "BR0425364",
    "display" : "MULTIVITAMINAS, VITAMINAS A, COMPLEXO B, C, ASSOCIADAS ÁCIDO FÓLICO, BIOTINA, MG, ZN, FE COMPRIMIDO"
  },
  {
    "code" : "BR0389863-1",
    "display" : "SUGAMADEX 100 MG/ML SOLUÇÃO INJETÁVEL  5 ML"
  },
  {
    "code" : "BR0287252U0120",
    "display" : "NICOTINA 2 MG PASTILHA"
  },
  {
    "code" : "BR0428148",
    "display" : "QUERATINA + SENE + ENXOFRE SUBLIMADO + BITARTARATO DE POTÁSSIO 200 MG DRÁGEA"
  },
  {
    "code" : "BR0414431",
    "display" : "GOLIMUMABE 50 MG SOLUÇÃO INJETÁVEL  0,5 ML"
  },
  {
    "code" : "BR0387438",
    "display" : "CAFEÍNA 5MG/ML XAROPE  50 ML"
  },
  {
    "code" : "BR0392113 (INATIVO)",
    "display" : "RISPERIDONA 0,25 MG COMP REV"
  },
  {
    "code" : "BR0392113U0042",
    "display" : "RISPERIDONA 0,25 MG COMP REV"
  },
  {
    "code" : "BR0435745",
    "display" : "MORUS NIGRA L. - AMORA 500 MG CÁPSULA"
  },
  {
    "code" : "BR0284106U0097",
    "display" : "RISPERIDONA 1 MG/ML SOL ORAL (FR) 30 ML GRUPO 1.B"
  },
  {
    "code" : "BR433940",
    "display" : "MIKANIA GLOMERATA (GUACO) 60 MG/ML XPE (FR) 100 ML"
  },
  {
    "code" : "br0434084",
    "display" : "CHAMOMILLA RECUTITA (L.) - CAMOMILA 100 MG BISNAGA 10 MG"
  },
  {
    "code" : "BR0270415",
    "display" : "OXALIPLATINA 50 MG PÓ LIOFILIZADO PARA SOLUÇÃO INJETÁVEL"
  },
  {
    "code" : "BR0339981",
    "display" : "SOMATROPINA 15 MG SOLUÇÃO INJETÁVEL COM SISTEMA DE APLICAÇÃO 1,5 ML"
  },
  {
    "code" : "BR0395726-2",
    "display" : "OXOMEMAZINA + GUAIFENESINA + BENZOATO DE SÓDIO + PARACETAMOL 0,332+6,66+6,66+6,66 MG/ML XAROPE  120 ML"
  },
  {
    "code" : "BR0352394",
    "display" : "BUDESONIDA 400 MCG CÁPSULA  ELENCO ESTADUAL"
  },
  {
    "code" : "BR0273639-2",
    "display" : "MULTIVITAMINAS + SAIS MINERAIS COMPRIMIDO EFERVESCENTE"
  },
  {
    "code" : "BR0356452",
    "display" : "TRAVOPROSTA + TIMOLOL, MALEATO 0,04 + 5 MG/ML SOLUÇÃO OFTÁLMICA 2,5 ML"
  },
  {
    "code" : "BR0271118",
    "display" : "FLUFENAZINA, ENANTATO 25 MG/ML SOLUÇÃO INJETÁVEL  1 ML"
  },
  {
    "code" : "BR0395627",
    "display" : "POLIMIXINA B + NEOMICINA + LIDOCAINA + FLUDROCORTISONA 10.000 UI/ML + 10 + 1 + 40 MG/ML SOLUÇÃO OTOLÓGICA 8 ML"
  },
  {
    "code" : "BR0269822",
    "display" : "BROMEXINA, CLORIDRATO 0,8 MG/ML XAROPE  120 ML"
  },
  {
    "code" : "BR0284109",
    "display" : "BENZBROMARONA 100 MG COMPRIMIDO"
  },
  {
    "code" : "BR0358123",
    "display" : "RANIBIZUMABE 10 MG/ML SUSPENSÃO INJETÁVEL 0,23 ML"
  },
  {
    "code" : "BR0395618U0041",
    "display" : "CYNARA SCOLYMUS  (ALCACHOFRA) 300 MG CÁPSULA"
  },
  {
    "code" : "BR0395716U0030",
    "display" : "SCHINUS TEREBENTHIFOLIUS (AROEIRA) 0,67 ML/G CREME  60 G"
  },
  {
    "code" : "BR0292238",
    "display" : "MESALAZINA 800 MG COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0292029",
    "display" : "TIBOLONA 1,25 MG COMPRIMIDO"
  },
  {
    "code" : "BR0295391",
    "display" : "MECLIZINA 25 MG COMPRIMIDO"
  },
  {
    "code" : "BR0380865",
    "display" : "POLIMIXINA B + NEOMICINA + FLUOCINOLONA + LIDOCAÍNA 10.000 UI + 3,5 + 0,25 + 20 MG/ML SOLUÇÃO OTOLÓGICA 5 ML"
  },
  {
    "code" : "BR0315734",
    "display" : "GALANTAMINA, BROMIDRATO 24 MG CÁPSULA DE LIBERAÇÃO CONTROLADA"
  },
  {
    "code" : "BR0342980-1",
    "display" : "OCTREOTIDA, ACETATO 20 MG MG INJ (FR)"
  },
  {
    "code" : "BR0329359",
    "display" : "TIOCOLCHICOSÍDEO 2 MG/ML SOLUÇÃO INJETÁVEL  2 ML"
  },
  {
    "code" : "BR0351443",
    "display" : "RABEPRAZOL SÓDICO 10 MG COMPRIMIDO"
  },
  {
    "code" : "BR0287533",
    "display" : "DESONIDA 0,05 % CREME  60 G"
  },
  {
    "code" : "BR0327802",
    "display" : "AMILORIDA, CLORIDRATO + CLORTALIDONA 5 MG+ 25 MG COMPRIMIDO"
  },
  {
    "code" : "BR0270917",
    "display" : "PARACETAMOL + DICLOFENACO DE SÓDIO + CARISOPRODOL + CAFEÍNA 300 MG + 50 MG + 125 MG + 30 MG COMPRIMIDO"
  },
  {
    "code" : "BR0266766",
    "display" : "ALFAINTERFERONA 2B 10.000.000 UI PÓ LIOFILIZADO PARA SOLUÇÃO INJETÁVEL"
  },
  {
    "code" : "BR0267470",
    "display" : "ALFAPEGINTERFERONA 2A 180 MCG SOLUÇÃO INJETÁVEL ELENCO ESTADUAL"
  },
  {
    "code" : "BR0270785",
    "display" : "FENOTEROL, BROMIDRATO 100 MCG/DOSE AEROSSOL 200 DOSES"
  },
  {
    "code" : "BR0292765",
    "display" : "PROPRANOLOL, CLORIDRATO + HIDROCLOROTIAZIDA 40 + 25 MG COMPRIMIDO"
  },
  {
    "code" : "BR0267713",
    "display" : "OMEPRAZOL 40 MG COMPRIMIDO"
  },
  {
    "code" : "BR0395602",
    "display" : "ÁCIDO GAMAMINOBUTÍRICO + LISINA + TIAMINA + PIRIDOXINA + CÁLCIO 100 MG + 100 MG + 4 MG + 8 MG + 8 MG/ML XAROPE  100 ML"
  },
  {
    "code" : "BR0395718",
    "display" : "SILDENAFILA, CITRATO 12,5 MG CÁPSULA"
  },
  {
    "code" : "BR0395885",
    "display" : "TRICLOSANA 1 % SABONETE 100 ML"
  },
  {
    "code" : "BR0275475-2",
    "display" : "DIPIRONA + PROMETAZINA + ADIFENINA 500 + 5 + 10 MG SOLUÇÃO ORAL 20 ML"
  },
  {
    "code" : "BR0273953",
    "display" : "PROGESTERONA 100 MG CÁPSULA"
  },
  {
    "code" : "BR0268072",
    "display" : "SELEGILINA, CLORIDRATO 5 MG COMPRIMIDO"
  },
  {
    "code" : "BR0292278",
    "display" : "PERGOLIDA, MESILATO 0,25 MG COMPRIMIDO"
  },
  {
    "code" : "BR0266628",
    "display" : "ALFAEPOETINA 2.000 UI SOLUÇÃO INJETÁVEL ELENCO ESTADUAL"
  },
  {
    "code" : "BR0267473",
    "display" : "ALFAPEGINTERFERONA 2B 100 MCG PÓ LIOFILIZADO PARA SOLUÇÃO INJETÁVEL ELENCO ESTADUAL"
  },
  {
    "code" : "BR0271107",
    "display" : "CICLOSPORINA 100 MG CÁPSULA  ELENCO ESTADUAL"
  },
  {
    "code" : "BR0268443",
    "display" : "CODEÍNA 30 MG/ML SOLUÇÃO INJETÁVEL 2 ML"
  },
  {
    "code" : "BR0361382",
    "display" : "DEFERIPRONA 500 MG COMPRIMIDO"
  },
  {
    "code" : "BR0267084",
    "display" : "FLUVASTATINA SÓDICA 40 MG CÁPSULA"
  },
  {
    "code" : "BR0305652",
    "display" : "FORMOTEROL + BUDESONIDA 12 + 400 MCG PÓ PARA INALAÇÃO ORAL 60 DOSES ELENCO ESTADUAL"
  },
  {
    "code" : "BR0395439",
    "display" : "FLUTICASONA, FUORATO 27,5 MCG/DOSE SPRAY NASAL 120 DOSES"
  },
  {
    "code" : "BR0305236",
    "display" : "CONTRASTE RADIOLOGICO, À BASE DE IOPAMIDOL 300 MG/ML SOLUÇÃO INJETÁVEL 50 ML"
  },
  {
    "code" : "BR0353397-1",
    "display" : "BERACTANTO (TENSOATIVO PULMONAR ORIGEM ANIMAL) 25 MG/ML SUSPENSÃO INJETÁVEL 4 ML"
  },
  {
    "code" : "BR0338298",
    "display" : "VORICONAZOL 200 MG PÓ LIOFILIZADO"
  },
  {
    "code" : "354516",
    "display" : "INATIVO- GLIPIZIDA 5 MG COMPRIMIDO"
  },
  {
    "code" : "BR0332849U0023",
    "display" : "CALCIPOTRIOL 50 MCG/G POM (BIS) 30 G GRUPO 2"
  },
  {
    "code" : "BR0414435U0135",
    "display" : "CERTOLIZUMABE PEGOL 200 MG/ML SOL INJ (SER PREENC) GRUPO 1.A"
  },
  {
    "code" : "BR0284460U0104",
    "display" : "CLOBETASOL 0,5 MG/G SOL CAPI (FR) 50 G GRUPO 2"
  },
  {
    "code" : "BR0414431U0135",
    "display" : "GOLIMUMABE 50 MG SOL INJ (SER PREENC) GRUPO 1.A"
  },
  {
    "code" : "BR0268520U0105",
    "display" : "RITUXIMABE 500 MG SOL INJ (FR-AMP) 50 ML GRUPO 1.A"
  },
  {
    "code" : "BR0352933-2",
    "display" : "LEVETIRACETAM 100 MG/ML SOLUÇÃO ORAL  500 ML"
  },
  {
    "code" : "BR0266701U0061",
    "display" : "BUDESONIDA 50 MCG/DOSE SOLUÇÃO NASAL 100 DOSES"
  },
  {
    "code" : "BR0266707-1",
    "display" : "BUDESONIDA 64 MCG/DOSE SOLUÇÃO NASAL 60 DOSES"
  },
  {
    "code" : "BR0340195 -1",
    "display" : "CITARABINA 100 mg/ml SOLUÇÃO INJETÁVEL 1 ML"
  },
  {
    "code" : "BR0271197",
    "display" : "PINDOLOL + CLOPAMIDA 10 MG + 5 MG COMPRIMIDO"
  },
  {
    "code" : "BR0268439-3",
    "display" : "INATIVO- CLARITROMICINA 500 MG  COMPRIMIDO"
  },
  {
    "code" : "BR0340121",
    "display" : "VARENICLINA, TARTARATO 0,5 + 1 MG COMPRIMIDO 11 + 42 COMPRIMIDOS"
  },
  {
    "code" : "BR0383688-1",
    "display" : "INSULINA ASPARTE + ASPARTE PROTAMINA 30 % + 70 % 100 UI/ML SOLUÇÃO INJETÁVEL COM SISTEMA DE APLICAÇÃO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0413041",
    "display" : "PLERIXAFOR 20 MG/ML SOLUÇÃO INJETÁVEL 1,2 ML"
  },
  {
    "code" : "BR0342469",
    "display" : "FENILBUTAZONA, CÁLCICA 200 MG COMPRIMIDO"
  },
  {
    "code" : "BR0402531",
    "display" : "FOLITROPINA, BETA 300 UI SOLUÇÃO INJETÁVEL  0,480 ML"
  },
  {
    "code" : "BR0426208",
    "display" : "TELMISARTANA + ANLODIPINO 80 + 5 MG COMPRIMIDO"
  },
  {
    "code" : "BR0318943",
    "display" : "CLORETO DE SÓDIO + CLORETO DE BENZALCÔNIO + NAFAZOLINA 9 + 0,1 + 0,5 MG/ML SOLUÇÃO NASAL 30 ML"
  },
  {
    "code" : "BR0368779U0067",
    "display" : "MIKANIA GLOMERATA (GUACO) 117,6 MG/ML XAROPE  120 ML"
  },
  {
    "code" : "BR0305738",
    "display" : "ÓLEO DE PRÍMULA 500 MG CÁPSULA"
  },
  {
    "code" : "BR0270835",
    "display" : "ESTRADIOL 50 MCG ADESIVO TRANSDÉRMICO"
  },
  {
    "code" : "BR0415213",
    "display" : "ALENDRONATO DE SÓDIO + CARBONATO DE CÁLCIO + COLECALCIFEROL 70 MG + 500 MG + 200 UI COMPRIMIDO"
  },
  {
    "code" : "BR0273694",
    "display" : "METILCELULOSE 2% SOL INJ (SER PREENC) 1,5 ML"
  },
  {
    "code" : "BR0394770",
    "display" : "VACINA HUMANA, CONTRA HPV ONCOGÊNICO (16 E 18), RECOMBINANTE, COM ADJUVANTE ASO4, 20 MCG, MONODOSE, SUSPENSÃO INJETÁVEL 0,5 ML SOLUÇÃO INJETÁVEL 0,5 ML"
  },
  {
    "code" : "BR0300498",
    "display" : "SUCRALFATO 200 MG/ML SUSP ORAL (FR) 10 ML"
  },
  {
    "code" : "BR0342680",
    "display" : "TRIPTORRELINA, ACETATO 11,25 MG SUSP INJ (FR-AMP) 2 ML"
  },
  {
    "code" : "BR039680-1",
    "display" : "PAPAÍNA 10 % GEL 50 G"
  },
  {
    "code" : "BR0309437-1",
    "display" : "TRAMADOL, CLORIDRATO 100 MG COMPRIMIDO DE LIBERAÇÃO PROLONGADA"
  },
  {
    "code" : "BR0410023",
    "display" : "DIPIRONA SÓDICA  1 G COMPRIMIDO"
  },
  {
    "code" : "BR0372335U0029",
    "display" : "METRONIDAZOL 100 MG/G BISNAGA 50 G"
  },
  {
    "code" : "BR0430315",
    "display" : "AFLIBERCEPT  40 MG/ML SOLUÇÃO INJETÁVEL 0,278  ML"
  },
  {
    "code" : "BR0338134",
    "display" : "ESPIRONOLACTONA  50 MG COMPRIMIDO"
  },
  {
    "code" : "BR0270911",
    "display" : "PARACETAMOL + CARISOPRODOL + CAFEINA 350 + 150 + 50 MG COMPRIMIDO"
  },
  {
    "code" : "BR0432197U0042",
    "display" : "GLYCINE MAX (ISOFLAVONA DE SOJA) 125 MG COMP REV"
  },
  {
    "code" : "BR0432210U0041",
    "display" : "UNCARIA TOMENTOSA (UNHA DE GATO) 450MG CÁPSULA"
  },
  {
    "code" : "BR0273702U0042",
    "display" : "NAPROXENO 250 MG COMP GRUPO 2"
  },
  {
    "code" : "BR0268005U0081",
    "display" : "TRAVOPROSTA 0,04 MG/ML SOL OFT (FR) 2,5 ML GRUPO 1.A"
  },
  {
    "code" : "BR0340191",
    "display" : "CITARABINA 100 MG  PÓ LIOFILIZADO PARA SOLUÇÃO INJETÁVEL"
  },
  {
    "code" : "BR0340138",
    "display" : "CETRORRELIX, ACETATO 0,25 MG  PÓ PARA SOLUÇÃO INJETÁVEL"
  },
  {
    "code" : "BR0320824",
    "display" : "BENAZEPRIL, CLORIDRATO 5 MG COMPRIMIDO"
  },
  {
    "code" : "BR0270127-3",
    "display" : "INATIVO- LEVODOPA + BENSERAZIDA  100 + 25 MG COMPRIMIDO"
  },
  {
    "code" : "BR0269072-1",
    "display" : "ÁCIDO TRICLOROACÉTICO 75 % SOLUÇÃO 20  ML"
  },
  {
    "code" : "BR0272567",
    "display" : "RETINOL + COLECALCIFEROL  5.500+ 2.200 UI/ML SOLUÇÃO ORAL 10  ML"
  },
  {
    "code" : "BR0380855",
    "display" : "DICLOFENACO DIETILAMONIO 11,6 MG/G AEROSSOL 85 ML"
  },
  {
    "code" : "BR0434945",
    "display" : "EXTRATO MEDICINAL, TRIFOLIUM PRATENSE L. 100 MG COMP"
  },
  {
    "code" : "BR0375387",
    "display" : "SOLUÇÃO OFTÁLMICA POLIETILENOGLICOL, COMPOSIÇÃO 400, PROPILENOGLICOL,HIDROXIPROPIL GUAR, ÁC.BÓRICO SOLUÇÃO OFTÁLMICA 10 ML"
  },
  {
    "code" : "BR0433257-1",
    "display" : "HIDRÓXIDO DE ALUMÍNIO 60 MG/ML SOLUÇÃO ORAL 100 ML"
  },
  {
    "code" : "BR0268477",
    "display" : "FLUORURACILA 25 MG/ML SOLUÇÃO INJETÁVEL  10 ML"
  },
  {
    "code" : "BR0377899",
    "display" : "VALERIANA OFFICINALIS, EXTRATO SECO 50 MG CÁPSULA"
  },
  {
    "code" : "BR0274996-1",
    "display" : "FERRIPOLIMALTOSE 10 MG/ML XAROPE  100 ML"
  },
  {
    "code" : "BR0273403",
    "display" : "ISOSSORBIDA, MONONITRATO 50 MG CÁPSULA DE LIBERAÇÃO CONTROLADA"
  },
  {
    "code" : "BR0266963",
    "display" : "SOMATROPINA 12 UI SOLUÇÃO INJETÁVEL  1,5 ML"
  },
  {
    "code" : "BR0268119",
    "display" : "HIDROXICLOROQUINA 400 MG COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0285689",
    "display" : "EZETIMIBA + SINVASTATINA 10 + 40 MG COMPRIMIDO"
  },
  {
    "code" : "BR0277525-2",
    "display" : "DIDANOSINA 250 MG CÁPSULA"
  },
  {
    "code" : "BR0280505",
    "display" : "ADEFOVIR 10 MG COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0388401",
    "display" : "OLMESARTANA + ANLODIPINO 40 + 5 MG COMPRIMIDO"
  },
  {
    "code" : "BR0395465",
    "display" : "ÁCIDO NICOTÍNICO 1000 MG COMPRIMIDO DE LIBERAÇÃO PROLONGADA"
  },
  {
    "code" : "BR0296650",
    "display" : "LEVOTIROXINA SÓDICA 112 MCG COMPRIMIDO"
  },
  {
    "code" : "BR0272406",
    "display" : "NAFAZOLINA, CLORIDRATO + FENIRAMINA, MALEATO 0,25 + 3 MG/ML SOLUÇÃO OFTÁLMICA 15 ML"
  },
  {
    "code" : "BR0267160",
    "display" : "CLORETO DE POTÁSSIO 15% SOLUÇÃO INJETÁVEL 10 ML"
  },
  {
    "code" : "BR0345240U0018",
    "display" : "HIDROCORTISONA, ACETATO 10 MG/G CREME  20 G"
  },
  {
    "code" : "BR0395609",
    "display" : "ÁCIDO ASCÓRBICO + ZINCO, CITRATO 1 G + 10 MG COMPRIMIDO EFERVESCENTE"
  },
  {
    "code" : "BR0358450",
    "display" : "DARIFENACINA, BROMIDRATO 15 MG COMPRIMIDO DE LIBERAÇÃO PROLONGADA"
  },
  {
    "code" : "BR0395947",
    "display" : "ÁCIDO CÍTRICO + CITRATO DE SÓDIO + CITRATO DE POTÁSSIO 70 MG + 98 MG + 108 MG/ML XAROPE  500 ML"
  },
  {
    "code" : "BR0326010",
    "display" : "TRIANCINOLONA, ACETONIDA 1 MG/G ORABASE 10 G"
  },
  {
    "code" : "BR0267088",
    "display" : "GENFIBROZILA 600 MG COMPRIMIDO"
  },
  {
    "code" : "BR0324415",
    "display" : "ETORICOXIBE 90 MG COMPRIMIDO"
  },
  {
    "code" : "BR0396414U0243",
    "display" : "PLANTAGO OVATA (PSYLLIUM) PÓ PARA DISPERSÃO ORAL 3,5 G"
  },
  {
    "code" : "BR0282889-1",
    "display" : "SENNA ALEXANDRINA MILL. + CASSIA FISTULA + TAMARINDUS INDICA L. + GLYCYRRHIZA GLABRA L. + CORIANDRUM SATIVUM GELÉIA 260 G"
  },
  {
    "code" : "BR0266532-2",
    "display" : "FENOTEROL, BROMIDRATO 200 MCG AEROSSOL 300 DOSES"
  },
  {
    "code" : "BR0369183",
    "display" : "IMUNOGLOBULINA ANTI-HEPATITE B 100 UI SOLUÇÃO INJETÁVEL"
  },
  {
    "code" : "BR0267471U0118",
    "display" : "ALFAPEGINTERFERONA 2B 120 MCG PÓ LIOF INJ (FR-AMP) GRUPO 1.A"
  },
  {
    "code" : "BR0268079U0042",
    "display" : "AMANTADINA 100 MG COMP GRUPO 1.B"
  },
  {
    "code" : "BR0268181U0041",
    "display" : "ETOFIBRATO 500 MG CAP GRUPO 2"
  },
  {
    "code" : "BR0267586E",
    "display" : "BECLOMETASONA 200 MCG CAP INAL GRUPO 2"
  },
  {
    "code" : "BR0342501U0041",
    "display" : "FENOFIBRATO 250 MG CAP DE LIB RETARD GRUPO 2"
  },
  {
    "code" : "BR0270785U0084",
    "display" : "FENOTEROL 100 MCG AER BUCAL (FR DE 200 DOSES) GRUPO 2"
  },
  {
    "code" : "BR0266809U0109",
    "display" : "SALMETEROL 50 MCG PÓ INAL OU AER BUCAL (FR DE 60 DOSES) GRUPO 2"
  },
  {
    "code" : "BR0277438U0118",
    "display" : "BETAINTERFERONA 1B 9.600.000UI (300MG) PÓ LIOF INJ (FR-AMP) GRUPO 1.A"
  },
  {
    "code" : "BR0266599U0109",
    "display" : "FORMOTEROL 12 MCG PÓ INAL (FR DE 60 DOSES) GRUPO 2"
  },
  {
    "code" : "BR0340783-1E",
    "display" : "HIDRÓXIDO DE ALUMÍNIO 61,5 MG SUSP ORAL (FR) 100 ML GRUPO 2"
  },
  {
    "code" : "BR0305106",
    "display" : "GLUCAGON 1 MG PÓ LIOFILIZADO 1 ML"
  },
  {
    "code" : "BR0392111",
    "display" : "PREGABALINA 150 MG CÁPSULA"
  },
  {
    "code" : "BR0354633U0081",
    "display" : "OLOPATADINA 2 MG/ML SOLUÇÃO OFTÁLMICA 2,5 ML"
  },
  {
    "code" : "BR0292372",
    "display" : "TOXINA BOTULINICA TIPO A 100 UI SOLUÇÃO INJETÁVEL ELENCO ESTADUAL"
  },
  {
    "code" : "BR0269575",
    "display" : "BUPIVACAÍNA, CLORIDRATO 0,75 % SOLUÇÃO INJETÁVEL  20 ML"
  },
  {
    "code" : "BR0272083",
    "display" : "SEVELÂMER, CLORIDRATO 800 MG COMPRIMIDO"
  },
  {
    "code" : "BR0371273-3",
    "display" : "CLORETO DE SÓDIO 0,9% ESTÉRIL SOLUÇÃO 250 ML NÃO INJETÁVEL"
  },
  {
    "code" : "BR0268397",
    "display" : "AZTREONAM 1 G PÓ PARA SOLUÇÃO INJETÁVEL"
  },
  {
    "code" : "BR0340194",
    "display" : "CITARABINA 50 MG/ML SOLUÇÃO INJETÁVEL 10 ML"
  },
  {
    "code" : "BR0278283U0042",
    "display" : "ACETAZOLAMIDA 250 MG COMP GRUPO 2"
  },
  {
    "code" : "BR0340183",
    "display" : "CISPLATINA 50 MG  PÓ LIOFILIZADO PARA SOLUÇÃO INJETÁVEL"
  },
  {
    "code" : "BR0417713U0042",
    "display" : "GLICLAZIDA 60 MG COMPRIMIDO DE LIBERAÇÃO PROLONGADA"
  },
  {
    "code" : "BR0399799",
    "display" : "SULTIAMO 50 MG COMPRIMIDO"
  },
  {
    "code" : "BR0266701U0109",
    "display" : "BUDESONIDA 50 MCG/DOSE SOLUÇÃO NASAL 60 DOSES"
  },
  {
    "code" : "BR0400470",
    "display" : "LISADO BACTERIANO 6 MG CÁPSULA"
  },
  {
    "code" : "BR0278393",
    "display" : "TRETINOÍNA 10 MG CÁPSULA"
  },
  {
    "code" : "BR0389863",
    "display" : "SUGAMADEX 100 MG/ML SOLUÇÃO INJETÁVEL  2 ML"
  },
  {
    "code" : "BR0383485",
    "display" : "TENECTEPLASE 50 MG PÓ PARA SOLUÇÃO INJETÁVEL 10 ML"
  },
  {
    "code" : "BR0373165U0118",
    "display" : "CAPREOMICINA 1 G PÓ LIOFILIZADO PARA SOLUÇÃO INJETÁVEL"
  },
  {
    "code" : "BR0333446-1",
    "display" : "PALIVIZUMABE 100 MG PÓ LIOF INJ (FR-AMP) ELENCO ESTADUAL"
  },
  {
    "code" : "BR0426668-1",
    "display" : "PALIVIZUMABE 50 MG PÓ LIOF INJ (FR-AMP) 1 ML ELENCO ESTADUAL"
  },
  {
    "code" : "BR0268481-4",
    "display" : "MIDAZOLAM, CLORIDRATO 5 MG/ML SOLUÇÃO INJETÁVEL 3 ML"
  },
  {
    "code" : "BR0340107",
    "display" : "CETOPROFENO 100 MG  SUPOSITÓRIO"
  },
  {
    "code" : "BR0426931",
    "display" : "CASSIA ANGUSTIFOLIA + TAMARINDUS INDICA +CASSIA FISTULA + CORIANDRUM SATIVUM 240 + 11,7  + 11,7 + 5,4 MG CÁPSULA"
  },
  {
    "code" : "BR0428786",
    "display" : "ALBUMINA HUMANA 10 % SOLUÇÃO INJETÁVEL  50 ML"
  },
  {
    "code" : "BR0401579-1",
    "display" : "BROSIMUM GAUDICHAUDII 200 MG/G POMADA 80 G"
  },
  {
    "code" : "BR0428952",
    "display" : "BROSIMUM GAUDICHAUDII 400 MG COMPRIMIDO"
  },
  {
    "code" : "BR0429010",
    "display" : "OLEO DE PEIXE 1100  MG CÁPSULA"
  },
  {
    "code" : "BR0428744-2",
    "display" : "COLECALCIFEROL 5.600 UI/ML SOLUÇÃO ORAL  10 ML"
  },
  {
    "code" : "BR0381879",
    "display" : "OMEPRAZOL MAGNÉSIO 10,3 MG COMPRIMIDO"
  },
  {
    "code" : "BR0430482",
    "display" : "OLEO DE PEIXE 1000 MG CÁPSULA"
  },
  {
    "code" : "BR0269760-1",
    "display" : "GENTAMICINA, SULFATO 140MG/ML AMP 2 ML"
  },
  {
    "code" : "BR0432782",
    "display" : "INSULINA DEGLUDECA 100 UI/ML INJ (FR) 3 ML ELENCO ESTADUAL"
  },
  {
    "code" : "BR0432741",
    "display" : "HIALURONATO DE SÓDIO 0,15% SOL OFT (FR) 10  ML"
  },
  {
    "code" : "BR0267328-1",
    "display" : "FOSFATO DE SÓDIO MONOBÁSICO + FOSFATO DE SÓDIO DIBÁSICO 0,16 G + 0,068 G/ML ENEMA  133 ML"
  },
  {
    "code" : "BR0384467",
    "display" : "NEPAFENACO 1MG/ML SUSP OFT (FR) 5 ML"
  },
  {
    "code" : "BR0270398",
    "display" : "MITOMICINA 5 MG PÓ LIOFILIZADO PARA SOLUÇÃO INJETÁVEL 10 ML"
  },
  {
    "code" : "BR0417026",
    "display" : "ASENAPINA 5 MG COMPRIMIDO SUBLINGUAL"
  },
  {
    "code" : "BR0275123",
    "display" : "PIRACETAM 400 MG COMPRIMIDO"
  },
  {
    "code" : "BR0413608",
    "display" : "MIDODRINA, CLORIDRATO 10 MG COMPRIMIDO"
  },
  {
    "code" : "BR0368922-1",
    "display" : "ÁCIDO ACÉTICO 2 % SOLUÇÃO 1000 ML"
  },
  {
    "code" : "BR0280115U0042",
    "display" : "BOSENTANA 125 MG COMP REV GRUPO 1.B"
  },
  {
    "code" : "BR0430292",
    "display" : "ÁCIDO ASCÓRBICO + ALFATOCOFEROL + ZINCO + SELÊNIO + RETINOL 45 MG + 4,4 MG + 3,75 MG + 17,5 MCG + 400 MCG COMPRIMIDO"
  },
  {
    "code" : "BR0434050",
    "display" : "MALVA SANTA 20% TINTURA 30 ML"
  },
  {
    "code" : "BR0394810U0004",
    "display" : "SORO, ANTIBOTRÓPICO-CROTÁLICO 5 MG + 1,5 MG/ML SOL INJ (AMP) 5 ML"
  },
  {
    "code" : "BR0436202",
    "display" : "PAROXETINA, CLORIDRATO 60 MG CÁPSULA"
  },
  {
    "code" : "BR0296742",
    "display" : "OLMESARTANA, MEDOXOMILA 40 MG COMP REV"
  },
  {
    "code" : "BR0411397-5",
    "display" : "PALIPERIDONA 150 MG SUSPENSÃO INJETÁVEL 1,5 ML"
  },
  {
    "code" : "BR436303",
    "display" : "CODEINA + MELOXICAN + PARACETAMOL + RANITIDINA  40 + 7,5 + 500 + 150 MG CÁPSULA"
  },
  {
    "code" : "BR0436303",
    "display" : "CODEINA + MELOXICAN + PARACETAMOL + RANITIDINA  40 + 7,5 + 500 + 150 MG CÁPSULA"
  },
  {
    "code" : "BR0278356",
    "display" : "AZELASTINA, CLORIDRATO 1 MG/ML SOLUÇÃO NASAL  10 ML"
  },
  {
    "code" : "BR0268427",
    "display" : "CICLOFOSFAMIDA 50 MG  COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0273821U0042",
    "display" : "SILDENAFILA 50 MG COMP GRUPO 1.B"
  },
  {
    "code" : "BR0388383U0162",
    "display" : "TOCILIZUMABE 20 MG/ML SOL INJ (FR-AMP) 4 ML GRUPO 1.A"
  },
  {
    "code" : "BR0387982",
    "display" : "RISPERIDONA 37,5 MG PÓ LIOFILIZADO"
  },
  {
    "code" : "BR0268534-1",
    "display" : "TRAMADOL, CLORIDRATO 50 MG CÁPSULA"
  },
  {
    "code" : "BR0383688",
    "display" : "INSULINA ASPARTE + ASPARTE PROTAMINA 30 % + 70 % 100 UI/ML SOLUÇÃO INJETÁVEL  3 ML ELENCO ESTADUAL"
  },
  {
    "code" : "BR0268353U0042",
    "display" : "NEVIRAPINA 200 MG COMPRIMIDO"
  },
  {
    "code" : "BR0296486",
    "display" : "METFORMINA, CLORIDRATO 1 G COMPRIMIDO"
  },
  {
    "code" : "BR0326902",
    "display" : "ETAMBUTOL, CLORIDRATO 25 MG/ML SUSPENSÃO ORAL  200 ML"
  },
  {
    "code" : "BR0267081",
    "display" : "FENOFIBRATO 200 MG CÁPSULA"
  },
  {
    "code" : "BR0392647",
    "display" : "VACINA HUMANA CONTRA DTP + HAEMOPHILUS INFLUENZAE TIPO B MONODOSE PÓ LIOFILIZADO + SUSPENSÃO INJETÁVEL"
  },
  {
    "code" : "BR0392762",
    "display" : "FLUTICASONA, PROPIONATO 250 MCG PÓ PARA INALAÇÃO ORAL 60 CAPS."
  },
  {
    "code" : "BR0268501",
    "display" : "NALBUFINA, CLORIDRATO 10 MG/ML SOLUÇÃO INJETÁVEL 1 ML"
  },
  {
    "code" : "BR0278310U0118",
    "display" : "VACINA BCG SOLUÇÃO INJETÁVEL"
  },
  {
    "code" : "BR0392775U0236",
    "display" : "VACINA HUMANA, ADSORVIDA, DUPLA BACTERIANA (TOX. DIFTÉRICO + TOX. TETÂNICO) SOLUÇÃO INJETÁVEL 10 ML"
  },
  {
    "code" : "BR0272831",
    "display" : "QUETIAPINA, FUMARATO 25 MG COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0308884U0062",
    "display" : "SULFAMETOXAZOL + TRIMETOPRIMA  40 + 8 MG/ML SUSPENSÃO ORAL  100 ML ELENCO ESTADUAL"
  },
  {
    "code" : "BR0267617U0042",
    "display" : "CARBAMAZEPINA  400 MG COMPRIMIDO"
  },
  {
    "code" : "BR0278268-1",
    "display" : "TRIFLUOPERAZINA, DICLORIDRATO 2 MG COMPRIMIDO"
  },
  {
    "code" : "BR0278268",
    "display" : "TRIFLUOPERAZINA, DICLORIDRATO 5 MG COMPRIMIDO"
  },
  {
    "code" : "BR0268378",
    "display" : "ALFENTANILA 0,544 MG/ML SOLUÇÃO INJETÁVEL 5 ML"
  },
  {
    "code" : "BR0271790-1",
    "display" : "FENILEFRINA, CLORIDRATO 10 % SOLUÇÃO OFTÁLMICA 5 ML"
  },
  {
    "code" : "BR0273706",
    "display" : "NARATRIPTANA, CLORIDRATO 2,5 MG COMPRIMIDO"
  },
  {
    "code" : "BR0273818",
    "display" : "DIOSMINA + HESPERIDINA 450 + 50 mg COMPRIMIDO"
  },
  {
    "code" : "BR0270597U0005",
    "display" : "BETAMETASONA, ACETATO + BETAMETASONA, FOSFATO DISSÓDICO 3 + 3 MG/ML SUSPENSÃO INJETÁVEL 1 ML"
  },
  {
    "code" : "BR0270621",
    "display" : "ESCOPOLAMINA, BUTILBROMETO + DIPIRONA SÓDICA 4 + 500 MG/ML SOLUÇÃO INJETÁVEL 5 ML"
  },
  {
    "code" : "BR0272380",
    "display" : "VENLAFAXINA, CLORIDRATO 150 MG CÁPSULA DE LIBERAÇÃO CONTROLADA"
  },
  {
    "code" : "BR0274631-2",
    "display" : "MONTELUCASTE DE SÓDIO 4 MG GRANULADO"
  },
  {
    "code" : "BR0333447",
    "display" : "INFLIXIMABE 100 MG PÓ LIOFILIZADO PARA SOLUÇÃO INJETÁVEL ELENCO ESTADUAL"
  },
  {
    "code" : "BR0272826",
    "display" : "PRAMIPEXOL, CLORIDRATO 1 MG COMPRIMIDO"
  },
  {
    "code" : "BR0268106",
    "display" : "GABAPENTINA 400 MG CÁPSULA  ELENCO ESTADUAL"
  },
  {
    "code" : "BR0282224-1",
    "display" : "CARBOCISTEÍNA 50 MG/ML XAROPE  100 ML"
  },
  {
    "code" : "BR0268454",
    "display" : "ENOXAPARINA SÓDICA  60 MG SOLUÇÃO INJETÁVEL 0,6 ML ELENCO ESTADUAL"
  },
  {
    "code" : "BR0318725U0058",
    "display" : "VACINA ROTAVÍRUS HUMANO G1P1[8] (ATENUADA) CARPULE"
  },
  {
    "code" : "BR0340060",
    "display" : "VACINA PNEUMOCÓCICA 7-VALENTE (CONJUGADA) SUSPENSÃO INJETÁVEL"
  },
  {
    "code" : "BR0292249-1",
    "display" : "METOTREXATO 25 MG/ML SOLUÇÃO INJETÁVEL 2 ML"
  },
  {
    "code" : "BR0332788",
    "display" : "SALMETEROL, XINAFOATO + FLUTICASONA 25 + 125 MCG/DOSE AEROSSOL 120 DOSES ELENCO ESTADUAL"
  },
  {
    "code" : "BR0272568-1",
    "display" : "INATIVO- RETINOL + COLECALCIFEROL + TOCOFEROL 50.000 + 10.000 UI SOLUÇÃO ORAL 3 ML"
  },
  {
    "code" : "BR0292419U0011",
    "display" : "CLINDAMICINA, FOSFATO 150 MG/ML SOLUÇÃO INJETÁVEL 4 ML"
  },
  {
    "code" : "BR0327766-1",
    "display" : "CARBONATO DE CÁLCIO + COLECALCIFEROL  600 MG + 200 UI COMPRIMIDO"
  },
  {
    "code" : "BR0270593",
    "display" : "CETOCONAZOL + BETAMETASONA + NEOMICINA 20 + 0,5 + 2,5 MG/G CREME  30 G"
  },
  {
    "code" : "BR0267572-1",
    "display" : "DILTIAZEM, CLORIDRATO 120 MG CÁPSULA DURA DE LIBERAÇÃO PROLONGADA"
  },
  {
    "code" : "BR0308224",
    "display" : "METILFENIDATO, CLORIDRATO 18 mg COMPRIMIDO DE LIBERAÇÃO PROLONGADA"
  },
  {
    "code" : "BR0280881",
    "display" : "SALMETEROL, XINAFOATO + FLUTICASONA 25 + 250 MCG/DOSE AEROSSOL 120 DOSES"
  },
  {
    "code" : "BR0271950-1",
    "display" : "FENTANILA, CITRATO 0,05 MG/ML SOLUÇÃO INJETÁVEL  2 ML"
  },
  {
    "code" : "BR0270372",
    "display" : "ETOPÓSIDO 100 MG SOLUÇÃO INJETÁVEL 5 ML"
  },
  {
    "code" : "BR0272525",
    "display" : "DIPIRIDAMOL 5 MG/ML SOLUÇÃO INJETÁVEL 2 ML"
  },
  {
    "code" : "BR0440864U0041",
    "display" : "CLARITROMICINA 500 MG  CÁPSULA"
  },
  {
    "code" : "BR0396559",
    "display" : "VALSARTANA + HIDROCLOROTIAZIDA + ANLODIPINO 160 + 25 + 10 MG COMPRIMIDO"
  },
  {
    "code" : "BR0315483",
    "display" : "FLUDROXICORTIDA + NEOMICINA 0,125 + 3,5 MG/G CREME  30 G"
  },
  {
    "code" : "BR0332382",
    "display" : "CIDOFOVIR 75 MG/ML SOLUÇÃO INJETÁVEL 5 ML"
  },
  {
    "code" : "BR0429327",
    "display" : "KAVA-KAVA (PIPER METHYSTICUM) 20 MG CAP"
  },
  {
    "code" : "BR0377422",
    "display" : "ACIDO FUSIDICO + BETAMETASONA 20 MG + 1 MG/G CREME  15 G"
  },
  {
    "code" : "BR0291019-1",
    "display" : "HIALURONIDASE + LIDOCAÍNA + NEOMICINA SULFATO 100 UTR + 50 + 5 MG/ML SOLUÇÃO OTOLÓGICA 8 ML"
  },
  {
    "code" : "BR0429853U0041",
    "display" : "MENTHA X PIPERITA L. (HORTELÃ) 300 MG CÁPSULA"
  },
  {
    "code" : "BR0305293",
    "display" : "MITOXANTRONA, CLORIDRATO 2 MG/ML SOLUÇÃO INJETÁVEL 10 ML"
  },
  {
    "code" : "BR0335097U0041",
    "display" : "CLORANFENICOL 250 MG CÁPSULA"
  },
  {
    "code" : "BR0397428U0086",
    "display" : "LIDOCAÍNA, CLORIDRATO + EPINEFRINA 2% + 1:80.000 SOLUÇÃO INJETÁVEL 20 ML"
  },
  {
    "code" : "BR0400564U0042",
    "display" : "ARTEMETER + LUMEFANTRINA 20 MG + 120 MG COMPRIMIDO 5 - 14 KG (BLISTER C/6 COMPRIMIDOS)"
  },
  {
    "code" : "BR0433021",
    "display" : "CÁLCIO, CARBONATO, FORMULAÇÃO ESPECIAMENTE MANIPULADA 100 MG/ML SOL ORAL (FR) 150 ML"
  },
  {
    "code" : "BR0362719",
    "display" : "BISOPROLOL, FUMARATO 1,25 MG COMPRIMIDO"
  },
  {
    "code" : "BR0271848U0098",
    "display" : "BIMATOPROSTA 0,3 MG/ML SOL OFT (FR) 3 ML GRUPO 1.A"
  },
  {
    "code" : "BR0273132",
    "display" : "CALAMINA+DIFENIDRAMINA, CLORIDRATO DE+CÂNFORA 80+10+1 MG LOÇÃO  120 ML"
  },
  {
    "code" : "BR0271353U0063",
    "display" : "PILOCARPINA 20 MG/ML SOL OFT (FR) 10 ML GRUPO 2"
  },
  {
    "code" : "BR0353128",
    "display" : "MULTIVITAMINAS(A,B1,B2,B5,B6,B12,PP,H,C,D,E); ASSOCIADAS COM SAIS MINERAIS (CA,FE,P,MG,MN,CU,ZN,MO,B)  COMPRIMIDO"
  },
  {
    "code" : "BR0340120",
    "display" : "VARENICLINA, TARTARATO 0,5 + 1 MG COMPRIMIDO 11 + 14 COMPRIMIDOS"
  },
  {
    "code" : "BR0352933-3",
    "display" : "LEVETIRACETAM 100 MG/ML SOLUÇÃO ORAL  473 ML"
  },
  {
    "code" : "BR0415504",
    "display" : "EXTRATO MEDICINAL, EXT.FLUIDO ALLII CEPAE,HEPARINA SÓDICA E ALANTOÍNA 100 MG + 50 UI + 10 MG/G GEL 50 G"
  },
  {
    "code" : "BR0436416",
    "display" : "ALTEPLASE 10 MG PÓ LIOF INJ (FR-AMP) 10 ML"
  },
  {
    "code" : "BR0432638",
    "display" : "METOPROLOL, TARTARATO 10 MG/ML SOL ORAL (FR) 60 ML"
  },
  {
    "code" : "BR0436508",
    "display" : "ALFAESTRADIOL 0,25 MG SOLUÇÃO 100 ML"
  },
  {
    "code" : "BR0268572",
    "display" : "DESMOPRESSINA, ACETATO 0,2 MG COMPRIMIDO"
  },
  {
    "code" : "BR0319000-1",
    "display" : "BRIMONIDINA, TARTARATO + TIMOLOL, MALEATO 0,2 + 0,5 % SOLUÇÃO OFTÁLMICA 5 ML"
  },
  {
    "code" : "BR0334016-1",
    "display" : "FLUTICASONA, PROPIONATO 50 MCG AEROSSOL 60 DOSES"
  },
  {
    "code" : "BR0296793-2",
    "display" : "SALMETEROL, XINAFOATO + FLUTICASONA 50 + 500 MCG/DOSE AEROSSOL ORAL 60 DOSES ELENCO ESTADUAL"
  },
  {
    "code" : "BR0332754U0097",
    "display" : "IBUPROFENO  50 MG/ML SUSPENSÃO ORAL  30 ML"
  },
  {
    "code" : "BR0270007",
    "display" : "NIMODIPINO 30 MG COMPRIMIDO"
  },
  {
    "code" : "BR0386396",
    "display" : "AMOXICILINA + CLAVULANATO DE POTÁSSIO 80 MG + 11,5 MG/ML SUSPENSÃO ORAL  70 ML"
  },
  {
    "code" : "BR0268417U0118",
    "display" : "CEFTRIAXONA SÓDICA 500 mg  PÓ PARA SOLUÇÃO INJETÁVEL"
  },
  {
    "code" : "BR0271689-2",
    "display" : "ÁCIDO ASCÓRBICO 200 MG/ML SOLUÇÃO ORAL 30 ML"
  },
  {
    "code" : "INATIVO 35",
    "display" : "INATIVO-BECLOMETASONA, DIPROPIONATO 50 MCG/ML SUSPENSÃO NASAL INATIVO, USAR BR0267582-1 DOSES"
  },
  {
    "code" : "BR0350587-1",
    "display" : "LOPINAVIR + RITONAVIR 80 + 20 MG/ML SOLUÇÃO ORAL  60 ML"
  },
  {
    "code" : "BR0269072",
    "display" : "ÁCIDO TRICLOROACÉTICO 75 % SOLUÇÃO 100 ML"
  },
  {
    "code" : "BR0273597",
    "display" : "TIORIDAZINA, CLORIDRATO 25 MG COMPRIMIDO"
  },
  {
    "code" : "BR0270095",
    "display" : "BUPIVACAÍNA + GLICOSE 5 + 80 MG/ML SOLUÇÃO INJETÁVEL  4 ML"
  },
  {
    "code" : "INATIVO 33",
    "display" : "INATIVO-GLICOSE 5 % SOLUÇÃO INJETÁVEL 500 ML"
  },
  {
    "code" : "BR0272134",
    "display" : "CICLOPENTOLATO, CLORIDRATO 1% SOLUÇÃO OFTÁLMICA 5 ML"
  },
  {
    "code" : "BR0282313",
    "display" : "CICLOBENZAPRINA, CLORIDRATO 10 MG COMPRIMIDO"
  },
  {
    "code" : "BR0284460",
    "display" : "CLOBETASOL, PROPIONATO 0,5 mg/g SOLUÇÃO TÓPICA 50 G"
  },
  {
    "code" : "BR0271992",
    "display" : "CELECOXIBE 100 MG  CÁPSULA"
  },
  {
    "code" : "BR0270768",
    "display" : "LEVOTIROXINA SÓDICA 175 MCG COMPRIMIDO"
  },
  {
    "code" : "BR0267164-1",
    "display" : "CLORETO DE POTÁSSIO 60 MG/ML SOLUÇÃO ORAL 100 ML"
  },
  {
    "code" : "BR0272335",
    "display" : "DIMENIDRINATO + PIRIDOXINA 25 + 5 MG/ML SOLUÇÃO ORAL 20 ML"
  },
  {
    "code" : "BR0284102",
    "display" : "CIPROFLOXACINO + DEXAMETASONA 3,5 + 1 MG/ML SOLUÇÃO OFTÁLMICA 5 ML"
  },
  {
    "code" : "BR0272042",
    "display" : "CLONIDINA, CLORIDRATO 0,2 MG  COMPRIMIDO"
  },
  {
    "code" : "BR0276374",
    "display" : "DILTIAZEM, CLORIDRATO 240 MG CÁPSULA DURA DE LIBERAÇÃO PROLONGADA"
  },
  {
    "code" : "BR0352194",
    "display" : "TIORIDAZINA, CLORIDRATO 30 MG/ML SOLUÇÃO ORAL  50 ML"
  },
  {
    "code" : "BR0268439U0042",
    "display" : "CLARITROMICINA 500 MG  COMPRIMIDO"
  },
  {
    "code" : "BR0272379",
    "display" : "VENLAFAXINA, CLORIDRATO 75 MG CÁPSULA DE LIBERAÇÃO CONTROLADA"
  },
  {
    "code" : "BR0271877",
    "display" : "INATIVO RINGER LACTATO SÓDICO  SOLUÇÃO INJETÁVEL 500 ML"
  },
  {
    "code" : "BR0273256",
    "display" : "OXCARBAZEPINA 600 MG COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0293892U0067",
    "display" : "ACEBROFILINA 10 MG/ML XAROPE  120 ML"
  },
  {
    "code" : "BR0274918-2",
    "display" : "RETINOL + AMINOÁCIDOS + METIONINA + CLORANFENICOL 10.000 UI + 25 + 5 + 5 MG/G POMADA OFTÁLMICA  3,5 G"
  },
  {
    "code" : "BR0271036U0042",
    "display" : "DOXICICLINA 100 MG COMPRIMIDO"
  },
  {
    "code" : "BR0315088",
    "display" : "ENTECAVIR 0,5 MG COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0305247U0067",
    "display" : "LACTULOSE 667 MG/ML XAROPE  120 ML"
  },
  {
    "code" : "BR0268160",
    "display" : "OMEPRAZOL 40 MG PÓ PARA SOLUÇÃO INJETÁVEL"
  },
  {
    "code" : "BR0268848",
    "display" : "PANTOPRAZOL 20 MG COMPRIMIDO"
  },
  {
    "code" : "BR0279493-2",
    "display" : "ÓXIDO DE ZINCO + COLECALCIFEROL + RETINOL 150 + 5000 + 900 MG + UI + UI/G POMADA 45 G"
  },
  {
    "code" : "BR0287471",
    "display" : "LOSARTANA POTÁSSICA + HIDROCLOROTIAZIDA 100 MG + 25 MG COMPRIMIDO"
  },
  {
    "code" : "BR0407030U0053",
    "display" : "MAGNÉSIO, SULFATO 990 MG/G PÓ PARA SOLUÇÃO ORAL 30 G"
  },
  {
    "code" : "BR0267419",
    "display" : "TIABENDAZOL 50 MG/ML SUSPENSÃO ORAL  40 ML"
  },
  {
    "code" : "BR0270965",
    "display" : "ÁCIDO ACETILSALICÍLICO  100 MG TAMPONADO COMPRIMIDO"
  },
  {
    "code" : "BR0267774U0042",
    "display" : "PIRIDOXINA, CLORIDRATO 40 MG COMPRIMIDO"
  },
  {
    "code" : "BR0339980",
    "display" : "SOMATROPINA 10 MG SOLUÇÃO INJETÁVEL COM SISTEMA DE APLICAÇÃO 1,5 ML"
  },
  {
    "code" : "BR0365047",
    "display" : "LENALIDOMIDA 5 MG CÁPSULA"
  },
  {
    "code" : "BR0429879",
    "display" : "METFORMINA, CLORIDRATO + SAXAGLIPTINA 1000 + 5 MG+MG COMPRIMIDO"
  },
  {
    "code" : "BR0389957-1",
    "display" : "DIPIRONA SÓDICA + ESCOPOLAMINA + HIOSCIAMINA + HOMATROPINA  300 + 6,5 + 104 + 1 MG+MCG+MCG+MG COMPRIMIDO"
  },
  {
    "code" : "BR0433940U0074",
    "display" : "MIKANIA GLOMERATA (GUACO) 35 MG/ML XAROPE  150 ML"
  },
  {
    "code" : "BR0267508U0042",
    "display" : "ALOPURINOL 100 MG COMPRIMIDO"
  },
  {
    "code" : "BR0390598U0150",
    "display" : "FATOR VIII RECOMBINANTE, CONCENTRADO DE FATOR DE COAGULAÇÃO 250 UI PÓ LIOFILIZADO PARA SOLUÇÃO INJETÁVEL"
  },
  {
    "code" : "BR0406015-3",
    "display" : "OXIBUTININA, CLORIDRATO, FORMULAÇÃO ESPECIALMENTE MANIPULADA 1 MG/ML SOLUÇÃO ORAL 300 ML"
  },
  {
    "code" : "BR0342108",
    "display" : "PROGESTERONA 80 MG/G GEL"
  },
  {
    "code" : "BR0303292U0033",
    "display" : "RINGER LACTATO SÓDICO SOLUÇÃO INJETÁVEL 1000 ML SISTEMA FECHADO"
  },
  {
    "code" : "BR0285965",
    "display" : "LEVETIRACETAM 250 MG COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0430434",
    "display" : "COLECALCIFEROL (VITAMINA D3) 5.000 UI COMPRIMIDO"
  },
  {
    "code" : "BR0434254",
    "display" : "CANAGLIFOZINA 300 MG COMPRIMIDO"
  },
  {
    "code" : "BR0434568",
    "display" : "RETINOL+COLECALCIFEROL+ACETATO DE TOCOFEROL+ACIDO ASCORBICO+TIAMINA+RIBOFLAVINA+NICOTINAMIDA+CLORIDRATO DE PIRIDOXINA+ACIDO FOLICO+CIANOCOBALAMINA+FERRO+ZINCO+CALCIO 2664+400+10UI+70+3+3,4+17+4+0,6MG+2,2MCG+30+15+125 MG CÁPSULA"
  },
  {
    "code" : "BR0337468-4",
    "display" : "DESLORATADINA 1,25 MG/ML SOLUÇÃO ORAL 20 ML"
  },
  {
    "code" : "BR0292241",
    "display" : "MESALAZINA 2 G PÓ"
  },
  {
    "code" : "BR0433657",
    "display" : "PASSIFLORA INCARNATA 600 MG COMPRIMIDO"
  },
  {
    "code" : "BR0432784",
    "display" : "TRASTUZUMABE, PERTUZUMABE 440, 420 MG EM FRASCOS SEPARADOS PÓ LIOFILIZADO PARA SOLUÇÃO INJETÁVEL"
  },
  {
    "code" : "BR0327792-1",
    "display" : "CEFALEXINA 25 MG/ML SUSPENSÃO ORAL  100 ML"
  },
  {
    "code" : "BR0407485",
    "display" : "DIAZOXIDO 100 MG CAP"
  },
  {
    "code" : "BR0270416",
    "display" : "OXALIPLATINA 100 MG PÓ LIOFILIZADO PARA SOLUÇÃO INJETÁVEL"
  },
  {
    "code" : "BR0288275-1",
    "display" : "TINIDAZOL + MICONAZOL, NITRATO 30 + 20 MG/G CREME VAGINAL  80 G"
  },
  {
    "code" : "BR0404655",
    "display" : "AMBRISENTANA 5 MG COMPRIMIDO"
  },
  {
    "code" : "BR0268252U0009",
    "display" : "DIPIRONA SÓDICA  500 MG/ML SOLUÇÃO INJETÁVEL 2 ML"
  },
  {
    "code" : "BR0324414",
    "display" : "LAMOTRIGINA 50 MG COMPRIMIDO"
  },
  {
    "code" : "BR0271124-2",
    "display" : "CETOTIFENO, FUMARATO 0,2 MG/ML XAROPE  120 ML"
  },
  {
    "code" : "BR0268954U0042",
    "display" : "PRAZIQUANTEL 600 MG COMPRIMIDO"
  },
  {
    "code" : "BR0273639-5",
    "display" : "MULTIVITAMINAS + SAIS MINERAIS SUSPENSÃO ORAL  100 ML"
  },
  {
    "code" : "BR0267564U0042",
    "display" : "CARVEDILOL 12,5 MG COMPRIMIDO"
  },
  {
    "code" : "BR0273264",
    "display" : "LOPERAMIDA, CLORIDRATO 2 MG COMPRIMIDO"
  },
  {
    "code" : "BR0267589U0061",
    "display" : "BECLOMETASONA, DIPROPIONATO 400 MCG PÓ PARA INALAÇÃO ORAL 100 DOSES"
  },
  {
    "code" : "BR0271773",
    "display" : "BROMAZEPAM 3 MG COMPRIMIDO"
  },
  {
    "code" : "BR0284114",
    "display" : "CETOCONAZOL + BETAMETASONA 0,5 + 20 MCG/G CREME  30 G"
  },
  {
    "code" : "BR0270791",
    "display" : "ATENOLOL + CLORTALIDONA 100 + 25 MG COMPRIMIDO"
  },
  {
    "code" : "BR0304870",
    "display" : "MORFINA, SULFATO 1 MG/ML SOLUÇÃO INJETÁVEL 1 ML"
  },
  {
    "code" : "BR0278261",
    "display" : "TIOPENTAL SÓDICO 1 G PÓ LIOFILIZADO"
  },
  {
    "code" : "BR0292380U0063",
    "display" : "TRAMADOL, CLORIDRATO 100 MG/ML SOLUÇÃO ORAL 10 ML"
  },
  {
    "code" : "BR0276388",
    "display" : "GALANTAMINA, BROMIDRATO 8 MG CÁPSULA DE LIBERAÇÃO CONTROLADA"
  },
  {
    "code" : "BR0273390",
    "display" : "IRBESARTANA + HIDROCLOROTIAZIDA 300 + 12,5 MG COMPRIMIDO"
  },
  {
    "code" : "BR0405149",
    "display" : "CAPTOPRIL  10 MG/ML SOLUÇÃO ORAL 100 ML"
  },
  {
    "code" : "BR0271727",
    "display" : "PRAVASTATINA SÓDICA 40 MG COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0282220",
    "display" : "CARBACOL, CLORETO 0,1 MG/ML SOLUÇÃO OFTÁLMICA 2 ML"
  },
  {
    "code" : "BR0276332",
    "display" : "PICOSSULFATO SÓDICO + ÓLEO MINERAL LEVE + AGAR-AGAR 0,334 + 282,25 + 2,72 MG/ML EMULSÃO ORAL 240 ML"
  },
  {
    "code" : "BR0393780U0042",
    "display" : "DARUNAVIR 600 MG COMP"
  },
  {
    "code" : "BR0275116-1",
    "display" : "NITRENDIPINO 10 MG COMP"
  },
  {
    "code" : "BR0383788",
    "display" : "VINORELBINA, TARTARATO 20 MG CÁPSULA"
  },
  {
    "code" : "BR0311390-1E",
    "display" : "BEVACIZUMABE 25 MG/ML SOL INJ (DOSE) GRUPO 1.A"
  },
  {
    "code" : "BR0308802U0149",
    "display" : "FATOR VIII, CONCENTRADO DE FATOR DE COAGULAÇÃO 500 UI PÓ LIOFILIZADO PARA SOLUÇÃO INJETÁVEL"
  },
  {
    "code" : "BR0426921",
    "display" : "BACLOFENO 20 MG COMPRIMIDO"
  },
  {
    "code" : "BR0398689",
    "display" : "LEVODOPA + BENSERAZIDA  100 + 25 MG CAP LIBERAÇÃO CONTROLADA ELENCO ESTADUAL"
  },
  {
    "code" : "BR0323096",
    "display" : "BROMAZEPAM 2,5 MG/ML SOL ORAL (FR) 20 ML"
  },
  {
    "code" : "BR0399597",
    "display" : "DIAZOXIDO 50 MG/ML SUSPENSÃO ORAL  30 ML"
  },
  {
    "code" : "BR0404137",
    "display" : "AZUL DE METILENO 2% FORMULAÇÃO ESPECIALMENTE MANIPULADA SOLUÇÃO TÓPICA 20 ML"
  },
  {
    "code" : "BR0435285",
    "display" : "HIALURONATO DE SÓDIO 1,6% SOLUÇÃO OFTÁLMICA 0,8 ML"
  },
  {
    "code" : "BR0435442",
    "display" : "IDEBENONA 150 MG CÁPSULA"
  },
  {
    "code" : "BR0266706-1",
    "display" : "BUDESONIDA 32 MCG/DOSE SOLUÇÃO NASAL 60 DOSES"
  },
  {
    "code" : "BR0409539U0042",
    "display" : "BENZNIDAZOL 12,5 MG COMPRIMIDO"
  },
  {
    "code" : "BR0349475-1",
    "display" : "METILA + ESS. TEREBENTINA + CÂNFORA + MENTOL 0,02 ML + 0,05 ML + 30 MG + 5 MG/G POMADA 50 G"
  },
  {
    "code" : "BR0401411-1",
    "display" : "ÓXIDO DE ZINCO + COLECALCIFEROL + RETINOL 100 + 1000 + 400 MG + UI/G POMADA 70 G"
  },
  {
    "code" : "BR0437051",
    "display" : "LACOSAMIDA 10 MG/ML SOLUÇÃO ORAL 200 ML"
  },
  {
    "code" : "BR0298445-1",
    "display" : "CROMOGLICATO DE SÓDIO 2% SOLUÇÃO OFTÁLMICA 15 ML"
  },
  {
    "code" : "BR0407013-1",
    "display" : "MENTOL + CÂNFORA + SALICILATO DE METILA + ÓLEO DE EUCALIPTO 150 MG + 100 MG + 80 MG + 50 MG/G POMADA 20 G"
  },
  {
    "code" : "BR0271218",
    "display" : "AMOXICILINA + CLAVULANATO DE POTÁSSIO 25 MG + 6,25 MG/ML SUSPENSÃO ORAL  75 ML"
  },
  {
    "code" : "BR0437357",
    "display" : "ROTIGOTINA 13,5 MG ADESIVO TRANSDÉRMICO"
  },
  {
    "code" : "BR0364781",
    "display" : "ARIPIPRAZOL 20 MG COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0412122",
    "display" : "BETACAROTENO 5 MG CÁPSULA"
  },
  {
    "code" : "BR0406975-3",
    "display" : "ÁCIDO VALPRÓICO (VALPROATO DE SÓDIO)  100 MG/ML SOLUÇÃO INJETÁVEL 5 ML"
  },
  {
    "code" : "BR0396703",
    "display" : "NIMESULIDA BETACICLODEXTRINA 400 MG COMPRIMIDO"
  },
  {
    "code" : "BR0271394",
    "display" : "MORFINA, SULFATO 10 MG/ML SOLUÇÃO ORAL  60 ML"
  },
  {
    "code" : "BR0394768U0135",
    "display" : "VACINA HUMANA, CONTRA HEPATITE A, ADSORVIDA, INATIVADA, 720 U.EL / 0,5ML, SUSPENSÃO INJETÁVEL ADULTO SOLUÇÃO INJETÁVEL 0,5 ML"
  },
  {
    "code" : "BR0396109U0106",
    "display" : "VACINA HUMANA, CONTRA INFLUENZA, FRAGMENTADA E INATIVADA, CEPAS SIMILARES AO TIPO A (H1N1 + H3N2) E TIPO B, SUSPENSÃO INJETÁVEL SOLUÇÃO INJETÁVEL 5 ML"
  },
  {
    "code" : "BR0269888",
    "display" : "MEPIVACAÍNA, CLORIDRATO + EPINEFRINA 36 MG (2%) + 0,018 MG (1:100.000)  SOL INJ (AMP) 1,8 ML"
  },
  {
    "code" : "BR0268000",
    "display" : "DIPIRONA SÓDICA 300 MG SUPOSITÓRIO  INFANTIL"
  },
  {
    "code" : "BR0269760",
    "display" : "GENTAMICINA, SULFATO 140MG/ML AMP 1 ML"
  },
  {
    "code" : "BR0434111",
    "display" : "AMITRIPTILINA, CLORIDRATO 10 MG COMPRIMIDO DE LIBERAÇÃO CONTROLADA"
  },
  {
    "code" : "BR0434128",
    "display" : "ÁCIDO FÓLICO + ACETATO DE RACEALFATOCOFEROL 800MCG + 20MG CÁPSULA"
  },
  {
    "code" : "BR0436237",
    "display" : "CARISOPRODOL + PARACETAMOL 300+100 MG CÁPSULA"
  },
  {
    "code" : "BR0436501",
    "display" : "ÓLEO DE CALÊNDULA+ÓLEO DE LAVANDA+ÓLEO DE ALECRIM+ÓLEO DE CAMOMILA+VITAMINAS A E E SOLUÇÃO 125 ML"
  },
  {
    "code" : "BR0431599",
    "display" : "SOFOSBUVIR 400 MG COMP REV"
  },
  {
    "code" : "BR0274648-8",
    "display" : "PASTA D&#146;ÁGUA PASTA  70 G"
  },
  {
    "code" : "BR0437411",
    "display" : "ARGININA 0,25 MG/ML XAROPE  150 ML"
  },
  {
    "code" : "BR0273469",
    "display" : "LORATADINA + PSEUDOEFEDRINA, SULFATO 10 MG + 240 MG COMPRIMIDO"
  },
  {
    "code" : "BR0308805U0118",
    "display" : "CONCENTRADO DE FATOR IX 500 A 600 UI PÓ LIOFILIZADO PARA SOLUÇÃO INJETÁVEL"
  },
  {
    "code" : "BR0271170",
    "display" : "LISINOPRIL + HIDROCLOROTIAZIDA 20 MG + 12,5 MG COMPRIMIDO"
  },
  {
    "code" : "BR0392118-4",
    "display" : "DIMETICONA 75 MG/ML SUSPENSÃO ORAL  20 ML"
  },
  {
    "code" : "BR0292468",
    "display" : "SUCCINATO DE SUMATRIPTANO 50 MG COMPRIMIDO"
  },
  {
    "code" : "BR0274648-7",
    "display" : "PASTA D&#146;ÁGUA PASTA  120 G"
  },
  {
    "code" : "BR0332761",
    "display" : "SUMATRIPTANA 25 MG COMP"
  },
  {
    "code" : "BR0393565",
    "display" : "FURAZOLIDONA 200 MG COMPRIMIDO"
  },
  {
    "code" : "BR0437668U0067",
    "display" : "MIKANIA GLOMERATA (GUACO) 60 MG/ML SOLUÇÃO ORAL 120 ML"
  },
  {
    "code" : "BR0268432",
    "display" : "CIPROFLOXACINO, CLORIDRATO 3 MG/G POMADA 3,5 G"
  },
  {
    "code" : "BR0272568-2",
    "display" : "RETINOL + COLECALCIFEROL 50.000 + 10.000 UI/ML SOLUÇÃO ORAL  20 ML"
  },
  {
    "code" : "BR0437374",
    "display" : "LEVOTIROXINA SÓDICA 37,5 MG COMP"
  },
  {
    "code" : "BR0437387",
    "display" : "AMBURANA CEARENSIS (CUMARU) 5 % XAROPE  100 ML"
  },
  {
    "code" : "BR0437379",
    "display" : "GARCINIA CAMBOGIA ROXB. 500 MG CAP"
  },
  {
    "code" : "BR0437383",
    "display" : "PASSIFLORA EDULIS (MARACUJÁ) 200 MG CÁPSULA"
  },
  {
    "code" : "BR0437384",
    "display" : "MYRACRODRUON URUNDEUVA (AROEIRA DO SERTÃO) 15 % CREME VAGINAL  50 G"
  },
  {
    "code" : "BR0437385",
    "display" : "MYRACRODRUON URUNDEUVA (AROEIRA DO SERTÃO) 7 % ELIXIR 150 ML"
  },
  {
    "code" : "BR0434045-1",
    "display" : "SYMPHITUM SP L. (CONFREI) 5 % POMADA 50 G"
  },
  {
    "code" : "BR0413606",
    "display" : "MIDODRINA, CLORIDRATO 5 MG COMPRIMIDO"
  },
  {
    "code" : "BR0268396-1",
    "display" : "ATRACÚRIO 10 MG/ML SOLUÇÃO INJETÁVEL  2,5 ML"
  },
  {
    "code" : "BR0269998U0105",
    "display" : "ERITROMICINA, ESTOLATO 50 MG/ML SUSPENSÃO ORAL  50 ML"
  },
  {
    "code" : "BR0404655U0042",
    "display" : "AMBRISENTANA 5 MG COMP REV GRUPO 1.B"
  },
  {
    "code" : "BR0404656U0042",
    "display" : "AMBRISENTANA 10 MG COMP REV GRUPO 1.B"
  },
  {
    "code" : "BR0337457-1",
    "display" : "MOMETASONA, FUROATO 0,05% SUSPENSÃO NASAL 120 DOSES"
  },
  {
    "code" : "BR0432995",
    "display" : "MOMETASONA, FUROATO + FORMOTEROL, FUMARATO 200 MCG/DOSE + 5 MCG/DOSE  AEROSSOL ORAL 120 DOSES"
  },
  {
    "code" : "BR0278482",
    "display" : "PRIMIDONA 250 MG COMPRIMIDO"
  },
  {
    "code" : "BR0431222",
    "display" : "UBIDECARENONA (COENZIMA Q10) 300 MG CÁPSULA"
  },
  {
    "code" : "BR0433148",
    "display" : "LISADO BACTERIANO 3,5 MG  CÁPSULA"
  },
  {
    "code" : "BR0340182",
    "display" : "CISPLATINA 10 MG  PÓ LIOFILIZADO PARA SOLUÇÃO INJETÁVEL"
  },
  {
    "code" : "BR0266629U0118",
    "display" : "ALFAEPOETINA 4.000 UI SOL INJ (FR-AMP) GRUPO 1.A"
  },
  {
    "code" : "BR0288641U0042",
    "display" : "MICOFENOLATO DE SÓDIO 360 MG COMP GRUPO 1.A"
  },
  {
    "code" : "BR0343607U0118",
    "display" : "ETANERCEPTE  25 MG PÓ LIOF INJ (FR-AMP) GRUPO 1.A"
  },
  {
    "code" : "BR0268143U0042",
    "display" : "MICOFENOLATO DE MOFETILA 500 MG COMP GRUPO 1.A"
  },
  {
    "code" : "BR0266820U0118",
    "display" : "IMUNOGLOBULINA HUMANA 5 G INJ (FR) GRUPO 1.A"
  },
  {
    "code" : "BR0267895U0041",
    "display" : "RIVASTIGMINA 6 MG CAP GRUPO 1.A"
  },
  {
    "code" : "BR0272083U0042",
    "display" : "SEVELAMER 800 MG COMP GRUPO 1.A"
  },
  {
    "code" : "BR0292242U0052",
    "display" : "MESALAZINA 3 G ENEMA  100 ML GRUPO 2"
  },
  {
    "code" : "BR0267498U0042",
    "display" : "COMPLEMENTO ALIMENTAR P/ PACIENTE FENILCETONURICO MAIOR DE 1 ANO - FORMULA DE AMINOÁCIDOS ISENTA DE FENILALANINA 1 G PÓ GRUPO 2"
  },
  {
    "code" : "BR0268107U0041",
    "display" : "GABAPENTINA 300 MG CAP GRUPO 2"
  },
  {
    "code" : "BR02",
    "display" : "CODEÍNA INATIVO MG/ML SOL ORAL (FR) INATIVO ML ELENCO ESTADUAL"
  },
  {
    "code" : "BR0271391U0042",
    "display" : "MORFINA 30 MG COMP GRUPO 2"
  },
  {
    "code" : "BR0354627U0042",
    "display" : "HIDRÓXIDO DE ALUMÍNIO 230 MG COMP GRUPO 2"
  },
  {
    "code" : "BR026844",
    "display" : "INATIVO-CODEÍNA INATIVO MG/ML SOL INJ (AMP) INATIVO ML ELENCO ESTADUAL"
  },
  {
    "code" : "BR0406520U0118",
    "display" : "ALFAEPOETINA 3.000 UI SOL INJ (FR-AMP) GRUPO 1.A"
  },
  {
    "code" : "BR0292372U0118",
    "display" : "TOXINA BOTULINICA TIPO A 100 U PÓ LIOF INJ (FR-AMP) GRUPO 1.A"
  },
  {
    "code" : "BR0308719U0041",
    "display" : "ACITRETINA 10 MG CAP GRUPO 1.B"
  },
  {
    "code" : "BR0342320U0041",
    "display" : "ZIPRASIDONA 80 MG CAP GRUPO 1.A"
  },
  {
    "code" : "BR0319883U0042",
    "display" : "SILDENAFILA 20 MG COMP GRUPO 1.A"
  },
  {
    "code" : "BR0270143U0042",
    "display" : "BROMOCRIPTINA 2,5 MG COMP GRUPO 1.B"
  },
  {
    "code" : "BR0306687",
    "display" : "ALFUZOSINA 10 MG COMPRIMIDO DE LIBERAÇÃO PROLONGADA"
  },
  {
    "code" : "BR0407076",
    "display" : "DROSPIRENONA + ETINILESTRADIOL 3 MG + 0,02 MG COMPRIMIDO"
  },
  {
    "code" : "BR0313186",
    "display" : "CLOTRIMAZOL + DEXAMETASONA 10 MG + 0,4 MG/G CREME  40 G"
  },
  {
    "code" : "BR0413607",
    "display" : "MIDODRINA, CLORIDRATO 2,5 MG COMPRIMIDO"
  },
  {
    "code" : "BR0279432",
    "display" : "LOTEPREDNOL, SAL ETABONATO 5 MG/ML SUSPENSÃO OFTÁLMICA 5 ML"
  },
  {
    "code" : "BR0368921U0090",
    "display" : "ÁCIDO ACÉTICO 3 % SOLUÇÃO 250 ML"
  },
  {
    "code" : "BR0407704",
    "display" : "PRASUGREL, CLORIDRATO 5 MG COMPRIMIDO"
  },
  {
    "code" : "BR0405997-1",
    "display" : "BIMATOPROSTA 0,1 MG/ML SOLUÇÃO OFTÁLMICA 5 ML"
  },
  {
    "code" : "BR0428705",
    "display" : "DUTASTERIDA + TANSULOSINA 0,5 + 0,4 MG CÁPSULA"
  },
  {
    "code" : "BR0435190",
    "display" : "VIOLETA DE GENCIANA 2% FORMULAÇÃO ESPECIALMENTE MANIPULADA SOLUÇÃO TÓPICA 20 ML"
  },
  {
    "code" : "BR0361507U0238",
    "display" : "VACINA HUMANA, ANTI-HPV (PAPILOMA VÍRUS), TETRAVALENTE SUSPENSÃO INJETÁVEL 0,5 ML"
  },
  {
    "code" : "BR0275937",
    "display" : "RACECADOTRILA 100 MG COMPRIMIDO"
  },
  {
    "code" : "BR0297787-2",
    "display" : "CETIRIZINA, DICLORIDRATO 1 MG/ML SOLUÇÃO ORAL 120 ML"
  },
  {
    "code" : "BR0363056U0106",
    "display" : "VACINA ADSORVIDA DIFTERIA, TÉTANO E PERTUSSIS (ACELULAR) ADULTO SUSPENSÃO INJETÁVEL 0,5 ML"
  },
  {
    "code" : "BR0437483",
    "display" : "EUCALYPTUS TERETICORNIS + MENTHA ARVENSIS 8 G + 4 G PÓ PARA INALAÇÃO ORAL"
  },
  {
    "code" : "BR0396558",
    "display" : "VALSARTANA + HIDROCLOROTIAZIDA + ANLODIPINO 160+25+5 MG COMPRIMIDO"
  },
  {
    "code" : "BR0299675-2",
    "display" : "MANITOL 20% SOLUÇÃO INJETÁVEL  500 ML SISTEMA FECHADO"
  },
  {
    "code" : "BR0324358U0086",
    "display" : "ANFOTERICINA B 5 MG/ML SUSPENSÃO INJETÁVEL 20 ML"
  },
  {
    "code" : "BR0431717",
    "display" : "DEXAMETASONA 0,7 MG IMPLANTE BIODEGRADÁVELPARA USO OFTALMICO (INTRAVÍTREO)"
  },
  {
    "code" : "BR0434946",
    "display" : "RETINOL, COLECALCIFEROL, RACEALFATOCOFEROL 20.000 UI + 1.600 UI + 30 MG/ML SOLUÇÃO ORAL 3 ML"
  },
  {
    "code" : "BR0434874",
    "display" : "EMPAGLIFLOZINA 25 MG COMPRIMIDO DE LIBERAÇÃO CONTROLADA"
  },
  {
    "code" : "BR0272603-1",
    "display" : "DROPROPIZINA 1,5 MG/ML XAROPE  120 ML"
  },
  {
    "code" : "BR0268816U0062",
    "display" : "NEVIRAPINA 10 MG/ML SUSPENSÃO ORAL  100 ML"
  },
  {
    "code" : "BR0364780",
    "display" : "ARIPIPRAZOL 10 MG COMPRIMIDO"
  },
  {
    "code" : "BR0421127",
    "display" : "METOPROLOL, SUCCINATO + HIDROCLOROTIAZIDA 95 MG + 12,5 MG COMPRIMIDO DE LIBERAÇÃO CONTROLADA"
  },
  {
    "code" : "BR0271570",
    "display" : "TOBRAMICINA + DEXAMETASONA 3 + 1 MG/G POMADA OFTÁLMICA  3,5 G"
  },
  {
    "code" : "BR0413768",
    "display" : "BUPROPIONA, CLORIDRATO 300 MG CÁPSULA DURA DE LIBERAÇÃO PROLONGADA"
  },
  {
    "code" : "BR0433077",
    "display" : "FENOFIBRATO 160 MG COMPRIMIDO"
  },
  {
    "code" : "BR0431732U0042",
    "display" : "DACLATASVIR 60 MG COMP REV GRUPO 1.A"
  },
  {
    "code" : "BR0269389",
    "display" : "PROMETAZINA, CLORIDRATO 20  MG/G CREME  30 G"
  },
  {
    "code" : "BR0337457",
    "display" : "MOMETASONA, FUROATO 0,05% SUSPENSÃO NASAL 60 DOSES"
  },
  {
    "code" : "BR0414456-2",
    "display" : "BENZOATO DE SÓDIO 4/20 G/ML XAROPE  1200 ML"
  },
  {
    "code" : "BR0270366",
    "display" : "EPIRRUBICINA, CLORIDRATO 50 MG PÓ LIOFILIZADO PARA SOLUÇÃO INJETÁVEL"
  },
  {
    "code" : "BR0412031",
    "display" : "DASATINIBE 100 MG COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0331223-1",
    "display" : "TERIPARATIDA 250 MCG/ML SOLUÇÃO INJETÁVEL 2,4 ML ELENCO ESTADUAL"
  },
  {
    "code" : "BR0394789-1",
    "display" : "ITRACONAZOL 10 MG/ML SUSPENSÃO ORAL  60 ML"
  },
  {
    "code" : "BR0433517",
    "display" : "VALERATO DE ESTRADIOL+DIENOGESTE 8MG+5MG 28 COMPRIMIDOS COMPRIMIDO DE LIBERAÇÃO CONTROLADA"
  },
  {
    "code" : "BR0412470E",
    "display" : "TELAPREVIR 375 MG COMP GRUPO 1.A"
  },
  {
    "code" : "BR0407989",
    "display" : "RIBAVIRINA 200 MG CÁPSULA"
  },
  {
    "code" : "BR0340117",
    "display" : "VARENICLINA, TARTARATO 0,5 MG COMPRIMIDO"
  },
  {
    "code" : "BR0292345U0110",
    "display" : "SULFATO FERROSO (25MG/ML DE FERRO ELEMENTAR) 125 MG/ML SOLUÇÃO ORAL 60 ML"
  },
  {
    "code" : "BR0399411U0062",
    "display" : "MAYTENUS ILICIFOLIA (ESPINHEIRA SANTA) 12 MG/ML SOLUÇÃO ORAL 100 ML"
  },
  {
    "code" : "BR0429151",
    "display" : "ÁCIDO GAMAMINOBUTÍRICO + LISINA + TIAMINA + PIRIDOXINA + CÁLCIO 50 MG + 50 MG + 2 MG + 4 MG + 4 MG COMPRIMIDO"
  },
  {
    "code" : "BR0268542",
    "display" : "VIMBLASTINA 10 MG PÓ LIOFILIZADO"
  },
  {
    "code" : "BR0423916",
    "display" : "ROSUVASTATINA CÁLCICA 5 MG COMPRIMIDO"
  },
  {
    "code" : "BR0430050-1",
    "display" : "ARGININA 250 MG/ML XAROPE  600 ML"
  },
  {
    "code" : "BR0318309",
    "display" : "BETAMETASONA, DIPROPIONATO + ÁCIDO SALICÍLICO 0,5MG + 30MG/G POMADA 30 G"
  },
  {
    "code" : "BR0426071",
    "display" : "MIRTAZAPINA 60 MG CÁPSULA"
  },
  {
    "code" : "BR0388392",
    "display" : "ROSUVASTATINA CÁLCICA 40 MG COMPRIMIDO"
  },
  {
    "code" : "BR0417266",
    "display" : "POLIESTIRENOSSULFONATO DE SÓDIO 454 mg PÓ PARA SUSPENSÃO 15 G"
  },
  {
    "code" : "BR0395847U0031",
    "display" : "ALOE VERA 50MG/G BISNAGA 80G"
  },
  {
    "code" : "BR0398382-1",
    "display" : "CICLESONIDA 50 MCG/DOSE SUSPENSÃO NASAL 60 DOSES"
  },
  {
    "code" : "BR0432140",
    "display" : "PIRIDOXINA, CLORIDRATO 500 MG COMPRIMIDO"
  },
  {
    "code" : "0304788 INATIVO 50",
    "display" : "CINACALCETE 30 MG COMP ELENCO ESTADUAL"
  },
  {
    "code" : "BR0431752U0041",
    "display" : "SIMEPREVIR 150 MG CAP GRUPO 1.A"
  },
  {
    "code" : "BR0432637",
    "display" : "CRIZOTINIBE 250 MG CÁPSULA"
  },
  {
    "code" : "BR0274049-2",
    "display" : "FLUTICASONA, PROPIONATO 50 MCG SPRAY NASAL 120 DOSES"
  },
  {
    "code" : "BR0421223",
    "display" : "DENOSUMABE 60 MG/ML SOLUÇÃO INJETÁVEL 1 ML"
  },
  {
    "code" : "BR0425580",
    "display" : "ZOLPIDEM, HEMITARTARATO 5 MG COMPRIMIDO SUBLINGUAL"
  },
  {
    "code" : "BR0409591",
    "display" : "PRAMIPEXOL, DICLORIDRATO 0,375 MG COMPRIMIDO DE LIBERAÇÃO CONTROLADA"
  },
  {
    "code" : "ENOXAPARINA, 80MG/0,",
    "display" : "INATIVO- ENOXAPARINA SÓDICA  100 MG/ML SOLUÇÃO INJETÁVEL 0,8 ML"
  },
  {
    "code" : "BR0356705",
    "display" : "MERCAPTAMINA, SAL BITARTARATO 50 MG COMPRIMIDO"
  },
  {
    "code" : "BR0335103-1",
    "display" : "CLORANFENICOL, PALMITATO 25 MG/ML SUSP ORAL (FR) 100 ML"
  },
  {
    "code" : "BR0271111U0062",
    "display" : "AMOXICILINA 50 MG/ML PÓ PARA SUSPENSÃO ORAL  100 ML"
  },
  {
    "code" : "BR0427533",
    "display" : "IPILIMUMABE 5 MG/ML  SOL INJ (FR-AMP) 10 ML ELENCO ESTADUAL"
  },
  {
    "code" : "BR0267666U0009",
    "display" : "FUROSEMIDA 10 MG/ML SOLUÇÃO INJETÁVEL 2 ML"
  },
  {
    "code" : "BR0395716-3",
    "display" : "SCHINUS TEREBINTHIFOLIUS (AROEIRA) 10 % GEL 60 G"
  },
  {
    "code" : "BR0394811U0004",
    "display" : "SORO, ANTIBOTRÓPICO-LAQUÉTICO 5MG + 3 MG/ML SOL INJ (AMP) 5 ML"
  },
  {
    "code" : "BR0420469",
    "display" : "HEPARINA SODICA + NICOTINATO DE BENZILA 50 UI + 2 MG/G POMADA 40 G"
  },
  {
    "code" : "BR0429549",
    "display" : "DIENOGESTE 2MG COMPRIMIDO"
  },
  {
    "code" : "BR0430404",
    "display" : "IBRUTINIBE 140 MG CÁPSULA"
  },
  {
    "code" : "BR0427533-1",
    "display" : "IPILIMUMABE 5 MG/ML  SOL INJ (FR-AMP) 40 ML"
  },
  {
    "code" : "BR0434045-2",
    "display" : "SYMPHITUM SP L. (CONFREI) 5 % POMADA 40 G"
  },
  {
    "code" : "BR0437604",
    "display" : "SILDENAFILA 20 MG/ML SOL ORAL (FR) 100 ML"
  },
  {
    "code" : "BR0340190",
    "display" : "CITARABINA 500 MG  PÓ LIOFILIZADO PARA SOLUÇÃO INJETÁVEL"
  },
  {
    "code" : "BR0405899",
    "display" : "DESVENLAFAXINA, SUCCINATO MONOIDRATADO 100 MG COMPRIMIDO DE LIBERAÇÃO PROLONGADA"
  },
  {
    "code" : "BR0340118",
    "display" : "VARENICLINA, TARTARATO 1 MG COMPRIMIDO"
  },
  {
    "code" : "BR0386041",
    "display" : "HIDROXICLOROQUINA 200 MG COMPRIMIDO"
  },
  {
    "code" : "BR0429325U0041",
    "display" : "CYNARA SCOLYMUS  (ALCACHOFRA) 250 MG CÁPSULA"
  },
  {
    "code" : "BR0395807",
    "display" : "BRINZOLAMIDA, TARTARATO + TIMOLOL, MALEATO 10 MG + 5 MG/ML SOLUÇÃO OFTÁLMICA 5 ML"
  },
  {
    "code" : "BR0428423U0042",
    "display" : "FUMARATO DE TENOFOVIR DESOPROXILA + LAMIVUDINA 300MG +300MG COMP REV"
  },
  {
    "code" : "BR0354516",
    "display" : "GLIPIZIDA 5 MG COMPRIMIDO"
  },
  {
    "code" : "BR0276261",
    "display" : "RAMIPRIL + HIDROCLOROTIAZIDA 5MG + 12,5MG COMP"
  },
  {
    "code" : "BR0292262-1",
    "display" : "MORFINA, SULFATO 100 MG COMPRIMIDO DE LIBERAÇÃO CONTROLADA"
  },
  {
    "code" : "BR0290992",
    "display" : "HIALURONIDASE 2000 UTR PÓ LIOFILIZADO"
  },
  {
    "code" : "BR0410008",
    "display" : "MULTIVITAMINAS ASSOCIADAS COM SAIS MINERAIS (NUTRISUS) PÓ 1 G"
  },
  {
    "code" : "BR0276839U0062",
    "display" : "ÁGUA DESTILADA SOLUÇÃO INJETÁVEL 100 ML"
  },
  {
    "code" : "BR0393920",
    "display" : "ETONOGESTREL 68 MCG ADESIVO TRANSDÉRMICO"
  },
  {
    "code" : "BR0270371",
    "display" : "ETOPÓSIDO 50 MG CÁPSULA"
  },
  {
    "code" : "BR0411397-2",
    "display" : "PALIPERIDONA 100 MG/ML SUSPENSÃO INJETÁVEL 1,5 ML ELENCO ESTADUAL"
  },
  {
    "code" : "BR0312860-1",
    "display" : "FLUORMETOLONA 1 MG/ML SOLUÇÃO OFTÁLMICA 5 ML"
  },
  {
    "code" : "BR0427613",
    "display" : "BELIMUMABE 120 MG PÓ LIOF INJ (AMP)"
  },
  {
    "code" : "BR0427335U0042",
    "display" : "FUMARATO DE TENOFOVIR DESOPROXILA + LAMIVUDINA  + EFAVIRENZ  300MG + 300MG + 600MG COMP REV"
  },
  {
    "code" : "BR0432315",
    "display" : "ALANTOINA, ALOE VERA, ÁCIDOS GRAXOS ESSENCIAIS, VITAMINA \"A\" E \"E\" GEL CREME 100 G"
  },
  {
    "code" : "BR0269068",
    "display" : "ÁCIDO TRICLOROACÉTICO 50 % SOLUÇÃO 5 ML"
  },
  {
    "code" : "BR0432783",
    "display" : "PANTOPRAZOL MAGNÉSIO 40 MG CAP"
  },
  {
    "code" : "BR0278357",
    "display" : "AZELASTINA, CLORIDRATO 1 MG/ML AEROSSOL NASAL 10 ML"
  },
  {
    "code" : "BR0327212-1",
    "display" : "LUGOL 5 % SOLUÇÃO 250 ML"
  },
  {
    "code" : "BR0267310U0009",
    "display" : "METOCLOPRAMIDA, CLORIDRATO 5 MG/ML SOLUÇÃO INJETÁVEL 2 ML"
  },
  {
    "code" : "BR0431160",
    "display" : "TRAMADOL + FAMOTIDINA + PARACETAMOL 20 MG + 20 MG + 400 MG CÁPSULA"
  },
  {
    "code" : "BR0326789",
    "display" : "CEFACLOR 500 MG COMPRIMIDO"
  },
  {
    "code" : "BR0383790",
    "display" : "VINORELBINA, TARTARATO 30 MG CÁPSULA"
  },
  {
    "code" : "BR0417285U0041",
    "display" : "HARPAGOPHYTUM PROCUBENS (GARRA DO DIABO) 200 MG CÁPSULA"
  },
  {
    "code" : "BR0269068-2",
    "display" : "ÁCIDO TRICLOROACÉTICO 50 % SOLUÇÃO 15  ML"
  },
  {
    "code" : "BR0272763-1",
    "display" : "SOLUÇÃO PARA DIÁLISE PERITONEAL, GLICOSE A 1,5 % SOLUÇÃO INJETÁVEL  1000 ML"
  },
  {
    "code" : "BR0274648-6",
    "display" : "PASTA DÁGUA PASTA  135 G"
  },
  {
    "code" : "BR0396086",
    "display" : "SAPROPTERINA, DICLORIDRATO 100 MG COMPRIMIDO PARA  SUSPENSÃO"
  },
  {
    "code" : "BR0428076",
    "display" : "FENOTEROL, BROMIDRATO + IPRATRÓPIO, BROMETO 0,05+0,02 MG/DOSE AEROSSOL ORAL 200 DOSES"
  },
  {
    "code" : "BR0268286U0023",
    "display" : "MICONAZOL, NITRATO 2 % CREME  30 G"
  },
  {
    "code" : "BR0367515U0041",
    "display" : "CYNARA SCOLYMUS (ALCACHOFRA) 200 MG CÁPSULA"
  },
  {
    "code" : "BR0342178",
    "display" : "ETOPÓSIDO 20 MG/ML SOLUÇÃO INJETÁVEL 5  ML"
  },
  {
    "code" : "BR0433428",
    "display" : "RETINOL + PIRIDOXINA + RACEALFATOCOFEROL   5.000 UI + 100 MG + 300 MG CÁPSULA"
  },
  {
    "code" : "BR0400091",
    "display" : "ANLODIPINO, BESILATO + ATORVASTATINA 5 MG + 10 MG COMPRIMIDO"
  },
  {
    "code" : "BR0368922-2",
    "display" : "ÁCIDO ACÉTICO 2 % SOLUÇÃO 250 ML"
  },
  {
    "code" : "BR0427532",
    "display" : "PERTUZUMABE 30 MG/ML SOLUÇÃO INJETÁVEL 14 ML"
  },
  {
    "code" : "BR0434130",
    "display" : "PIRENOXINA SÓDICA 0,085% COMP"
  },
  {
    "code" : "BR0364660",
    "display" : "MEGLUMINA, IOXITALAMATO 300 DE IODO /ML SOL INJ (FR-AMP) 50 ML"
  },
  {
    "code" : "BR0273690",
    "display" : "METILCELULOSE 2% SOLUÇÃO OFTÁLMICA 10 ML"
  },
  {
    "code" : "BR0412094U0041",
    "display" : "FINGOLIMODE 0,5 MG CAP GRUPO 1.A"
  },
  {
    "code" : "BR0392617",
    "display" : "TIANFENICOL 500 MG COMP"
  },
  {
    "code" : "BR0367514U0042",
    "display" : "HIDRÓXIDO DE ALUMÍNIO 230 MG COMPRIMIDO"
  },
  {
    "code" : "BR0309063",
    "display" : "AESCULUS HIPPOCASTANUM L. (CASTANHA DA ÍNDIA) 300 MG CÁPSULA"
  },
  {
    "code" : "BR0275122",
    "display" : "PIRACETAM 60 MG/ML SOLUÇÃO ORAL 110 ML"
  },
  {
    "code" : "BR0268301-2",
    "display" : "SECNIDAZOL 30 MG/ML SUSPENSÃO ORAL  30 ML"
  },
  {
    "code" : "BR0357119",
    "display" : "BETAGALSIDASE 35 MG PÓ LIOF INJ (FR-AMP) ELENCO ESTADUAL"
  },
  {
    "code" : "BR0340149",
    "display" : "CICLOFOSFAMIDA 200 mg  PÓ LIOFILIZADO PARA SOLUÇÃO INJETÁVEL"
  },
  {
    "code" : "BR0293327",
    "display" : "BENJOIM 20% TINTURA 1 L"
  },
  {
    "code" : "BR0319004",
    "display" : "DEXAMETASONA  0,75 MG COMPRIMIDO"
  },
  {
    "code" : "BR0318989",
    "display" : "SOMATROPINA 16 UI PÓ LIOF INJ (FR-AMP)"
  },
  {
    "code" : "BR0404606",
    "display" : "LANREOTIDA 120 MG/ML SOLUÇÃO INJETÁVEL"
  },
  {
    "code" : "BR0280116U0042",
    "display" : "BOSENTANA 62,5 MG COMP REV GRUPO 1.B"
  },
  {
    "code" : "BR0275422",
    "display" : "ALTEPLASE 20 MG/ML SOL INJ (FR-AMP) 20 ML"
  },
  {
    "code" : "BR0381881",
    "display" : "OMEPRAZOL MAGNÉSIO 41,3 MG COMPRIMIDO DE LIBERAÇÃO CONTROLADA"
  },
  {
    "code" : "BR0267582U0573",
    "display" : "BECLOMETASONA, DIPROPIONATO 50 MCG/DOSE AEROSSOL NASAL 130 DOSES"
  },
  {
    "code" : "BR0273149",
    "display" : "DEFLAZACORTE 7,5 MG COMPRIMIDO"
  },
  {
    "code" : "BR0272817",
    "display" : "MIDAZOLAM, MALEATO 15 MG MG COMPRIMIDO"
  },
  {
    "code" : "BR0300988",
    "display" : "PERICIAZINA 10 MG/ML SOLUÇÃO ORAL 20 ML"
  },
  {
    "code" : "BR0433812",
    "display" : "TRANILCIPROMINA, SULFATO 10 MG COMP"
  },
  {
    "code" : "BR0434796-1",
    "display" : "LEVOCETIRIZINA, DIPROPIONATO 5 MG/ML SOLUÇÃO ORAL 20 ML"
  },
  {
    "code" : "BR0340184",
    "display" : "CISPLATINA 100 MG  PÓ LIOFILIZADO PARA SOLUÇÃO INJETÁVEL"
  },
  {
    "code" : "BR0399052",
    "display" : "CARBONATO DE CÁLCIO + CARBONATO DE MAGNÉSIO + CARBONATO BÁSICO BISMUTO + BICARBONATO DE SÓDIO 521 + 67 + 3,30 + 63,70 MG PASTILHA"
  },
  {
    "code" : "BR0276839U0009",
    "display" : "ÁGUA DESTILADA SOLUÇÃO INJETÁVEL 2 ML"
  },
  {
    "code" : "BR0273668U0118",
    "display" : "PRALIDOXIMA, MESILATO 200 MG PÓ LIOFILIZADO PARA SOLUÇÃO INJETÁVEL"
  },
  {
    "code" : "BR0267355",
    "display" : "ISOCONAZOL, NITRATO 10 MG/G CREME  20 G"
  },
  {
    "code" : "BR0407705",
    "display" : "PRASUGREL, CLORIDRATO 10 MG COMPRIMIDO"
  },
  {
    "code" : "BR0267735U0009",
    "display" : "RANITIDINA, CLORIDRATO  25 MG/ML SOLUÇÃO INJETÁVEL 2 ML"
  },
  {
    "code" : "BR331223",
    "display" : "TERIPARATIDA 250 MCG/ML SOLUÇÃO INJETÁVEL 3  ML"
  },
  {
    "code" : "BR0269070-2",
    "display" : "ÁCIDO TRICLOROACÉTICO 30% SOLUÇÃO TÓPICA 10 ML"
  },
  {
    "code" : "BR0266699-2",
    "display" : "BUDESONIDA 50 MCG/DOSE AER BUCAL (FR DE 200 DOSES)"
  },
  {
    "code" : "BR0400597",
    "display" : "FENTANILA, CITRATO 12,5 MCG ADESIVO TRANSDÉRMICO"
  },
  {
    "code" : "BR0389480",
    "display" : "TOBRAMICINA, SULFATO 60 MG/ML SOLUÇÃO PARA INALAÇÃO 5 ML ELENCO ESTADUAL"
  },
  {
    "code" : "BR0436234-1",
    "display" : "ESCITALOPRAM, OXALATO  20 MG/ML SOLUÇÃO ORAL 30 ML"
  },
  {
    "code" : "BR0330115U0118",
    "display" : "GANCICLOVIR SÓDICO 500 MG PÓ LIOFILIZADO PARA SOLUÇÃO INJETÁVEL"
  },
  {
    "code" : "BR0423946",
    "display" : "NORETISTERONA+ETINILESTRADIOL 2 + 0,01 MG CÁPSULA"
  },
  {
    "code" : "BR0427719",
    "display" : "PRUCALOPRIDA, SUCCINATO 2 MG COMPRIMIDO"
  },
  {
    "code" : "BR0428744-1",
    "display" : "COLECALCIFEROL  5.600 UI/ML SOLUÇÃO ORAL 20 ML"
  },
  {
    "code" : "BR0428804",
    "display" : "BENDAMUSTINA 100 MG PÓ LIOFILIZADO"
  },
  {
    "code" : "BR0269998U0062",
    "display" : "ERITROMICINA, ESTOLATO 50 MG/ML SUSPENSÃO ORAL  100 ML"
  },
  {
    "code" : "BR0400564",
    "display" : "ARTEMETER + LUMEFANTRINA 20 MG + 120 MG COMPRIMIDO"
  },
  {
    "code" : "BR0399995",
    "display" : "POSACONAZOL 40 MG/ML SUSPENSÃO ORAL  105 ML"
  },
  {
    "code" : "BR0427614",
    "display" : "BELIMUMABE 400 MG PÓ LIOFILIZADO PARA SOLUÇÃO INJETÁVEL"
  },
  {
    "code" : "BR0269881-2",
    "display" : "CLOREXIDINA, DIGLUCONATO 0,2 % SOLUÇÃO TÓPICA 100 ML"
  },
  {
    "code" : "BR0394789U0074",
    "display" : "ITRACONAZOL 10 MG/ML SUSP ORAL (FR) 150 ML"
  },
  {
    "code" : "BR0266765",
    "display" : "ALFAINTERFERONA 2B 5.000.000 UI PÓ LIOFILIZADO PARA SOLUÇÃO INJETÁVEL"
  },
  {
    "code" : "BR0385450",
    "display" : "HIDROQUINONA 40 MG/G GEL 30 G"
  },
  {
    "code" : "BR0426207",
    "display" : "LISINOPRIL + HIDROCLOROTIAZIDA 10 MG + 12,5 MG COMPRIMIDO"
  },
  {
    "code" : "BR0381073",
    "display" : "MERCAPTAMINA, SAL BITARTARATO 150 MG COMPRIMIDO"
  },
  {
    "code" : "BR0396853-1",
    "display" : "FENILEFRINA + TETRACAINA 1 + 10 MG/ML SOLUÇÃO OFTÁLMICA 5 ML"
  },
  {
    "code" : "BR0310761",
    "display" : "LARONIDASE 0,58 MG/ML SOLUÇÃO INJETÁVEL 5 ML"
  },
  {
    "code" : "TESTE01",
    "display" : "DIPIRONA SÓDICA  1 MCG AMP 1 L ELENCO ESTADUAL"
  },
  {
    "code" : "BR0292344U0042",
    "display" : "SULFATO FERROSO (40MG DE FERRO ELEMENTAR) COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0406230",
    "display" : "SOLIFENACINA, SUCCINATO 5 MG COMPRIMIDO"
  },
  {
    "code" : "BR0287061",
    "display" : "LIDOCAÍNA, CLORIDRATO + NOREPINEFRINA 3 % SOLUÇÃO INJETÁVEL  1,8 ML"
  },
  {
    "code" : "BR0305252",
    "display" : "ASPARAGINASE 10000 UI PÓ LIOF INJ (FR-AMP) ELENCO ESTADUAL"
  },
  {
    "code" : "BR0270456",
    "display" : "DEXAMETASONA+CLORANFENICOL+CLORIDRATO DE TETRIZOLINA 0,05MG + 5MG + 0,25MG /ML SOLUÇÃO OFTÁLMICA 5 ML"
  },
  {
    "code" : "BR0352411",
    "display" : "BECLOMETASONA, DIPROPIONATO + SALBUTAMOL 400MG + 800MCG  SUSPENSÃO PARA NEBULIZAÇÃO 2 ML"
  },
  {
    "code" : "BR0394804-4",
    "display" : "PACLITAXEL 6 MG/ML SOLUÇÃO INJETÁVEL 50 ML"
  },
  {
    "code" : "BR0425719",
    "display" : "BUMETANIDA 1 MG COMPRIMIDO"
  },
  {
    "code" : "BR0425582",
    "display" : "LAMOTRIGINA 200 MG COMPRIMIDO"
  },
  {
    "code" : "BR0268005-2",
    "display" : "TRAVOPROSTA 0,004 % SOLUÇÃO OFTÁLMICA 5 ML"
  },
  {
    "code" : "BR0294887U0084",
    "display" : "SALBUTAMOL, SULFATO 100 MCG/DOSE AEROSSOL 200 DOSES ELENCO ESTADUAL"
  },
  {
    "code" : "BR0269987-2",
    "display" : "CLARITROMICINA 25 MG/ML PÓ PARA SUSPENSÃO 100 ML"
  },
  {
    "code" : "BR0337478-1",
    "display" : "SALMETEROL, XINAFOATO + FLUTICASONA 50 + 100 MCG PÓ PARA INALAÇÃO ORAL 60 DOSES ELENCO ESTADUAL"
  },
  {
    "code" : "BR0311143-1",
    "display" : "BENZOATO DE BENZILA 100 MG/G SABONETE 80 G"
  },
  {
    "code" : "BR0269568",
    "display" : "VECURÔNIO, BROMETO 4 MG/ML PÓ LIOFILIZADO"
  },
  {
    "code" : "BR0417028",
    "display" : "ASENAPINA 10 MG COMPRIMIDO SUBLINGUAL"
  },
  {
    "code" : "BR0396379",
    "display" : "PREDNISOLONA 11 MG/ML SOLUÇÃO ORAL  5 ML"
  },
  {
    "code" : "BR0431099",
    "display" : "LISINOPRIL + HIDROCLOROTIAZIDA + ANLODIPINO 15 MG + 12,5 MG + 7,5 MG CÁPSULA"
  },
  {
    "code" : "BR0270444",
    "display" : "IFOSFAMIDA 2 G PÓ LIOFILIZADO PARA SOLUÇÃO INJETÁVEL"
  },
  {
    "code" : "BR0342666",
    "display" : "GENTAMICINA, SULFATO 3 MG/G POMADA OFTALMICA 3 G"
  },
  {
    "code" : "BR0268423",
    "display" : "CETOPROFENO 25MG/G GEL 30 G"
  },
  {
    "code" : "BR0411397-4",
    "display" : "PALIPERIDONA 100 MG/ML SUSPENSÃO INJETÁVEL 0,5 ML ELENCO ESTADUAL"
  },
  {
    "code" : "BR0338288-2",
    "display" : "TESTOSTERONA, SAL UNDECILATO 250 MG/ML AMP 4 ML"
  },
  {
    "code" : "BR0393999",
    "display" : "BENZOATO DE SÓDIO 100 MG/ML SOLUÇÃO ORAL 20 ML"
  },
  {
    "code" : "BR0269872",
    "display" : "HIDROCORTISONA, ACETATO + LIDOCAÍNA + SUBGALATO DE BISMUTO + ÓXIDO DE ZINCO 0,5% +  2,0% + 2,0% +  10,0 % MG POMADA 20 G"
  },
  {
    "code" : "BR0437668U0062",
    "display" : "MIKANIA GLOMERATA (GUACO) 60 MG/ML XPE (FR) 100 ML"
  },
  {
    "code" : "BR0271570U0022",
    "display" : "DEXAMETASONA 1 MG/G POMADA OFTALMICA  3,5 G"
  },
  {
    "code" : "BR0281135-3",
    "display" : "AMOXICILINA + CLAVULANATO DE POTÁSSIO 40+5,7 MG/ML SUSPENSÃO ORAL  70 ML"
  },
  {
    "code" : "BR0333569-3",
    "display" : "TACROLIMO 0,03 % POMADA 30 G"
  },
  {
    "code" : "BR0401579",
    "display" : "BROSIMUM GAUDICHAUDII 200 MG/G POMADA 30 G"
  },
  {
    "code" : "BR0416784",
    "display" : "POLIETILENOGLICOL (MACROGOL) 4000 G GRANULADO 10 G"
  },
  {
    "code" : "INATIVO 36",
    "display" : "INATIVO-CLORANFENICOL 4 MG/ML SOLUÇÃO OFTÁLMICA 10 ML INATIVO, USAR O BR0345638"
  },
  {
    "code" : "BR0272852",
    "display" : "TRIEXIFENIDIL, CLORIDRATO 5 MG COMPRIMIDO"
  },
  {
    "code" : "BR0340195-4",
    "display" : "CITARABINA 100 MG/ML SOLUÇÃO INJETÁVEL 20 ML"
  },
  {
    "code" : "BR0268241",
    "display" : "DELTAMETRINA 0,2 MG/ML LOÇÃO 100 ML"
  },
  {
    "code" : "BR0269941U0062",
    "display" : "ÁLCOOL ETÍLICO 70% SOLUÇÃO 100 ML"
  },
  {
    "code" : "BR0392108",
    "display" : "IMUNOGLOBULINA HUMANA  10 G, ENDOVENOSA PÓ LIOFILIZADO PARA SUSPENSÃO INJETÁVEL 100 ML"
  },
  {
    "code" : "BR0397872",
    "display" : "HIDRÓXIDO DE MAGNÉSIO 85,5 MG/ML SUSPENSÃO OFTÁLMICA 350  ML"
  },
  {
    "code" : "BR0433023",
    "display" : "CALCIO, CITRATO + COLECALCIFEROL 250 MG + 2,5 MCG COMP"
  },
  {
    "code" : "BR0432577",
    "display" : "ÓLEO DE LINHAÇA 1000 MG CÁPSULA"
  },
  {
    "code" : "BR0269987-1",
    "display" : "CLARITROMICINA 25 MG/ML PÓ PARA SUSPENSÃO 50 ML"
  },
  {
    "code" : "BR0411397",
    "display" : "PALIPERIDONA 75 MG/ML SUSPENSÃO INJETÁVEL 0,75 ML ELENCO ESTADUAL"
  },
  {
    "code" : "BR0417156",
    "display" : "METENAMINA+METILTIONINIO 120 MG + 20 MG DRÁGEA"
  },
  {
    "code" : "BR0390598U0154",
    "display" : "FATOR VIII RECOMBINANTE, CONCENTRADO DE FATOR DE COAGULAÇÃO 1000 UI PÓ LIOFILIZADO PARA SOLUÇÃO INJETÁVEL"
  },
  {
    "code" : "BR0376357",
    "display" : "VALSARTANA 40 MG COMPRIMIDO"
  },
  {
    "code" : "BR0267731-1",
    "display" : "NIFEDIPINO 20 MG COMPRIMIDO DE LIBERAÇÃO PROLONGADA"
  },
  {
    "code" : "BR0432635",
    "display" : "CARBOXIMALTOSE, FÉRRICA 50 MG/ML SUSPENSÃO INJETÁVEL 10 ML"
  },
  {
    "code" : "BR0433249U0062",
    "display" : "ZINCO, SULFATO 4 MG/ML XAROPE  100 ML"
  },
  {
    "code" : "BR0273694-1",
    "display" : "METILCELULOSE 2% SOLUÇÃO OFTÁLMICA 2 ML"
  },
  {
    "code" : "BR0427409",
    "display" : "EVEROLIMO 2,5 MG COMPRIMIDO"
  },
  {
    "code" : "BR0436433",
    "display" : "FENTICONAZOL, NITRATO 20 MG/ML SPRAY  TÓPICO 30 ML"
  },
  {
    "code" : "BR0436500",
    "display" : "RAMIPRIL + ANLODIPINO, BESILATO 10 MG + 10 MG CAP"
  },
  {
    "code" : "BR0414456-1",
    "display" : "BENZOATO DE SÓDIO 200 MG/ML XAROPE  150 ML"
  },
  {
    "code" : "BR0271758",
    "display" : "BETANECOL 10 MG CÁPSULA"
  },
  {
    "code" : "BR0437403",
    "display" : "LIPPIA SIDOIDES CHAM. (ALECRIM PIMENTA) 20 % TINTURA 30 ML"
  },
  {
    "code" : "BR0305490-1",
    "display" : "METILFENIDATO, CLORIDRATO 40 MG CAP LIBERAÇÃO CONTROLADA"
  },
  {
    "code" : "BR0270431",
    "display" : "GENCITABINA 20 MG/ML PÓ LIOFILIZADO PARA SOLUÇÃO INJETÁVEL 10 ML"
  },
  {
    "code" : "BR0305428-4",
    "display" : "CARMELOSE SÓDICA 10 MG SOLUÇÃO OFTÁLMICA 15 ML"
  },
  {
    "code" : "BR0353641-1",
    "display" : "HILANO GF-20 8 MG/ML SOLUÇÃO INJETÁVEL 6 ML"
  },
  {
    "code" : "BR0270438",
    "display" : "DACARBAZINA 200 MG PÓ LIOFILIZADO PARA SOLUÇÃO INJETÁVEL"
  },
  {
    "code" : "BR0421663",
    "display" : "BUTOCONAZOL 5 MG/G CREME VAGINAL  APLICADOR PREENCHIDO 5 G"
  },
  {
    "code" : "BR0273892-1",
    "display" : "BUDESONIDA 0,5 MG/ML SUSPENSÃO PARA NEBULIZAÇÃO 5 ML"
  },
  {
    "code" : "BR0270128U0042",
    "display" : "LEVODOPA + BENSERAZIDA  100 + 25 MG COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0393731",
    "display" : "OXICODONA, CLORIDRATO 40 MG COMPRIMIDO DE LIBERAÇÃO PROLONGADA ELENCO ESTADUAL"
  },
  {
    "code" : "BR0431314",
    "display" : "ITRACONAZOL 20 MG/ML SUSPENSÃO ORAL  60 ML"
  },
  {
    "code" : "BR0425182-1",
    "display" : "DEXTROCETAMINA, CLORIDRATO 50MG/ML SOLUÇÃO INJETÁVEL 2 ML"
  },
  {
    "code" : "BR0435101",
    "display" : "PARACETAMOL  +  AMITRIPTILINA + MELOXICAM, FORMULAÇÃO ESPECIALMENTE MANIPULADA  500 + 25 + 7,5 MG CAP"
  },
  {
    "code" : "BR0435189",
    "display" : "PARACETAMOL + MELOXICAM + CICLOBENZAPRINA, FORMULAÇÃO ESPECIALMENTE MANIPULADA 500 + 15 + 5 MG CÁPSULA"
  },
  {
    "code" : "BR0364324U0042",
    "display" : "HIDROCLOROTIAZIDA  12,5 MG COMPRIMIDO"
  },
  {
    "code" : "BR0270889-1",
    "display" : "ESCINA AMORFA + ESCINA POLISSULFONADA SÓDICA + SALICILATO DE DIETILAMINA 10 + 10 + 50  mg/g GEL 100 G"
  },
  {
    "code" : "BR0406975",
    "display" : "ÁCIDO VALPRÓICO (VALPROATO DE SÓDIO)  100 MG/ML SOLUÇÃO INJETÁVEL 10 ML"
  },
  {
    "code" : "BR0270836",
    "display" : "ESTRADIOL 25 MCG ADESIVO TRANSDÉRMICO"
  },
  {
    "code" : "BR0373415",
    "display" : "DAPTOMICINA 500 MG PÓ LIOF INJ (FR-AMP)"
  },
  {
    "code" : "BR0301591",
    "display" : "FOTEMUSTINA 208 MG PÓ LIOFILIZADO"
  },
  {
    "code" : "BR0418793",
    "display" : "VEMURAFENIBE 240 MG COMPRIMIDO"
  },
  {
    "code" : "BR0404612",
    "display" : "PRAMIPEXOL 1,5 MG COMPRIMIDO"
  },
  {
    "code" : "BR0428425",
    "display" : "DIOSMINA + HESPERIDINA 900 + 100 MG COMPRIMIDO"
  },
  {
    "code" : "BR0431301-1",
    "display" : "VASELINA (PETROLATO, PURO) SOLUÇÃO 100 ML"
  },
  {
    "code" : "BR0428637",
    "display" : "FOSFATO TRICÁLCICO 38 MG/ML SOL ORAL (FR) 100 ML"
  },
  {
    "code" : "BR0267643-2",
    "display" : "DEXAMETASONA 0,1% CREME  15 G"
  },
  {
    "code" : "BR0268994U0042",
    "display" : "BUPROPIONA, CLORIDRATO 150 MG COMPRIMIDO DE LIBERAÇÃO PROLONGADA"
  },
  {
    "code" : "BR0434127",
    "display" : "CURCUMA LONGA 250MG (EQUIVALENTE A 50MG DE CURCUMINOIDES) CÁPSULA"
  },
  {
    "code" : "BR0338413",
    "display" : "DACTINOMICINA 0,5 MG PÓ LIOFILIZADO PARA SOLUÇÃO INJETÁVEL ELENCO ESTADUAL"
  },
  {
    "code" : "BR0273137",
    "display" : "DICLOFENACO SÓDICO 75 MG COMPRIMIDO"
  },
  {
    "code" : "BR0266762-1",
    "display" : "ALFAINTERFERONA 2A 3.000.000 UI  SOLUÇÃO INJETÁVEL COM SISTEMA DE APLICAÇÃO 0,5 ML"
  },
  {
    "code" : "BR0435334U0042",
    "display" : "DACLATASVIR 30 MG COMP REV GRUPO 1.A"
  },
  {
    "code" : "BR0429847",
    "display" : "APIXABANA 2,5 MG COMP REV"
  },
  {
    "code" : "BR0437891",
    "display" : "FERRO QUELATO + COBRE QUELATO + ÁCIDO FÓLICO + MULTIVITAMINAS 300MCG + 20MG + 100MG + 20MG + 2MG + 0,5MG + 25 MG CÁPSULA"
  },
  {
    "code" : "BR0437903",
    "display" : "LISINOPRIL + HIDROCLOROTIZIDA + ANLODIPINO 20 MG + 12,5 MG + 7,5 MG CÁPSULA"
  },
  {
    "code" : "BR0437905",
    "display" : "ZINCO QUELATO 10 MG CÁPSULA"
  },
  {
    "code" : "BR0274227-1",
    "display" : "GLICOSAMINA, SULFATO + CONDROITINA, SULFATO 500 MG + 400MG PRODUTO MANIPULADO PÓ"
  },
  {
    "code" : "BR0437908",
    "display" : "PASSIFLORA ALATA 400 MG CÁPSULA"
  },
  {
    "code" : "BR0273664",
    "display" : "MESNA 100 MG/ML SOLUÇÃO INJETÁVEL 4 ML"
  },
  {
    "code" : "BR0273258",
    "display" : "PAMIDRONATO DISSÓDICO 90 MG PÓ LIOFILIZADO PARA SOLUÇÃO INJETÁVEL"
  },
  {
    "code" : "BR0416731",
    "display" : "MEDROXIPROGESTERONA, ACETATO + ESTRADIOL, CIPIONATO 25 MG + 5 MG/ML SOLUÇÃO INJETÁVEL 0,05 ML"
  },
  {
    "code" : "BR0357239",
    "display" : "ÁLCOOL ETÍLICO 99,5 % SOLUÇÃO 1000 ML"
  },
  {
    "code" : "BR0420599",
    "display" : "MORFINA, SULFATO 0,1 MG/ML SOLUÇÃO INJETÁVEL 1 ML"
  },
  {
    "code" : "BR0396414U0334",
    "display" : "PLANTAGO OVATA (PSYLLIUM) PÓ PARA DISPERSÃO ORAL 174 G"
  },
  {
    "code" : "BR0269068-1",
    "display" : "ÁCIDO TRICLOROACÉTICO 50 % SOLUÇÃO 10 ML"
  },
  {
    "code" : "BR0412965-2",
    "display" : "SIMETICONA 75 MG/ML SOLUÇÃO ORAL  20 ML"
  },
  {
    "code" : "BR0268298",
    "display" : "PRAZIQUANTEL 500 MG COMPRIMIDO"
  },
  {
    "code" : "BR0278483",
    "display" : "VITAMINAS DO COMPLEXO B, VITAMINAS: B1, B2,B6,B12 E PP SOLUÇÃO ORAL 120 ML"
  },
  {
    "code" : "BR0433514",
    "display" : "UBGALATO DE BISMUTO + ÓXIDO DE ZINCO 1,5 MG/G + 45 MG/G GEL 100 G"
  },
  {
    "code" : "BR0406081",
    "display" : "LORNOXICAM 8 MG COMP"
  },
  {
    "code" : "BR0415027-1",
    "display" : "PODOFILINA 25 % SOLUÇÃO TÓPICA 60 ML"
  },
  {
    "code" : "BR0432781",
    "display" : "VALERIANA OFFICINALIS, EXTRATO SECO 225,75 MG COMPRIMIDO"
  },
  {
    "code" : "BR0292262-2",
    "display" : "MORFINA, SULFATO 100 MG COMPRIMIDO DE LIBERAÇÃO PROLONGADA"
  },
  {
    "code" : "BR0409592",
    "display" : "PRAMIPEXOL, DICLORIDRATO 3 MG COMPRIMIDO DE LIBERAÇÃO CONTROLADA"
  },
  {
    "code" : "BR0270793",
    "display" : "ATENOLOL + CLORTALIDONA 25+12,5 MG COMPRIMIDO"
  },
  {
    "code" : "BR0433171",
    "display" : "PITAVASTATINA CÁLCICA 2 MG COMPRIMIDO DE LIBERAÇÃO CONTROLADA"
  },
  {
    "code" : "BR0433940U0062",
    "display" : "MIKANIA GLOMERATA (GUACO) 35 MG/ML XAROPE  100 ML"
  },
  {
    "code" : "BR0436201",
    "display" : "SERTRALINA, CLORIDRATO 150 MG CÁPSULA"
  },
  {
    "code" : "BR0431752",
    "display" : "SIMEPREVIR 150 MG CÁPSULA"
  },
  {
    "code" : "BR0436480",
    "display" : "FLUTICASONA, FUROATO + VILANTEROL, TRIFENATATO 200/25 MCG PÓ PARA INALAÇÃO ORAL 30 DOSES"
  },
  {
    "code" : "BR0400982",
    "display" : "ZINCO, SULFATO 2,5 MG SOLUÇÃO ORAL 60 ML"
  },
  {
    "code" : "BR0399442-1",
    "display" : "UNCARIA TOMENTOSA (UNHA DE GATO) 300 MG CÁPSULA"
  },
  {
    "code" : "BR0411397-1",
    "display" : "PALIPERIDONA 100 MG/ML SUSPENSÃO INJETÁVEL 1 ML ELENCO ESTADUAL"
  },
  {
    "code" : "BR0404585-1",
    "display" : "HIDRÓXIDO DE CÁLCIO PÓ 20 G"
  },
  {
    "code" : "BR0434872",
    "display" : "TOFACITINIBE, CITRATO 5 MG COMP"
  },
  {
    "code" : "BR0397428U0165",
    "display" : "LIDOCAÍNA, CLORIDRATO + EPINEFRINA 2% + 1:80.000 SOLUÇÃO INJETÁVEL 1,8 ML"
  },
  {
    "code" : "BR0271724",
    "display" : "PIPERACILINA SÓDICA + TAZOBACTAM SÓDICA 2 G + 250 MG PÓ PARA SOLUÇÃO INJETÁVEL"
  },
  {
    "code" : "BR0267395",
    "display" : "IBUPROFENO 400 MG COMPRIMIDO"
  },
  {
    "code" : "BR0267210",
    "display" : "ESTRIOL 2 MG COMPRIMIDO"
  },
  {
    "code" : "BR0374313U0237",
    "display" : "ACIDO PARA-AMINOSALICILICO 4G GRANULADO 4 G"
  },
  {
    "code" : "BR0433494",
    "display" : "CARBAMIDA 100MG/ML  SOLUÇÃO OTOLÓGICA 10 ML"
  },
  {
    "code" : "BR0425676",
    "display" : "DIAZOXIDO 25 MG CÁPSULA"
  },
  {
    "code" : "BR0434045",
    "display" : "SYMPHITUM SP L. (CONFREI) 5% POMADA 30  G"
  },
  {
    "code" : "BR0272948",
    "display" : "FLUORESCEÍNA 10 % SOLUÇÃO INJETÁVEL 5 ML"
  },
  {
    "code" : "BR0426892",
    "display" : "TIZANIDINA, CLORIDRATO 4 MG COMPRIMIDO"
  },
  {
    "code" : "BR0433019",
    "display" : "ROMIPLOSTIM 250 MCG PÓ LIOF INJ (FR-AMP)"
  },
  {
    "code" : "BR0435102",
    "display" : "PARACETAMOL + AMITRIPTILINA + CICLOBENZAPRINA + MELOXICAM , FORMULAÇÃO ESPECIALMENTE MANIPULADA 500 MG + 25 MG + 5 MG +  7,5 MG CAP"
  },
  {
    "code" : "BR0273599",
    "display" : "TERBINAFINA, CLORIDRATO 250 MG COMPRIMIDO"
  },
  {
    "code" : "BR0426292U0041",
    "display" : "RHAMNUS PURSHIANA (CÁSCARA SAGRADA) 380 MG CÁPSULA"
  },
  {
    "code" : "BR0416528",
    "display" : "ERITROPOETINA HUMANA RECOMBINANTE 4.000 UI PÓ LIOFILIZADO PARA SUSPENSÃO INJETÁVEL 2 ML"
  },
  {
    "code" : "BR0436705-2",
    "display" : "BUPRENORFINA 10 MG ADESIVO TRANSDÉRMICO"
  },
  {
    "code" : "BR0404406-1",
    "display" : "SILYBUM MARIANUM (L.) GAERTN 64/5 MG/ML SOLUÇÃO ORAL 100 ML"
  },
  {
    "code" : "BR0436788",
    "display" : "CÁLCIO TRIBÁSICO + COLECALCIFEROL + CIANOCOBALAMINA 10 + 0,00025 + 0,0012 MG SOLUÇÃO 250 ML"
  },
  {
    "code" : "BR0436839",
    "display" : "COMPLEXO B (B1,B2,B6,B3) TIAMINA + RIBOFLAVINA + PIRIDOXINA + NICOTINAMIDA 7,5 + 0,825 + 2,5 + 12,5  MG COMP REV"
  },
  {
    "code" : "BR0406015-4",
    "display" : "OXIBUTININA, CLORIDRATO, FORMULAÇÃO ESPECIALMENTE MANIPULADA 1 MG/ML SOL ORAL (FR) 800 ML"
  },
  {
    "code" : "BR0292195-4",
    "display" : "HALOPERIDOL 2 MG/ML SOLUÇÃO ORAL 15 ML"
  },
  {
    "code" : "BR0268444",
    "display" : "DILTIAZEM, CLORIDRATO 25 MG AMP"
  },
  {
    "code" : "BR0405900",
    "display" : "BENZOCAÍNA + TRICLOSANA + MENTOL 45+5+5 MG/G AEROSSOL"
  },
  {
    "code" : "BR0432197-1",
    "display" : "GLYCINE MAX (ISOFLAVONA DE SOJA) 100 MG COMPRIMIDO"
  },
  {
    "code" : "BR0384297-1",
    "display" : "CISTEAMINA 150 MG CÁPSULA"
  },
  {
    "code" : "BR0304788U0042",
    "display" : "CINACALCETE 30 MG COMP GRUPO 1.A"
  },
  {
    "code" : "BR0448254",
    "display" : "MULTIVITAMINAS, VITS: A, B1, B12, C, D, E, MINERAIS: CA, CU, FE, SE, ZN, ÁCIDO FÓLICO COMPRIMIDO MASTIGÁVEL"
  },
  {
    "code" : "BR0292343",
    "display" : "SULFADIAZINA DE PRATA 30 G BISNAGA"
  },
  {
    "code" : "BR0437869U0042",
    "display" : "FUMARATO DE DIMETILA 120 MG COMP GRUPO 1.A"
  },
  {
    "code" : "BR0268225",
    "display" : "CARBONATO DE CÁLCIO (CÁLCIO ELEMENTAR) 200 MG COMPRIMIDO"
  },
  {
    "code" : "BR0337472-1",
    "display" : "INSULINA DETEMIR 100 UI/ML INJ (FR) 30 ML"
  },
  {
    "code" : "BR0391938U0086",
    "display" : "COLECALCIFEROL (VITAMINA D3) 3.300 UI/ML SOLUÇÃO ORAL 20 ML"
  },
  {
    "code" : "BR0399486",
    "display" : "PERINDOPRIL + ANLODIPINO, BESILATO 7 + 5 MG COMPRIMIDO"
  },
  {
    "code" : "BR0448121",
    "display" : "ANAMIRTA COCCULUS D4 + ASSOCIAÇÃO 210 + 30 + 30 MG COMPRIMIDO"
  },
  {
    "code" : "BR0435745U0041",
    "display" : "MORUS NIGRA L. - AMORA  50 G DROGA VEGETAL"
  },
  {
    "code" : "BR0438819",
    "display" : "UBIDECARENONA (COENZIMA Q10) 2000MG INJ (FR) 30ML"
  },
  {
    "code" : "BR0451696",
    "display" : "EXTRATO MEDICINAL, ÓLEO DE CANABIDIOL, ÓLEO DE CÂNFORA E AMÊNDOAS E EXTRATO HERBAL POMADA 37 G ELENCO ESTADUAL"
  },
  {
    "code" : "BR0436722",
    "display" : "HARPAGOPHYTUM PROCUBENS (GARRA DO DIABO) 300MG COMP"
  },
  {
    "code" : "BR0440255U0137",
    "display" : "INSULINA ANÁLOGA DE AÇÃO RÁPIDA (ASPARTE) 100 UI/ML TUBETE 3 ML GRUPO 1.A"
  },
  {
    "code" : "BR0400563U0170",
    "display" : "USTEQUINUMABE 90 MG/ML SOLUÇÃO INJETÁVEL 1 ML"
  },
  {
    "code" : "BR0270633U0063",
    "display" : "DIPIRONA + ISOMETEPTENO + CAFEÍNA 30 + 50 + 30 MG/ML SOLUÇÃO ORAL 10 ML"
  },
  {
    "code" : "BR0437160U0106",
    "display" : "CLORETO DE SÓDIO 0,9 % SOLUÇÃO NASAL 5 ML"
  },
  {
    "code" : "BR0342320",
    "display" : "ZIPRASIDONA 80 MG CÁPSULA  ELENCO ESTADUAL"
  },
  {
    "code" : "BR0453816U0097",
    "display" : "EXTRATO MEDICINAL, ÓLEO DE CANABIDIOL  33,33 MG/ML SOLUÇÃO ORAL 30 ML ELENCO ESTADUAL"
  },
  {
    "code" : "BR0362057U0316",
    "display" : "RIVASTIGMINA 9 MG ADESIVO TRANSDÉRMICO GRUPO 1.A"
  },
  {
    "code" : "BR0389799U0593",
    "display" : "CONCENTRADO DE FATOR VII 100KUI ATIVADO RECOMBINADO INJ (FR)"
  },
  {
    "code" : "BR0271052U0123",
    "display" : "BICARBONATO DE SÓDIO PÓ 500 G"
  },
  {
    "code" : "BR0454934U0041",
    "display" : "EXTRATO MEDICINAL, ÓLEO DE CANABIDIOL 50 MG CÁPSULA"
  },
  {
    "code" : "BR0410020U0042",
    "display" : "ELTROMBOPAGUE 50 MG COMP REV GRUPO 1.B"
  },
  {
    "code" : "BR0271110U0042",
    "display" : "CIPROTERONA + ETINILESTRADIOL 2 + 0,035 MG COMPRIMIDO"
  },
  {
    "code" : "BR390598-3",
    "display" : "CONCENTRADO DE FATOR DE COAGULAÇÃO, FATOR VIII RECOMBINANTE 500 UI INJ (FR)"
  },
  {
    "code" : "BR0439450U0041",
    "display" : "BIOTINA 2,5 MG CÁPSULA  GRUPO 1.A"
  },
  {
    "code" : "BR040442-1",
    "display" : "BARBATIMÃO 10% CREME  10G"
  },
  {
    "code" : "BR0268286U0018",
    "display" : "MICONAZOL, NITRATO 2 % CREME  20 G"
  },
  {
    "code" : "BR0320796U0005",
    "display" : "DESMOPRESSINA, ACETATO 15 MCG/ML INJ (FR)"
  },
  {
    "code" : "BR0327215U0103",
    "display" : "IODO IODETO DE POTÁSSIO  SOLUÇÃO 500ML"
  },
  {
    "code" : "BR0332383U0118",
    "display" : "IDURSULFASE ALFA 2 MG/ML SOL INJ (FR) 3 ML GRUPO 1.A"
  },
  {
    "code" : "BR0450929U0284",
    "display" : "EXTRATO MEDICINAL, ÓLEO DE CANABIDIOL 100  MG/ML SOLUÇÃO ORAL 3 ML ELENCO ESTADUAL"
  },
  {
    "code" : "BR0297697U0165",
    "display" : "ARTICAÍNA ASSOCIADA COM EPINEFRINA 4% + 1/100.000 SOLUÇÃO INJETÁVEL 1,8 ML"
  },
  {
    "code" : "BR0399486U0042",
    "display" : "PERINDOPRIL + ANLODIPINO, BESILATO 3,5 + 2,5 MG COMP"
  },
  {
    "code" : "BR0386022",
    "display" : "MINOXIDIL 50MG/ML SOLUÇÃO 50ML"
  },
  {
    "code" : "BR0377899U0042",
    "display" : "VALERIANA OFFICINALIS, EXTRATO SECO 50 MG COMPRIMIDO"
  },
  {
    "code" : "BR0439128",
    "display" : "PASSIFLORA INCARNATA 260 MG COMP REV"
  },
  {
    "code" : "BR0434357",
    "display" : "PASSIFLORA INCARNATA 90 MG/ML SOL ORAL (FR)"
  },
  {
    "code" : "BR0438851",
    "display" : "FENTANILA, CITRATO + DROPERIDOL CITRATO DE FENTANILA + DROPERIDOL 0,0785 MG/ML + 2 INJ (FR)"
  },
  {
    "code" : "BR0274502-1",
    "display" : "CEFACLOR 250MG/5ML SUSP ORAL (FR) 100 ML"
  },
  {
    "code" : "BR040442",
    "display" : "BARBATIMÃO 10% CREME  60G"
  },
  {
    "code" : "BR0443478U0490",
    "display" : "AMORFO, ALANTOÍNA, GLICERINA E CARBOXIMETILCELULOSE   BISNAGA 85G"
  },
  {
    "code" : "BR0352933-4",
    "display" : "LEVETIRACETAM 100 MG/ML SOLUÇÃO ORAL 150 ML ELENCO ESTADUAL"
  },
  {
    "code" : "BR0436600",
    "display" : "PERINDOPRIL 10MG COMP"
  },
  {
    "code" : "BR0443373U0124",
    "display" : "CALENDULA OFFICINALIS L 10% GEL 60G"
  },
  {
    "code" : "BR0310761U0118",
    "display" : "LARONIDASE 0,58 MG/ML SOL INJ (FR) 5 ML GRUPO 1.A"
  },
  {
    "code" : "BR0438355U0587",
    "display" : "RITUXIMABE 1400MG/11,7ML SOL INJ (FR) 11,7ML"
  },
  {
    "code" : "BR0437160U0068",
    "display" : "CLORETO DE SÓDIO 0,9 % SOLUÇÃO NASAL 125 ML"
  },
  {
    "code" : "BR0391660U0238",
    "display" : "VACINA PNEUMOCÓCICA 10-VALENTE CONJUGADA SUSPENSÃO INJETÁVEL"
  },
  {
    "code" : "BR0441461U0106",
    "display" : "DARATUMUMABE 20 MG/ML SOLUÇÃO INJETÁVEL 5 ML"
  },
  {
    "code" : "BR0272342U0009",
    "display" : "TIAMINA, CLORIDRATO 50 MG/ML AMP 2 ML"
  },
  {
    "code" : "BR0448601",
    "display" : "ÁCIDO FÓLICO + FERRO QUELATO GLICINATO (30 MG FERRO ELEMENTAR)  5 + 150  MG CÁPSULA"
  },
  {
    "code" : "BR0278650U0042",
    "display" : "CARISOPRODOL, DIPIRONA + PIRIDOXINA + TIAMINA + CIANOCOBALAMINA 250MG + 250MG + 100MG + 50MG + 1MG COMP"
  },
  {
    "code" : "BR0414435",
    "display" : "CERTOLIZUMABE PEGOL 200 MG/ML SOLUÇÃO INJETÁVEL 1 ML"
  },
  {
    "code" : "BR0433690",
    "display" : "ENZALUTAMIDA 40 MG CAP"
  },
  {
    "code" : "BR0389779U0042",
    "display" : "RASAGILINA 1 MG COMPRIMIDO GRUPO 1.A"
  },
  {
    "code" : "BR0333569U0023",
    "display" : "TACROLIMO 1 MG/G POMADA 30 G"
  },
  {
    "code" : "BR0436550",
    "display" : "SIMETICONA 125MG CÁPSULA"
  },
  {
    "code" : "BR0437083",
    "display" : "SECUQUINUMABE 150 MG/ML SOLUÇÃO INJETÁVEL"
  },
  {
    "code" : "BR0389799U0591",
    "display" : "CONCENTRADO DE FATOR VII 50KUI ATIVADO RECOMBINANTE INJ (FR)"
  },
  {
    "code" : "BR0327212U0063",
    "display" : "LUGOL 5 % SOLUÇÃO 100 ML"
  },
  {
    "code" : "BR0267282-1",
    "display" : "ESCOPOLAMINA, BUTILBROMETO 20 MG/ML INJ (FR) 2 ML"
  },
  {
    "code" : "BR0394769U0135",
    "display" : "VACINA HUMANA, CONTRA HEPATITE A, ADSORVIDA, INATIVADA, 720 U.EL / 0,5ML, SUSPENSÃO INJETÁVEL INFANTIL SOLUÇÃO INJETÁVEL 0,5 ML"
  },
  {
    "code" : "BR0451608",
    "display" : "HAMAMELIS + CASTANHA DA ÍNDIA + RUTINA 150MG + 150MG + 50 MG CÁPSULA"
  },
  {
    "code" : "BR0440195",
    "display" : "COLECALCIFEROL 10.000UI/ML SOLUÇÃO ORAL 10ML"
  },
  {
    "code" : "BR0433687U0042",
    "display" : "DOLUTEGRAVIR  50 MG COMP"
  },
  {
    "code" : "BR0314517-5 INATIVO",
    "display" : "AZITROMICINA 40MG/ML 600MG PÓ PARA SOLUÇÃO 15 ML"
  },
  {
    "code" : "BR0441621U0042",
    "display" : "METFORMINA CLORIDRATO ASSOCIADA A DAPAGLIFLOZINA 1000 MG + 5 MG COMP"
  },
  {
    "code" : "BR0445431U0041",
    "display" : "VALSARTANA, ASSOCIADO AO SACUBITRIL 26 MG + 24 MG CÁPSULA"
  },
  {
    "code" : "BR0493705",
    "display" : "SILIMARINA 180 MG CÁPSULA"
  },
  {
    "code" : "BR0285081U0041",
    "display" : "TANSULOSINA, CLORIDRATO 0,4 MG CAP DE LIB PROL"
  },
  {
    "code" : "BR0434252U0041",
    "display" : "PIRFENIDONA 267MG CÁPSULA"
  },
  {
    "code" : "BR0452264U0171",
    "display" : "ÓXIDO DE ZINCO, ASSOCIADO À GELATINA E GLICEROL 25% + 25% + 25% ESPECIALMENTE MANIPULADO PASTA  500  G"
  },
  {
    "code" : "BR0449866",
    "display" : "ATEZOLIZUMABE 60 MG/ML SOLUÇÃO INJETÁVEL 20 ML"
  },
  {
    "code" : "BR0437994",
    "display" : "LACOSAMIDA 150 MG COMPRIMIDO"
  },
  {
    "code" : "BR0451578",
    "display" : "RHAMNUS PURSHIANA (CÁSCARA SAGRADA)  400 MG CÁPSULA"
  },
  {
    "code" : "BR0404421U0018",
    "display" : "STRYPHNODENDRON BARBATIMAN MART. 60 MG/G POMADA 20 G"
  },
  {
    "code" : "BR0365018U0007",
    "display" : "SORO, ANTI-BOTULÍNICO AB 375 + 275 UI/ML SOLUÇÃO INJETÁVEL 20 ML"
  },
  {
    "code" : "BR0457213U0577",
    "display" : "ESTRADIOL  1 MG/G GEL 0,5 G"
  },
  {
    "code" : "BR0267378U0062",
    "display" : "NISTATINA 100.000 UI/ML SUSP ORAL (FR) 100ML"
  },
  {
    "code" : "BR0436889",
    "display" : "MESALAZINA 1 G PÓ"
  },
  {
    "code" : "BR0391962U0006",
    "display" : "IMUNOGLOBULINA HUMANA ANTIVARICELA ZOSTER 125 UI SOLUÇÃO INJETÁVEL 2,5 ML"
  },
  {
    "code" : "BR0449650U0110",
    "display" : "EXTRATO MEDICINAL, ÓLEO DE CANABIDIOL 50 MG/ML SOLUÇÃO ORAL 60 ML ELENCO ESTADUAL"
  },
  {
    "code" : "BR0278379",
    "display" : "TRETINOÍNA 0,1 % CREME"
  },
  {
    "code" : "BR0434478U0288",
    "display" : "EXTRATO MEDICINAL, ÓLEO DE CANABIDIOL 24 % SOLUÇÃO ORAL 10 ML ELENCO ESTADUAL"
  },
  {
    "code" : "BR0451686U0582",
    "display" : "EXTRATO MEDICINAL, ÓLEO DE CANABIDIOL, CÂNHAMO DESCARBOXILADO 8,47 MG/ML SOLUÇÃO 118 ML ELENCO ESTADUAL"
  },
  {
    "code" : "BR0271637",
    "display" : "ÓLEO DE RÍCINO INJ (FR)"
  },
  {
    "code" : "BR0351479U0261",
    "display" : "ETODOLACO 500 MG COMPRIMIDO"
  },
  {
    "code" : "BR0292399",
    "display" : "FITOMENADIONA 10 MG/ML SOLUÇÃO INJETÁVEL 0,2 ML IV"
  },
  {
    "code" : "BR0272849",
    "display" : "TOPIRAMATO 25 MG COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0286740U0067",
    "display" : "FENDIZOATO DE CLOPERASTINA 3,54MG/ML  XAROPE"
  },
  {
    "code" : "BR0451163U0041",
    "display" : "EXTRATO MEDICINAL, ÓLEO DE CANABIDIOL , CÂNHAMO DESCARBOXILADO E FILTRADO, CÚRCUMA E SALGUEIRO, 25 MG CÁPSULA  ELENCO ESTADUAL"
  },
  {
    "code" : "BR0266830U0005",
    "display" : "IMUNOGLOBULINA HUMANA ANTITETÂNICA 250 UI/ML SOLUÇÃO INJETÁVEL 1 ML"
  },
  {
    "code" : "BR0266863U0115",
    "display" : "METRONIDAZOL (BENZOILMETRONIDAZOL) 40 MG/ML SUSPENSÃO ORAL  80 ML"
  },
  {
    "code" : "BR0267517U0042",
    "display" : "ATENOLOL 50 MG COMPRIMIDO"
  },
  {
    "code" : "BR0267586U0041",
    "display" : "BECLOMETASONA, DIPROPIONATO 200 MCG CÁPSULA  60 DOSES"
  },
  {
    "code" : "BR0267652U0042",
    "display" : "ENALAPRIL, MALEATO 20 MG COMPRIMIDO"
  },
  {
    "code" : "BR0267734U0067",
    "display" : "RANITIDINA, CLORIDRATO  15 MG/ML XAROPE  120 ML"
  },
  {
    "code" : "BR0267747U0042",
    "display" : "SINVASTATINA  20 MG COMPRIMIDO"
  },
  {
    "code" : "BR0268075U0004",
    "display" : "MAGNÉSIO, SULFATO 50 % SOLUÇÃO INJETÁVEL  10 ML"
  },
  {
    "code" : "BR0268159U0042",
    "display" : "PENTOXIFILINA 400 MG COMPRIMIDO"
  },
  {
    "code" : "BR0268236U0068",
    "display" : "CLORETO DE SÓDIO 0,9% SOLUÇÃO INJETÁVEL 125 ML SISTEMA FECHADO"
  },
  {
    "code" : "BR0268955U0041",
    "display" : "CLINDAMICINA, CLORIDRATO 150 MG  CÁPSULA"
  },
  {
    "code" : "BR0272473U0041",
    "display" : "DANAZOL 100 MG CAP GRUPO 1.B"
  },
  {
    "code" : "BR0384894U0042",
    "display" : "PROPAFENONA, CLORIDRATO 150 MG COMPRIMIDO"
  },
  {
    "code" : "BR0440866U0062",
    "display" : "CLARITROMICINA 50 MG/ML PÓ PARA SUSPENSÃO 100 ML"
  },
  {
    "code" : "BR0322079",
    "display" : "METOTREXATO 50 MG/ML SOLUÇÃO INJETÁVEL 2 ML"
  },
  {
    "code" : "BR0277311U0042",
    "display" : "ACIDO AMINOCAPRÓICO 500MG COMPRIMIDO"
  },
  {
    "code" : "BR0437081U0042",
    "display" : "RIOCIGUATE 1,0 MG COMPRIMIDO"
  },
  {
    "code" : "BR0309095U0066",
    "display" : "FORMOTEROL + BUDESONIDA 6 + 200 MCG PÓ PARA INALAÇÃO ORAL 120 DOSES"
  },
  {
    "code" : "BR0396086U0042",
    "display" : "DICLORIDRATO DE SAPROPTERINA 100 MG COMP GRUPO 1.B"
  },
  {
    "code" : "BR0385423",
    "display" : "CEFACLOR 75 MG/ML SUSPENSÃO ORAL  100 ML"
  },
  {
    "code" : "BR0432367",
    "display" : "HIALURONATO DE SÓDIO 0,2 % SOLUÇÃO OFTÁLMICA 10 ML"
  },
  {
    "code" : "BR0407520U0042",
    "display" : "IVERMECTINA 3MG COMP"
  },
  {
    "code" : "BR0429928",
    "display" : "DOXORRUBICINA, CLORIDRATO 20 MG/ML SOLUÇÃO INJETÁVEL 10 ML"
  },
  {
    "code" : "BR0410008U0130",
    "display" : "MICRONUTRIENTES - SUPLEMENTO DE VITAMINAS E MINERAIS EM PÓ PÓ"
  },
  {
    "code" : "BR0309040U0042",
    "display" : "ÁCIDO URSODESOXICÓLICO 300 MG COMP GRUPO 1.B"
  },
  {
    "code" : "BR0426076",
    "display" : "MULTIVITAMINAS, VITS (A, D3, E, K1, B1, B2, B3, B5, B6, C) SOLUÇÃO INJETÁVEL 10 ML"
  },
  {
    "code" : "BR0394809U0004",
    "display" : "SORO, ANTILONÔMICO 3,5 MG/ML SOLUÇÃO INJETÁVEL 10 ML"
  },
  {
    "code" : "BR0452935U0110",
    "display" : "EXTRATO MEDICINAL, ÓLEO DE CANABIDIOL 200 MG/ML SOLUÇÃO ORAL 60 ML ELENCO ESTADUAL"
  },
  {
    "code" : "BR0297697",
    "display" : "ARTICAÍNA ASSOCIADA COM EPINEFRINA 4 % AMP 1,8 ML"
  },
  {
    "code" : "BR0425510U0087",
    "display" : "ÁCIDOS GRAXOS ESSENCIAIS, COMPOSTO DOS ÁCIDOS CAPRÍLICO, CÁPRICO, LÁURICO, MANTEIGA DE KARITÉ, ÓLEO DE OLIVA, GLICERINA, EXTRATO DE COCO LOÇÃO 240ML"
  },
  {
    "code" : "BR0400983",
    "display" : "ZINCO, SULFATO 17,60 MG/ML SOL ORAL (FR) 100 ML"
  },
  {
    "code" : "BR0454932U0288",
    "display" : "EXTRATO MEDICINAL, ÓLEO DE CANABIDIOL, CÂNHAMO DESCARBOXILADO 180  MG/ML SOLUÇÃO EM DOSADOR ORAL 10 ML ELENCO ESTADUAL"
  },
  {
    "code" : "BR0444570U0041",
    "display" : "FUMARATO DE FORMOTEROL DI-HIDRATADO + PROPIONATO DE FLUTICASONA 12 MCG + 250 MCG CÁPSULA"
  },
  {
    "code" : "BR0433847",
    "display" : "CICLOBENZAPRINA, CLORIDRATO + CAFEINA 10 + 60 MG COMPRIMIDO"
  },
  {
    "code" : "BR0435176",
    "display" : "ALGINATO DE SODIO + BICARBONATO DE POTASSIO 100 + 20 MG/ML SOL ORAL (FR) 150 ML"
  },
  {
    "code" : "BR0292380-1",
    "display" : "TRAMADOL, CLORIDRATO 100MG/2ML SOL INJ (AMP) 2ML"
  },
  {
    "code" : "BR0426103",
    "display" : "MENTHA X PIPERITA L. (HORTELÃ) 750 MG CÁPSULA"
  },
  {
    "code" : "BR0452476",
    "display" : "GEL A BASE DE SULFATO DE COBRE, DERIVADOS DE COCO E GLICERINA GEL 500 ML"
  },
  {
    "code" : "BR0441769",
    "display" : "SITAGLIPTINA, FOSFATO + METFORMINA, CLORIDRATO 100 + 1000 MG COMPRIMIDO"
  },
  {
    "code" : "BR0453817U0062",
    "display" : "EXTRATO MEDICINAL, ÓLEO DE CANABIDIOL 60 MG/ML SOLUÇÃO ORAL 100 ML ELENCO ESTADUAL"
  },
  {
    "code" : "BR0451170U0288",
    "display" : "EXTRATO MEDICINAL, ÓLEO DE CANABIDIOL 170 MG/ML SOLUÇÃO ORAL 10 ML ELENCO ESTADUAL"
  },
  {
    "code" : "BR0454126U0124",
    "display" : "EXTRATO MEDICINAL, ÓLEO DE CANABIDIOL 500 MG CREME  60 G ELENCO ESTADUAL"
  },
  {
    "code" : "BR0443209",
    "display" : "SOMATROPINA 5,83 MG/ML SOLUÇÃO INJETÁVEL 1,03 ML"
  },
  {
    "code" : "BR0387488U0042",
    "display" : "ISONIAZIDA 300 MG COMPRIMIDO"
  },
  {
    "code" : "BR0447820U0041",
    "display" : "GLYCINE MAX (ISOFLAVONA DE SOJA) 500 MG CAP"
  },
  {
    "code" : "BR0357118",
    "display" : "BETAGALSIDASE 5 MG PÓ LIOFILIZADO PARA SOLUÇÃO INJETÁVEL ELENCO ESTADUAL"
  },
  {
    "code" : "BR0437109",
    "display" : "VITAMINAS DO COMPLEXO B, B1, B2, B3, B5, B6, B12 COMPRIMIDO"
  },
  {
    "code" : "BR0442230",
    "display" : "VORTIOXETINA, BROMIDATO 5 MG COMP REV"
  },
  {
    "code" : "BR0461415",
    "display" : "DEXLANSOPRAZOL 30 MG CAP LIBERAÇÃO CONTROLADA"
  },
  {
    "code" : "BR0461235",
    "display" : "RIFAMPICINA + ISONIAZIDA + PIRAZINAMIDA 75 + 50 + 150 MG COMPRIMIDO DISPERSÍVEL"
  },
  {
    "code" : "BR0434714",
    "display" : "DOBESILATO DE CÁLCIO 500 MG CÁPSULA"
  },
  {
    "code" : "BR0452264U0251",
    "display" : "ÓXIDO DE ZINCO, ASSOCIADO À GELATINA E GLICEROL 25% + 25% + 25% ESPECIALMENTE MANIPULADO PASTA  1000 G"
  },
  {
    "code" : "BR0437283",
    "display" : "LEVOFLOXACINO 750 MG COMPRIMIDO"
  },
  {
    "code" : "BR0268693U0118",
    "display" : "COMPLEXO PROTROMBÍNICO PARCIALMENTE ATIVADO 1000UI INJ (FR)"
  },
  {
    "code" : "BR0440878U0118",
    "display" : "COMPLEXO PROTROMBÍNICO PARCIALMENTE ATIVADO 2500UI INJ (FR)"
  },
  {
    "code" : "BR0305247U0085",
    "display" : "LACTULOSE 667 MG/ML XAROPE  200 ML"
  },
  {
    "code" : "BR0296876",
    "display" : "CARBONATO DE CÁLCIO + COLECALCIFEROL 1500 + 400 MG/ UI COMPRIMIDO"
  },
  {
    "code" : "BR0439252U0106",
    "display" : "NUSINERSENA 2,4 MG/ML SOLUÇÃO INJETÁVEL 5 ML GRUPO 1.A"
  },
  {
    "code" : "BR0274990U0097",
    "display" : "HIDRÓXIDO DE FERRO III 50MG SOL ORAL (FR) 30ML"
  },
  {
    "code" : "BR0451599U0023",
    "display" : "PAPAÍNA 4 % GEL 30 G"
  },
  {
    "code" : "BR0448031",
    "display" : "MIRTAZAPINA 30 MG COMPRIMIDO ORODISPERSÍVEL"
  },
  {
    "code" : "BR0451611",
    "display" : "GLYCINE MAX (ISOFLAVONA DE SOJA) 40 MG CÁPSULA"
  },
  {
    "code" : "BR0452616",
    "display" : "INSULINA, DEGLUDECA ASSOCIADA À LIRAGLUTIDA 100 UI/ML + 3,5  MG/ML SOLUÇÃO INJETÁVEL 3 ML"
  },
  {
    "code" : "BR0429678",
    "display" : "LEVETIRACETAM 1 G COMP REV"
  },
  {
    "code" : "BR0437993",
    "display" : "UMECLIDÍNIO BROMETO + VILANTEROL, TRIFENATATO 62,5 MCG/DOSE + 25 MCG/DOSE MCG/DOSE PÓ PARA INALAÇÃO ORAL"
  },
  {
    "code" : "BR0269460U0042",
    "display" : "ÁCIDO URSODESOXICÓLICO 150 MG COMP GRUPO 1.B"
  },
  {
    "code" : "BR0432911",
    "display" : "DAPAGLIFLOZINA 5 MG COMPRIMIDO"
  },
  {
    "code" : "BR0341850",
    "display" : "FLUVOXAMINA, MALEATO 50 MG COMPRIMIDO"
  },
  {
    "code" : "BR04349380002",
    "display" : "OLODATEROL, CLORIDRATO 2,5 MCG/DOSE SOLUÇÃO PARA INALAÇÃO 4 ML"
  },
  {
    "code" : "BR0411397U0135",
    "display" : "PALIPERIDONA 525 MG SUSPENSÃO INJETÁVEL"
  },
  {
    "code" : "BR308805-1",
    "display" : "CONCENTRADO DE FATOR IX 500UI MAIOR 50UI ALTA PUREZA INJ (FR)"
  },
  {
    "code" : "BR0268111U0042",
    "display" : "HIDRALAZINA, CLORIDRATO 25 MG COMP"
  },
  {
    "code" : "BR0419964",
    "display" : "DEXCLORFENIRAMINA, MALEATO 10 MG/G CREME  30 G"
  },
  {
    "code" : "BR0455337",
    "display" : "DUPILUMABE 150 MG/ML SOLUÇÃO INJETÁVEL"
  },
  {
    "code" : "BR0438041",
    "display" : "BENZOATO DE ALOGLIPTINA 6,25 MG COMP"
  },
  {
    "code" : "BR0327212U0103",
    "display" : "LUGOL 5 % SOLUÇÃO 500 ML"
  },
  {
    "code" : "BR0308807U0118",
    "display" : "CONCENTRADO DE FATOR VIII 500 UI AE MAIOR 1UI PARA TRATAMENTO DE DOENÇA DE VON WILLEBRAND INJ (FR)"
  },
  {
    "code" : "BR0273902U0097",
    "display" : "ÓLEO DE AMÊNDOAS DOCE SUSPENSÃO TÓPICA 30 ML"
  },
  {
    "code" : "BR0461236",
    "display" : "ISONIAZIDA + RIFAMPICINA 50 + 75 MG COMPRIMIDO DISPERSÍVEL"
  },
  {
    "code" : "BR0431732",
    "display" : "DACLATASVIR 60MG COMP"
  },
  {
    "code" : "BR0268162U0029",
    "display" : "MICONAZOL, NITRATO 2%  CREME VAGINAL  50G"
  },
  {
    "code" : "BR0296120",
    "display" : "OXIBUPROCAÍNA 4 MG/ML SOLUÇÃO OFTÁLMICA 10 ML"
  },
  {
    "code" : "BR0332908",
    "display" : "TERLIPRESSINA 1 MG SOLUÇÃO INJETÁVEL"
  },
  {
    "code" : "BR0359903U0118",
    "display" : "ALFA-ALGLICOSIDASE 50 MG PÓ LIOF INJ (FR-AMP)"
  },
  {
    "code" : "BR0444962",
    "display" : "EXTRATO MEDICINAL, ÓLEO DE CANABIDIOL 21,19 MG/ML SOLUÇÃO ORAL 236 ML ELENCO ESTADUAL"
  },
  {
    "code" : "BR0388714",
    "display" : "PREGABALINA 100 MG CÁPSULA"
  },
  {
    "code" : "BR0427485U0042",
    "display" : "VANDETANIBE 100MG COMP"
  },
  {
    "code" : "BR0489024",
    "display" : "BACILLUS CEREUS 1.000.000 SOLUÇÃO ORAL 5 ML"
  },
  {
    "code" : "BR0270633-1",
    "display" : "DIPIRONA + ISOMETEPTENO + CAFEÍNA 300 + 50 + 30 MG COMPRIMIDO"
  },
  {
    "code" : "BR0270813U0046",
    "display" : "CIANOCOBALAMINA + TIAMINA + PIRIDOXINA 5MG + 100 MG + 100 MG DRÁGEA"
  },
  {
    "code" : "BR0437870",
    "display" : "FUMARATO DE DIMETILA 240 MG CAP DE LIB RETARD"
  },
  {
    "code" : "BR0451589",
    "display" : "FERRO QUELATO GLICINATO 60 MG CÁPSULA"
  },
  {
    "code" : "BR0292408U0005",
    "display" : "SAL SÓDICO DE AZUL PATENTE V 25MG/ML AMP 1ML"
  },
  {
    "code" : "BR0396604",
    "display" : "BIPERIDENO, CLORIDRATO 5 MG/ML AMP 1 ML"
  },
  {
    "code" : "BR0444167U0120",
    "display" : "FLURBIPROFENO 8,75 MG PASTILHA"
  },
  {
    "code" : "BR0270929U0042",
    "display" : "PARACETAMOL, ASSOCIADO AO DIMETINDENO,HIDROXIETIL RUTOSÍDEOS, ÁCIDO ASCÓRBICO E FENILEFRINA 500 MG + 0,5 MG + 15 MG + 40 MG + 2 MG COMP"
  },
  {
    "code" : "BR0270612U0162",
    "display" : "BENZILPENICILINA BENZATINA 1.200.000 UI SUSPENSÃO INJETÁVEL 4 ML"
  },
  {
    "code" : "BR0449569U0042",
    "display" : "SOFOSBUVIR + VELPATASVIR 400 + 100 MG COMPRIMIDO GRUPO 1.A"
  },
  {
    "code" : "BR0433685",
    "display" : "RUXOLITINIBE 20MG COMPRIMIDO"
  },
  {
    "code" : "BR0442925U0042",
    "display" : "levonorgestrel + etinilestradiol + cloridrato de piridoxina 0,05+0,03+10/0,075+0,04+10/0,125+0,03,+10/10MG COMP"
  },
  {
    "code" : "BR0438655",
    "display" : "ZOLPIDEM, HEMITARTARATO 12,5 MG COMP"
  },
  {
    "code" : "BR0271036U0118",
    "display" : "DOXICICLINA 100 MG PÓ PARA SOLUÇÃO INJETÁVEL"
  },
  {
    "code" : "BR0271128",
    "display" : "BISOPROLOL, FUMARATO + HIDROCLOROTIAZIDA 2,5 + 6,25 MG COMPRIMIDO"
  },
  {
    "code" : "BR0290058U0118",
    "display" : "ADALIMUMABE 40 MG/ML SOL INJ (FR-AMP) GRUPO 1.A"
  },
  {
    "code" : "BR0270622U0075",
    "display" : "ESCOPOLAMINA, BUTILBROMETO + DIPIRONA SÓDICA 6,67 + 333,4 MG/ML SOLUÇÃO ORAL 15 ML"
  },
  {
    "code" : "BR0436601",
    "display" : "FELODIPINO, METOPROLOL 200 + 50 MG MG COMPRIMIDO LIBERAÇÃO PROLONGADA COMP"
  },
  {
    "code" : "BR0451687U0582",
    "display" : "EXTRATO MEDICINAL, ÓLEO DE CANABIDIOL, CÂNHAMO DESCARBOXILADO E FILTRADO 8,47 MG/ML SOLUÇÃO 118 ML ELENCO ESTADUAL"
  },
  {
    "code" : "BR0340758",
    "display" : "DIPIRONA + CAFEINA 500 + 65 MG COMPRIMIDO"
  },
  {
    "code" : "BR0311799",
    "display" : "RACECADOTRILA 30 MG PÓ"
  },
  {
    "code" : "BR0439252",
    "display" : "NUSINERSENA 2,4 MG/ML SOLUÇÃO INJETÁVEL 5 ML"
  },
  {
    "code" : "BR0458280",
    "display" : "OLAPARIBE 150 MG CÁPSULA"
  },
  {
    "code" : "BR0451161U0041",
    "display" : "EXTRATO MEDICINAL, ÓLEO DE CANABIDIOL , CÂNHAMO, CÚRCUMA E SALGUEIRO, 25 MG MG CÁPSULA  ELENCO ESTADUAL"
  },
  {
    "code" : "BR0271645U0075",
    "display" : "OXIMETAZOLINA, CLORIDRATO 0,5 MG/ML SOLUÇÃO NASAL 15 ML"
  },
  {
    "code" : "BR0466430",
    "display" : "PIRAZINAMIDA 150 MG COMPRIMIDO DISPERSÍVEL"
  },
  {
    "code" : "BR0400476U0005",
    "display" : "PARICALCITOL 5 MCG/ML SOL INJ (AMP) 1 ML GRUPO 1.A"
  },
  {
    "code" : "BR0267328U0068",
    "display" : "FOSFATO DE SÓDIO MONOBÁSICO + FOSFATO DE SÓDIO DIBÁSICO 160 + 60 MG/ML ENEMA  125 ML"
  },
  {
    "code" : "BR0439609",
    "display" : "GLICOPIRRÔNIO 50MCG CÁPSULA  COM INALADOR ELENCO ESTADUAL"
  },
  {
    "code" : "BR0398703U0005",
    "display" : "MEDROXIPROGESTERONA, ACETATO 50 MG/ML SUSPENSÃO INJETÁVEL 1 ML"
  },
  {
    "code" : "BR0449556U0042",
    "display" : "GLECAPREVIR + PIBRENTASVIR 100 + 40 MG COMPRIMIDO GRUPO 1.A"
  },
  {
    "code" : "BR0322441U0041",
    "display" : "GLICOSAMINA, SULFATO 750 MG CÁPSULA"
  },
  {
    "code" : "BR0333569",
    "display" : "TACROLIMO 1MG/G BISNAGA"
  },
  {
    "code" : "BR0272567U0086",
    "display" : "RETINOL + COLECALCIFEROL 5500 UI/ML + 2200 UI/ML  SOL ORAL (FR)"
  },
  {
    "code" : "BR0451598U0023",
    "display" : "PAPAÍNA 3 % GEL 30 G"
  },
  {
    "code" : "BR0396112",
    "display" : "NORELGESTROMINA, ASSOCIADA AO ETINILESTRADIOL 6 MG + 0,6 MG ADESIVO TRANSDÉRMICO"
  },
  {
    "code" : "BR0445954",
    "display" : "ALOGLIPTINA + PIOGLITAZONA 25 + 30 MG COMP REV"
  },
  {
    "code" : "BR0447820",
    "display" : "GLYCINE MAX (ISOFLAVONA DE SOJA) 450 MG COMP REV"
  },
  {
    "code" : "BR0273902U0086",
    "display" : "ÓLEO DE AMÊNDOAS DOCE SOLUÇÃO TÓPICA 20 ML"
  },
  {
    "code" : "BR0433023U0042",
    "display" : "CALCIO, CITRATO + COLECALCIFEROL 500 MG + 200 UI COMPRIMIDO"
  },
  {
    "code" : "BR0352414",
    "display" : "MESALAZINA 500 MG SUPOSITÓRIO"
  },
  {
    "code" : "BR0422123U0042",
    "display" : "REGORAFENIBE 40 MG COMPRIMIDO"
  },
  {
    "code" : "BR0292345U0062",
    "display" : "SULFATO FERROSO (25MG/ML DE FERRO ELEMENTAR) 125 MG/ML SOLUÇÃO ORAL 100 ML"
  },
  {
    "code" : "BR0268286U0017",
    "display" : "MICONAZOL, NITRATO 2 % CREME  15 G"
  },
  {
    "code" : "BR0436778U0162",
    "display" : "NIVOLUMABE 10 MG/ML SOLUÇÃO INJETÁVEL 4 ML"
  },
  {
    "code" : "BR0429215U0118",
    "display" : "CONCENTRADO DE FATOR VIII 250UI CONTENDO FATOR DE VON WILLEBRAND PARA IMUNOTOLERÂNCIA INJ (FR)"
  },
  {
    "code" : "BR0428258U0086",
    "display" : "PODOFILINA 10 % SOLUÇÃO 20 ML"
  },
  {
    "code" : "BR0440056",
    "display" : "AFATINIBE DIMALEATO 40 MG COMPRIMIDO"
  },
  {
    "code" : "BR0450561",
    "display" : "ÁCIDO ASCÓRBICO, ASPARTATO DE ARGININA 1G + 1 G COMPRIMIDO"
  },
  {
    "code" : "BR0274186U0042",
    "display" : "ESOMEPRAZOL, MAGNÉSIO 20 MG COMPRIMIDO"
  },
  {
    "code" : "BR0269073U0063",
    "display" : "ÁCIDO TRICLOROACÉTICO 80% SOLUÇÃO 10ML"
  },
  {
    "code" : "BR0268375U0017",
    "display" : "ACICLOVIR 5 % CREME  15 G"
  },
  {
    "code" : "BR0354515",
    "display" : "ESOMEPRAZOL SODICO 40 MG SOLUÇÃO INJETÁVEL"
  },
  {
    "code" : "BR04389570036",
    "display" : "METFORMINA, CLORIDRATO + ALOGLIPTINA 850 + 12,5 MG COMP"
  },
  {
    "code" : "BR0394662-1",
    "display" : "NEOMICINA 5 MG/G POMADA 10G"
  },
  {
    "code" : "BR0396568",
    "display" : "MICAFUNGINA 100 MG PÓ LIOF INJ (FR-AMP)"
  },
  {
    "code" : "BR0321234",
    "display" : "DEXAMETASONA + NEOMICINA + POLIMIXINA B 1MG + 3,5 MG + 6000 UI SUSPENSÃO OFTÁLMICA 5 ML"
  },
  {
    "code" : "BR0436718U0041",
    "display" : "COLECALCIFEROL (VITAMINA D3) 15.000 UI CÁPSULA"
  },
  {
    "code" : "BR0267778-1",
    "display" : "PARACETAMOL 500MG PÓ PARA SOLUÇÃO 10ML"
  },
  {
    "code" : "BR0450888",
    "display" : "OCRELIZUMABE 300/10 MG/ML SOLUÇÃO INJETÁVEL 10 ML"
  },
  {
    "code" : "BR0427719U0042",
    "display" : "PRUCALOPRIDA, SUCCINATO 1 MG COMPRIMIDO"
  },
  {
    "code" : "BR0269069U0106",
    "display" : "ÁCIDO TRICLOROACÉTICO 90 % SOLUÇÃO 5 ML"
  },
  {
    "code" : "BR0444809",
    "display" : "TRAMETINIBE 0,5 MG COMPRIMIDO"
  },
  {
    "code" : "BR0435539",
    "display" : "LACOSAMIDA 50 MG COMP ELENCO ESTADUAL"
  },
  {
    "code" : "BR0443165U0042",
    "display" : "HARPAGOPHYTUM PROCUBENS (GARRA DO DIABO) 450MG COMP"
  },
  {
    "code" : "BR0277519U0042",
    "display" : "ÁCIDO URSODESOXICÓLICO 50 MG COMP GRUPO 1.B"
  },
  {
    "code" : "BR0399614",
    "display" : "PREDNISOLONA 0,12% SOL INJ (FR) 10 MG/ML"
  },
  {
    "code" : "BR0451597U0023",
    "display" : "ALOE VERA (BABOSA) 10 % GEL 30 G"
  },
  {
    "code" : "BR0446772",
    "display" : "PALBOCICLIBE 125 MG CÁPSULA DURA DE LIBERAÇÃO PROLONGADA"
  },
  {
    "code" : "BR0272898",
    "display" : "BETAMETASONA, DEXCLORFE NIRAMINA MALEATO 2MG 0,25MG  COMP"
  },
  {
    "code" : "BR0438093U0086",
    "display" : "COLECALCIFEROL 200 UI SOL ORAL (FR) 20 ML"
  },
  {
    "code" : "BR0301906U0103",
    "display" : "FLUORETO DE SODIO 0,05 % SOLUÇÃO 500 ML"
  },
  {
    "code" : "BR0292205U0062",
    "display" : "ISONIAZIDA 20 MG/ML SUSPENSÃO ORAL  100 ML"
  },
  {
    "code" : "BR0457885",
    "display" : "MEPOLIZUMABE 100 MG/ML SOLUÇÃO INJETÁVEL"
  },
  {
    "code" : "BR0442877",
    "display" : "OLAPARIBE 50 MG CÁPSULA"
  },
  {
    "code" : "BR0445952",
    "display" : "ALOGLIPTINA + PIOGLITAZONA 25 + 15 MG COMP REV"
  },
  {
    "code" : "BR0322441U0046",
    "display" : "GLICOSAMINA, SULFATO 1 G CÁPSULA"
  },
  {
    "code" : "BR0384830U0042",
    "display" : "ÁCIDO TRANEXÂMICO 500 MG COMPRIMIDO"
  },
  {
    "code" : "BR308802-1",
    "display" : "CONCENTRADO DE FATOR VIII 500 UI AE MAIOR 100 UI/MG INJ (FR)"
  },
  {
    "code" : "BR0435700U0032",
    "display" : "OMBITASVIR/VERUPREVIR/RITONAVIR + DASABUVIR 12,5/75/50 MG + 250 MG CARTELA (04 COMP REV) GRUPO 1.A"
  },
  {
    "code" : "BR0269388U0006",
    "display" : "DEXAMETASONA  4 MG/ML SOL INJ (AMP) 2,5ML"
  },
  {
    "code" : "BR0419942U0118",
    "display" : "MEROPENEM 2 G PÓ LIOF INJ (FR-AMP)"
  },
  {
    "code" : "BR0271913U0041",
    "display" : "RETINOL, PALMITATO 50.000 UI CÁPSULA"
  },
  {
    "code" : "BR038566",
    "display" : "CLOREXIDINA, DIGLUCONATO 2% GEL 2 X 3G"
  },
  {
    "code" : "BR0451582",
    "display" : "DEFLAZACORTE 12 MG CÁPSULA"
  },
  {
    "code" : "BR0436718U0063",
    "display" : "COLECALCIFEROL 14.000 UI/ML SOLUÇÃO ORAL 10 ML"
  },
  {
    "code" : "BR0274468",
    "display" : "HIALURONATO DE SÓDIO 2 % SOLUÇÃO INJETÁVEL 3 ML"
  },
  {
    "code" : "BR0457206",
    "display" : "APALUTAMIDA 60 MG COMP REV"
  },
  {
    "code" : "BR0438039",
    "display" : "BENZOATO DE ALOGLIPTINA 12,5 MG COMP"
  },
  {
    "code" : "BR0398178-1",
    "display" : "COLECALCIFEROL 200 UI/ML SOL ORAL (FR) 10 ML"
  },
  {
    "code" : "BR0443375U0041",
    "display" : "PASSIFLORA INCARNATA 500MG CÁPSULA"
  },
  {
    "code" : "BR0437080U0042",
    "display" : "RIOCIGUATE 2,5 MG COMPRIMIDO"
  },
  {
    "code" : "BR0452496",
    "display" : "DABRAFENIBE 75 MG CÁPSULA"
  },
  {
    "code" : "BR0288275-2",
    "display" : "TINIDAZOL + MICONAZOL, NITRATO 30 MG/G 20MG/G BISNAGA 40G"
  },
  {
    "code" : "BR0390804",
    "display" : "POLIHEXANIDA, ASSOCIADA À UNDECILAMINOPROPIL BETAÍNA 0,1% + 0,1% SOLUÇÃO 350ML"
  },
  {
    "code" : "BR0434125-1",
    "display" : "COLECALCIFEROL 500 UI SOLUÇÃO ORAL 20 ML"
  },
  {
    "code" : "BR0442717",
    "display" : "LIDOCAÍNA, FLUOCORTOLONA 1MG/G + 2MG/G CREME"
  },
  {
    "code" : "BR0448319U0042",
    "display" : "NIFURTIMOX 120 MG COMP ELENCO ESTADUAL"
  },
  {
    "code" : "BR0420857U0085",
    "display" : "HIDROCORTISONA, ACETATO 1  MG/ML SOLUÇÃO ORAL 200 ML"
  },
  {
    "code" : "BR0445431U0042",
    "display" : "VALSARTANA, ASSOCIADO AO SACUBITRIL  26 MG + 24 MG COMP"
  },
  {
    "code" : "BR0348002U0060",
    "display" : "ÁCIDOS GRAXOS ESSENCIAIS SOLUÇÃO 1000 ML"
  },
  {
    "code" : "BR0432448",
    "display" : "METFORMINA CLORIDRATO , LINAGLIPTINA 500 MG + 2,5 MG COMP"
  },
  {
    "code" : "BR0450511",
    "display" : "CARBONATO DE CÁLCIO + VIT D, A, B6, E 625 MG + 200  UI COMPRIMIDO"
  },
  {
    "code" : "BR0445432",
    "display" : "VALSARTANA, ASSOCIADO AO SACUBITRIL 103 MG + 97 MG COMPRIMIDO"
  },
  {
    "code" : "BR0438280",
    "display" : "LEVOTIROXINA SÓDICA 62,5 MCG COMP"
  },
  {
    "code" : "BR0269469U0007",
    "display" : "ROPIVACAÍNA, CLORIDRATO 2MG/ML  AMP 20ML"
  },
  {
    "code" : "BR0437991",
    "display" : "MELÃO DE SÃO CAETANO 16% 16 % SUPOSITÓRIO"
  },
  {
    "code" : "BR0443164U0042",
    "display" : "GLYCINE MAX (ISOFLAVONA DE SOJA)  60MG COMP"
  },
  {
    "code" : "BR0450166",
    "display" : "LURASIDONA 40 MG COMP REV"
  },
  {
    "code" : "BR0433548",
    "display" : "VALSARTANA + HIDROCLOROTIAZIDA + ANLODIPINO 320 + 25 +10 MG COMPRIMIDO"
  },
  {
    "code" : "BR0440199",
    "display" : "ESCINA ,SALICILATO DE DIETILAMÔNIO 10MG/G + 50MG/G BISNAGA 30G"
  },
  {
    "code" : "BR0449425",
    "display" : "BENZOATO DE SÓDIO, CMC, SORBITOL, GLICEROL E XAROPE SIMPLES 2% + 2,5% + 10% + 10% + 10 % SPRAY ORAL FORMULA ESPECIALMENTE MANIPULADA 100 ML"
  },
  {
    "code" : "BR0340758U0042",
    "display" : "DIPIRONA + CLORFENAMINA MALEATO + CAFEÍNA 250 MG + 2 MG E 250 MG + 30 MG COMP REV"
  },
  {
    "code" : "BR0272831-1",
    "display" : "QUETIAPINA, HEMIFUMARATO 25 MG COMPRIMIDO"
  },
  {
    "code" : "BR0282299U0041",
    "display" : "SULPIRIDA 50 MG CÁPSULA"
  },
  {
    "code" : "BR0270909",
    "display" : "PARACETAMOL + CAFEINA 500 MG + 65 MG COMPRIMIDO"
  },
  {
    "code" : "BR0394681U0118",
    "display" : "CONCENTRADO DE FIBRINOGÊNIO -  FATOR I 1 G PÓ LIOFILIZADO PARA SOLUÇÃO INJETÁVEL"
  },
  {
    "code" : "BR0379725U0086",
    "display" : "ÁCIDO TRICLOROACÉTICO 70% SOLUÇÃO 20ML"
  },
  {
    "code" : "BR0452266U0023",
    "display" : "SALICILATO DE METILA, ASSOCIADO À CÂNFORA, MENTOL E ARNICA 2% + 5% + 2% + 10% ESPECIALMENTE MANIPULADO GEL 30 G"
  },
  {
    "code" : "BR0436256",
    "display" : "BISOPROLOL, FUMARATO + HIDROCLOROTIAZIDA 5 MG + 12,5  MG COMPRIMIDO"
  },
  {
    "code" : "BR0268112U0042",
    "display" : "HIDRALAZINA, CLORIDRATO 50 MG COMPRIMIDO"
  },
  {
    "code" : "BR0437082U0042",
    "display" : "RIOCIGUATE 2,0 MG COMPRIMIDO"
  },
  {
    "code" : "BR0302442U0041",
    "display" : "DULOXETINA, CLORIDRATO 30 MG CAP DE LIB RETARD"
  },
  {
    "code" : "BR0272089-8",
    "display" : "SULFADIAZINA DE PRATA 1% CREME VAGINAL  30G"
  },
  {
    "code" : "BR0354633U0106",
    "display" : "OLOPATADINA 2 MG/ML SOLUÇÃO OFTÁLMICA 5 ML"
  },
  {
    "code" : "BR0452409",
    "display" : "MALEATO DE DEXCLORFENIRAMINA + SULFATO DE PSEUDOEFEDRINA + GUAIFENESINA 0,4 + 4 + 20 MG/ML XAROPE  120 ML"
  },
  {
    "code" : "BR0437284",
    "display" : "LEVETIRACETAM 750 MG COMP ELENCO ESTADUAL"
  },
  {
    "code" : "BR0452302U0023",
    "display" : "EXTRATO MEDICINAL, ÓLEO DE CANABIDIOL 50 MG/ML SOLUÇÃO ORAL 120 ML ELENCO ESTADUAL"
  },
  {
    "code" : "BR0396751",
    "display" : "DICLOFENACO SÓDICO 100MG COMP"
  },
  {
    "code" : "BR0272484",
    "display" : "ZUCLOPENTIXOL, ACETATO 50 MG/ML SOLUÇÃO INJETÁVEL 1 ML"
  },
  {
    "code" : "BR0443476U0041",
    "display" : "HIDROSMINA 200MG CÁPSULA"
  },
  {
    "code" : "BR0317787",
    "display" : "SALICILATO DE METILA, ASSOCIADA À CÂNFORA E MENTOL 0,0333 ML/ML + 0,0333 G/ML + 0,0833 G/ML AEROSSOL 120 ML"
  },
  {
    "code" : "BR0435625",
    "display" : "LACOSAMIDA 200 MG COMP REV"
  },
  {
    "code" : "BR0440604",
    "display" : "MULTIVITAMINAS (A, B1, B2, B6, B12, C, D, E)ASSOCIADAS COM SAIS MINERAIS (ZINCO, COBRE E ACIDO FOLICO) COMPRIMIDO"
  },
  {
    "code" : "BR0393886U0118",
    "display" : "ENFUVIRTIDA 90MG/ML PO-LIOFILO P/ INJETÁVEL PÓ LIOF INJ (FR-AMP)"
  },
  {
    "code" : "BR0338591U0030",
    "display" : "METRONIDAZOL 100MG/G GEL 60MG"
  },
  {
    "code" : "BR0446631",
    "display" : "ISONIAZIDA + RIFAMPICINA 150 + 300 MG COMPRIMIDO"
  },
  {
    "code" : "BR0270114-3",
    "display" : "CETAMINA, CLORIDRATO DE  50 MG/ML INJ (FR) 50 ML"
  },
  {
    "code" : "BR0368499",
    "display" : "VITAMINAS DO COMPLEXO B (B1,B2,B3,B5,B6)  SOLUÇÃO ORAL 100  ML"
  },
  {
    "code" : "BR0442701U0118",
    "display" : "CEFTRIAXONA SÓDICA 1 G PÓ PARA SOLUÇÃO INJETÁVEL"
  },
  {
    "code" : "BR0399097",
    "display" : "BENZOATO DE SÓDIO 200 MG/ML SOLUÇÃO ORAL 45 ML"
  },
  {
    "code" : "BR0273398",
    "display" : "ISOSSORBIDA, DINITRATO 40 MG COMP"
  },
  {
    "code" : "BR0268692",
    "display" : "COMPLEXO PROTROMBÍNICO PARCIALMENTE ATIVADO 500UI 500 UI PÓ LIOFILIZADO PARA SOLUÇÃO INJETÁVEL"
  },
  {
    "code" : "BR0399066U0062",
    "display" : "CYNARA SCOLYMUS  (ALCACHOFRA) 5 % SOLUÇÃO 100 ML"
  },
  {
    "code" : "BR0442724",
    "display" : "MESILATO DE OSIMERTINIBE 40 MG COMP REV"
  },
  {
    "code" : "BR0437839",
    "display" : "DULAGLUTIDA 3MG/ML INJ (FR) 0,5ML"
  },
  {
    "code" : "BR0450073",
    "display" : "DEXLANSOPRAZOL 60 MG CÁPSULA DURA DE LIBERAÇÃO PROLONGADA"
  },
  {
    "code" : "BR0272381U0041",
    "display" : "VENLAFAXINA, CLORIDRATO 37,5 MG CAP DE LIB PROL"
  },
  {
    "code" : "BR0271052U0121",
    "display" : "BICARBONATO DE SÓDIO PÓ 100 G"
  },
  {
    "code" : "BR0267541U0007",
    "display" : "GLICOSE 50% AMP 20ML"
  },
  {
    "code" : "BR0340482",
    "display" : "Iodopovidona (pvpi) 2,5 % SOLUÇÃO OFTÁLMICA 5 ML"
  },
  {
    "code" : "BR0437402",
    "display" : "CALCIO, CITRATO + COLECALCIFEROL 400 + 100 MG TABLETE"
  },
  {
    "code" : "BR0442723U0042",
    "display" : "MESILATO DE OSIMERTINIBE 80 MG COMP REV"
  },
  {
    "code" : "BR0446467U0229",
    "display" : "PALIVIZUMABE 100 MG/ML SOL INJ (FR-AMP) 0,5 ML"
  },
  {
    "code" : "BR0439098",
    "display" : "DONEPEZILA, CLORIDRATO + MEMANTINA, CLORIDRATO 10 + 20 MG COMP REV"
  },
  {
    "code" : "BR0404656",
    "display" : "AMBRISENTANA 10MG COMP"
  },
  {
    "code" : "BR0429216U0118",
    "display" : "CONCENTRADO DE FATOR VIII 500UI CONTENDO FATOR DE VON WILLEBRAND PARA IMUNOTOLERÂNCIA INJ (FR)"
  },
  {
    "code" : "BR0442113",
    "display" : "SERENOA REPENS 160G160MG  CÁPSULA"
  },
  {
    "code" : "BR0387359U0023",
    "display" : "PAPAÍNA 2 % GEL 30 G"
  },
  {
    "code" : "BR0440071",
    "display" : "ALIROCUMABE 75MG/ML SOLUÇÃO INJETÁVEL"
  },
  {
    "code" : "BR0420857U0062",
    "display" : "HIDROCORTISONA, ACETATO 1MG/ML SOL ORAL (FR) 100ML"
  },
  {
    "code" : "BR0438741",
    "display" : "RUXOLITINIBE 15 MG COMPRIMIDO"
  },
  {
    "code" : "BR0451575",
    "display" : "ÁCIDO ASCÓRBICO + PARACETAMOL + CAFEÍNA 240MG + 250 MG + 15  MG CÁPSULA"
  },
  {
    "code" : "BR0447888",
    "display" : "MULTIVITAMINAS E MINERAIS:  VITAMINAS: B2, C, E, MINERAIS: COBRE, SELÊNIO, ZINCO COM BETACAROTENO                                             300 MG+100 UI+10.000 UI+25 MG+2 MG+50 MG+0,1 MG COMP"
  },
  {
    "code" : "BR0399160",
    "display" : "OXOMEMAZINA, CLORIDRATO + IODETO DE POTÁSSIO + BENZOATO DE SÓDIO + GUAIFENESINA 0,4 + 20  + 4 + 6 MG/ML XAROPE  120 ML"
  },
  {
    "code" : "BR0388865",
    "display" : "ALENTUZUMABE 10MG/ML AMP 1,2ML"
  },
  {
    "code" : "BR0365246",
    "display" : "ALOE VERA (BABOSA) 10 % CREME"
  },
  {
    "code" : "BR0362058U0347",
    "display" : "RIVASTIGMINA 18 MG ADESIVO TRANSDÉRMICO GRUPO 1.A"
  },
  {
    "code" : "BR0453062",
    "display" : "CITALOPRAM 10 MG CÁPSULA  FÓRMULA ESPECIALMENTE MANIPULADA"
  },
  {
    "code" : "BR0410019U0042",
    "display" : "ELTROMBOPAGUE 25 MG COMP REV GRUPO 1.B"
  },
  {
    "code" : "BR0346580U0118",
    "display" : "CONCENTRADO DE FATOR XIII 250 UI + DILUENTE INJ (FR)"
  },
  {
    "code" : "BR0297697.1",
    "display" : "LIDOCAÍNA, CLORIDRATO + EPINEFRINA 4% + 1/100.000 AMP"
  },
  {
    "code" : "BR0308736U0017",
    "display" : "CETOCONAZOL 2 % CREME  15 G"
  },
  {
    "code" : "BR0400982U0062",
    "display" : "ZINCO, SULFATO 2,5 MG/ML SOLUÇÃO ORAL 100 ML"
  },
  {
    "code" : "BR0451610",
    "display" : "HYPERICUM PERFORATUM L. 150 MG CÁPSULA"
  },
  {
    "code" : "BR0273717U0027",
    "display" : "FENTICONAZOL, NITRATO 2% CREM (BIS) 40G"
  },
  {
    "code" : "BR0432450U0042",
    "display" : "METFORMINA CLORIDRATO , LINAGLIPTINA 850 MG + 2,5 MG COMP"
  },
  {
    "code" : "BR0448649U0041",
    "display" : "NILOTINIBE 150 MG CÁPSULA"
  },
  {
    "code" : "BR0458670",
    "display" : "INSULINA, GLARGINA ASSOCIADA À LIXISENATIDA 100 UI/ML + 33 MCG/ML SOLUÇÃO INJETÁVEL 3 ML"
  },
  {
    "code" : "BR0448828",
    "display" : "CICLOPIROX OLAMINA, ASSOCIADO AO ZINCO 1,5% + 1 % XAMPU"
  },
  {
    "code" : "BR0292399U0297",
    "display" : "FITOMENADIONA 10 MG/ML SOLUÇÃO INJETÁVEL 0,2 ML IM"
  },
  {
    "code" : "BR0438956U0041",
    "display" : "EXTRATO MEDICINAL, ÓLEO DE CANABIDIOL 25 MG CÁPSULA  ELENCO ESTADUAL"
  },
  {
    "code" : "BR0409005",
    "display" : "ENROFLOXACINA 10 % INJ (FR) 10 ML"
  },
  {
    "code" : "BR0437078",
    "display" : "EMPAGLIFLOZINA MPAGLIFLOZINA 10MG COMP"
  },
  {
    "code" : "BR0330113U0034",
    "display" : "GANCICLOVIR SÓDICO 1 MG/ML SOLUÇÃO INJETÁVEL 100 ML"
  },
  {
    "code" : "BR0292242",
    "display" : "MESALAZINA 3 G ENEMA  100 ML ELENCO ESTADUAL"
  },
  {
    "code" : "BR0268693",
    "display" : "COMPLEXO PROTROMBÍNICO PARCIALMENTE ATIVADO 500UI 1.000 UI PÓ LIOFILIZADO PARA SOLUÇÃO INJETÁVEL"
  },
  {
    "code" : "BR0269073-4",
    "display" : "ÁCIDO TRICLOROACÉTICO  80% SOLUÇÃO 1L"
  },
  {
    "code" : "BR0441461U0086",
    "display" : "DARATUMUMABE 20 MG/ML SOLUÇÃO INJETÁVEL 20 ML"
  },
  {
    "code" : "BR0407498",
    "display" : "ACEPROMAZINA 1 % INJ (FR) 20 ML"
  },
  {
    "code" : "BR0430630U0042",
    "display" : "TERIFLUNOMIDA 14 MG COMP GRUPO 1.A"
  },
  {
    "code" : "BR0450164",
    "display" : "MELATONINA ESPECIALMENTE MANIPULADO 800 MCG/ML XAROPE  150 ML"
  },
  {
    "code" : "BR0425365U0063",
    "display" : "MULTIVITAMINAS (A, C, D, E, COMPLEXO B) SOL ORAL (FR) 10 ML"
  },
  {
    "code" : "BR0464309",
    "display" : "ÓXIDO DE ZINCO, ASSOCIADO À CÂNFORA E CLORETO DE BENZALCÔNIO 200 MG/G + 50MG/G + 5 MG/G POMADA 30 G"
  },
  {
    "code" : "BR0268944U0164",
    "display" : "SELANTE DE FIBRINA 0,5ML INJ (FR)"
  },
  {
    "code" : "BR0443280U0042",
    "display" : "MAYTENUS ILICIFOLIA (ESPINHEIRA SANTA) 350MG COMP"
  },
  {
    "code" : "BR02844600003",
    "display" : "CLOBETASOL, PROPIONATO 0,05 % SOLUÇÃO TÓPICA 59 ML"
  },
  {
    "code" : "BR0435393",
    "display" : "TESTOSTERONA 20MG/ML  INJ (FR) 110ML"
  },
  {
    "code" : "BR0437970",
    "display" : "ROTIGOTINA 9MG ADESIVO TRANSDÉRMICO"
  },
  {
    "code" : "BR0437990",
    "display" : "PASSIFLORA INCARNATA 182,93 MG CÁPSULA"
  },
  {
    "code" : "BR0449650U0062",
    "display" : "EXTRATO MEDICINAL, ÓLEO DE CANABIDIOL 50 MG/ML SOLUÇÃO ORAL 100 ML ELENCO ESTADUAL"
  },
  {
    "code" : "BR0451583",
    "display" : "DEFLAZACORTE 20 MG CÁPSULA"
  },
  {
    "code" : "BR0409588",
    "display" : "PRAMIPEXOL, DICLORIDRATO 0,75 MG COMPRIMIDO DE LIBERAÇÃO PROLONGADA"
  },
  {
    "code" : "BR390598",
    "display" : "CONCENTRADO DE FATOR DE COAGULAÇÃO, FATOR VIII RECOMBINANTE 250 UI INJ (FR)"
  },
  {
    "code" : "BR0452484",
    "display" : "ÁCIDOS GRAXOS ESSENCIAIS, COMPOSTO DOS ÁCIDOS CAPRÍLICO, CÁPRICO, LÁURICO, ÓLEO DE GIRASSOL E ÓLEO DE CANOLA , PETROLATO E VITAMINA \"E\" LOÇÃO CREMOSA"
  },
  {
    "code" : "BR0395847",
    "display" : "ALOE VERA (BABOSA) 50 MG/G CREME  30 G"
  },
  {
    "code" : "BR0438993U0269",
    "display" : "UMECLIDÍNIO, BROMETO 62,5 MCG PÓ PARA INALAÇÃO ORAL 30 DOSES ELENCO ESTADUAL"
  },
  {
    "code" : "BR0443167U0042",
    "display" : "MAYTENUS ILICIFOLIA (ESPINHEIRA SANTA) 450MG COMP"
  },
  {
    "code" : "BR0293892U0062",
    "display" : "ACEBROFILINA 10 MG/ML XAROPE  100 ML"
  },
  {
    "code" : "BR0440994",
    "display" : "DONEPEZILA, CLORIDRATO + MEMANTINA, CLORIDRATO 10 + 15 MG COMP REV"
  },
  {
    "code" : "BR0367897U0062",
    "display" : "IMUNOGLOBULINA HUMANA 50 MG/ML SOLUÇÃO INJETÁVEL 100 ML"
  },
  {
    "code" : "BR0260160",
    "display" : "IMUNOGLOBULINA HUMANA 200 UI/ML SOLUÇÃO INJETÁVEL 3 ML"
  },
  {
    "code" : "BR0426098U0005",
    "display" : "CIANOCOBALAMINA 1000 MCG/ML SOLUÇÃO INJETÁVEL 1 ML"
  },
  {
    "code" : "BR0445035",
    "display" : "MAGNÉSIO, SULFATO 20 % SOLUÇÃO ORAL 500 ML"
  },
  {
    "code" : "BR0429217U0118",
    "display" : "CONCENTRADO DE FATOR VIII 1000UI CONTENDO FATOR DE VON WILLEBRAND PARA IMUNOTOLERÂNCIA INJ (FR)"
  },
  {
    "code" : "BR0381073U0041",
    "display" : "MERCAPTAMINA, SAL BITARTARATO 150MG CÁPSULA"
  },
  {
    "code" : "BR0432366U0063",
    "display" : "HIALURONATO DE SÓDIO 1 MG/ML SOLUÇÃO OFTÁLMICA 10 ML"
  },
  {
    "code" : "BR0270126-1",
    "display" : "LEVODOPA + BENSERAZIDA  200 + 50 MG MG COMPRIMIDO LIBERAÇÃO MODIFICADA  COMP"
  },
  {
    "code" : "BR0449181",
    "display" : "MULTIVITAMINAS, VITS: A, B1, B2, B3, B5, B6, B12, C, D, MINERAIS: FE, MN, ZN, ÁCIDO FÓLICO COMPRIMIDO"
  },
  {
    "code" : "BR0272565",
    "display" : "RETINOL, PALMITATO 150.000 UI/ML SOLUÇÃO ORAL"
  },
  {
    "code" : "BR0296486U0042",
    "display" : "METFORMINA, CLORIDRATO 1 G COMPRIMIDO DE LIBERAÇÃO PROLONGADA"
  },
  {
    "code" : "BR0393803U0074",
    "display" : "ÁCIDO FÓLICO 1 MG/ML SOL ORAL (FR) 150 ML"
  },
  {
    "code" : "BR0437006U0063",
    "display" : "EXTRATO MEDICINAL, DELTA-9-TETRAHIDRO CANABINOL (THC) + CANABIDIOL 27 MG/ML + 25 MG/ML SPRAY ORAL 10  ML ELENCO ESTADUAL"
  },
  {
    "code" : "BR0458500",
    "display" : "ALECTINIBE 150 MG CÁPSULA"
  },
  {
    "code" : "BR0292373U0596",
    "display" : "TOXINA BOTULINICA TIPO A  200 UI PÓ LIOFILIZADO PARA SOLUÇÃO INJETÁVEL"
  },
  {
    "code" : "BR0451722",
    "display" : "AMINOÁCIDOS, ARG, GLN, SER, THR, TRP,VIT: B12A 10MG+6MG+4MG+1MG+4MG+48,7 MCG PÓ PARA SOLUÇÃO"
  },
  {
    "code" : "BR0401579U0105",
    "display" : "BROSIMUM GAUDICHAUDII LOÇÃO 50 ML"
  },
  {
    "code" : "BR0437989",
    "display" : "MALEATO DE INDACATEROL + BROMETO DE GLICOPIRRÔNIO 110 MCG + 50 MCG 110 +50 MCG CÁPSULA  ELENCO ESTADUAL"
  },
  {
    "code" : "BR0438223",
    "display" : "PRAZIQUANTEL/PAMOATO DE PIRANTEL/PAMOATO DE OXANTEL INJ (FR) 20 ML"
  },
  {
    "code" : "BR0425365",
    "display" : "MULTIVITAMINAS (A, C, D, E, COMPLEXO B) SOL ORAL (FR) 20 ML"
  },
  {
    "code" : "BR0459805",
    "display" : "EDOXABANA 60 MG COMP REV"
  },
  {
    "code" : "BR0304790U0042",
    "display" : "CINACALCETE 60 MG COMP GRUPO 1.A"
  },
  {
    "code" : "BR043783",
    "display" : "METFORMINA CLORIDRATO ASSOCIADA A DAPAGLIFLOZINA  1000 MG + 10 MG  CÁPSULA"
  },
  {
    "code" : "BR0273221U0041",
    "display" : "MEMANTINA, CLORIDRATO 10 MG CAP LIBERAÇÃO CONTROLADA GRUPO 1.A"
  },
  {
    "code" : "BR0432449U0042",
    "display" : "METFORMINA CLORIDRATO , LINAGLIPTINA 1000MG + 2,5MG COMP"
  },
  {
    "code" : "BR0437160U0062",
    "display" : "CLORETO DE SÓDIO  0,9 % SOLUÇÃO NASAL 100 ML"
  },
  {
    "code" : "BR0401323U0063",
    "display" : "EPINASTINA, CLORIDRATO 0,5 MG/ML SOLUÇÃO OFTÁLMICA 10 ML"
  },
  {
    "code" : "BR0449556",
    "display" : "GLECAPREVIR + PIBRENTASVIR 100 + 40 MG COMPRIMIDO"
  },
  {
    "code" : "BR0434251",
    "display" : "LEDIPASVIR + SOFOSBUVIR 90 + 400 MG COMPRIMIDO"
  },
  {
    "code" : "BR0439142U0042",
    "display" : "TENOFOVIR, ENTRICITABINA,   300 MG + 200 MG  COMP"
  },
  {
    "code" : "BR0342616-1",
    "display" : "LIDOCAÍNA, CLORIDRATO + EPINEFRINA  20MG/ML + 0,005MG/ML  AMP 1 ML"
  },
  {
    "code" : "BR0274437U0062",
    "display" : "FLUCONAZOL 10 MG/ML SUSPENSÃO INJETÁVEL 100 ML"
  },
  {
    "code" : "BR0444963U0582",
    "display" : "EXTRATO MEDICINAL, ÓLEO DE CANABIDIOL 8,47 MG/ML SOLUÇÃO 118 ML ELENCO ESTADUAL"
  },
  {
    "code" : "BR0436461U0118",
    "display" : "VEDOLIZUMABE 300MG PÓ LIOF INJ (FR-AMP)"
  },
  {
    "code" : "BR0270986U0041",
    "display" : "CLORFENIRAMINA + PARACETAMOL + FENILEFRINA 4 + 400 + 4 MG CÁPSULA"
  },
  {
    "code" : "BR0409234",
    "display" : "CETOPROFENO 1 % SOL INJ (FR)"
  },
  {
    "code" : "BR0439610U0041",
    "display" : "NINTEDANIBE, SAL ESILATO CÁPSULA GELATINOSA MOLE 100 MG"
  },
  {
    "code" : "BR0438093U0097",
    "display" : "COLECALCIFEROL  200 UI SOLUÇÃO ORAL 30 ML"
  },
  {
    "code" : "BR0268458U0037",
    "display" : "GANCICLOVIR SÓDICO 250 MG SOLUÇÃO INJETÁVEL BOLSA 250 ML"
  },
  {
    "code" : "BR0406013U0042",
    "display" : "ESTRADIOL, VALERATO 1 MG COMPRIMIDO"
  },
  {
    "code" : "BR0325838",
    "display" : "DEFERASIROX 125 MG COMPRIMIDO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0449719",
    "display" : "ÁCIDO FÓLICO + VIT, B1,B2,B3,B5,B6,B12,C,D,E,H,K MIN: CA,CO,CR,CU,FE,I,MG,MN,MO,SE,ZN CÁPSULA"
  },
  {
    "code" : "BR0268944U0170",
    "display" : "SELANTE DE FIBRINA 1,0ML INJ (FR)"
  },
  {
    "code" : "BR0437585U0042",
    "display" : "ZOLPIDEM 6,25MG COMP DE LIB PROL"
  },
  {
    "code" : "BR0438042",
    "display" : "UNGUENTO 200 G CREME"
  },
  {
    "code" : "BR0407500",
    "display" : "ACEPROMAZINA 0,2 % INJ (FR) 20 ML"
  },
  {
    "code" : "BR0437083U0234",
    "display" : "SECUQUINUMABE 150 MG/ML SOL INJ (SER PREENC) GRUPO 1.A"
  },
  {
    "code" : "BR0449559U0042",
    "display" : "ELBASVIR + GRAZOPREVIR 50 + 100 MG COMPRIMIDO GRUPO 1.A"
  },
  {
    "code" : "BR0456529",
    "display" : "TETRABENAZINA 25 MG COMPRIMIDO"
  },
  {
    "code" : "BR0432447U0041",
    "display" : "MOMETASONA, FUROATO 200MCG CÁPSULA"
  },
  {
    "code" : "BR0451596U0042",
    "display" : "ARNICA MONTANA D2 + ASSOCIAÇÃO 301,5 MG COMPRIMIDO SUBLINGUAL"
  },
  {
    "code" : "BR0290947U0042",
    "display" : "AMINOÁCIDOS (LISINA 75MG, TREONINA 53MG, TRIPTOFANO 23MG, HISTIDINA 38MG, TIROSINA 30MG) + ANÁLOGOS (ISOLEUCINA 67MG, LEUCINA 101MG, VALINA 85MG, ALFA-HIDROXI-ANÁLOGO DA METIONINA 59MG) COMP REV"
  },
  {
    "code" : "BR0417811U0041",
    "display" : "TAFAMIDIS 20 MG CÁPSULA  GRUPO 1.A"
  },
  {
    "code" : "BR0394876U0013",
    "display" : "SORO, ANTILOXOSCÉLICO SOLUÇÃO INJETÁVEL 5 ML"
  },
  {
    "code" : "BR0395147-1",
    "display" : "DIAZEPAM 10MG/2ML SOL INJ (AMP) 2ML"
  },
  {
    "code" : "BR0450872",
    "display" : "MULTIVITAMINAS, VITS: A, B1, B2, B3, B5, B6, B12, C, D, E, H, K, MINERAIS: NA, SE, ZN, ÁCIDO FÓLICO, COENZIMA Q10 CÁPSULA"
  },
  {
    "code" : "BR0449803",
    "display" : "RITONAVIR 100 MG PÓ PARA SUSPENSÃO 30 ENVELOPES"
  },
  {
    "code" : "BR0271036U0062",
    "display" : "DOXICICLINA 20 MG/ML SUSPENSÃO ORAL  100 ML"
  },
  {
    "code" : "BR0273260",
    "display" : "CETILPIRIDÍNIO + BENZOCAÍNA 1,466 + 10 MG PASTILHA"
  },
  {
    "code" : "BR0459790",
    "display" : "BENRALIZUMABE 30 MG/ML SOL INJ (SER PREENC) 1 ML"
  },
  {
    "code" : "BR0268946U0042",
    "display" : "AZITROMICINA 250 MG COMPRIMIDO"
  },
  {
    "code" : "BR0452627",
    "display" : "PALBOCICLIBE 75 MG CÁPSULA DURA DE LIBERAÇÃO PROLONGADA"
  },
  {
    "code" : "BR0338591",
    "display" : "METRONIDAZOL 100MG/G BISNAGA 55G"
  },
  {
    "code" : "BR0402927",
    "display" : "CIPROEPTADINA, ASSOCIADOS 0,8 + 0,12 + 0,15 + 1,334 + 0,134 + 4,334 MG/ML XAROPE  240ML"
  },
  {
    "code" : "BR0437160U0075",
    "display" : "CLORETO DE SÓDIO 0,9 % SOLUÇÃO NASAL 15 ML"
  },
  {
    "code" : "BR0396751U0374",
    "display" : "DICLOFENACO SÓDICO 150 MG COMPRIMIDO DE LIBERAÇÃO PROLONGADA"
  },
  {
    "code" : "BR0399066U0097",
    "display" : "CYNARA SCOLYMUS (ALCACHOFRA) 20 % TINTURA 30 ML"
  },
  {
    "code" : "BR0267587",
    "display" : "BECLOMETASONA, DIPROPIONATO 200 MCG AER BUCAL (FR DE 200 DOSES) 200 DOSES"
  },
  {
    "code" : "BR0399096",
    "display" : "MILTEFOSINA 50 MG COMPRIMIDO"
  },
  {
    "code" : "BR0438040",
    "display" : "ENROFLOXACINO  2,5% MG INJ (FR) 20 ML"
  },
  {
    "code" : "BR0434872U0042",
    "display" : "CITRATO DE TOFACITINIBE 5 MG COMP GRUPO 1.A"
  },
  {
    "code" : "BR0404151U0023",
    "display" : "PAPAÍNA 6 % GEL 30 G"
  },
  {
    "code" : "BR0438993U0472",
    "display" : "UMECLIDÍNIO, BROMETO 62,5 MCG PÓ PARA INALAÇÃO ORAL 7 DOSES ELENCO ESTADUAL"
  },
  {
    "code" : "BR9278660",
    "display" : "FERRO, QUELATO + ACIDO FOLICO + B12 300 + 5 + 0,015 MG COMP REV"
  },
  {
    "code" : "BR0396730",
    "display" : "DESOXIMETASONA 2,5 MG/G POMADA 20 G"
  },
  {
    "code" : "BR0266788",
    "display" : "NISTATINA 25.000UI/G BISNAGA 60G"
  },
  {
    "code" : "BR0269595U0097",
    "display" : "PICOSSULFATO SODICO  7,5 MG/ML SOL ORAL (FR) 30ML"
  },
  {
    "code" : "BR0437160U0091",
    "display" : "CLORETO DE SÓDIO 0,9 % SOLUÇÃO NASAL 25 ML"
  },
  {
    "code" : "BR0449681U0042",
    "display" : "COLECALCIFEROL 10.000 UI COMP REV"
  },
  {
    "code" : "BR0426045",
    "display" : "NITISINONA 5 MG CÁPSULA"
  },
  {
    "code" : "BR0426046",
    "display" : "NITISINONA 10 MG CÁPSULA"
  },
  {
    "code" : "BR0380419-1",
    "display" : "BIMATOPROSTA + TIMOLOL 00,3MG/ML + 0,5MG/ML SOLUÇÃO OFTÁLMICA 5ML"
  },
  {
    "code" : "BR0399066-1",
    "display" : "CYNARA SCOLYMUS  (ALCACHOFRA) 50 G DROGA VEGETAL"
  },
  {
    "code" : "BR0439938",
    "display" : "AMOXICILINA + CLARITROMICINA + ESOMEPRAZOL 500MG + 500 MG + 20  MG COMP REV"
  },
  {
    "code" : "BR0436169",
    "display" : "BENZOATO DE ALOGLIPTINA 25 MG COMP"
  },
  {
    "code" : "BR0458725",
    "display" : "SUPLEMENTO NUTRICIONAL, VITAMINA E, ÔMEGA 3, 6 E 9 CÁPSULA"
  },
  {
    "code" : "BR0268286-4",
    "display" : "MICONAZOL, NITRATO 2% CREME  50G"
  },
  {
    "code" : "BR0269877U0062",
    "display" : "CLOREXIDINA, DIGLUCONATO 4%  SOLUÇÃO 100ML"
  },
  {
    "code" : "BR0430083U0041",
    "display" : "ROSMARINUS OFFICINALIS (ALECRIM) 50 G DROGA VEGETAL"
  },
  {
    "code" : "BR0453501U0009",
    "display" : "NITROPRUSSETO DE SÓDIO 25 MG/ML SOLUÇÃO 2 ML"
  },
  {
    "code" : "BR0453967U0110",
    "display" : "EXTRATO MEDICINAL, ÓLEO DE CANABIDIOL 100 MG/ML SOLUÇÃO ORAL 60 ML ELENCO ESTADUAL"
  },
  {
    "code" : "BR0440313",
    "display" : "CIPROEPTADINA, CLORIDRATO + COBAMAMIDA 4MG+1MG COMPRIMIDO"
  },
  {
    "code" : "BR0431163U0086",
    "display" : "PODOFILINA 20 % SOLUÇÃO TÓPICA 20 ML"
  },
  {
    "code" : "BR0272581",
    "display" : "TIMOLOL, MALEATO 0,5 % SOLUÇÃO OFTÁLMICA 5 ML ELENCO ESTADUAL"
  },
  {
    "code" : "BR0370118",
    "display" : "DABIGATRANA, ETEXILATO 75 MG CÁPSULA"
  },
  {
    "code" : "BR0430630",
    "display" : "TERIFLUNOMIDA 14 MG COMPRIMIDO"
  },
  {
    "code" : "BR0311465-1",
    "display" : "ZINCO, SULFATO 20MG COMP"
  },
  {
    "code" : "BR0454125U0124",
    "display" : "EXTRATO MEDICINAL, ÓLEO DE CANABIDIOL 1000 MG CREME  60 G ELENCO ESTADUAL"
  },
  {
    "code" : "BR0428744-4",
    "display" : "COLECALCIFEROL (VITAMINA D3) 2.000 UI CÁPSULA"
  },
  {
    "code" : "BR0435720",
    "display" : "ÁCIDO FÓLICO 400 MCG CÁPSULA GELATINOSA MOLE"
  },
  {
    "code" : "BR0268691U0118",
    "display" : "COMPLEXO PROTROMBÍNICO HUMANO (FATORES DE COAGULAÇÃO II, VII, IX, X EM COMBINAÇÃO) 500 A 600 UI PÓ LIOFILIZADO PARA SOLUÇÃO INJETÁVEL"
  },
  {
    "code" : "BR0448159U0042",
    "display" : "ALPRAZOLAM LIBERAÇÃO LENTA 1 MG COMP"
  },
  {
    "code" : "BR0390680U0023",
    "display" : "PAPAÍNA 10 % GEL 30 G"
  },
  {
    "code" : "BR0451596U0023",
    "display" : "ARNICA 10 % GEL 30 G"
  },
  {
    "code" : "BR0366934",
    "display" : "NAFAZOLINA, CLORIDRATO + ZINCO, SULFATO 0,15 + 0,30 MG/ML SOL OFT (FR) 20 ML ELENCO ESTADUAL"
  },
  {
    "code" : "BR0390005-1",
    "display" : "QUETIAPINA, HEMIFUMARATO 50 MG COMPRIMIDO"
  },
  {
    "code" : "BR0451162U0041",
    "display" : "EXTRATO MEDICINAL, ÓLEO DE CANABIDIOL, CÂNHAMO DESCARBOXILADO, CÚRCUMA E SALGUEIRO, 25 MG CÁPSULA  ELENCO ESTADUAL"
  },
  {
    "code" : "BR0417811U0042",
    "display" : "TAFAMIDIS 20 MG CÁPSULA"
  },
  {
    "code" : "BR0355132U0042",
    "display" : "DOXAZOSINA, MESILATO 4MG COMPRIMIDO DE LIBERAÇÃO CONTROLADA"
  },
  {
    "code" : "BR0437160U0110",
    "display" : "CLORETO DE SÓDIO 0,9 % SOLUÇÃO NASAL 60 ML"
  },
  {
    "code" : "BR0400982U0063",
    "display" : "ZINCO, SULFATO 2,5 MG/ML SOLUÇÃO ORAL 10 ML"
  },
  {
    "code" : "BR0268692U0118",
    "display" : "COMPLEXO PROTROMBÍNICO PARCIALMENTE ATIVADO 500UI PÓ PARA SOLUÇÃO INJETÁVEL"
  },
  {
    "code" : "BR0462392U0042",
    "display" : "EMPAGLIFLOZINA + LINAGLIPTINA 10 + 5 COMP REV"
  },
  {
    "code" : "BR0440665U0106",
    "display" : "TRASTUZUMABE 120 MG/ML SOLUÇÃO INJETÁVEL 5 ML"
  },
  {
    "code" : "BR0442585U0324",
    "display" : "RANITIDINA, CLORIDRATO 40 MG/ML SOLUÇÃO ORAL 45 ML"
  },
  {
    "code" : "BR0454933U0288",
    "display" : "EXTRATO MEDICINAL, ÓLEO DE CANABIDIOL, CÂNHAMO DESCARBOXILADO 300 MG/ML SOLUÇÃO EM DOSADOR ORAL 10 ML ELENCO ESTADUAL"
  },
  {
    "code" : "BR0453967U0097",
    "display" : "EXTRATO MEDICINAL, ÓLEO DE CANABIDIOL 100 MG/ML SOLUÇÃO ORAL 30 ML"
  },
  {
    "code" : "BR0431311U0193",
    "display" : "HIDRÓXIDO DE ALUMÍNIO + HIDRÓXIDO DE MAGNÉSIO + DIMETICONA 37 MG + 40 MG + 5 MG/ML SUSPENSÃO ORAL  150 ML"
  },
  {
    "code" : "BR0395597U0098",
    "display" : "VACINA CÓLERA (INATIVADA) SUSPENSÃO ORAL"
  },
  {
    "code" : "BR0449559",
    "display" : "ELBASVIR + GRAZOPREVIR 50 + 100 MG COMPRIMIDO"
  },
  {
    "code" : "BR0437411U0324",
    "display" : "ARGININA 0,25 MG/ML XAROPE  45 ML"
  },
  {
    "code" : "BR0405903U0106",
    "display" : "IMUNOGLOBULINA HUMANA, ANTIRÁBICA 2,5 UI PÓ LIOF INJ (AMP) 5 ML ELENCO ESTADUAL"
  },
  {
    "code" : "BR0331387",
    "display" : "SITAGLIPTINA, FOSFATO 25 MG COMPRIMIDO"
  },
  {
    "code" : "BR0270494U0388",
    "display" : "COLAGENASE + CLORANFENICOL  0,6 UI + 10 MG/G POMADA"
  },
  {
    "code" : "BR0268361",
    "display" : "ZIDOVUDINA 10 MG/ML SOLUÇÃO ORAL 240 ML"
  },
  {
    "code" : "BR0436302",
    "display" : "BACILLUS CLAUSII SOLUÇÃO 5ML"
  },
  {
    "code" : "BR0451170U0284",
    "display" : "EXTRATO MEDICINAL, ÓLEO DE CANABIDIOL 170 MG/ML SOLUÇÃO ORAL 3 ML ELENCO ESTADUAL"
  },
  {
    "code" : "BR0434251U0042",
    "display" : "LEDIPASVIR + SOFOSBUVIR 90 + 400 MG COMPRIMIDO GRUPO 1.A"
  },
  {
    "code" : "BR0445704",
    "display" : "MAGNÉSIO, CLORETO 500 MG CÁPSULA"
  },
  {
    "code" : "BR0269845",
    "display" : "LIDOCAÍNA, CLORIDRATO 10 % SPRAY  TÓPICO 50 ML"
  },
  {
    "code" : "BR0433853",
    "display" : "COLISTIMETATO DE SODIO (POLIMIXINA E) 2.000.000 UI PÓ LIOFILIZADO PARA SOLUÇÃO INJETÁVEL"
  },
  {
    "code" : "BR0429724",
    "display" : "CARFILZOMIBE 60 MG SOLUÇÃO INJETÁVEL"
  },
  {
    "code" : "BR0389799U0592",
    "display" : "CONCENTRADO DE FATOR VII 250KUI ATIVADO RECOMBINADO INJ (FR)"
  },
  {
    "code" : "BR0448171U0042",
    "display" : "LACTOBACILLUS REUTERI 100 MILHÕES UFC COMPRIMIDO MASTIGÁVEL"
  },
  {
    "code" : "BR0438433U0098",
    "display" : "INSULINA GLARGINA 300 UI/ML SOLUÇÃO INJETÁVEL 1,5 ML"
  },
  {
    "code" : "BR0449017",
    "display" : "ALCAFTADINA 2,5 MG/ML SOLUÇÃO OFTÁLMICA 3 ML"
  },
  {
    "code" : "BR392423",
    "display" : "DEXPANTENOL 50 MG/G GEL 10 G"
  },
  {
    "code" : "BR0322081",
    "display" : "METOTREXATO 100 MG/ML SOLUÇÃO INJETÁVEL 50 ML"
  },
  {
    "code" : "BR0308802U0150",
    "display" : "CONCENTRADO DE FATOR VIII 250UI AE MAIOR 100UI/MG INJ (FR)"
  },
  {
    "code" : "BR0269845U0101",
    "display" : "LIDOCAÍNA, CLORIDRATO 100 MG/ML SOLUÇÃO TÓPICA 40 ML"
  },
  {
    "code" : "BR0438956",
    "display" : "EXTRATO MEDICINAL, ÓLEO DE CANABIDIOL 25 MG CÁPSULA"
  },
  {
    "code" : "BR0452607U0118",
    "display" : "GLATIRAMER 40 MG PÓ LIOF INJ (FR-AMP OU SER PREENC) GRUPO 1.A"
  },
  {
    "code" : "BR0319000U0063",
    "display" : "BRIMONIDINA, TARTARATO + TIMOLOL, MALEATO 2MG + 5MG/ML SOL OFT (FR) 10ML"
  },
  {
    "code" : "BR0273659",
    "display" : "MESNA 100 MG/ML SOLUÇÃO INJETÁVEL 4 ML"
  },
  {
    "code" : "BR0275649",
    "display" : "GONADOTROPINA, CORIÔNICA ALFA HCG RECOMBINANTE, CORIOGONADOTROPINA ALFA 5000 UI SOLUÇÃO INJETÁVEL"
  },
  {
    "code" : "BR0439143U0042",
    "display" : "MIRABEGRONA 50MG COMPRIMIDO DE LIBERAÇÃO PROLONGADA"
  },
  {
    "code" : "BR0434827",
    "display" : "CETRIMIDA + ÓLEOS VEGETAIS SABONETE 150ML"
  },
  {
    "code" : "BR0398702U0005",
    "display" : "MEDROXIPROGESTERONA, ACETATO 150 MG/ML SUSPENSÃO INJETÁVEL 1 ML"
  },
  {
    "code" : "BR0451600U0023",
    "display" : "PAPAÍNA 5 % GEL 30 G"
  },
  {
    "code" : "BR0454936U0067",
    "display" : "EXTRATO MEDICINAL, ÓLEO DE CANABIDIOL 50 MG/ML SOLUÇÃO ORAL ISENTO DE THC 120 ML"
  },
  {
    "code" : "BR0448838U0062",
    "display" : "ACEBROFILINA 5 MG/ML XAROPE  100 ML"
  },
  {
    "code" : "BR0401323U0106",
    "display" : "EPINASTINA, CLORIDRATO 0,5 MG/ML SOLUÇÃO OFTÁLMICA 5 ML"
  },
  {
    "code" : "BR0273705",
    "display" : "NAPROXENO 550 MG COMPRIMIDO"
  },
  {
    "code" : "BR0451691U0582",
    "display" : "EXTRATO MEDICINAL, ÓLEO DE CANABIDIOL, CÂNHAMO DESCARBOXILADO E FILTRADO, ISENTO DE THC 8,47 MG/ML SOLUÇÃO 118 ML ELENCO ESTADUAL"
  },
  {
    "code" : "BR0362573",
    "display" : "NIMESULIDA 20 MG/G GEL 30 G"
  },
  {
    "code" : "BR0434445U0106",
    "display" : "TRIANCINOLONA, SAL HEXACETONIDA 20MG/ML  SUSPENSÃO INJETÁVEL 5ML"
  },
  {
    "code" : "BR0292427U0018",
    "display" : "DEXAMETASONA, FOSFATO DISSÓDICO 4  MG/ML SOLUÇÃO INJETÁVEL FRASCO-AMPOLA 2,5 ML"
  },
  {
    "code" : "BR0333568U15",
    "display" : "TACROLIMO 0,03 % POMADA 10 G"
  },
  {
    "code" : "BR0442521",
    "display" : "DULAGLUTIDA 1,5MG/ML INJ (FR) 0,5ML"
  },
  {
    "code" : "BR0443278",
    "display" : "KARITÉ, ILIPÉ E MANGA SABONETE 150G"
  },
  {
    "code" : "BR0406994U0097",
    "display" : "PASSIFLORA INCARNATA 150MG SOL ORAL (FR) 30ML"
  },
  {
    "code" : "BR0383409U0063",
    "display" : "CARMELOSE SÓDICA + GLICEROL 5 + 9 MG/ML SOLUÇÃO OFTÁLMICA 10 ML"
  },
  {
    "code" : "BR0269845U0086",
    "display" : "LIDOCAÍNA, CLORIDRATO 100 MG/ML SOLUÇÃO TÓPICA 20 ML"
  },
  {
    "code" : "BR0268865U0042",
    "display" : "EPINASTINA, CLORIDRATO 10MG  COMP"
  },
  {
    "code" : "BR0396567",
    "display" : "MICAFUNGINA 50 MG PÓ LIOF INJ (FR-AMP)"
  },
  {
    "code" : "BR0389803",
    "display" : "TEMOZOLOMIDA 180 MG CÁPSULA"
  },
  {
    "code" : "BR0314517U0059",
    "display" : "AZITROMICINA 40 MG/ML 1500 MG PÓ PARA SUSPENSÃO 37,5 ML"
  },
  {
    "code" : "BR0443373U0409",
    "display" : "CALENDULA OFFICINALIS L 10% GEL 120G"
  },
  {
    "code" : "BR0400579U0023",
    "display" : "CORDIA VERBENACEA DC. 5 MG/G CREME  30 G"
  },
  {
    "code" : "BR0308802U0118",
    "display" : "CONCENTRADO DE FATOR VIII 1.000 UI - AE IGUAL OU MAIOR 100 UI LIOFILIZADO INJ (FR)"
  },
  {
    "code" : "BR0449401",
    "display" : "SUFENTANILA, CITRATO 5 MCG/ML SOLUÇÃO INJETÁVEL 2 ML"
  },
  {
    "code" : "BR0308806U0118",
    "display" : "CONCENTRADO DE FATOR IX 200 UI A 250 UI UI PÓ LIOFILIZADO PARA SOLUÇÃO INJETÁVEL"
  },
  {
    "code" : "BR0445430",
    "display" : "VALSARTANA, ASSOCIADO AO SACUBITRIL 51  MG + 49 MG COMPRIMIDO"
  },
  {
    "code" : "BR0437402U0042",
    "display" : "CALCIO, CITRATO + COLECALCIFEROL + MENAQUINONA (K2) 600 + 0,005 + 0,055 MG COMP"
  },
  {
    "code" : "BR390598-2",
    "display" : "CONCENTRADO DE FATOR DE COAGULAÇÃO, FATOR VIII RECOMBINANTE 1000 UI INJ (FR)"
  },
  {
    "code" : "BR0292380U0075",
    "display" : "TRAMADOL, CLORIDRATO 100 MG/ML SOLUÇÃO ORAL 15 ML"
  },
  {
    "code" : "BR0458965",
    "display" : "DOXEPINA 20 MG CÁPSULA  MANIPULADO"
  },
  {
    "code" : "BR0437402U0046",
    "display" : "CALCIO, CITRATO + COLECALCIFEROL + MENAQUINONA (K2) 250 + 0,005 + 0,045 MG COMP REV"
  },
  {
    "code" : "BR0443373U0023",
    "display" : "CALENDULA OFFICINALIS L 10 % GEL 30 G"
  },
  {
    "code" : "BR0434478U0284",
    "display" : "EXTRATO MEDICINAL, ÓLEO DE CANABIDIOL 24 % SOLUÇÃO ORAL 3 ML ELENCO ESTADUAL"
  },
  {
    "code" : "BR0343212",
    "display" : "OCITOCINA 40 UI/ML SOLUÇÃO NASAL 10 ML"
  },
  {
    "code" : "BR0275534",
    "display" : "PARACETAMOL + CAFEÍNA + METOCLOPRAMIDA + DIIDROERGOTAMINA 450 + 75 + 10 + 1 MG COMPRIMIDO"
  },
  {
    "code" : "BR0435720U0041",
    "display" : "ÁCIDO FÓLICO + DEXTROALFATOCOFEROL 0,4 + 10 MG CÁPSULA GELATINOSA MOLE"
  },
  {
    "code" : "BR0436345",
    "display" : "NINTEDANIBE, SAL ESILATO 150 MG CAP"
  },
  {
    "code" : "BR0388713",
    "display" : "PREGABALINA 50MG CÁPSULA"
  },
  {
    "code" : "BR0436778U0063",
    "display" : "NIVOLUMABE 10 MG/ML SOLUÇÃO INJETÁVEL 10 ML"
  },
  {
    "code" : "BR0464306",
    "display" : "CARBONATO DE CÁLCIO + COLECALCIFEROL  400 MG + 100 UI TABLETE"
  },
  {
    "code" : "BR0443374U0041",
    "display" : "AESCULUS HIPPOCASTANUM L. (CASTANHA DA ÍNDIA) 500MG CÁPSULA"
  },
  {
    "code" : "BR0273422",
    "display" : "LOXOPROFENO SÓDICO 60 MG COMPRIMIDO"
  },
  {
    "code" : "BR0311465U0013",
    "display" : "ZINCO, SULFATO 200MCG INJ (FR)"
  },
  {
    "code" : "BR0433218U0005",
    "display" : "INSULINA DEGLUDECA 100 UI/ML COM APLICADOR SOL INJ (AMP)"
  },
  {
    "code" : "BR0454935U0067",
    "display" : "EXTRATO MEDICINAL, ÓLEO DE CANABIDIOL 8,33 MG/ML SOLUÇÃO ORAL ISENTO DE THC 120 ML"
  },
  {
    "code" : "BR0389480U0005",
    "display" : "TOBRAMICINA, SULFATO 300 MG SOLUÇÃO PARA INALAÇÃO ELENCO ESTADUAL"
  },
  {
    "code" : "BR0437079U0042",
    "display" : "RIOCIGUATE 1,5 MG COMPRIMIDO"
  },
  {
    "code" : "BR0451580",
    "display" : "URÉIA + LACTATO DE AMÔNIA + CAMOMILA 10% + 6% + 10 % CREME  50 G"
  },
  {
    "code" : "BR0269963U0110",
    "display" : "DOMPERIDONA 1 MG/ML SUSPENSÃO ORAL  60 ML"
  },
  {
    "code" : "BR0287559-1",
    "display" : "ESTAVUDINA  1 MG/ML PÓ PARA SOLUÇÃO 200 ML"
  },
  {
    "code" : "BR0333568U516",
    "display" : "TACROLIMO 0,03 % POMADA OFTALMICA  ESPECIALMENTE MANIPULADO"
  },
  {
    "code" : "BR0433553",
    "display" : "NISTATINA + NEOMICINA + TIROTRICINA + DEXAMETASONA 100.000 UI + 10 + 2 + 0,32 MG CREME VAGINAL  60 G"
  },
  {
    "code" : "BR0297696U0165",
    "display" : "ARTICAÍNA ASSOCIADA COM EPINEFRINA 4 % + 1/200.000 SOLUÇÃO INJETÁVEL 1,8 ML"
  },
  {
    "code" : "BR0451597",
    "display" : "ALOE VERA (BABOSA) 25 % GEL 10 G"
  },
  {
    "code" : "BR0443166U0042",
    "display" : "MAYTENUS ILICIFOLIA (ESPINHEIRA SANTA) 400MG COMP"
  },
  {
    "code" : "BR0417393",
    "display" : "FLUDROCORTISONA, ACETATO 0,1 MG/ML SOL ORAL (FR)"
  },
  {
    "code" : "BR0445513U0097",
    "display" : "EXTRATO MEDICINAL, ÓLEO DE CANABIDIOL 500 MG SOLUÇÃO ORAL 30 ML ELENCO ESTADUAL"
  },
  {
    "code" : "BR0313595U0017",
    "display" : "POLICRESULENO + CINCHOCAÍNA, CLORIDRATO 100 + 10 MG/G POMADA 15 G"
  },
  {
    "code" : "BR0448689",
    "display" : "NEMOGESTROL, ACETATO + ESTRADIOL 2,5 + 1,5 MG COMPRIMIDO"
  },
  {
    "code" : "BR0447078",
    "display" : "EMPAGLIFLOZINA + LINAGLIPTINA 25 + 5 MG COMPRIMIDO"
  },
  {
    "code" : "BR0455395",
    "display" : "USTEQUINUMABE 5 MG/ML SOLUÇÃO INJETÁVEL"
  },
  {
    "code" : "BR0389779",
    "display" : "RASAGILINA 1 MG COMPRIMIDO"
  },
  {
    "code" : "BR0270615U0391",
    "display" : "BENZILPENICILINA POTÁSSICA 1.000.000UI SOL INJ (FR) 2ML"
  },
  {
    "code" : "BR0451695U0288",
    "display" : "EXTRATO MEDICINAL, ÓLEO DE CANABIDIOL, CÂNHAMO DESCARBOXILADO 380 MG/ML SOLUÇÃO 10 ML ELENCO ESTADUAL"
  },
  {
    "code" : "BR0271645U0063",
    "display" : "OXIMETAZOLINA, CLORIDRATO 0,5 MG/ML SOLUÇÃO NASAL 10 ML"
  },
  {
    "code" : "BR0449569",
    "display" : "VELPATASVIR + SOFOSBUVIR 100 + 400 MG COMPRIMIDO"
  },
  {
    "code" : "BR0352933U0074",
    "display" : "LEVETIRACETAM 100 MG/ML SOLUÇÃO ORAL 150 ML GRUPO 1.A"
  },
  {
    "code" : "BR0442819",
    "display" : "RHODIOLA ROSEA 400 MG COMP REV"
  },
  {
    "code" : "BR0368640",
    "display" : "NITAZOXANIDA 20 MG/ML PÓ PARA SUSPENSÃO"
  },
  {
    "code" : "BR0400563-1",
    "display" : "USTEQUINUMABE 45MG INJ (FR) 0,5ML"
  },
  {
    "code" : "BR0402937U0046",
    "display" : "ESTRADIOL TRIMEGESTONA 1MG+0,125MG DRÁGEA"
  },
  {
    "code" : "BR0450929U1687",
    "display" : "EXTRATO MEDICINAL, ÓLEO DE CANABIDIOL 100 MG/ML SOLUÇÃO ORAL 15 ML ELENCO ESTADUAL"
  },
  {
    "code" : "BR0452264",
    "display" : "ÓXIDO DE ZINCO, ASSOCIADO À GELATINA E GLICEROL  25 + 25 + 25 % SOLUÇÃO 100 G"
  },
  {
    "code" : "BR0410284",
    "display" : "CAFEÍNA 10 MG/ML SOL INJ (FR) 1 ML"
  },
  {
    "code" : "BR0346317U0042",
    "display" : "ÁCIDO ASCÓRBICO, ASPARTATO DE ARGININA 50MG + 500MG COMP"
  },
  {
    "code" : "BR0449186",
    "display" : "CETOCONAZOL + BETAMETASONA + NEOMICINA 20 + 0,5 + 1,5 MG POMADA"
  },
  {
    "code" : "BR0426091U0042",
    "display" : "VANDETANIBE 300 MG COMPRIMIDO"
  },
  {
    "code" : "BR0433257U0087",
    "display" : "HIDRÓXIDO DE ALUMÍNIO 60 MG/ML SUSPENSÃO ORAL  240 ML"
  },
  {
    "code" : "BR0433940U0067",
    "display" : "MIKANIA GLOMERATA (GUACO) 35 MG/ML XAROPE  120 ML"
  },
  {
    "code" : "BR0446467U0005",
    "display" : "PALIVIZUMABE 100 MG/ML SOL INJ (FR-AMP) 1 ML"
  },
  {
    "code" : "BR0437087",
    "display" : "TESTOSTERONA 10 MG/G GEL 5 G"
  },
  {
    "code" : "BR0364037-1",
    "display" : "RIFAMPICINA + CLOFAZIMINA + DAPSONA 300 + 100+50 +100 MG COMP"
  },
  {
    "code" : "BR0392775U0106",
    "display" : "VACINA HUMANA, ADSORVIDA, DUPLA BACTERIANA (TOX. DIFTÉRICO + TOX. TETÂNICO) INFANTIL SOLUÇÃO INJETÁVEL"
  },
  {
    "code" : "BR0438993",
    "display" : "UMECLIDÍNIO, BROMETO 62,5 MCG PÓ PARA INALAÇÃO ORAL"
  },
  {
    "code" : "BR0361135U0042",
    "display" : "DIPIRONA SÓDICA, PAPAVERINA E EXTRATO FLUIDO BELADONA 250 MG + 30 MG + 0,03 ML  COMP"
  },
  {
    "code" : "BR0422156",
    "display" : "RUXOLITINIBE 5 MG COMPRIMIDO"
  },
  {
    "code" : "BR0278372",
    "display" : "TRETINOÍNA 0,05 % CREME  30 G"
  },
  {
    "code" : "BR0291231",
    "display" : "ESTREPTOMICINA, SULFATO 1 G SUSPENSÃO INJETÁVEL"
  },
  {
    "code" : "BR0452623",
    "display" : "METFORMINA, CLORIDRATO + ALOGLIPTINA 1000 + 12,5 MG COMP REV"
  },
  {
    "code" : "BR0436711U0042",
    "display" : "ETRAVIRINA 200 MG COMPRIMIDO"
  },
  {
    "code" : "BR0437006U0370",
    "display" : "EXTRATO MEDICINAL, DELTA-9-TETRAHIDRO CANABINOL (THC) + CANABIDIOL 27MG/ML + 25  MG/ML SPRAY ORAL 5,5 ML ML ELENCO ESTADUAL"
  },
  {
    "code" : "BR0434445U0058",
    "display" : "TRIANCINOLONA, SAL HEXACETONIDA 20MG/ML SUSPENSÃO INJETÁVEL 1ML"
  },
  {
    "code" : "BR0440269U0118",
    "display" : "PEMBROLIZUMABE 25 MG/ML SOLUÇÃO INJETÁVEL 4 ML"
  },
  {
    "code" : "BR0273936U0101",
    "display" : "PIRVÍNIO EMBONATO 10 MG/ML SUSPENSÃO ORAL  20 ML"
  },
  {
    "code" : "BR0437870U0042",
    "display" : "FUMARATO DE DIMETILA 240 MG COMP GRUPO 1.A"
  }]
}

```
