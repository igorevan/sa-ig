# Bundle de exemplo do SA - Guia de Implementação do Sumário de Alta (SA) da RNDS v1.0.0-release

## Example Bundle: Bundle de exemplo do SA



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "example-SA",
  "identifier" : {
    "system" : "http://www.saude.gov.br/fhir/r4/NamingSystem/BRRNDS-12345",
    "value" : "c6d8d486"
  },
  "type" : "document",
  "timestamp" : "2022-12-07T10:59:51.244-03:00",
  "entry" : [{
    "fullUrl" : "urn:uuid:b602ff2a-11c1-498a-b1e2-afbc41476225",
    "resource" : {
      "resourceType" : "Composition",
      "meta" : {
        "profile" : ["http://www.saude.gov.br/fhir/r4/StructureDefinition/BRSumarioAlta"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Composition_null\"> </a><p class=\"res-header-id\"><b>Narrativa gerada: Composition </b></p><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Perfil: <a href=\"StructureDefinition-BRSumarioAlta.html\">Sumário de Alta (SA)</a></p></div><p><b>status</b>: Final</p><p><b>type</b>: <span title=\"Códigos:{http://www.saude.gov.br/fhir/r4/CodeSystem/BRTipoDocumento SA}\">Sumário de Alta</span></p><p><b>category</b>: <span title=\"Códigos:{http://www.saude.gov.br/fhir/r4/CodeSystem/BRModalidadeAssistencial 04}\">Atenção Hospitalar</span></p><p><b>date</b>: 2021-01-25</p><p><b>author</b>: Identifier: <code>http://www.saude.gov.br/fhir/r4/StructureDefinition/BREstabelecimentoSaude-1.0</code>/1113333</p><p><b>title</b>: Sumário de Alta</p></div>"
      },
      "status" : "final",
      "type" : {
        "coding" : [{
          "system" : "http://www.saude.gov.br/fhir/r4/CodeSystem/BRTipoDocumento",
          "code" : "SA"
        }]
      },
      "category" : [{
        "coding" : [{
          "system" : "http://www.saude.gov.br/fhir/r4/CodeSystem/BRModalidadeAssistencial",
          "code" : "04"
        }]
      }],
      "subject" : {
        "identifier" : {
          "system" : "http://www.saude.gov.br/fhir/r4/StructureDefinition/BRIndividuo-1.0",
          "value" : "706004324048847"
        }
      },
      "date" : "2021-01-25",
      "author" : [{
        "identifier" : {
          "system" : "http://www.saude.gov.br/fhir/r4/StructureDefinition/BREstabelecimentoSaude-1.0",
          "value" : "1113333"
        }
      }],
      "title" : "Sumário de Alta",
      "section" : [{
        "entry" : [{
          "reference" : "urn:uuid:613e423b-175e-4adc-b062-e477da88ba3c"
        }]
      },
      {
        "entry" : [{
          "reference" : "urn:uuid:c6d8d486-6c0d-411b-a51f-746400f57faf"
        }]
      },
      {
        "entry" : [{
          "reference" : "urn:uuid:282704c4-979b-402a-b8ed-5e740a320982"
        }]
      },
      {
        "entry" : [{
          "reference" : "urn:uuid:42ed53db-5dec-437f-bd10-8895b6f6105d"
        }]
      },
      {
        "entry" : [{
          "reference" : "urn:uuid:efc37c9a-fdb2-4d11-ade4-b0c0d218f69c"
        }]
      },
      {
        "entry" : [{
          "reference" : "urn:uuid:6fd5513d-96f2-4e52-be36-fbbc85cb91f4"
        }]
      },
      {
        "entry" : [{
          "reference" : "urn:uuid:c8e3cf5f-96b7-43a9-919e-22e9947dc415"
        }]
      },
      {
        "entry" : [{
          "reference" : "urn:uuid:5c1de72d-fdc9-448d-9032-505dc78de8ca"
        }]
      },
      {
        "entry" : [{
          "reference" : "urn:uuid:7f396bd9-998a-4784-bbcb-8554ba5b015c"
        }]
      },
      {
        "entry" : [{
          "reference" : "urn:uuid:98d60b66-07b6-4c6c-a31f-dc6d1f80e626"
        }]
      },
      {
        "entry" : [{
          "reference" : "urn:uuid:038ad91c-ba1a-4560-8719-2428e998ea53"
        }]
      }]
    }
  },
  {
    "fullUrl" : "urn:uuid:613e423b-175e-4adc-b062-e477da88ba3c",
    "resource" : {
      "resourceType" : "Encounter",
      "meta" : {
        "profile" : ["http://www.saude.gov.br/fhir/r4/StructureDefinition/BRContatoAssistencial-1.0"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Encounter_null\"> </a><p class=\"res-header-id\"><b>Narrativa gerada: Encounter </b></p><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Perfil: <a href=\"StructureDefinition-BRContatoAssistencial-1.0.html\">Contato Assistencial</a></p></div><p><b>status</b>: Finished</p><p><b>class</b>: <a href=\"CodeSystem-BRModalidadeAssistencial.html#BRModalidadeAssistencial-04\">Modalidade Assistencial (CodeSystem): 04</a> (Atenção Hospitalar)</p><p><b>priority</b>: <span title=\"Códigos:{http://www.saude.gov.br/fhir/r4/CodeSystem/BRCaraterAtendimento 02}\">Urgência</span></p><p><b>subject</b>: Identifier: <code>http://www.saude.gov.br/fhir/r4/StructureDefinition/BRIndividuo-1.0</code>/706004324048847</p><h3>Participants</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Extension</b></td><td><b>Type</b></td><td><b>Individual</b></td></tr><tr><td style=\"display: none\">*</td><td/><td><span title=\"Códigos:{http://www.saude.gov.br/fhir/r4/CodeSystem/BRResponsabilidadeParticipante alta}\">Profissional que realizou a alta do indivíduo no Contato Assistencial</span></td><td>Identifier: <code>http://www.saude.gov.br/fhir/r4/StructureDefinition/BRLotacaoProfissional-1.0</code>/815113499149874-3191384</td></tr></table><p><b>period</b>: 2021-01-18 11:00:00+0000 --&gt; 2021-01-25 11:00:00+0000</p><blockquote><p><b>diagnosis</b></p><p><b>condition</b>: <a href=\"Bundle-example-SA.html#urn-uuid-c6d8d486-6c0d-411b-a51f-746400f57faf\">Condition Pneumonia devida a vírus respiratório sincicial</a></p><p><b>use</b>: <span title=\"Códigos:{http://terminology.hl7.org/CodeSystem/diagnosis-role AD}\">Admission diagnosis</span></p><p><b>rank</b>: 1</p></blockquote><blockquote><p><b>diagnosis</b></p><p><b>condition</b>: <a href=\"Bundle-example-SA.html#urn-uuid-282704c4-979b-402a-b8ed-5e740a320982\">Condition Infecção por coronavírus de localização não especificada</a></p><p><b>rank</b>: 2</p></blockquote><blockquote><p><b>diagnosis</b></p><p><b>condition</b>: <a href=\"Bundle-example-SA.html#urn-uuid-42ed53db-5dec-437f-bd10-8895b6f6105d\">Procedure TOMOGRAFIA DE HEMITORAX, PULMÃO OU DO MEDIASTINO</a></p></blockquote><h3>Hospitalizations</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>AdmitSource</b></td><td><b>DischargeDisposition</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Códigos:{http://www.saude.gov.br/fhir/r4/CodeSystem/BRProcedencia 09}\">Demanda espontânea</span></td><td><span title=\"Códigos:{http://www.saude.gov.br/fhir/r4/CodeSystem/BRMotivoDesfecho 03}\">Encaminhamento</span></td></tr></table><p><b>serviceProvider</b>: Identifier: <code>http://www.saude.gov.br/fhir/r4/StructureDefinition/BREstabelecimentoSaude-1.0</code>/1113333</p></div>"
      },
      "status" : "finished",
      "class" : {
        "system" : "http://www.saude.gov.br/fhir/r4/CodeSystem/BRModalidadeAssistencial",
        "code" : "04"
      },
      "priority" : {
        "coding" : [{
          "system" : "http://www.saude.gov.br/fhir/r4/CodeSystem/BRCaraterAtendimento",
          "code" : "02"
        }]
      },
      "subject" : {
        "identifier" : {
          "system" : "http://www.saude.gov.br/fhir/r4/StructureDefinition/BRIndividuo-1.0",
          "value" : "706004324048847"
        }
      },
      "participant" : [{
        "extension" : [{
          "url" : "http://www.saude.gov.br/fhir/r4/StructureDefinition/BROcupacao-1.0",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "http://www.saude.gov.br/fhir/r4/CodeSystem/BRCBO",
              "code" : "225125"
            }]
          }
        }],
        "type" : [{
          "coding" : [{
            "system" : "http://www.saude.gov.br/fhir/r4/CodeSystem/BRResponsabilidadeParticipante",
            "code" : "alta"
          }]
        }],
        "individual" : {
          "identifier" : {
            "system" : "http://www.saude.gov.br/fhir/r4/StructureDefinition/BRLotacaoProfissional-1.0",
            "value" : "815113499149874-3191384"
          }
        }
      }],
      "period" : {
        "start" : "2021-01-18T11:00:00Z",
        "end" : "2021-01-25T11:00:00Z"
      },
      "diagnosis" : [{
        "condition" : {
          "reference" : "urn:uuid:c6d8d486-6c0d-411b-a51f-746400f57faf"
        },
        "use" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/diagnosis-role",
            "code" : "AD"
          }]
        },
        "rank" : 1
      },
      {
        "condition" : {
          "reference" : "urn:uuid:282704c4-979b-402a-b8ed-5e740a320982"
        },
        "rank" : 2
      },
      {
        "condition" : {
          "extension" : [{
            "url" : "http://www.saude.gov.br/fhir/r4/StructureDefinition/BRFinanciamento-1.0",
            "valueCodeableConcept" : {
              "coding" : [{
                "system" : "http://www.saude.gov.br/fhir/r4/CodeSystem/BRFinanciamento",
                "code" : "02"
              }]
            }
          }],
          "reference" : "urn:uuid:42ed53db-5dec-437f-bd10-8895b6f6105d"
        }
      }],
      "hospitalization" : {
        "admitSource" : {
          "coding" : [{
            "system" : "http://www.saude.gov.br/fhir/r4/CodeSystem/BRProcedencia",
            "code" : "09"
          }]
        },
        "dischargeDisposition" : {
          "coding" : [{
            "system" : "http://www.saude.gov.br/fhir/r4/CodeSystem/BRMotivoDesfecho",
            "code" : "03"
          }]
        }
      },
      "serviceProvider" : {
        "identifier" : {
          "system" : "http://www.saude.gov.br/fhir/r4/StructureDefinition/BREstabelecimentoSaude-1.0",
          "value" : "1113333"
        }
      }
    }
  },
  {
    "fullUrl" : "urn:uuid:c6d8d486-6c0d-411b-a51f-746400f57faf",
    "resource" : {
      "resourceType" : "Condition",
      "meta" : {
        "profile" : ["http://www.saude.gov.br/fhir/r4/StructureDefinition/BRProblemaDiagnostico"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Condition_null\"> </a><p class=\"res-header-id\"><b>Narrativa gerada: Condition </b></p><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Perfil: <a href=\"StructureDefinition-BRProblemaDiagnostico.html\">Problema / Diagnóstico</a></p></div><p><b>clinicalStatus</b>: <span title=\"Códigos:{http://terminology.hl7.org/CodeSystem/condition-clinical active}\">Active</span></p><p><b>category</b>: <span title=\"Códigos:{http://terminology.hl7.org/CodeSystem/condition-category encounter-diagnosis}\">Encounter Diagnosis</span></p><p><b>code</b>: <span title=\"Códigos:{http://www.saude.gov.br/fhir/r4/CodeSystem/BRCID10 J121}\">Pneumonia devida a vírus respiratório sincicial</span></p><p><b>subject</b>: Identifier: <code>http://www.saude.gov.br/fhir/r4/StructureDefinition/BRIndividuo-1.0</code>/706004324048847</p></div>"
      },
      "clinicalStatus" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/condition-clinical",
          "code" : "active"
        }]
      },
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/condition-category",
          "code" : "encounter-diagnosis"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://www.saude.gov.br/fhir/r4/CodeSystem/BRCID10",
          "code" : "J121"
        }]
      },
      "subject" : {
        "identifier" : {
          "system" : "http://www.saude.gov.br/fhir/r4/StructureDefinition/BRIndividuo-1.0",
          "value" : "706004324048847"
        }
      }
    }
  },
  {
    "fullUrl" : "urn:uuid:282704c4-979b-402a-b8ed-5e740a320982",
    "resource" : {
      "resourceType" : "Condition",
      "meta" : {
        "profile" : ["http://www.saude.gov.br/fhir/r4/StructureDefinition/BRProblemaDiagnostico"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Condition_null\"> </a><p class=\"res-header-id\"><b>Narrativa gerada: Condition </b></p><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Perfil: <a href=\"StructureDefinition-BRProblemaDiagnostico.html\">Problema / Diagnóstico</a></p></div><p><b>clinicalStatus</b>: <span title=\"Códigos:{http://terminology.hl7.org/CodeSystem/condition-clinical active}\">Active</span></p><p><b>category</b>: <span title=\"Códigos:{http://terminology.hl7.org/CodeSystem/condition-category encounter-diagnosis}\">Encounter Diagnosis</span></p><p><b>code</b>: <span title=\"Códigos:{http://www.saude.gov.br/fhir/r4/CodeSystem/BRCID10 B342}\">Infecção por coronavírus de localização não especificada</span></p><p><b>subject</b>: Identifier: <code>http://www.saude.gov.br/fhir/r4/StructureDefinition/BRIndividuo-1.0</code>/706004324048847</p></div>"
      },
      "clinicalStatus" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/condition-clinical",
          "code" : "active"
        }]
      },
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/condition-category",
          "code" : "encounter-diagnosis"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://www.saude.gov.br/fhir/r4/CodeSystem/BRCID10",
          "code" : "B342"
        }]
      },
      "subject" : {
        "identifier" : {
          "system" : "http://www.saude.gov.br/fhir/r4/StructureDefinition/BRIndividuo-1.0",
          "value" : "706004324048847"
        }
      }
    }
  },
  {
    "fullUrl" : "urn:uuid:42ed53db-5dec-437f-bd10-8895b6f6105d",
    "resource" : {
      "resourceType" : "Procedure",
      "meta" : {
        "lastUpdated" : "2022-05-09T17:39:08.701859Z",
        "profile" : ["http://www.saude.gov.br/fhir/r4/StructureDefinition/BRProcedimentoRealizado-1.0"]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Procedure_null\"> </a><p class=\"res-header-id\"><b>Narrativa gerada: Procedure </b></p><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\">Última atualização: 2022-05-09 17:39:08+0000</p><p style=\"margin-bottom: 0px\">Perfil: <a href=\"StructureDefinition-BRProcedimentoRealizado-1.0.html\">Procedimento Realizado</a></p></div><p><b>Quantidade</b>: 8</p><p><b>identifier</b>: Código de Autorização/301010170</p><p><b>status</b>: Completed</p><p><b>code</b>: <span title=\"Códigos:{http://www.saude.gov.br/fhir/r4/CodeSystem/BRTabelaSUS 0206020040}\">TOMOGRAFIA DE HEMITORAX, PULMÃO OU DO MEDIASTINO</span></p><p><b>subject</b>: Identifier: <code>http://www.saude.gov.br/fhir/r4/StructureDefinition/BRIndividuo-1.0</code>/706004324048847</p><p><b>performed</b>: 2026-06-05 12:20:32-0300</p><h3>Performers</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Function</b></td><td><b>Actor</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Códigos:{http://www.saude.gov.br/fhir/r4/CodeSystem/BRCBO 225125}\">MEDICO CLINICO</span></td><td>Identifier: <code>http://www.saude.gov.br/fhir/r4/StructureDefinition/BREstabelecimentoSaude-1.0</code>/1113333</td></tr></table><p><b>note</b>: </p><blockquote><div><p>Texto livre</p>\n</div></blockquote></div>"
      },
      "extension" : [{
        "url" : "http://www.saude.gov.br/fhir/r4/StructureDefinition/BRQuantidade-1.0",
        "valuePositiveInt" : 8
      }],
      "identifier" : [{
        "type" : {
          "coding" : [{
            "system" : "http://www.saude.gov.br/fhir/r4/CodeSystem/BRTipoIdentificador",
            "code" : "AUTH"
          }]
        },
        "value" : "301010170"
      }],
      "status" : "completed",
      "code" : {
        "coding" : [{
          "system" : "http://www.saude.gov.br/fhir/r4/CodeSystem/BRTabelaSUS",
          "code" : "0206020040"
        }]
      },
      "subject" : {
        "identifier" : {
          "system" : "http://www.saude.gov.br/fhir/r4/StructureDefinition/BRIndividuo-1.0",
          "value" : "706004324048847"
        }
      },
      "performedDateTime" : "2026-06-05T12:20:32-03:00",
      "performer" : [{
        "function" : {
          "coding" : [{
            "system" : "http://www.saude.gov.br/fhir/r4/CodeSystem/BRCBO",
            "code" : "225125"
          }]
        },
        "actor" : {
          "identifier" : {
            "system" : "http://www.saude.gov.br/fhir/r4/StructureDefinition/BREstabelecimentoSaude-1.0",
            "value" : "1113333"
          }
        }
      }],
      "note" : [{
        "text" : "Texto livre"
      }]
    }
  },
  {
    "fullUrl" : "urn:uuid:efc37c9a-fdb2-4d11-ade4-b0c0d218f69c",
    "resource" : {
      "resourceType" : "Condition",
      "meta" : {
        "profile" : ["http://www.saude.gov.br/fhir/r4/StructureDefinition/BRRestricaoFuncionalIncapacidadeSaude"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Condition_null\"> </a><p class=\"res-header-id\"><b>Narrativa gerada: Condition </b></p><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Perfil: <code>http://www.saude.gov.br/fhir/r4/StructureDefinition/BRRestricaoFuncionalIncapacidadeSaude</code></p></div><p><b>clinicalStatus</b>: <span title=\"Códigos:{http://terminology.hl7.org/CodeSystem/condition-clinical active}\">Active</span></p><p><b>code</b>: <span title=\"Códigos:\">Texto livre</span></p><p><b>subject</b>: Identifier: <code>http://www.saude.gov.br/fhir/r4/StructureDefinition/BRIndividuo-1.0</code>/706004324048847</p></div>"
      },
      "clinicalStatus" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/condition-clinical",
          "code" : "active"
        }]
      },
      "code" : {
        "text" : "Texto livre"
      },
      "subject" : {
        "identifier" : {
          "system" : "http://www.saude.gov.br/fhir/r4/StructureDefinition/BRIndividuo-1.0",
          "value" : "706004324048847"
        }
      }
    }
  },
  {
    "fullUrl" : "urn:uuid:6fd5513d-96f2-4e52-be36-fbbc85cb91f4",
    "resource" : {
      "resourceType" : "AllergyIntolerance",
      "meta" : {
        "profile" : ["http://www.saude.gov.br/fhir/r4/StructureDefinition/BRAlergiaReacaoAdversa-1.0"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"AllergyIntolerance_null\"> </a><p class=\"res-header-id\"><b>Narrativa gerada: AllergyIntolerance </b></p><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Perfil: <a href=\"StructureDefinition-BRAlergiaReacaoAdversa-1.0.html\">Alergia ou Reação Adversa</a></p></div><p><b>verificationStatus</b>: <span title=\"Códigos:{http://terminology.hl7.org/CodeSystem/allergyintolerance-verification confirmed}\">Confirmed</span></p><p><b>category</b>: Medication</p><p><b>criticality</b>: High Risk</p><p><b>code</b>: <span title=\"Códigos:{http://www.saude.gov.br/fhir/r4/CodeSystem/BRMedicamento BR0267205U0063}\">DIPIRONA SÓDICA  500 MG/ML SOLUÇÃO ORAL 10 ML</span></p><p><b>patient</b>: Identifier: <code>http://www.saude.gov.br/fhir/r4/StructureDefinition/BRIndividuo-1.0</code>/706004324048847</p><p><b>onset</b>: 2025-09-17</p><p><b>note</b>: </p><blockquote><div><p>Alergia a dipirona sódica</p>\n</div></blockquote><h3>Reactions</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Manifestation</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Códigos:{http://www.saude.gov.br/fhir/r4/CodeSystem/BRMedDRA 10002198}\">Anafilaxia</span></td></tr></table></div>"
      },
      "verificationStatus" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/allergyintolerance-verification",
          "code" : "confirmed"
        }]
      },
      "category" : ["medication"],
      "criticality" : "high",
      "code" : {
        "coding" : [{
          "system" : "http://www.saude.gov.br/fhir/r4/CodeSystem/BRMedicamento",
          "code" : "BR0267205U0063"
        }]
      },
      "patient" : {
        "identifier" : {
          "system" : "http://www.saude.gov.br/fhir/r4/StructureDefinition/BRIndividuo-1.0",
          "value" : "706004324048847"
        }
      },
      "onsetDateTime" : "2025-09-17",
      "note" : [{
        "text" : "Alergia a dipirona sódica"
      }],
      "reaction" : [{
        "manifestation" : [{
          "coding" : [{
            "system" : "http://www.saude.gov.br/fhir/r4/CodeSystem/BRMedDRA",
            "code" : "10002198"
          }]
        }]
      }]
    }
  },
  {
    "fullUrl" : "urn:uuid:c8e3cf5f-96b7-43a9-919e-22e9947dc415",
    "resource" : {
      "resourceType" : "MedicationRequest",
      "meta" : {
        "profile" : ["http://www.saude.gov.br/fhir/r4/StructureDefinition/BRPrescricaoMedicamento"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MedicationRequest_null\"> </a><p class=\"res-header-id\"><b>Narrativa gerada: MedicationRequest </b></p><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Perfil: <a href=\"StructureDefinition-BRPrescricaoMedicamento.html\">Prescrição de Medicamento</a></p></div><p><b>status</b>: Completed</p><p><b>medication</b>: <a href=\"Bundle-example-SA.html#urn-uuid-5c1de72d-fdc9-448d-9032-505dc78de8ca\">Medication Água para injeção 1 L Sistema Fechado; frasco-ampola</a></p><p><b>subject</b>: Identifier: <code>http://www.saude.gov.br/fhir/r4/StructureDefinition/BRIndividuo-1.0</code>/706004324048847</p><p><b>note</b>: Por Dr. Getúlio @2022-03-04</p><blockquote><div><p>Medicamento necessário para tratamento da febre devido à gripe.</p>\n</div></blockquote><blockquote><p><b>dosageInstruction</b></p><p><b>text</b>: Texto livre</p><p><b>patientInstruction</b>: Tomar uma vez ao dia via oral.</p><p><b>timing</b>: Contagem 1  times, 12</p><p><b>asNeeded</b>: true</p><p><b>route</b>: <span title=\"Códigos:{http://www.saude.gov.br/fhir/r4/CodeSystem/BRViaAdministracao 10907}\">Oral</span></p><h3>DoseAndRates</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Type</b></td><td><b>Dose[x]</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Códigos:{http://www.saude.gov.br/fhir/r4/CodeSystem/BRUnidadeMedida 13}\">Cápsula</span></td><td>10</td></tr></table><p><b>maxDosePerAdministration</b>: 10</p></blockquote><h3>DispenseRequests</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>ValidityPeriod</b></td><td><b>Quantity</b></td></tr><tr><td style=\"display: none\">*</td><td>2022-02-24 --&gt; 2022-03-03</td><td>10</td></tr></table></div>"
      },
      "status" : "completed",
      "medicationReference" : {
        "reference" : "urn:uuid:5c1de72d-fdc9-448d-9032-505dc78de8ca"
      },
      "subject" : {
        "identifier" : {
          "system" : "http://www.saude.gov.br/fhir/r4/StructureDefinition/BRIndividuo-1.0",
          "value" : "706004324048847"
        }
      },
      "note" : [{
        "authorString" : "Dr. Getúlio",
        "time" : "2022-03-04",
        "text" : "Medicamento necessário para tratamento da febre devido à gripe."
      }],
      "dosageInstruction" : [{
        "text" : "Texto livre",
        "patientInstruction" : "Tomar uma vez ao dia via oral.",
        "timing" : {
          "repeat" : {
            "extension" : [{
              "url" : "http://www.saude.gov.br/fhir/r4/StructureDefinition/BRTurno",
              "valueCode" : "3"
            },
            {
              "extension" : [{
                "url" : "periodUnit",
                "valueCode" : "min"
              },
              {
                "url" : "period",
                "valuePositiveInt" : 1
              }],
              "url" : "http://www.saude.gov.br/fhir/r4/StructureDefinition/BRIntervaloDoses"
            }],
            "count" : 1,
            "countMax" : 1,
            "frequency" : 12
          }
        },
        "asNeededBoolean" : true,
        "route" : {
          "coding" : [{
            "system" : "http://www.saude.gov.br/fhir/r4/CodeSystem/BRViaAdministracao",
            "code" : "10907"
          }]
        },
        "doseAndRate" : [{
          "type" : {
            "coding" : [{
              "system" : "http://www.saude.gov.br/fhir/r4/CodeSystem/BRUnidadeMedida",
              "code" : "13"
            }]
          },
          "doseQuantity" : {
            "value" : 10
          }
        }],
        "maxDosePerAdministration" : {
          "value" : 10
        }
      }],
      "dispenseRequest" : {
        "validityPeriod" : {
          "start" : "2022-02-24",
          "end" : "2022-03-03"
        },
        "quantity" : {
          "value" : 10
        }
      }
    }
  },
  {
    "fullUrl" : "urn:uuid:5c1de72d-fdc9-448d-9032-505dc78de8ca",
    "resource" : {
      "resourceType" : "Medication",
      "meta" : {
        "profile" : ["http://www.saude.gov.br/fhir/r4/StructureDefinition/BRMedicamento"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Medication_null\"> </a><p class=\"res-header-id\"><b>Narrativa gerada: Medication </b></p><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Perfil: <a href=\"StructureDefinition-BRMedicamento.html\">Medicamento (StructureDefinition)</a></p></div><p><b>code</b>: <span title=\"Códigos:{http://www.saude.gov.br/fhir/r4/CodeSystem/BRObmCATMAT BR0352317}\">Água para injeção 1 L Sistema Fechado; frasco-ampola</span></p><p><b>form</b>: <span title=\"Códigos:{http://www.saude.gov.br/fhir/r4/CodeSystem/BRUnidadeMedida 2}\">Ampola</span></p></div>"
      },
      "code" : {
        "coding" : [{
          "system" : "http://www.saude.gov.br/fhir/r4/CodeSystem/BRObmCATMAT",
          "code" : "BR0352317"
        }]
      },
      "form" : {
        "coding" : [{
          "system" : "http://www.saude.gov.br/fhir/r4/CodeSystem/BRUnidadeMedida",
          "code" : "2"
        }]
      }
    }
  },
  {
    "fullUrl" : "urn:uuid:7f396bd9-998a-4784-bbcb-8554ba5b015c",
    "resource" : {
      "resourceType" : "ClinicalImpression",
      "meta" : {
        "profile" : ["http://www.saude.gov.br/fhir/r4/StructureDefinition/BRResumoEvolucaoClinica"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"ClinicalImpression_null\"> </a><p class=\"res-header-id\"><b>Narrativa gerada: ClinicalImpression </b></p><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Perfil: <a href=\"StructureDefinition-BRResumoEvolucaoClinica.html\">Resumo da Evolução Clínica</a></p></div><p><b>status</b>: Completed</p><p><b>subject</b>: Identifier: <code>http://www.saude.gov.br/fhir/r4/StructureDefinition/BRIndividuo-1.0</code>/706004324048847</p><p><b>summary</b>: Evoluiu com agravamento do desconforto respiratório, aumento da necessidade de oxigênio suplementar e transferência para unidade de terapia intensiva.</p></div>"
      },
      "status" : "completed",
      "subject" : {
        "identifier" : {
          "system" : "http://www.saude.gov.br/fhir/r4/StructureDefinition/BRIndividuo-1.0",
          "value" : "706004324048847"
        }
      },
      "summary" : "Evoluiu com agravamento do desconforto respiratório, aumento da necessidade de oxigênio suplementar e transferência para unidade de terapia intensiva."
    }
  },
  {
    "fullUrl" : "urn:uuid:98d60b66-07b6-4c6c-a31f-dc6d1f80e626",
    "resource" : {
      "resourceType" : "CarePlan",
      "meta" : {
        "profile" : ["http://www.saude.gov.br/fhir/r4/StructureDefinition/BRPlanoCuidados-1.0"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"CarePlan_null\"> </a><p class=\"res-header-id\"><b>Narrativa gerada: CarePlan </b></p><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Perfil: <a href=\"StructureDefinition-BRPlanoCuidados-1.0.html\">Plano de Cuidados</a></p></div><p><b>status</b>: Active</p><p><b>intent</b>: Plan</p><p><b>description</b>: Repouso pós-medicação intramuscular</p><p><b>subject</b>: Identifier: <code>http://www.saude.gov.br/fhir/r4/StructureDefinition/BRIndividuo-1.0</code>/706004324048847</p></div>"
      },
      "status" : "active",
      "intent" : "plan",
      "description" : "Repouso pós-medicação intramuscular",
      "subject" : {
        "identifier" : {
          "system" : "http://www.saude.gov.br/fhir/r4/StructureDefinition/BRIndividuo-1.0",
          "value" : "706004324048847"
        }
      }
    }
  },
  {
    "fullUrl" : "urn:uuid:038ad91c-ba1a-4560-8719-2428e998ea53",
    "resource" : {
      "resourceType" : "Observation",
      "meta" : {
        "profile" : ["http://www.saude.gov.br/fhir/r4/StructureDefinition/BRObservacaoDescritiva-1.0"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_null\"> </a><p class=\"res-header-id\"><b>Narrativa gerada: Observation </b></p><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Perfil: <a href=\"StructureDefinition-BRObservacaoDescritiva-1.0.html\">Observação Descritiva</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Códigos:{http://loinc.org 48767-8}\">Annotation comment [Interpretation] Narrative</span></p><p><b>subject</b>: Identifier: <code>http://www.saude.gov.br/fhir/r4/StructureDefinition/BRIndividuo-1.0</code>/706004324048847</p><p><b>issued</b>: 2026-06-05 12:20:32-0300</p><p><b>value</b>: Após 7 dias de tratamento recebeu alta com encaminhamento para Unidade Básica de Saúde sem queixas ou sintomas respiratórios, com saturação O2 = 92-93%.</p></div>"
      },
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "48767-8"
        }]
      },
      "subject" : {
        "identifier" : {
          "system" : "http://www.saude.gov.br/fhir/r4/StructureDefinition/BRIndividuo-1.0",
          "value" : "706004324048847"
        }
      },
      "issued" : "2026-06-05T12:20:32-03:00",
      "valueString" : "Após 7 dias de tratamento recebeu alta com encaminhamento para Unidade Básica de Saúde sem queixas ou sintomas respiratórios, com saturação O2 = 92-93%."
    }
  }]
}

```
