# Modalidade Assistencial (CodeSystem) - Guia de Implementação do Sumário de Alta (SA) da RNDS v1.0.0-release

## CodeSystem: Modalidade Assistencial (CodeSystem) 

 
Classifica os contatos assistenciais de acordo com as especificidades do modo, local e duração do atendimento 

This Code system is referenced in the definition of the following value sets:

* [Modalidade Assistencial (ValueSet)](ValueSet-BRModalidadeAssistencial-1.0.md)

-------

 [Description of the above table(s)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "BRModalidadeAssistencial",
  "meta" : {
    "lastUpdated" : "2020-03-11T18:15:59.439+00:00"
  },
  "language" : "pt-BR",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-wg",
    "valueCode" : "ehr"
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-fmm",
    "valueInteger" : 1,
    "_valueInteger" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "https://fhir.saude.gov.br/sa/ImplementationGuide/br.gov.saude.sa.fhir"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
    "valueCode" : "normative",
    "_valueCode" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "https://fhir.saude.gov.br/sa/ImplementationGuide/br.gov.saude.sa.fhir"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-normative-version",
    "valueCode" : "4.0.1"
  }],
  "url" : "http://www.saude.gov.br/fhir/r4/CodeSystem/BRModalidadeAssistencial",
  "version" : "1.0.0-release",
  "name" : "BRModalidadeAssistencial",
  "title" : "Modalidade Assistencial (CodeSystem)",
  "status" : "active",
  "experimental" : false,
  "date" : "2020-03-11T18:16:19.9468275+00:00",
  "publisher" : "Ministério da Saúde do Brasil",
  "contact" : [{
    "name" : "Ministério da Saúde do Brasil",
    "telecom" : [{
      "system" : "url",
      "value" : "http://www.saude.gov.br"
    },
    {
      "system" : "email",
      "value" : "cgiis.datasus@saude.gov.br"
    }]
  }],
  "description" : "Classifica os contatos assistenciais de acordo com as especificidades do modo, local e duração do atendimento",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "BR"
    }]
  }],
  "caseSensitive" : true,
  "content" : "complete",
  "concept" : [{
    "code" : "01",
    "display" : "Atenção Básica"
  },
  {
    "code" : "02",
    "display" : "Atenção Domiciliar"
  },
  {
    "code" : "03",
    "display" : "Atenção Intermediária"
  },
  {
    "code" : "04",
    "display" : "Atenção Hospitalar"
  },
  {
    "code" : "05",
    "display" : "Atenção Psicossocial"
  },
  {
    "code" : "06",
    "display" : "Atenção à Urgência/Emergência"
  },
  {
    "code" : "07",
    "display" : "Ambulatorial Especializada"
  },
  {
    "code" : "08",
    "display" : "Assistência Farmacêutica"
  },
  {
    "code" : "09",
    "display" : "Assistência Ambulatorial"
  }]
}

```
